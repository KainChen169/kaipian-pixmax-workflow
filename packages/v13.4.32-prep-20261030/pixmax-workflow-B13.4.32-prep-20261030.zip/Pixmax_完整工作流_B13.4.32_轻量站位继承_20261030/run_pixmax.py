"""Tested packaged overlay, using this computer's own account configuration."""
import os
from pathlib import Path
import subprocess
import sys

root=Path(__file__).resolve().parent
env=os.environ.copy()
env['PYTHONPATH']=os.pathsep.join([str(root/'skills/pixmax-codex-pipeline/runtime-overlay'),str(root/'vendor/pixmax-cli-runtime/vendor')])
env.setdefault('PIXMAX_CLI_HOME',str(Path.home()/'.pixmax-cli'))
env.setdefault('PYTHONIOENCODING','utf-8')
raise SystemExit(subprocess.call([sys.executable,'-X','utf8','-B','-m','pixmax',*sys.argv[1:]],env=env))
