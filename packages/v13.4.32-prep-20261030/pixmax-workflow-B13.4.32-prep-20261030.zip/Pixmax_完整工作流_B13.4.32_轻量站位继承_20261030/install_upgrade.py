"""Offline, checksum-verified per-file upgrade. Does not call Pixmax or delete files."""
from __future__ import annotations
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import sys
import uuid

ROOT = Path(__file__).resolve().parent

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def contained(root, relative):
    rel = PurePosixPath(relative)
    if not relative or rel.is_absolute() or '..' in rel.parts or '\\' in relative or ':' in relative:
        raise ValueError('Unsafe package path: ' + relative)
    dest = root.joinpath(*rel.parts)
    if not dest.resolve().is_relative_to(root.resolve()):
        raise ValueError('Path escapes selected directory: ' + str(dest))
    if any(p.is_symlink() for p in [root, dest, *dest.parents] if p != root.parent):
        raise ValueError('Symlink is not supported: ' + str(dest))
    return dest

def read_verified_package():
    manifest = json.loads((ROOT/'PACKAGE_MANIFEST.json').read_text(encoding='utf-8'))
    if manifest.get('schema') != 'pixmax_portable_upgrade_v1':
        raise ValueError('Unsupported manifest')
    for relative, expected in manifest['files'].items():
        p = contained(ROOT, relative)
        if not p.is_file() or sha(p) != expected:
            raise ValueError('Package missing/changed: ' + relative)
    return manifest

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--codex-home', type=Path, default=Path(os.environ.get('CODEX_HOME', Path.home()/'.codex')))
    parser.add_argument('--pixmax-home', type=Path, default=Path(os.environ.get('PIXMAX_CLI_HOME', Path.home()/'.pixmax-cli')))
    parser.add_argument('--skills-only', action='store_true')
    parser.add_argument('--skill', action='append', help='Install only this named Skill; repeat to select several. Combine with --skills-only to leave the CLI runtime untouched.')
    parser.add_argument('--dry-run', action='store_true')
    args = parser.parse_args()
    if sys.version_info < (3,10):
        parser.error('Python 3.10+ is required')
    manifest = read_verified_package()
    selected_skills = set(args.skill or manifest['skills'])
    if not selected_skills.issubset(set(manifest['skills'])):
        raise ValueError('Unknown selected Skill: '+', '.join(sorted(selected_skills-set(manifest['skills']))))
    skills_root = args.codex_home.resolve()/'skills'
    runtime_root = args.pixmax_home.resolve()/'runtime/versions'/manifest['runtime']['directory']
    changes=[]
    for relative, expected in manifest['files'].items():
        if relative.startswith('skills/'):
            if PurePosixPath(relative).parts[1] not in selected_skills:
                continue
            dest=contained(skills_root,relative[len('skills/'):]); category='skills'
        elif relative.startswith('vendor/pixmax-cli-runtime/') and not args.skills_only:
            dest=contained(runtime_root,relative[len('vendor/pixmax-cli-runtime/'):]); category='runtime'
        else:
            continue
        if dest.exists() and not dest.is_file():
            raise ValueError('Target is not a regular file: '+str(dest))
        before=sha(dest) if dest.is_file() else None
        if before != expected:
            changes.append({'source':relative,'target':str(dest),'category':category,'before_sha256':before,'after_sha256':expected})
    result={'package_id':manifest['package_id'],'dry_run':args.dry_run,'changed_files':len(changes),'skills':manifest['skills'],'selected_skills':sorted(selected_skills),'skills_root':str(skills_root),'runtime_root':str(runtime_root),'preserve_extra_files':True}
    if args.dry_run:
        result['changes']=changes
        print(json.dumps(result,ensure_ascii=False,indent=2));return
    if not changes:
        result['status']='ALREADY_CURRENT'
        print(json.dumps(result,ensure_ascii=False,indent=2));return
    backup_root=args.codex_home.resolve()/'workflow-upgrade-backups'/(datetime.datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:8])
    backup_root.mkdir(parents=True,exist_ok=False)
    journal={**result,'status':'PREPARED','backup_root':str(backup_root),'changes':changes}
    def save():
        temporary=backup_root/'installation.json.tmp'
        temporary.write_text(json.dumps(journal,ensure_ascii=False,indent=2),encoding='utf-8')
        os.replace(temporary,backup_root/'installation.json')
    # Backup every file that will be overwritten before any destination mutation.
    for n, row in enumerate(changes):
        if row['before_sha256']:
            p=backup_root/'files'/str(n)/Path(row['target']).name
            p.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(row['target'],p)
            if sha(p)!=row['before_sha256']:raise ValueError('Backup verification failed')
            row['backup']=str(p.relative_to(backup_root))
    save()
    try:
        for row in changes:
            dest=Path(row['target'])
            current=sha(dest) if dest.is_file() else None
            if current!=row['before_sha256']:raise ValueError('Target changed during installation: '+str(dest))
            dest.parent.mkdir(parents=True,exist_ok=True)
            temporary=dest.with_name(dest.name+'.upgrade-'+uuid.uuid4().hex+'.tmp')
            shutil.copy2(ROOT/row['source'],temporary)
            if sha(temporary)!=row['after_sha256']:raise ValueError('Copy verification failed')
            os.replace(temporary,dest)
            row['installed']=True;save()
        for row in changes:
            if sha(Path(row['target']))!=row['after_sha256']:raise ValueError('Installed file changed: '+row['target'])
        journal['status']='COMPLETE';save()
    except Exception as error:
        journal['status']='INCOMPLETE';journal['error']=str(error);save();raise
    result.update(status='COMPLETE',backup_record=str(backup_root/'installation.json'))
    print(json.dumps(result,ensure_ascii=False,indent=2))

if __name__=='__main__':
    try:main()
    except Exception as error:
        print('Upgrade stopped: '+str(error),file=sys.stderr);raise SystemExit(1)
