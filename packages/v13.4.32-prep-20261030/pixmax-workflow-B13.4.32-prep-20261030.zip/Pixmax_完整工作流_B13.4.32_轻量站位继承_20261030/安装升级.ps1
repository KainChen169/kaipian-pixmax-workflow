﻿param(
    [string]$PythonPath = '',
    [string]$CodexHome = '',
    [string]$PixmaxHome = '',
    [switch]$DryRun,
    [switch]$SkillsOnly
)
$ErrorActionPreference = 'Stop'
$TaskPython = $null
$TaskPythonArgs = @()
$BundledPython = Join-Path ([Environment]::GetFolderPath('UserProfile')) '.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
foreach ($Candidate in @($PythonPath, $env:PIXMAX_PYTHON, 'py', 'python', 'python3', $BundledPython)) {
    if (-not $Candidate -or -not (Get-Command $Candidate -ErrorAction SilentlyContinue)) { continue }
    $ProbeArgs = if ($Candidate -eq 'py') { @('-3') } else { @() }
    & $Candidate @ProbeArgs -c 'import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)' *> $null
    if ($LASTEXITCODE -eq 0) { $TaskPython = $Candidate; $TaskPythonArgs = $ProbeArgs; break }
}
if (-not $TaskPython) { throw 'Python 3.10+ was not found. Supply -PythonPath or install Python and run again.' }
$InstallArgs = @('-X','utf8','-B',(Join-Path $PSScriptRoot 'install_upgrade.py'))
if ($CodexHome) { $InstallArgs += @('--codex-home',$CodexHome) }
if ($PixmaxHome) { $InstallArgs += @('--pixmax-home',$PixmaxHome) }
if ($DryRun) { $InstallArgs += '--dry-run' }
if ($SkillsOnly) { $InstallArgs += '--skills-only' }
& $TaskPython @TaskPythonArgs @InstallArgs
if ($LASTEXITCODE -ne 0) { throw 'Upgrade did not complete. See the error and any backup installation record.' }
