"""Verify every file, the manifest paths and all packaged hashes."""
from pathlib import Path
import hashlib,json,sys
from install_upgrade import read_verified_package
root=Path(__file__).resolve().parent
manifest=read_verified_package()
excluded={'__pycache__','.git','backups','归档'}
actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and not excluded.intersection(p.relative_to(root).parts) and p.suffix!='.pyc' and p.name!='.DS_Store'}
expected=set(manifest['files'])|{'PACKAGE_MANIFEST.json'}
if actual!=expected:raise SystemExit('Unexpected or missing files: '+str(sorted(actual^expected)))
print(json.dumps({'status':'PASS','files':len(expected),'skills':manifest['skills'],'runtime':manifest['runtime']},ensure_ascii=False,indent=2))
