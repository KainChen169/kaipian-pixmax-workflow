import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
EXAMPLES = ROOT / 'assets' / 'examples'
sys.path.insert(0, str(ROOT / 'scripts'))
import validate_handoff as checker


class HandoffChecks(unittest.TestCase):
    def fixture(self, name='ex-a'):
        return ((EXAMPLES / (name + '.handoff.md')).read_text(encoding='utf-8'),
                json.loads((EXAMPLES / (name + '.source.json')).read_text(encoding='utf-8')))

    def rejects(self, text, message, source=None):
        errors, _ = checker.validate(text, source)
        self.assertTrue(any(message in e for e in errors), errors)

    def test_all_complete_examples_with_independent_source(self):
        catalog = json.loads((EXAMPLES / 'catalog.json').read_text(encoding='utf-8'))
        self.assertEqual(len(catalog['packets']), 7)
        self.assertEqual(len({r['scenario'] for r in catalog['packets']}), 6)
        self.assertEqual(len({r['genre'] for r in catalog['packets']}), 6)
        for row in catalog['packets']:
            with self.subTest(row=row['id']):
                text = (EXAMPLES / row['handoff']).read_text(encoding='utf-8')
                source = json.loads((EXAMPLES / row['source']).read_text(encoding='utf-8'))
                self.assertEqual(checker.validate(text, source), ([], []))
                self.assertEqual(checker.parse(text)[-1]['end'], row['duration_seconds'])
                self.assertEqual(checker.parse(text)[0]['scene_start'], row['scene_offset'])
                self.assertIn('DESIGN_REFERENCE', text)
                self.assertEqual(row['evidence_level'], 'DESIGN_REFERENCE')

    def test_exact_dialogue_change_is_detected(self):
        text, source = self.fixture()
        self.rejects(text.replace('先把事实说清楚。', '先把事实说清楚！'), 'DIALOGUE_SOURCE_MISMATCH', source)

    def test_wrong_speaker_is_detected(self):
        text, source = self.fixture()
        self.rejects(text.replace('周远（现场对白）', '林夕（现场对白）'), 'DIALOGUE_SOURCE_MISMATCH', source)

    def test_omitted_source_fact_is_detected(self):
        text, source = self.fixture()
        source['events'].append({'id': 'SC01-E099', 'source_ref': 'L99', 'text': '另一项必须动作。'})
        self.rejects(text, 'source events coverage mismatch', source)

    def test_unassigned_source_event_is_detected(self):
        text, _ = self.fixture()
        text += '\n源事件SC01-E099｜来源：L99｜事实：未被镜头覆盖的动作。\n'
        self.rejects(text, 'source event has no associated shot')

    def test_time_gap_is_detected(self):
        text, _ = self.fixture()
        self.rejects(text.replace('包内4–8秒｜场次4–8秒', '包内4.5–8秒｜场次4.5–8秒'), 'gap or overlap')

    def test_packet_offset_is_checked(self):
        text, _ = self.fixture('ex-t-pk02')
        self.rejects(text.replace('场次起点｜12秒', '场次起点｜0秒'), 'time conversion mismatch')

    def test_duplicate_shot_is_detected(self):
        text, _ = self.fixture()
        self.rejects(text.replace('### SC01-SH002', '### SC01-SH001'), 'duplicate shot IDs')

    def test_duplicate_dialogue_is_detected(self):
        text, source = self.fixture()
        line = next(s for s in text.splitlines() if s.startswith('**节拍与表演：**') and '：“' in s)
        self.rejects(text.replace(line, line + "\n" + line.split("**节拍与表演：**",1)[1]), 'DIALOGUE_SOURCE_MISMATCH', source)

    def test_crosscut_voice_must_continue(self):
        text, source = self.fixture('ex-s')
        rows = checker.parse(text)
        body = rows[-1]['body']
        cut = re.sub(r'\[0–0.5秒，镜内\].*?”', '', body, count=1)
        self.assertNotEqual(body, cut)
        self.rejects(text.replace(body, cut), 'DIALOGUE_SOURCE_MISMATCH', source)

    def test_locked_voice_window_change_is_detected(self):
        text, source = self.fixture('ex-s')
        self.rejects(text.replace('[0–0.5秒，镜内]', '[0–0.8秒，镜内]'), 'DIALOGUE_TIME', source)

    def test_alias_cannot_replace_actual_words(self):
        text, source = self.fixture('ex-s')
        self.rejects(text + '\n对白D01继续。', 'dialogue aliases', source)

    def test_ready_cannot_hide_open_decision(self):
        text, _ = self.fixture()
        self.rejects(text.replace('**OPEN：** 无', '**OPEN：** 等待确认出口', 1), 'READY conflicts')

    def test_needs_decision_preserves_unresolved_scope(self):
        text, _ = self.fixture()
        text = text.replace('状态｜READY', '状态｜NEEDS_DECISION').replace('**OPEN：** 无', '**OPEN：** 等待确认出口', 1)
        errors, reviews = checker.validate(text)
        self.assertEqual(errors, [])
        self.assertEqual(len(reviews), 1)
        self.assertIn('SC01-SH001', reviews[0])

    def test_unresolved_external_source_reference_is_detected(self):
        text, _ = self.fixture()
        self.rejects(text.replace('**关联：**', '**关联：** SC01-E999、', 1), 'unresolved source ID')

    def test_malformed_header_is_not_silently_skipped(self):
        text, _ = self.fixture()
        self.rejects(text.replace('包内4–8秒', '包内四至八秒'), 'malformed shot header')

    def test_missing_performance_is_detected(self):
        text, _ = self.fixture()
        text = re.sub(r'^\*\*节拍与表演：\*\*[^\n]*\n', '', text, count=1, flags=re.M)
        self.rejects(text, 'missing 节拍与表演')

    def test_source_schema_errors_are_reported(self):
        text, _ = self.fixture()
        self.rejects(text, 'source must be an object', [])
        self.rejects(text, 'invalid source events schema', {'events': 'wrong', 'dialogues': []})

    def test_crosspacket_interface_and_ids(self):
        catalog = json.loads((EXAMPLES / 'catalog.json').read_text(encoding='utf-8'))
        packets = [r for r in catalog['packets'] if r['scenario'] == 'EX-T']
        a, b = packets
        self.assertEqual(a['exit_state'], b['entry_state'])
        self.assertEqual(a['scene_offset'] + a['duration_seconds'], b['scene_offset'])
        shot_ids = []
        for row in packets:
            text = (EXAMPLES / row['handoff']).read_text(encoding='utf-8')
            shot_ids.extend(s['id'] for s in checker.parse(text))
            self.assertIn('入口快照', text)
            self.assertIn('出口快照', text)
        self.assertEqual(len(shot_ids), len(set(shot_ids)))

    def test_case_inventory_and_catalogue_references(self):
        case_ids = []
        for path in (ROOT / 'references' / 'cases').glob('*.md'):
            text = path.read_text(encoding='utf-8')
            ids = re.findall(r'^## ([AHRSFT]\d{2})｜', text, re.M)
            self.assertEqual(len(ids), 8, str(path))
            self.assertIn('DESIGN_REFERENCE', text)
            for name in ('前提：', '选案：', '分镜组织：', '误用与修正：', '验收：'):
                self.assertEqual(text.count(name), 8, (str(path), name))
            case_ids.extend(ids)
        self.assertEqual(len(case_ids), 48)
        self.assertEqual(len(set(case_ids)), 48)
        catalog = json.loads((EXAMPLES / 'catalog.json').read_text(encoding='utf-8'))
        for row in catalog['packets']:
            self.assertTrue(set(row['case_ids']).issubset(case_ids))

    def test_relative_markdown_links_resolve(self):
        for path in ROOT.rglob('*.md'):
            for link in re.findall(r'\[[^\]]+\]\(([^)]+)\)', path.read_text(encoding='utf-8')):
                if '://' in link or link.startswith('#'):
                    continue
                self.assertTrue((path.parent / link.split('#')[0]).exists(), (str(path), link))

    def test_cli_result_and_no_source_limitation(self):
        env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
        command = [sys.executable, '-X', 'utf8', '-B', str(ROOT / 'scripts' / 'validate_handoff.py')]
        good = subprocess.run(command + [str(EXAMPLES / 'ex-s.handoff.md')], capture_output=True, text=True, encoding='utf-8', env=env)
        self.assertEqual(good.returncode, 0, good.stdout + good.stderr)
        self.assertIn('no independent source table', good.stdout)
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / 'invalid.md'
            path.write_text('not a packet', encoding='utf-8')
            bad = subprocess.run(command + [str(path)], capture_output=True, text=True, encoding='utf-8', env=env)
            self.assertNotEqual(bad.returncode, 0)
            self.assertIn('ERROR:', bad.stdout)


if __name__ == '__main__':
    unittest.main()
