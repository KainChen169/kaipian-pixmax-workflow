#!/usr/bin/env python3
"""Check the optional SD25 handoff text format, not film quality or geometry."""
from __future__ import annotations
import argparse
import json
import math
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from inline_dialogue import parse_inline, compare_source, count_units

NUMBER = r'\d+(?:\.\d+)?'
META = re.compile(rf'^包ID｜(PK\d+)｜场次｜(SC\d+)｜场次起点｜({NUMBER})秒｜包时长｜({NUMBER})秒｜画幅｜(9:16|16:9)\s*$', re.M)
SHOT = re.compile(rf'^### (SC\d+-SH\d+[a-z]?)｜包内({NUMBER})[–-]({NUMBER})秒｜场次({NUMBER})[–-]({NUMBER})秒｜主任务：([^\n]+)$', re.M)
EVENT = re.compile(r'^源事件(SC\d+-E\d+)｜来源：([^｜\n]+)｜事实：([^\n]+)$', re.M)
DIALOGUE = re.compile(rf'^对白(SC\d+-D\d+)｜\[({NUMBER})[–-]({NUMBER})\]｜说话者：([^｜\n]+)｜听者：([^｜\n]+)｜来源：([^｜\n]+)｜原文：“([^\n]*)”\s*$', re.M)
FIELDS = ('关联', '起幅', '过程', '落幅', '节拍与表演', '对白执行', '声光', '连续性出口', 'LOCK', 'FLEX', 'OPEN')

def field(body, name):
    found = re.search(rf'^\*\*{re.escape(name)}：\*\*\s*(.*?)(?=\n\*\*[^*]+：\*\*|\n## |\Z)', body, re.M | re.S)
    return found.group(1).strip() if found else ''

def parse(text):
    matches = list(SHOT.finditer(text))
    rows = []
    for i, m in enumerate(matches):
        sid, start, end, scene_start, scene_end, intent = m.groups()
        body = text[m.end():matches[i+1].start() if i+1 < len(matches) else len(text)]
        body = re.split(r'\n## ', body, maxsplit=1)[0]
        rows.append({'id': sid, 'start': float(start), 'end': float(end), 'scene_start': float(scene_start), 'scene_end': float(scene_end), 'intent': intent, 'body': body})
    return rows

def validate_legacy(text, source=None):
    errors, reviews = [], []
    if '协议｜SD25-SHOT-HANDOFF/1.0' not in text:
        errors.append('unsupported or missing handoff protocol')
    status = re.search(r'状态｜(READY|NEEDS_DECISION)\b', text)
    if not status:
        errors.append('missing READY/NEEDS_DECISION status')
    meta = META.search(text)
    if not meta:
        return errors + ['unsupported or missing packet metadata; use the optional handoff-validation format'], reviews
    _, scene, offset, duration, _ = meta.groups()
    offset, duration = float(offset), float(duration)
    if not math.isfinite(offset) or not math.isfinite(duration) or duration <= 0:
        errors.append('packet duration must be positive')
    shots = parse(text)
    if not shots:
        errors.append('no parsable shots')
    if len(re.findall(r'^### SC\d+-SH[^\n]*', text, re.M)) != len(shots):
        errors.append('malformed shot header must not be skipped')
    ids = [s['id'] for s in shots]
    if len(set(ids)) != len(ids):
        errors.append('duplicate shot IDs')
    if shots and (abs(shots[0]['start']) > 0.01 or abs(shots[-1]['end']-duration) > 0.01):
        errors.append('shot timeline must cover zero through packet duration')
    for a, b in zip(shots, shots[1:]):
        if abs(a['end']-b['start']) > 0.01:
            errors.append('shot timeline gap or overlap')
    events, dialogue = {}, {}
    for m in EVENT.finditer(text):
        eid, source_ref, words = m.groups()
        if eid in events:
            errors.append(f'duplicate source event {eid}')
        events[eid] = {'id': eid, 'source_ref': source_ref, 'text': words}
    for m in DIALOGUE.finditer(text):
        did, start, end, speaker, listener, source_ref, words = m.groups()
        if did in dialogue:
            errors.append(f'duplicate dialogue {did}')
        dialogue[did] = {'id': did, 'source_ref': source_ref, 'speaker': speaker, 'listener': listener, 'text': words,
                         'start': float(start), 'end': float(end)}
    if len(re.findall(r'^源事件SC[^\n]*', text, re.M)) != len(list(EVENT.finditer(text))):
        errors.append('malformed source event row')
    if len(re.findall(r'^对白SC[^\n]*', text, re.M)) != len(list(DIALOGUE.finditer(text))):
        errors.append('malformed dialogue row')
    if not events:
        errors.append('source event mapping is required')
    for ident in list(events) + list(dialogue) + ids:
        if not ident.startswith(scene + '-'):
            errors.append(f'{ident}: ID belongs to a different scene')
    used_events = set()
    for shot in shots:
        sid, body = shot['id'], shot['body']
        if any(not math.isfinite(shot[k]) for k in ('start', 'end', 'scene_start', 'scene_end')):
            errors.append(f'{sid}: nonfinite shot time')
        if shot['end'] <= shot['start']:
            errors.append(f'{sid}: nonpositive duration')
        if abs(shot['scene_start']-offset-shot['start']) > 0.01 or abs(shot['scene_end']-offset-shot['end']) > 0.01:
            errors.append(f'{sid}: scene/packet time conversion mismatch')
        for name in FIELDS:
            if not field(body, name):
                errors.append(f'{sid}: missing {name}')
        linked = set(re.findall(r'SC\d+-[ED]\d+', field(body, '关联')))
        if not linked:
            errors.append(f'{sid}: missing source association')
        used_events.update(linked.intersection(events))
        for ref in set(re.findall(r'SC\d+-[ED]\d+', body)):
            if ref not in events and ref not in dialogue:
                errors.append(f'{sid}: unresolved source ID {ref}')
        unresolved = field(body, 'OPEN')
        if unresolved and unresolved not in {'无', '无。', 'none', 'NONE'}:
            reviews.append(f'{sid}: unresolved OPEN: {unresolved}')
            if status and status.group(1) == 'READY':
                errors.append(f'{sid}: READY conflicts with unresolved OPEN')
    for eid in events.keys() - used_events:
        errors.append(f'{eid}: source event has no associated shot')
    for did, row in dialogue.items():
        if not 0 <= row['start'] < row['end'] <= duration:
            errors.append(f'{did}: invalid dialogue window')
        for shot in shots:
            voice_refs = set(re.findall(r'SC\d+-D\d+', field(shot['body'], '对白执行')))
            if shot['start'] < row['end'] and shot['end'] > row['start'] and did not in voice_refs:
                errors.append(f'{did}: missing continuous voice coverage in {shot["id"]}')
    if source is not None:
        if not isinstance(source, dict):
            return errors + ['source must be an object with events and dialogues lists'], reviews
        for key, actual, fields in [('events', events, ('id', 'source_ref', 'text')), ('dialogues', dialogue, ('id', 'source_ref', 'speaker', 'listener', 'text'))]:
            expected = source.get(key)
            if not isinstance(expected, list) or any(not isinstance(r, dict) or any(not isinstance(r.get(f), str) for f in fields) for r in expected):
                errors.append(f'invalid source {key} schema')
                continue
            expected_map = {r['id']: r for r in expected}
            if len(expected_map) != len(expected):
                errors.append(f'duplicate source {key} IDs')
            if set(actual) != set(expected_map):
                errors.append(f'source {key} coverage mismatch')
            for ident in set(actual).intersection(expected_map):
                if any(actual[ident][f] != expected_map[ident][f] for f in fields):
                    errors.append(f'{ident}: exact source {key} mismatch')
                if key == 'dialogues':
                    for time_key in ('start', 'end'):
                        if time_key in expected_map[ident] and actual[ident][time_key] != expected_map[ident][time_key]:
                            errors.append(f'{ident}: locked source dialogue {time_key} mismatch')
    return errors, reviews


def validate(text, source=None):
    if '协议｜SD25-SHOT-HANDOFF/2.0' not in text:
        return validate_legacy(text,source)
    errors=[]
    if re.search(r'(?<![A-Za-z0-9_])(?:SC\d+-)?D\d+(?![A-Za-z0-9_])',text):
        errors.append('dialogue aliases are not allowed in v2 output')
    if '**对白执行：**' in text or re.search(r'^对白SC',text,re.M):
        errors.append('dialogue must be inline in 节拍与表演, not a separate table or field')
    shots=parse(text);rows=[];synthetic=[];adapted=text.replace('SD25-SHOT-HANDOFF/2.0','SD25-SHOT-HANDOFF/1.0')
    meta=META.search(text)
    if not meta:
        return errors+['unsupported or missing packet metadata'],[]
    scene=meta[2]; duration=float(meta[4]);index=0
    intro=text.split('## D.',1)[-1].split('### ',1)[0]
    overview=re.search(r'\*\*整段剧情概述：\*\*\s*(.*)',intro,re.S)
    if not overview:
        errors.append('missing 整段剧情概述 before shots')
    elif count_units(overview[1])/max(count_units(text),1)>0.10:
        errors.append('overview exceeds 10% of document')
    if abs(duration-30)<0.06 and len(shots)>13:
        errors.append('30-second packet exceeds 13 shots')
    for shot in shots:
        for label in FIELDS:
            if shot['body'].count('**'+label+'：**')>1:
                errors.append(f'{shot["id"]}: duplicate field {label}')
        parsed,issues=parse_inline(field(shot['body'],'节拍与表演'),shot['start'],shot['end'])
        errors.extend(f'{shot["id"]}: {code}: {message}' for code,message in issues)
        rows.extend(parsed); refs=[]
        for row in parsed:
            index+=1;ident=f'{scene}-D{9000+index}'
            refs.append(ident)
            synthetic.append(dict(id=ident,source_ref='inline',speaker=row['speaker'],listener='当前听者',text=row['text'],start=row['start'],end=row['end']))
        # Reuse the mature event/offset/LOCK validation, with synthetic dialogue
        # metadata kept exclusively in memory. Source dialogue is checked
        # independently below, never against these reconstructed records.
        insertion='**对白执行：** '+('、'.join(refs) if refs else '无对白')+'\n'
        adapted=adapted.replace(shot['body'],shot['body']+'\n'+insertion,1)
    for row in synthetic:
        adapted+=f'\n对白{row["id"]}｜[{row["start"]}–{row["end"]}]｜说话者：{row["speaker"]}｜听者：当前听者｜来源：inline｜原文：“{row["text"]}”\n'
    legacy_source=None
    if source is not None:
        if not isinstance(source,dict):
            errors.append('source must be an object with events and dialogues lists')
        else:
            errors.extend(code+': '+message for code,message in compare_source(rows,source.get('dialogues')))
            legacy_source={'events':source.get('events'),'dialogues':synthetic}
    inherited,reviews=validate_legacy(adapted,legacy_source)
    return errors+inherited,reviews


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('packet', type=Path)
    p.add_argument('--source', type=Path)
    a = p.parse_args()
    try:
        text = a.packet.read_text(encoding='utf-8-sig')
        source = json.loads(a.source.read_text(encoding='utf-8-sig')) if a.source else None
        errors, reviews = validate(text, source)
    except (OSError, ValueError, TypeError, KeyError) as exc:
        print('ERROR:', exc)
        return 2
    for item in errors:
        print('ERROR:', item)
    for item in reviews:
        print('REVIEW:', item)
    print(f'HANDOFF CHECK: {len(errors)} errors, {len(reviews)} open decisions; geometry, acting and generated output not verified')
    if not a.source:
        print('NOTE: no independent source table; exact source fidelity not checked')
    return 1 if errors else 0

if __name__ == '__main__':
    sys.exit(main())
