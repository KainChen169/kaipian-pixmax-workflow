#!/usr/bin/env python3
"""Validate Seedance 2.5 Director Compiler v13 prompts (legacy input supported).

The checks are intentionally conservative. They catch structural, timing,
prop, hand, persistence, visibility, language, and coverage risks while the
semantic review in references/quality_gates.md remains authoritative.
"""

from __future__ import annotations

import argparse
import json
import math
import re
import sys
from dataclasses import dataclass
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from inline_dialogue import parse_inline, compare_source, count_units


REQUIRED_HEADINGS = [
    "人物指定",
    "道具指定",
    "场景指定",
    "开场整体站位",
    "开场当前空间状态",
    "人物与道具状态时间轴",
    "时间线镜头设计",
    "Camera设计",
    "表演设计",
    "音频设计",
    "正向约束",
]

HEADING_RE = re.compile(r"^##\s*(\d+)\.\s*(.+?)\s*$", re.MULTILINE)
SHOT_RE = re.compile(
    r"^###\s*镜头\s*(\d+)\s*[｜|]\s*"
    r"(\d+(?:\.\d+)?)\s*[–—-]\s*(\d+(?:\.\d+)?)\s*秒\s*[｜|]\s*"
    r"([^｜|\n]+?)(?:\s*[｜|]\s*([^\n]+?))?\s*$",
    re.MULTILINE,
)
INTERVAL_RE = re.compile(r"\[(-?\d+(?:\.\d+)?)\s*[–—-]\s*(-?\d+(?:\.\d+)?)\]")
QUOTED_RE = re.compile(r"[“\"'].*?[”\"']")

NEGATIVE_TERMS = ("不要", "禁止", "不得", "避免", "不能", "不可", "切勿")
PROJECT_RISK_TERMS = (
    "脸色苍白", "面部发红", "眼眶通红", "嘴唇失去血色",
    "眉头紧锁", "眉心剧烈收紧", "额头明显褶皱", "五官挤压",
    "电影感拉满", "氛围感拉满", "情绪丰富",
)
CROSS_PROMPT_TERMS = ("与上一场一致", "与上场一致", "参考上一段", "参考上文", "后续保持", "同上一场")
AMBIGUOUS_TRANSITIONS = ("稳定落下", "自动戴上", "突然变成", "凭空出现", "凭空消失")
PROP_TOKENS = (
    "戒指", "项链", "衬衫", "外套", "手机", "信件", "照片", "药车", "门把手",
    "水龙头", "镜子", "全身镜", "被单", "被子", "人鱼之心", "蓝宝石",
)
DIALOGUE_MARKERS = ("台词：", "说：", "问：", "回答：", "口型")
RELATIONSHIP_TOKENS = ("双人", "关系镜头", "过肩", "OTS", "ots")
REACTION_TRIGGER = ("听到", "听见", "说到", "触发", "话音", "看见")
REACTION_FACE = ("目光", "眼神", "眼睫", "呼吸", "泪", "嘴唇", "吞咽")
REACTION_BODY = ("手", "肩", "重心", "身体", "上身", "靠", "抓", "松开", "停住")
SCALE_TOKENS = ("极近特写", "大特写", "特写", "近景", "中近景", "中景", "全景", "大全景")
ANGLE_TOKENS = ("俯拍", "仰拍", "低机位", "高机位", "平视", "侧面", "正面", "斜侧")
MOVEMENT_TOKENS = ("推近", "缓推", "拉远", "横移", "跟拍", "环绕", "摇摄", "固定", "焦点")
NO_COMPOSITION_MODE_MARKERS = ("输出模式｜无独立构图栏模式", "输出模式：无独立构图栏模式", "OUTPUT_MODE|NO_COMPOSITION")
COMPOSITION_MODE_MARKERS = ("输出模式｜构图模式", "输出模式：构图模式", "OUTPUT_MODE|COMPOSITION")
BODY_DIRECTION_TERMS = ("身体朝向", "胸口朝向", "骨盆朝向", "上半身朝向", "身体斜朝", "胸口斜朝", "身体面向")
FACE_DIRECTION_TERMS = ("面部方向", "面部朝向", "脸朝向", "头部朝向", "侧脸朝向")
GAZE_DIRECTION_TERMS = ("视线目标", "视线看向", "视线落向", "目光看向", "目光落向", "注视", "望向")
TURN_ACTION_TERMS = ("转头", "回头", "侧过脸", "抬眼", "垂眼", "转身", "旋身", "肩线转向", "胸口转向", "骨盆转向", "视线移向", "目光移向", "重新看向")
NON_CHARACTER_SHOT_TERMS = ("空镜", "环境镜头", "风景镜头", "无人镜头", "纯道具", "手机特写", "物件特写")
CAMERA_REPROJECTION_TERMS = ("摄影机绕至", "Camera绕至", "摄影机移至", "摄影机穿越轴线", "越过轴线", "重新建立方向", "画面投影重新计算")


@dataclass
class Finding:
    level: str
    code: str
    message: str
    line: int | None = None

    def render(self) -> str:
        where = f" line {self.line}" if self.line else ""
        return f"[{self.level}] {self.code}{where}: {self.message}"


@dataclass
class Shot:
    number: int
    start: float
    end: float
    title: str
    movement: str
    body: str
    line: int

    @property
    def combined(self) -> str:
        return f"{self.title} {self.movement} {self.body}"



COMPACT_HEADINGS = [
    "生成规格与素材映射", "人物、道具与持续状态", "场景、光源与动态站位",
    "时间线镜头设计", "声音与对白安排", "连续性与输出要求",
]
ASSET_HEADINGS = [
    "人物指定", "场景指定", "道具指定", "时间线镜头设计", "声音安排", "输出要求",
]
ASSET_ENTRY_RE = re.compile(r"^\s*\*\*([^*\n]+?)[：:]\*\*\s*(.*?)\s*$", re.MULTILINE)
DIALOGUE_RE = re.compile(
    r"^对白([A-Za-z0-9_-]+)\s*｜\s*\[([0-9.]+)\s*[–—-]\s*([0-9.]+)\]"
    r"\s*｜\s*说话者：([^｜\n]+)\s*｜\s*听者：([^｜\n]+)"
    r"\s*｜\s*原文：“(.*)”\s*$", re.MULTILINE
)


def line_number(text, offset):
    return text.count("\n", 0, offset) + 1


def has_any(text, terms):
    return any(term in text for term in terms)


def strip_quoted(text):
    return QUOTED_RE.sub("", text)


def section(text, number):
    found = list(HEADING_RE.finditer(text))
    for index, match in enumerate(found):
        if int(match.group(1)) == number:
            end = found[index + 1].start() if index + 1 < len(found) else len(text)
            return text[match.end():end]
    return ""


def asset_template(text):
    headings = list(HEADING_RE.finditer(text))
    return bool(headings and headings[0].group(2).strip() == "人物指定"
                and (len(headings) <= 6 or any(
                    int(m.group(1)) == 2 and m.group(2).strip() == "场景指定"
                    for m in headings)))


def compact_template(text):
    prefix = text.split("\n## ", 1)[0]
    return asset_template(text) or "模板｜精简六段" in prefix or bool(re.search(r"^##\s*1\.\s*生成规格与素材映射\s*$", text, re.MULTILINE))


def role_section(text, role):
    if asset_template(text):
        if role == "state":
            return "\n".join(section(text, n) for n in (1, 3, 2))
        return section(text, {"people": 1, "props": 3, "space": 2, "shots": 4, "audio": 5}[role])
    mapping = (
        {"people": 2, "props": 2, "space": 3, "state": 3, "shots": 4, "audio": 5}
        if compact_template(text) else
        {"people": 1, "props": 2, "space": 5, "state": 6, "shots": 7, "audio": 10}
    )
    return section(text, mapping[role])


def v10_document(text):
    return compact_template(text) or "版本｜v10" in text.split("\n## ", 1)[0]


def output_mode(text):
    prefix = text.split("\n## ", 1)[0]
    if has_any(prefix, NO_COMPOSITION_MODE_MARKERS) or "无独立构图栏模式" in prefix:
        return "no_composition"
    if has_any(prefix, COMPOSITION_MODE_MARKERS) or "构图模式" in prefix or asset_template(text):
        return "composition"
    return "legacy"


def labeled_field(body, label):
    match = re.search(rf"\*\*{re.escape(label)}：\*\*(.*?)(?=\n\s*\*\*[^*]+：\*\*|\Z)", body, re.S)
    return match.group(1).strip() if match else ""


def infer_duration(text):
    match = re.search(r"(?:总时长|时长)\s*[：:｜|]?\s*(-?\d+(?:\.\d+)?)\s*秒", text.split("\n## ", 1)[0])
    return float(match.group(1)) if match else None


def parse_shots(text):
    timeline = role_section(text, "shots")
    base = text.find(timeline) if timeline else 0
    matches = list(SHOT_RE.finditer(timeline))
    return [
        Shot(int(m.group(1)), float(m.group(2)), float(m.group(3)),
             m.group(4).strip(), (m.group(5) or "未声明").strip(),
             timeline[m.end():matches[i + 1].start() if i + 1 < len(matches) else len(timeline)].strip(),
             line_number(text, base + m.start()))
        for i, m in enumerate(matches)
    ]


def validate_headings(text):
    found = [(int(m.group(1)), m.group(2).strip()) for m in HEADING_RE.finditer(text)]
    expected = list(ASSET_HEADINGS if asset_template(text) else COMPACT_HEADINGS if compact_template(text) else REQUIRED_HEADINGS)
    if v11_document(text) and not asset_template(text):
        if compact_template(text):
            expected[4:] = ["声音安排", "输出要求"]
        else:
            expected[-1] = "输出要求"
    findings = []
    if [name for _, name in found] != expected:
        findings.append(Finding("ERROR", "STRUCTURE", "模块缺失、命名或顺序错误；要求：" + " → ".join(expected)))
    if [number for number, _ in found] != list(range(1, len(found) + 1)):
        findings.append(Finding("ERROR", "HEADING_NUMBER", "模块编号必须连续从1开始"))
    if "模板｜兼容十一段" in text.split("\n## ", 1)[0] and compact_template(text):
        findings.append(Finding("ERROR", "TEMPLATE_CONFLICT", "头部模板与实际模块冲突"))
    return findings


def validate_shots(shots, target, mode="legacy"):
    if not shots:
        return [Finding("ERROR", "NO_SHOTS", "没有可解析的镜头标题")]
    findings = []
    for expected, shot in enumerate(shots, 1):
        if shot.number != expected:
            findings.append(Finding("ERROR", "SHOT_NUMBER", f"镜头编号应为{expected}", shot.line))
        if shot.end <= shot.start:
            findings.append(Finding("ERROR", "TIME_RANGE", "镜头区间必须为正长度", shot.line))
        composition = "**构图：**" in shot.body
        if mode == "no_composition" and composition:
            findings.append(Finding("ERROR", "UNEXPECTED_COMPOSITION", "合并模式不能另列构图字段", shot.line))
        if mode != "no_composition" and not composition:
            findings.append(Finding("ERROR", "COMPOSITION", "缺少构图字段", shot.line))
        if "**画面内容：**" not in shot.body:
            findings.append(Finding("ERROR", "VISUAL_CONTENT", "缺少画面内容字段", shot.line))
    if abs(shots[0].start) > 0.06:
        findings.append(Finding("ERROR", "TIMELINE_START", "时间线须从零开始"))
    for previous, current in zip(shots, shots[1:]):
        delta = current.start - previous.end
        if abs(delta) > 0.06:
            findings.append(Finding("ERROR", "TIMELINE_GAP" if delta > 0 else "TIMELINE_OVERLAP", f"镜间时间差{delta:.2f}秒", current.line))
    if target is not None and abs(shots[-1].end - target) > 0.06:
        findings.append(Finding("ERROR", "TOTAL_DURATION", "镜头结束与总时长不一致"))
    return findings


def validate_state_timeline(text, target):
    state = role_section(text, "state")
    if asset_template(text):
        findings = [Finding("REVIEW", "STATE_IN_DESIGNATIONS", "在人物、场景、道具名称后核对自然语言初态、变化、末态及接触连续性；不强制另列状态表")]
        # Natural descriptions need no interval ledger. When a local change
        # is explicitly timed, check its range without forcing it to cover
        # the entire package as a second state table would.
        for bracket in re.findall(r"\[[^\]]*\]", state):
            if not re.search(r"[–—-]|秒", bracket):
                continue
            match = re.fullmatch(r"\[\s*(-?\d+(?:\.\d+)?)\s*[–—-]\s*(-?\d+(?:\.\d+)?)\s*秒?\s*\]", bracket)
            if not match:
                findings.append(Finding("ERROR", "STATE_FORMAT", "指定项含不可解析的显式状态区间"))
                continue
            start, end = map(float, match.groups())
            if start < 0 or end <= start:
                findings.append(Finding("ERROR", "STATE_RANGE", "指定项的显式状态区间须为非负、正长度"))
            if target is not None and end > target + 0.06:
                findings.append(Finding("ERROR", "STATE_END", "指定项的显式状态区间超出总时长"))
        return findings
    candidate_rows = [line for line in state.splitlines() if "｜" in line and "[" in line]
    rows = [line for line in candidate_rows if INTERVAL_RE.search(line)]
    if not rows:
        return [Finding("ERROR", "NO_STATE_LEDGER", "状态区域须包含基准／变化区间，无变化时用[0–总时长]")]
    findings = []
    for row in candidate_rows:
        if len(re.findall(r"\[[^\]]*\]", row)) != len(INTERVAL_RE.findall(row)):
            findings.append(Finding("ERROR", "STATE_FORMAT", "状态行含不可解析区间"))
    for row in rows:
        name = row.split("｜", 1)[0].strip()
        ranges = [(float(a), float(b)) for a, b in INTERVAL_RE.findall(row)]
        if any(b <= a for a, b in ranges):
            findings.append(Finding("ERROR", "STATE_RANGE", f"{name}存在零长或倒置区间"))
        if ranges != sorted(ranges):
            findings.append(Finding("ERROR", "STATE_ORDER", f"{name}区间未按时间排列"))
        ordered = sorted(ranges)
        if abs(ordered[0][0]) > 0.06:
            findings.append(Finding("ERROR", "STATE_START", f"{name}未从零开始"))
        for previous, current in zip(ordered, ordered[1:]):
            delta = current[0] - previous[1]
            if abs(delta) > 0.06:
                findings.append(Finding("ERROR", "STATE_GAP" if delta > 0 else "STATE_OVERLAP", f"{name}区间差{delta:.2f}秒；不同状态维度应分行命名"))
        if target is not None and abs(ordered[-1][1] - target) > 0.06:
            findings.append(Finding("ERROR", "STATE_END", f"{name}未恰好覆盖总时长"))
        if re.search(r"(?:左手|右手).{0,18}同时.{0,18}(?:抓|持|托|按|扶|取|放)", row):
            findings.append(Finding("REVIEW", "HAND_OCCUPANCY", f"{name}请检查并行手部任务是否物理兼容"))
        if re.search(r"同时由.{1,16}(?:和|与).{1,16}(?:持有|握住|佩戴)", row) and not has_any(row, ("共持", "共同接触", "承接重量", "共同承重")):
            findings.append(Finding("REVIEW", "MULTIPLE_PROP_OWNERS", f"{name}须区分合法共持与互斥位置"))
    return findings


def character_names(text):
    people = role_section(text, "people")
    if asset_template(text):
        return list(dict.fromkeys(name.strip() for name, _ in ASSET_ENTRY_RE.findall(people)))
    latin = re.findall(r"(?<![A-Za-z])([A-Z][A-Za-z0-9_-]{1,24})(?![A-Za-z])", people)
    chinese = re.findall(r"(?:\*\*|^)([\u4e00-\u9fff]{2,8})(?=：|\*\*)", people, re.MULTILINE)
    return list(dict.fromkeys(latin + chinese))


def named_direction(source, name, terms):
    for clause in re.split(r"[；;\n。]", source):
        # Restrict matching to the named subject, never join separate actor clauses.
        pos = re.search(rf"(?:^|[：:，, ]){re.escape(name)}", clause)
        if not pos:
            continue
        for term in terms:
            match = re.search(rf"{re.escape(term)}.{{0,8}}?(画面左侧|画面右侧|画面中央)", clause[pos.end():])
            if match:
                return match.group(1)
    return None


def validate_orientation(shots, mode, text=""):
    if mode == "legacy":
        return []
    findings, previous = [], {}
    modern = v10_document(text)
    baseline = role_section(text, "space") + role_section(text, "state")
    names = character_names(text)
    for shot in shots:
        detail = has_any(shot.title, NON_CHARACTER_SHOT_TERMS + ("手部特写", "掌心", "接触特写", "脚部特写"))
        if detail and not has_any(shot.title, ("至面部", "至近景", "到面部")):
            continue
        source = labeled_field(shot.body, "画面内容" if mode == "no_composition" else "构图")
        for kind, terms, code in (
            ("body", BODY_DIRECTION_TERMS, "BODY_ORIENTATION_MISSING"),
            ("face", FACE_DIRECTION_TERMS, "FACE_DIRECTION_MISSING"),
            ("gaze", GAZE_DIRECTION_TERMS, "GAZE_TARGET_MISSING"),
        ):
            scope = source + (baseline if modern and kind == "body" else "")
            if not has_any(scope, terms):
                findings.append(Finding("REVIEW", code, "核对可见人物方向与基准继承；程序不能证明逐人空间", shot.line))
            for name in names:
                current = named_direction(source, name, terms)
                key = name, kind
                if current is not None:
                    if key in previous:
                        prior, prior_shot = previous[key]
                        bridge = prior_shot.body + shot.body
                        turns = TURN_ACTION_TERMS if kind != "body" else ("转身", "胸口转向", "骨盆转向", "肩线转向")
                        explained = has_any(bridge, turns + CAMERA_REPROJECTION_TERMS) or "画外" in baseline
                        if current != prior and not explained:
                            findings.append(Finding("REVIEW", "UNMOTIVATED_ORIENTATION_CHANGE", f"{name}的{kind}投影变化须检查世界转向或机位变化", shot.line))
                    previous[key] = current, shot
    return findings


def validate_props(text, shots):
    declared = role_section(text, "props")
    timeline = strip_quoted(role_section(text, "shots"))
    return [Finding("REVIEW", "UNDECLARED_PROP", f"核对“{token}”是否实际使用且已声明；词表不代表完整道具识别")
            for token in PROP_TOKENS if token in timeline and token not in declared]


def validate_language(text):
    findings = []
    for number, raw in enumerate(text.splitlines(), 1):
        line = strip_quoted(raw)
        if line.lstrip().startswith("#"):
            continue
        output_requirement = re.search(r"(?:无|不要|禁止|不得|避免|不能).{0,4}(?:字幕|水印|配乐|音乐|对白|文字)", line)
        for term in NEGATIVE_TERMS:
            if term in line and not output_requirement:
                findings.append(Finding("REVIEW", "NEGATIVE_LANGUAGE", f"可考虑将“{term}”改为明确目标；用户输出要求及原话保留", number))
        for term in PROJECT_RISK_TERMS:
            if term in line:
                findings.append(Finding("REVIEW", "PROJECT_LANGUAGE", f"核对“{term}”是否来源支持及表演适度", number))
        for term in CROSS_PROMPT_TERMS:
            if term in line:
                findings.append(Finding("ERROR", "NON_SELF_CONTAINED", f"“{term}”依赖其他段，展开必要事实", number))
        for term in AMBIGUOUS_TRANSITIONS:
            if term in line:
                findings.append(Finding("REVIEW", "AMBIGUOUS_TRANSITION", f"核对“{term}”的因果与路径", number))
    return findings


def validate_visibility(shots):
    findings = []
    for shot in shots:
        body = labeled_field(shot.body, "画面内容")
        combined = shot.title + " " + body
        staged = "起幅" in shot.body and "落幅" in shot.body and has_any(shot.combined, ("抬摇", "俯摇", "拉远", "后退", "至"))
        if staged and "同时清晰可见" not in body:
            continue
        if "掌心" in combined and has_any(combined, ("顶视", "俯拍")) and "鱼尾" in body:
            findings.append(Finding("REVIEW", "VISIBILITY_CONFLICT", "核对掌心镜头读取鱼尾是否可能，区别先后揭示与同时可见", shot.line))
        if has_any(combined, ("脸部近景", "眼神特写", "面部特写")) and "镜中" in combined and has_any(body, ("双腿", "脚踝", "脚背", "鱼尾")):
            findings.append(Finding("REVIEW", "MIRROR_VISIBILITY", "核对镜中脸部近景是否要求读取画外下肢", shot.line))
        if has_any(shot.title, ("远景", "大全景", "超远景")) and "虚焦" in body and has_any(body, ("指尖", "戒指细节", "汗滴", "鳞片纹理")):
            findings.append(Finding("REVIEW", "DISTANT_DETAIL", "核对虚焦远景的细节可读性", shot.line))
    return findings


def validate_reactions(shots):
    findings = []
    for shot in shots:
        if has_any(shot.combined, RELATIONSHIP_TOKENS) and has_any(shot.body, DIALOGUE_MARKERS + ("对白D",)):
            if not has_any(shot.body, REACTION_FACE + REACTION_BODY + ("注视", "等待", "延迟", "克制", "沉默", "停顿")):
                findings.append(Finding("REVIEW", "LISTENER_REACTION", "核对听者具体交流状态，不强制脸／手／呼吸三项齐全", shot.line))
    return findings


def validate_camera_rhythm(shots):
    findings = []
    for a, b, c in zip(shots, shots[1:], shots[2:]):
        if a.body == b.body == c.body:
            findings.append(Finding("REVIEW", "REPEATED_COVERAGE", "三镜正文完全相同，请核对递进或有意重复；不按变化维度计分", c.line))
    return findings


def validate_state_evidence(text, shots):
    state, timeline = role_section(text, "state"), role_section(text, "shots")
    findings = []
    if "昏迷" in state and has_any(timeline, ("睁眼", "回握", "主动坐起", "主动抬头")):
        findings.append(Finding("REVIEW", "PASSIVE_STATE_BREAK", "核对主动动作主体与昏迷区间，恢复须有来源及过程"))
    if has_any(state, ("低伏坐姿", "持续坐姿", "全程坐姿")) and has_any(timeline, ("站起", "走向", "站立")) and not has_any(state, ("→", "转为", "站起", "画外")):
        findings.append(Finding("REVIEW", "SUPPORT_STATE_BREAK", "核对坐姿人物是否有未记录支撑变化"))
    if "脱下" in state and not has_any(timeline, ("脱下", "褪下")) and "画外" not in state:
        findings.append(Finding("REVIEW", "TRANSITION_EVIDENCE", "核对衣物变化的可见过程或合理画外动作与证据"))
    return findings


def validate_movement(text, shots):
    if not v10_document(text):
        return []
    findings = []
    for shot in shots:
        if shot.movement == "未声明":
            findings.append(Finding("WARNING", "CAMERA_MODE", "镜头标题须声明运动或固定观察方式", shot.line))
        elif has_any(shot.movement, ("推", "移", "摇", "跟", "环绕", "手持", "拉远", "后退")):
            if not has_any(shot.body, ("起幅", "从")) or not has_any(shot.body, ("落幅", "停在", "最终")):
                findings.append(Finding("REVIEW", "MOVEMENT_ENDPOINTS", "核对运动起幅、路径和落幅", shot.line))
    return findings


def validate_dialogue(text, target, source=None):
    if v11_document(text):
        return validate_inline_dialogue(text, source)
    audio = role_section(text, "audio")
    rows, findings = {}, []
    for match in DIALOGUE_RE.finditer(audio):
        ident, start, end, speaker, listener, words = match.groups()
        try:
            start, end = float(start), float(end)
        except ValueError:
            findings.append(Finding("ERROR", "DIALOGUE_TIME", f"{ident}时间无效"))
            continue
        if start < 0 or end <= start or (target is not None and end > target + 0.06):
            findings.append(Finding("ERROR", "DIALOGUE_TIME", f"{ident}发声窗口无效或超片长"))
        if ident in rows:
            findings.append(Finding("ERROR", "DUPLICATE_DIALOGUE", f"{ident}重复声明，跨镜只排一次"))
        rows[ident] = {"id": ident, "speaker": speaker.strip(), "text": words}
    for line in audio.splitlines():
        if re.match(r"^对白[A-Za-z0-9_-]+\s*｜", line) and not DIALOGUE_RE.fullmatch(line.strip()):
            findings.append(Finding("ERROR", "DIALOGUE_FORMAT", "对白表行须包含区间、说话者、听者及原文"))
    for ident in set(re.findall(r"对白([A-Za-z][A-Za-z0-9_-]*)", role_section(text, "shots"))):
        if ident not in rows:
            findings.append(Finding("ERROR", "UNRESOLVED_DIALOGUE", f"{ident}缺少本包原话定义"))
    if source is not None:
        if not isinstance(source, list) or any(not isinstance(x, dict) or any(not isinstance(x.get(k), str) for k in ("id", "speaker", "text")) for x in source):
            return findings + [Finding("ERROR", "SOURCE_FORMAT", "源对白须为含字符串id、speaker、text的JSON列表")]
        expected = {x["id"]: x for x in source}
        if len(expected) != len(source):
            findings.append(Finding("ERROR", "SOURCE_DUPLICATE", "源对白ID重复"))
        for ident, wanted in expected.items():
            if ident not in rows:
                findings.append(Finding("ERROR", "MISSING_DIALOGUE", f"缺少原话{ident}"))
            elif any(rows[ident][key] != wanted[key] for key in ("speaker", "text")):
                findings.append(Finding("ERROR", "DIALOGUE_SOURCE_MISMATCH", f"{ident}原话或说话者不符来源"))
        for ident in rows.keys() - expected.keys():
            findings.append(Finding("ERROR", "EXTRA_DIALOGUE", f"新增源未包含的台词{ident}"))
    return findings


def validate(text, target_duration=None, source_dialogue=None, profile=None, length_target=None, max_shots=None):
    target = target_duration if target_duration is not None else infer_duration(text)
    if target is not None and (not math.isfinite(target) or target <= 0):
        return [Finding("ERROR", "INVALID_DURATION", "总时长须为正的有限数")]
    shots, mode = parse_shots(text), output_mode(text)
    extra = []
    if target is None and v10_document(text):
        extra.append(Finding("WARNING", "DURATION_MISSING", "头部须声明总时长"))
    raw_headers = re.findall(r"^###\s*镜头[^\n]*", role_section(text, "shots"), re.MULTILINE)
    if len(raw_headers) != len(shots):
        extra.append(Finding("ERROR", "SHOT_HEADER_FORMAT", "存在无法解析的镜头标题，不能跳过该镜"))
    return extra + (
        validate_v11(text, shots, target, profile, length_target, max_shots)
        + validate_asset_format(text)
        + validate_headings(text) + validate_shots(shots, target, mode)
        + validate_state_timeline(text, target) + validate_orientation(shots, mode, text)
        + validate_props(text, shots) + validate_language(text) + validate_visibility(shots)
        + validate_reactions(shots) + validate_camera_rhythm(shots)
        + validate_state_evidence(text, shots) + validate_movement(text, shots)
        + validate_dialogue(text, target, source_dialogue)
    )



def v11_document(text):
    return asset_template(text) or bool(re.search(r"版本[｜：]v(?:11|1[2-9])\b", text.split("\n## ",1)[0]))


def validate_asset_format(text):
    if not asset_template(text):
        return []
    findings = []
    # Only director instructions are filtered. Original quoted dialogue is
    # left intact, including source words that resemble labels or identifiers.
    prose = re.sub(r'“[^”]*”|"[^"\n]*"', '', text)
    if re.search(r"女主|男主|男二|女反|男一|女一|女二", prose):
        findings.append(Finding("ERROR", "ROLE_ALIAS", "人物标题、镜头标题和执行描述须使用来源人名，不加角色代称"))
    if re.search(r"%%@|REF_[A-Za-z0-9_]+|\[(?:image|video)\]|\b[0-9a-fA-F]{8}-(?:[0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12}\b", prose):
        findings.append(Finding("ERROR", "ASSET_REFERENCE", "成稿删除机器资产引用串、UUID和图片索引；映射留在内部"))
    if re.search(r"沿用既有人物形象|沿用人物素材|沿用同一枚道具|同一枚(?:道具|家徽|戒指)", prose):
        findings.append(Finding("ERROR", "EMPTY_INHERITANCE", "名称后直接写实际位置、身体、情绪与连续状态，删除空泛继承语"))
    prefix = text.split("\n## ", 1)[0]
    if re.search(r"生成规格|素材映射|版本[｜：]|任务模式|控制强度|内容类型", prefix):
        findings.append(Finding("ERROR", "HEADER_METADATA", "成稿头部仅保留标题、时长、画幅和构图模式"))
    for number, label in ((1, "人物"), (2, "场景"), (3, "道具")):
        body = section(text, number)
        entries = ASSET_ENTRY_RE.findall(body)
        if number == 3 and re.search(r"本段无剧情道具", body):
            continue
        if not entries or any(not description.strip() for _, description in entries):
            findings.append(Finding("ERROR", "ASSET_DESIGNATION", f"{label}指定需在各名称后直接写具体描述；无道具时说明本段无剧情道具"))
    names = set(character_names(text))
    rows, _ = inline_rows(text)
    for speaker in sorted({row['speaker'] for row in rows} - names):
        findings.append(Finding("ERROR", "UNDECLARED_SPEAKER", f"说话者{speaker}未在人物指定中声明"))
    return findings


def inline_rows(text):
    rows, findings = [], []
    for shot in parse_shots(text):
        parsed, issues = parse_inline(labeled_field(shot.body, "画面内容"), shot.start, shot.end)
        rows.extend(parsed)
        findings.extend(Finding("ERROR", code, message, shot.line) for code,message in issues)
    return rows, findings


def validate_inline_dialogue(text, source=None):
    rows, findings = inline_rows(text)
    if source is not None:
        findings.extend(Finding("ERROR", code, message) for code,message in compare_source(rows,source))
    return findings


def length_metrics(text):
    timeline = role_section(text,"shots")
    shots = parse_shots(text)
    # Only actual shot fields count toward the timeline quota. The synopsis
    # and a long preamble cannot be used to inflate shot coverage.
    body = "\n".join(s.body for s in shots)
    intro = timeline[:SHOT_RE.search(timeline).start()] if SHOT_RE.search(timeline) else timeline
    match=re.search(r"\*\*整段剧情概述：\*\*\s*(.*)", intro, re.S)
    overview=match.group(1).strip() if match else ""
    total=count_units(text)
    return dict(total=total, timeline=count_units(body), overview=count_units(overview),
                ratio=count_units(body)/max(total,1), overview_ratio=count_units(overview)/max(total,1),
                has_overview=match is not None)


def validate_v11(text, shots, target, profile=None, length_target=None, max_shots=None):
    if not v11_document(text):
        return []
    findings=[]
    alias_scope = re.sub(r'“[^”]*”|"[^"\n]*"', '', text) if asset_template(text) else text
    if re.search(r"(?<![A-Za-z0-9_])(?:SC\d+-)?D\d+[a-z]?(?![A-Za-z0-9_])",alias_scope):
        findings.append(Finding("ERROR","DIALOGUE_ALIAS","新成稿不允许台词代号；将实际原文写入时间线"))
    if re.search(r"\*\*(?:英文)?(?:台词|旁白)与发声：\*\*|^对白[^\n]*原文：",text,re.M):
        findings.append(Finding("ERROR","SEPARATE_DIALOGUE","台词不可另列发声栏或原话表"))
    for shot in shots:
        for label in ("构图", "画面内容", "声音"):
            if shot.body.count("**"+label+"：**")>1:
                findings.append(Finding("ERROR","DUPLICATE_FIELD",f"重复{label}字段可能隐藏台词或动作",shot.line))
    metrics=length_metrics(text)
    if not metrics['has_overview']:
        findings.append(Finding("ERROR","OVERVIEW_MISSING","时间线逐镜前缺少整段剧情概述"))
    if length_target is not None and length_target<=0:
        findings.append(Finding("ERROR","LENGTH_CONFIG","字数覆盖须为正整数"))
    if max_shots is not None and max_shots<=0:
        findings.append(Finding("ERROR","SHOT_LIMIT_CONFIG","镜数上限须为正整数"))
    # Length, section ratios and shot count have no default cap.
    # Only an explicit user limit is enforced, independently of duration.
    if max_shots is not None and max_shots > 0 and len(shots) > max_shots:
        findings.append(Finding("ERROR","SHOT_LIMIT","实际子镜头超过用户明确指定的上限"))
    if length_target is not None and length_target > 0:
        low, high = length_target * 0.94, length_target * 1.06
        if not low <= metrics['total'] <= high:
            findings.append(Finding("WARNING","LENGTH_BUDGET",f"当前{metrics['total']}字；用户明确要求约{low:g}–{high:g}"))
    return findings


def build_parser():
    parser = argparse.ArgumentParser(description="Seedance Director Compiler v13: structural checks, not a semantic or visual proof")
    parser.add_argument("prompt", type=Path)
    parser.add_argument("--duration", type=float, help="Expected total duration")
    parser.add_argument("--source-dialogue", type=Path, help="Independent UTF-8 JSON list with speaker/text; legacy id supported")
    parser.add_argument("--profile", choices=("normal", "enhanced"), help="Compatibility profile; no implicit length or density limits")
    parser.add_argument("--length-target", type=int, help="Explicit user-requested word count override")
    parser.add_argument("--max-shots", type=int, help="Explicit user-requested shot limit override")
    parser.add_argument("--strict", action="store_true", help="Fail on ERROR or WARNING; REVIEW requires human/semantic judgment")
    return parser


def main():
    args = build_parser().parse_args()
    try:
        text = args.prompt.read_text(encoding="utf-8-sig")
        source = json.loads(args.source_dialogue.read_text(encoding="utf-8-sig")) if args.source_dialogue else None
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        print(f"[ERROR] FILE: {exc}", file=sys.stderr)
        return 2
    findings = validate(text, args.duration, source, args.profile, args.length_target, args.max_shots)
    if v11_document(text):
        m = length_metrics(text)
        print(f"LENGTH: {m['total']} units; shot body {m['ratio']:.1%}; overview {m['overview_ratio']:.1%}")
    for finding in findings:
        print(finding.render())
    errors = sum(item.level == "ERROR" for item in findings)
    warnings = sum(item.level == "WARNING" for item in findings)
    reviews = sum(item.level == "REVIEW" for item in findings)
    if not errors and not warnings:
        print("PASS: automated structure/timing checks; semantic and visual review still required.")
    print(f"SUMMARY: {errors} error(s), {warnings} warning(s), {reviews} semantic review item(s)")
    if args.source_dialogue is None:
        print("NOTE: no source dialogue supplied; exact source fidelity was not mechanically verified.")
    return 1 if errors or (args.strict and warnings) else 0


if __name__ == "__main__":
    raise SystemExit(main())
