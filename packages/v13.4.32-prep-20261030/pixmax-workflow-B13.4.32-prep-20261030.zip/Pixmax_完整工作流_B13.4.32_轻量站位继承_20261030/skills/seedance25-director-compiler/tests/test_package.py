from __future__ import annotations

import re
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


class PackageTests(unittest.TestCase):
    def test_required_files_exist(self):
        required = [
            "SKILL.md", "VERSION", "agents/openai.yaml",
            "scripts/validate_director_prompt.py",
            "references/director_core_engine.md",
            "references/character_state_ledger.md",
            "references/prop_specification_engine.md",
            "references/spatial_blocking_engine.md",
            "references/temporal_state_compiler.md",
            "references/dialogue_performance_engine.md",
            "references/camera_shot_library.md",
            "references/shot_orchestration_engine.md",
            "references/duration_modules.md",
            "references/short_drama_pacing.md",
            "references/prompt_compiler.md",
            "references/affirmative_visual_language.md",
            "references/project_expression_rules.md",
            "references/prop_and_state_examples.md",
            "references/quality_gates.md",
            "references/contradiction_audit.md",
            "references/asset_reference_contract.md",
            "references/storyboard_intake.md",
        ]
        self.assertEqual([], [item for item in required if not (ROOT / item).is_file()])

    def test_skill_frontmatter_and_name(self):
        text = (ROOT / "SKILL.md").read_text(encoding="utf-8")
        self.assertTrue(text.startswith("---\n"))
        self.assertRegex(text, r"(?m)^name:\s*seedance25-director-compiler\s*$")
        self.assertRegex(text, r"(?m)^description:\s*.+$")

    def test_local_markdown_links_resolve(self):
        text = (ROOT / "SKILL.md").read_text(encoding="utf-8")
        links = re.findall(r"\[[^\]]+\]\(([^)]+\.md)\)", text)
        self.assertTrue(links)
        self.assertEqual([], [link for link in links if not (ROOT / link).is_file()])

    def test_version(self):
        self.assertEqual("13.3.0-20261004", (ROOT / "VERSION").read_text(encoding="utf-8").strip())

    def test_new_workflow_references_exist(self):
        for name in ("scene_prompt_library", "previsualization_workflow", "foreground_design",
                     "vfx_design", "combat_camera", "length_and_density"):
            self.assertTrue((ROOT / "references" / (name + ".md")).is_file())


if __name__ == "__main__":
    unittest.main()
