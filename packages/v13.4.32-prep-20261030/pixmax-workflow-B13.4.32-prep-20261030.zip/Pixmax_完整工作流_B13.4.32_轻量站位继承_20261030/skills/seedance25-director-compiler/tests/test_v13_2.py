import unittest
from test_v11 import PROMPT, SOURCE
from test_validator import validator as v


class FlexibleCoverageTests(unittest.TestCase):
    def test_long_and_short_descriptions_have_no_default_budget(self):
        for text in (PROMPT, PROMPT.replace('**整段剧情概述：**', '**整段剧情概述：** ' + '心理变化' * 3000)):
            for profile in (None, 'normal', 'enhanced'):
                found = {f.code for f in v.validate_v11(text, v.parse_shots(text), 30, profile=profile)}
                self.assertFalse(found & {'LENGTH_BUDGET', 'TIMELINE_DENSITY', 'OVERVIEW_TOO_LONG'})

    def test_explicit_limits_remain_opt_in_and_duration_independent(self):
        for duration in (15, 30):
            found = {f.code for f in v.validate_v11(PROMPT, v.parse_shots(PROMPT), duration, max_shots=2, length_target=100)}
            self.assertTrue({'SHOT_LIMIT', 'LENGTH_BUDGET'} <= found)

    def test_bad_explicit_configuration_still_fails(self):
        found = {f.code for f in v.validate_v11(PROMPT, v.parse_shots(PROMPT), 30, max_shots=0, length_target=0)}
        self.assertTrue({'SHOT_LIMIT_CONFIG', 'LENGTH_CONFIG'} <= found)

    def test_real_16_shot_timeline_without_default_cap(self):
        first = PROMPT[:PROMPT.index('### 镜头01')].replace('总时长：15秒', '总时长：30秒')
        tail = '\n## 5. 声音安排\n房间底噪。\n## 6. 输出要求\n无字幕、无水印、无背景音乐。\n'
        shots = []
        for index in range(16):
            a, b = index * 1.875, (index + 1) * 1.875
            shots.append(f'### 镜头{index+1:02d}｜{a:g}–{b:g}秒｜林夕近景｜固定\n**构图：** 林夕面部朝向周远，视线看向周远。\n**画面内容：** 林夕继续已有表演，信纸仍在右手。\n')
        text = first + '\n'.join(shots) + tail
        parsed = v.parse_shots(text)
        self.assertEqual(16, len(parsed))
        self.assertEqual([], v.validate_shots(parsed, 30, 'composition'))
        self.assertNotIn('SHOT_LIMIT', {f.code for f in v.validate(text)})

    def test_source_and_timing_protection_not_relaxed(self):
        self.assertIn('DIALOGUE_SOURCE_MISMATCH', {f.code for f in v.validate(PROMPT.replace('：“就走。”', '：“走。”'), source_dialogue=SOURCE)})
        self.assertIn('BEAT_TIME', {f.code for f in v.validate(PROMPT.replace('[0–1.2秒，镜内]', '[0–4.2秒，镜内]'), source_dialogue=SOURCE)})

    def test_medium_and_wide_continuous_dialogue_are_not_formal_errors(self):
        source = [dict(speaker='周远', text='我明天就走。别等我。'),
                  dict(speaker='林夕', text='那你看着我。')]
        head = PROMPT[:PROMPT.index('### 镜头01')]
        tail = PROMPT[PROMPT.index('## 5. 声音安排'):]
        for scale in ('双人中景', '双人全景'):
            with self.subTest(scale=scale):
                timeline = f'''### 镜头01｜0–15秒｜{scale}｜固定平视
**构图：** 摄影机在关系轴南侧，林夕在画面左侧、周远在右侧；林夕身体和面部朝周远，视线看周远，周远身体和面部朝林夕，视线先落信纸再抬向林夕双眼。两人及桌两端的距离持续可见。
**画面内容：** [0–4.8秒，镜内] 林夕右拇指轻摩挲信纸，等待周远说明。[4.8–9秒，镜内] 周远（现场对白）平静地对林夕说：“我明天就走。别等我。”两句在同一构图自然说完，林夕拇指停住，仍用右手握稳信纸。[9–11秒，镜内] 林夕接收决定，没有松开信纸。[11–13.2秒，镜内] 林夕（现场对白）压住失落，对周远说：“那你看着我。”周远听清后抬眼回应。[13.2–15秒，镜内] 两人保持目光接触，双手和脚下位置持续。
'''
                text = head + timeline + tail
                findings = v.validate(text, source_dialogue=source)
                self.assertEqual(1, len(v.parse_shots(text)))
                self.assertFalse([f for f in findings if f.level in ('ERROR', 'WARNING')])
                changed = text.replace('：“我明天就走。别等我。”', '：“我明天就走。”')
                self.assertIn('DIALOGUE_SOURCE_MISMATCH', {f.code for f in v.validate(changed, source_dialogue=source)})


if __name__ == '__main__':
    unittest.main()
