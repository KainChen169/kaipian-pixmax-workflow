import re
import unittest

from test_v11 import PROMPT, SOURCE
from test_validator import validator as v


def rescale_fixture(duration):
    # Parser regression only: scaling this fixture does not prove natural speech.
    ratio = duration / 15
    text = re.sub(
        r'(\d+(?:\.\d+)?)\s*([–—-])\s*(\d+(?:\.\d+)?)',
        lambda m: f'{float(m[1]) * ratio:g}{m[2]}{float(m[3]) * ratio:g}',
        PROMPT,
    )
    return text.replace('总时长：15秒', f'总时长：{duration}秒')


class ContentDurationTests(unittest.TestCase):
    def test_non_30_second_packages_keep_time_and_source_validation(self):
        for duration in (10, 22, 27):
            with self.subTest(duration=duration):
                text = rescale_fixture(duration)
                self.assertEqual(duration, v.infer_duration(text))
                self.assertEqual(duration, v.parse_shots(text)[-1].end)
                findings = v.validate(text, source_dialogue=SOURCE)
                self.assertFalse([f for f in findings if f.level in ('ERROR', 'WARNING')])

    def test_declared_duration_still_must_match_timeline(self):
        text = PROMPT.replace('总时长：15秒', '总时长：22秒')
        self.assertIn('TOTAL_DURATION', {f.code for f in v.validate(text, source_dialogue=SOURCE)})

    def test_variable_duration_does_not_relax_exact_dialogue(self):
        text = rescale_fixture(22).replace('：“就走。”', '：“走。”')
        self.assertIn('DIALOGUE_SOURCE_MISMATCH', {f.code for f in v.validate(text, source_dialogue=SOURCE)})

    def test_action_during_speech_is_not_a_formal_error(self):
        text = PROMPT.replace(
            '画面留住林夕停止摩挲的拇指和完整信纸。',
            '周远发声的同时，画面留住林夕停止摩挲的拇指和完整信纸，林夕不动嘴。',
        )
        self.assertFalse([f for f in v.validate(text, source_dialogue=SOURCE) if f.level in ('ERROR', 'WARNING')])

    def test_deliberate_waiting_has_no_new_automatic_pacing_threshold(self):
        # The original fixture has intentional silence; review needs context.
        self.assertFalse([f for f in v.validate(PROMPT, source_dialogue=SOURCE) if f.level in ('ERROR', 'WARNING')])


if __name__ == '__main__':
    unittest.main()
