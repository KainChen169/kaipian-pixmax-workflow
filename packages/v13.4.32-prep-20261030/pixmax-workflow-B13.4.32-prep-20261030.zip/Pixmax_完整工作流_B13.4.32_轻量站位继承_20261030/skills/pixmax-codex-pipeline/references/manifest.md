# 任务清单格式

新清单默认Seedance2.5 Draft 480P、9:16、有声音；显式普通版2.5会被规格检查拦截。明确指定的旧2.0清单仍可解析，不作为新任务模板。保存为 UTF-8 JSON。相对素材路径相对于清单文件所在目录；`output_root` 相对于清单所在目录。`run_id` 对一次批次保持固定，重跑不得更换。

```json
{
  "run_id": "ep01-v1",
  "project_name": "暴雨弃犬",
  "canvas_name": "EP01 镜头生成",
  "episode": "EP01",
  "output_root": "./deliveries",
  "shots": [
    {
      "id": "S001",
      "prompt": "具体的视频提示词",
      "reference_image": "./assets/S001.png",
      "model": "PIXDANCE_2_5_DRAFT",
      "resolution": "480P",
      "aspect_ratio": "9:16",
      "duration": "7",
      "audio": true
    },
    {
      "id": "S002",
      "prompt": "无参考图时走文生视频",
      "model": "PIXDANCE_2_5_DRAFT",
      "resolution": "480P",
      "aspect_ratio": "9:16",
      "duration": "7",
      "audio": true
    }
  ]
}
```

需要两张以上有序参考图片时，用 `reference_images` 替换 `reference_image`，并明确 `refer_model`：

```json
{
  "id": "S003",
  "prompt": "从第一张外门夜景过渡到第二张反向夜景",
  "reference_images": ["./assets/first.png", "./assets/last.png"],
  "refer_model": "firstAndLastFrame",
  "model": "PIXDANCE_2_5_DRAFT",
  "resolution": "480P",
  "aspect_ratio": "9:16",
  "duration": "15",
  "audio": true
}
```

数组顺序就是画布 `prevNodeUuids` 的输入顺序；调换顺序会改变清单指纹，原 `run_id` 不可继续，应使用新 `run_id`。`reference_images`须至少两张且不得同时使用`reference_image`，不设通用9张上限；`firstAndLastFrame`必须恰好两张，`referToVideo`按当前目标模型与模式的真实输入规则核验，详见[参考输入容量](reference-input-limits.md)。2.5不得因超过9张自动拆段；2026-10-10查询的2.5图片上限30，多媒体合计50，不是50张图片。离线plan只做结构检查；prepare／run在远端写入前查当前限制，未知／超限停该项保留原稿。`prepare`可逐张上传并记录有序节点。生成节点写入仍受官方Pixmax CLI协议闸门限制，旧1.3.0构建的历史缺口须按当前版本核验，不能只凭版本号推断支持。`model`等参数须受实时配置允许；时长和比例并非通用。旧脚本未实现音频／视频参考、多段合成或字幕，不把素材路径简单塞入prompt。

如模型提供容器格式（例如 `PIXDANCE_2_5_DRAFT`），可选填 `"output_format": "mov"` 或 `"mp4"`。仅在模型的 `outputFormat` schema 提供该值时才能提交；`PIXDANCE_2` 当前不提供此字段。若模型有 `bitrateMode`，可选填 `"bitrate_mode": "standard"` 或当前模型允许的其他选项。容器格式、分辨率、画幅比例和码率是四个不同设置。
