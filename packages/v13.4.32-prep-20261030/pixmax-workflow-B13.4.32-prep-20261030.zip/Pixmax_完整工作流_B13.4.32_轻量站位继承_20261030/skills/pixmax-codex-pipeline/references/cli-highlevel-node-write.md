# 高层 CLI 普通节点写入闸门

2026-10-02 长稿适配：本覆盖层的prompt长度处理与官方build100014保持一致，交由服务器判定；增加 `--prompt-file` 文件传参。具体见 [长提示词通用处理](long-prompt-handling.md)。其他模型参数、输入、普通节点协议闸门与版本约束仍需核验。

随附的 `runtime-overlay/pixmax/` 和 `tools/pixmax_fixed.py` 来自 2026-09-28 工作流包。它针对官方 Pixmax CLI **1.3.0/build100012** 普通生成节点创建的字段缺口：补当前画布 `baseRevision`、必要的空资产字段，移除协议外创建字段，并让 Windows 保留真实 `%%@...%%`。本工作流不改写全局官方 CLI 安装；覆盖层只作为同版本备用高层命令入口，不使用 raw API 绕过协议。

使用前先对照已安装的 [pixmax-cli 普通节点协议](../../pixmax-cli/references/generation-node-protocol-v1.md)，检查当前 CLI 版本、动态模型 schema 和当前账号。跨版本或字段不一致时停止覆盖层。运行 `python tools/pixmax_fixed.py --version` 仅验证本地入口；随后在**目标画布**用一个不收费的 `node create --dry-run` 检查 `fileUuid`、`baseRevision`、`create[0]` 的字段、`params`、有序 `prevNodeUuids` 和字面 @。原始15秒节点的 dry-run prompt 必须与已核验的绑定执行副本字节一致，平台保存回读也与该副本一致；源文件哈希和可逆 token 差异另行核对。源文件缺 @ 可按 SKILL.md 直接在指定区编译，不逐镜确认。执行副本仍缺必要 @ 或普通文字／格式被改动时停止该镜头。dry-run 通过后才保存一条测试节点并回读。任何写入结果不明，先按唯一标签和画布修订号查询，不重复创建。

修改现有节点时必须传完整模型参数集合，因为平台可能整体替换 `params`。优先新建修订节点，保留原任务及结果作比较；原英文对白和说话者逐字核对。提交已保存且验收通过的节点仍使用官方 `group unuse → group bind → group run --dry-run → group run`；节点写入能力与整组提交能力分别判断。

若覆盖层与当前平台不兼容，使用 [当前账号原生剪贴板备用路径](fast-binding-and-state.md)；不能通过手工 raw `canvas batch` 或 `tasks submit-batch` 规避协议闸门。

## 已观察到的故障与分流

- Pixmax CLI 1.3.0/build100012 的普通 `GENERATE_VIDEO` 高层命令曾在 `--dry-run` 返回缺少 `baseRevision` 的 `/canvas/node/batch` 计划；`create` 项还包含协议外的 `fileUuid`、`isGenerateNode`，且缺少初始空 `defaultAssetUuid`。这属于**节点写入协议闸门失败**：停止该命令的保存与连线，不把 dry-run 成功或 CLI 仍能读取节点当作写入已修复。仅在同版本覆盖层重新通过当前画布的字段检查和零积分单节点回读后，才恢复高层 CLI 节点写入。
- 受限环境中，稳定启动器可能因无法写入本地 `update.lock` 而不能启动；直达已安装 runtime 可完成只读查询。`group unuse` 也曾因本地 `session.json` 的 `PermissionError` 失败，取得允许 CLI 正常写入其会话目录的运行权限后，官方 `group unuse → bind → dry-run → run` 成功。这是**本地文件权限问题**，不能据此推断生成节点协议、账号鉴权或整组提交能力均已失效；不要手改会话文件、关闭更新校验或改用 raw 请求。每种 CLI 能力单独验证，任何提交响应不明先查任务 UUID。
- 网页画布与其他窗口同时修改时可能提示文件版本冲突。保留云端版本，重新读取节点、任务及修订号后再决定是否续做；不得覆盖云端版本来强行保存自己的旧快照。

CLI 节点写入闸门仍未通过时，已登录画布可以使用 [原生剪贴板路径](fast-binding-and-state.md#原生剪贴板实操检查点) 建视频节点和有序连线。此替代路径只改变平台操作方式；资产 @ 按 SKILL.md 编译，叙事原文不自动改写，也不绕过保存回读、人物合规和生成前预检。
