# 批量绑定、人物状态与保存回读

> B13.4.24：先按[制作类型分流](project-style-routing.md)核验下载项目。真人继续seedance25_v134，动画使用seedance25_animation、显式v2锚点及动画整集／声音／调度证据；批量编译和保存回读已支持两种实际role。下文旧v134唯一路由描述仅适用于真人，其他真实@、输入顺序、参数和防重规则共用。

2026-10-19追加：[每视频两秒黑场仅连线](black-video-reference.md)。新计划顶层填写connection_only_video及当前reference_input_limits；原bindings保持图片顺序，编译器只在prevNodeUuids末尾加同一BASE_VIDEO，不加视频token、不改原词／时长。保存回读及实际资产身份继续核对，旧清单兼容，不回填历史。下方有序图片描述不排除此明确的仅连接视频末项。

## 新2.5逐镜正文引用（2026-10-16）

新任务先读[逐镜关键引用](shot-body-mentions.md)，采用asset_mentions_shot_anchors_v2＋body_mentions显式计划，前置指定保留、正文关键处追加同资产真实@；输入去重，台词和普通文字不改。下文asset_mentions_only_v1及“仅资产行／正文不重复”只用于历史v1或旧2.0，不能覆盖此新入口。脚本从相同源文与锚点计划重编译核对，实际入画与身份映射仍由Agent判断，不全篇替名、不手工逐个点击。昼夜规则不变。

新2.5使用 `prompt_role=seedance25_v134`，接 [v13.4模块](seedance25-30s-workflow.md)：自然时长、完整三项指定；`supported_durations` 来自动态schema，头部/时间线/params.duration一致。新2.0仍用original_15s/automation_15s/supplement。历史seedance25_30s继续固定30秒；旧三种角色说明属于2.0或历史清单。完整长稿文件传入与源哈希/可逆绑定照常执行。

该路径用于镜头多、重复连线和真实 `@` 耗时的分集画布。先读正式剧本、当前集全部原提示词和 [剧本驱动工作规范](script-driven-workflow.md)。只在确定人物、场景、道具的语义映射后执行确定性编译；同名不同服装、昼夜或受伤状态要先解决歧义。

## 一次编译整批连线，原镜提示词保持原样

前置条件：已按 [导入后资产分析](post-import-asset-analysis.md) 看过导入图片、确认各段缺口并完成补图／状态更新验收。仅把对该段已确认可用的资产写入正式 `bind-plan.json`；新导入或替换的素材先复核，不能因名称相符直接编译。分析记录由助手维护，绑定脚本不自动识图。

1. 用官方 CLI 只读获取目标画布节点，保存 `canvas-before.json`。新自动化版从同集 MD 提取视频正文与六宫格附录，核对源及逐镜哈希；`prompt_file` 指向逐镜视频源，不把图片附录送入视频。按人物→场景→道具、同类沿指定区顺序写 `bind-plan.json`，每项保存 `designation` 和真实图片节点 UUID；已验收六宫格附 `storyboard_reference` 及图词／同集源文件与哈希，已有首段说明里编译 @。每镜记录当前模型的 `max_image_inputs`、`max_prompt_chars`、`supported_durations`。原镜用 `original_15s`，新自动化正片用 `automation_15s`，独立补镜用 `supplement`；三种角色都可以编译资产 token，角色不改变叙事保护或时长约定。缺 @ 不触发逐镜授权询问；原始文件不变。
2. 首选当前版本已通过 [高层 CLI 节点写入闸门](cli-highlevel-node-write.md) 的 `node create --left`。每节点 dry-run、保存、回读完整 `params`、`prevNodeUuids` 和 `%%@[标签][image][编号](节点UUID)%%`；只要协议检查失败就停止该写入路径。
3. CLI 写入不可用时，可在**当前登录账号、当前画布**原生复制一个空视频节点。保存原生剪贴板 JSON；运行 `scripts/fast_bind.py --plan <bind-plan.json> --canvas <canvas-before.json> --native-template <native-template.json> --output <本批记录目录>`。脚本仅生成本地计划和剪贴板，不写平台。内置浏览器用支持的剪贴板写入与画布“粘贴（保留连线）”完成一批。跨账号的 `copiedByAuthFingerprint` 不能复用。
4. 粘贴后只读回查画布，用 `resolve_saved_batch.py` 按唯一标签解析实际节点 UUID。核对完整参数、有序输入、全部真实 @ 和平台prompt与执行副本全文一致；核对源哈希未变、binding_edits可逐字还原。新2.5记录binding_policy=asset_mentions_shot_anchors_v2、body_mentions、binding_labels、带designation的bindings及bound_prompt_sha256；历史v1仍记录asset_mentions_only_v1。提交前从源和映射／锚点重编译，任何普通文字变化都拒绝；正文重复引用不能变成重复连线。保存暂不可见时查询，不重复粘贴；重复节点标签停止。
5. 完成 [连线后的资产视觉自查](pre-generation-asset-visual-review.md)，逐张看实际图片并核对每段剧本和提示词。`fast_bind.py` 只写入PENDING；完成实际节点UUID解析和真实看图后再填写 `visual_review`，不能将名称匹配或保存成功当作视觉PASS。获得本次生成授权后，使用 `submit_saved_batch.py` 的精确整组预检、`group unuse`、bind、dry-run 和一次提交。超时或未知状态先按任务 UUID 对账。

`fast_bind.py` 对三种提示词角色均在资产行添加／更新 token，不改源文件。已经正确的 @ 保持原样；过期 UUID、标签或编号按确认映射替换；多余、重复或正文中的 token 先定位，不擅自删正文。脚本生成精确差异和执行副本哈希，`submit_saved_batch.py`／`resolve_saved_batch.py` 重编译核对。旧清单未记录绑定差异时仍按旧版本严格校验，不自动放宽。补镜时长须在实时模型 schema 的 `supported_durations` 中；10秒四镜来源映射规则保持不变。

人物、场景与道具的跨集依据统一见 [三阶段自检](continuity-self-review.md)。两套新编译清单的 `visual_review` 都必须带跨集来源与账本哈希；单集文字未变也不能复用前文已改变的状态结论。

## 人物状态资产

按同级[资产规划规则](../../tiktok-custom-drama-production/references/资产规划与按需生成规则.md)记录实际可见变化，先复用正确母图；小伤痕、污损和小破损选镜头处理，不因无独立图阻塞绑定。关键形态／证据／结构缺口才补最小必要图，完整状态板才执行四视图规范。母图按身份／主要造型职责验收，轻微状态在镜头中核对，不伪造图上状态。新含人像资产仍按真实UUID检测。

旧 `scripts/validate_character_states.py` 仅解析旧15秒标题，不证明2.5整集覆盖；2.5继续用账本及 `visual_review.continuity_review`。旧记录缺省 `implementation=state_image` 保持原图像哈希与验收闸门；选择 `implementation=prompt` 或 `tolerance` 时不要求state_image／state_sha256。沿用from_state、trigger、visible_from/until、mother_image／mother_sha256及review，新增简短reason说明依据；prompt方式另填prompt_state说明对应镜头前态／变化／后态。review保留same_face、same_person、outfit_continuity、script_state、non_graphic五项PASS，母图不得伪称已带伤。确认免生成无需迁移历史FAIL；另存本次复核方案，必要状态图仍按原规则检查，脚本不自动识图或分类状态。

原生剪贴板的格式属于当前网页实现细节。首次换账号或平台更新后，先用一条零积分测试节点验收，不能把离线文件生成成功当作平台保存成功。

## 原生剪贴板实操检查点

当高层 CLI 的普通视频节点写入未通过协议闸门，而用户仍要在当前画布完成节点和连线时，先用仍可用的 CLI 只读查询或网页可见状态确认目标画布和资产，再使用当前登录账号的可见画布操作：

1. 在目标画布新建一个空视频节点，确认网页显示用户指定的模型。通过节点右键菜单的“复制”取**当前账号**原生剪贴板模板；检查剪贴板 `text/html` 中的 `pixmax-clipboard`、`base64url` JSON、单个 `video-gen` 节点、`schemaVersion` 和 `copiedByAuthFingerprint`。保存模板供本批编译，账号、画布实现或网页版本改变时重新复制；不填写或传播别人的指纹。
2. 用已核实的资产 UUID 编译唯一节点标签、完整 `params`、真实 `%%@[标签][image][零起始编号](上游节点UUID)%%` 和 `inboundExternalEdges`。边的顺序为人物→场景→道具→可选六宫格，类别内部依指定顺序；前三类资产在指定区各引用一次，六宫格在整段提示词的**第一段通用说明**真实 @ 一次。`fast_bind.py` 可在原镜执行副本补齐或更新资产 @，不把原镜冒充补镜。六宫格只在已有置顶说明内绑定 token／占位符；精确差异只涉及资产引用，其余正文逐字不变。
3. 先粘贴一条不提交生成的测试节点。在画布空白处打开右键菜单，选择“粘贴（保留连线）”；普通粘贴不能证明外部连线保留。本次浏览器虚拟剪贴板的快捷键粘贴曾返回无可粘贴数据，而菜单操作成功，因此快捷键失败后应检查剪贴板内容并使用可见菜单，不重复盲贴。
4. 待画布显示云端同步后，只读回查该画布。Pixmax 粘贴时可能重分配视频节点 UUID，按本批唯一标签解析**实际** UUID，不用剪贴板中的临时 UUID 提交。逐节点核对提示词全文、模型、时长、画幅、音频、`prevNodeUuids`、每个 @ 的标签／UUID／编号和人物 ACTIVE 状态。测试通过后再按精确批次粘贴；保存状态不明时先查节点，不能再次粘贴。
5. 用户在其他窗口修改同一画布而出现版本冲突时，选云端版本并重新回查；不覆盖用户新改动。已保存节点的官方整组提交与 CLI 节点创建是独立能力，仍按 [整批提交脚本](saved-batch-runner.md) 的精确组和防重规则执行。

本次 Seedance 2.0 Fast 实测可在网页保存并生成超过模型说明中 1024 字符的完整提示词；这只说明当次网页和账号的实际行为，不能推断其他模型或版本没有长度限制。遇到说明值与网页行为不一致时，不自动缩写原词或换模型；先保留原文做单节点保存回读，再依据当次生成授权与实际任务结果判断，任何失败或状态不明按任务 UUID 对账。
