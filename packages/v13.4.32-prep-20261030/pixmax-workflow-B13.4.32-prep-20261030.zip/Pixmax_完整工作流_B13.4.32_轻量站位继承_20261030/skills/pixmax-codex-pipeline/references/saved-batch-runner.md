# 已保存节点的整批提交脚本

2026-10-19新任务按[黑场视频仅连线](black-video-reference.md)登记connection_only_video及当前reference_input_limits。图片bindings／token不变，prevNodeUuids在末尾追加一次黑场BASE_VIDEO；校验完整输入及实际asset UUID，不要求黑场token或伪造图片验收。旧无字段清单兼容，不批量迁移。明确恢复视频生成前，本脚本仍只做只读预检，不加--submit。

新2.5清单用 `seedance25_v134`，按 [模块规则](seedance25-30s-workflow.md) 验证自然时长、完整时间线、重算后的引用编号。两套新编译清单均带workflow_policy与共享连续性证据。旧站位图连线只保留历史回读兼容，不用于新制作。

新编译的`seedance25_30s` 清单要求 `PIXDANCE_2_5_DRAFT`、30秒与可逆资产绑定记录，保存后核对完整prompt；长度提示不代替全文核验，见 [长提示词通用处理](long-prompt-handling.md)。本提交器仍仅处理普通生成节点，2.5产物的1080P超分按 [专用分支](seedance25-30s-workflow.md) 独立记录，不伪装成普通视频重生成。

入口：`scripts/submit_saved_batch.py`。由 Codex 先完成剧本理解、资产匹配、节点保存和执行清单编译，再运行此脚本。它只检查和提交已经存在的图片/视频节点，不创建项目、节点，不改提示词，不重排素材，不下载视频。

## 三种操作

```powershell
python scripts/submit_saved_batch.py --manifest 执行清单.json --records 执行记录/本批
python scripts/submit_saved_batch.py --manifest 执行清单.json --records 执行记录/本批 --submit
python scripts/submit_saved_batch.py --manifest 执行清单.json --records 执行记录/本批 --status
```

第一条只读检查。第二条仅用于当前会话已经授权生成的批次，必要的人物检测也由此发起；已有授权直接执行，无需再次请示。第三条只查询。停止测试或只要求优化流程时，不运行第二条。

默认使用已安装 `pixmax` 稳定启动器。已有受信运行环境需要命令数组时，可配置 `PIXMAX_CLI_COMMAND_JSON`，值为 JSON 字符串数组；不把凭证放入此变量，不自动固定某个旧版本 Runtime。

## 执行清单

根字段 `file_uuid` 与 `shots` 必填；每项结构：

```json
{
  "id": "EP01_S001",
  "node_uuid": "实际视频节点UUID",
  "params": {
    "nodeType": "GENERATE_VIDEO",
    "model": "PIXDANCE_2_5_DRAFT",
    "resolution": "480P",
    "aspectRatio": "9:16",
    "includeAudio": true,
    "prompt": "完整的已保存提示词及真实平台mention",
    "count": 1
  },
  "prevNodeUuids": ["人物节点UUID", "场景节点UUID", "道具节点UUID"],
  "bindings": [
    {"category": "character", "node_uuid": "人物节点UUID"},
    {"category": "scene", "node_uuid": "场景节点UUID"},
    {"category": "prop", "node_uuid": "道具节点UUID"}
  ],
  "character_asset_uuids": ["人物节点对应的实际资产UUID"],
  "mention_ranges": [[10, 100], [120, 190], [210, 300]]
}
```

上例只展示字段结构，不能直接提交。`params` 必须包含该节点动态模型 schema 的全部实际参数：视频分辨率、画幅、时长、参考模式、音频等；脚本与服务端逐项比较，缺项或多项均停止。模型 schema、限制数量、素材属性以及角色/场景/道具的语义正确性，由 Codex 在编译前校验。

mention_ranges使用最终完整字符串的Python字符偏移、左闭右开。历史v1只包含三项指定区；新2.5 v2按[逐镜关键引用](shot-body-mentions.md)，另包含由锚点编译器计算的精确正文token区间，不能手写宽泛范围放开正文。程序核对指定区及已登记正文重复引用的完整重编译结果、UUID、标签、媒体类型和零起始索引；上游数组仍按人物→场景→道具去重。无上游节点用空数组；场景补图母图仍按原图像分支，不套视频正文策略。

## 提交和恢复

两套新编译视频同时强制核对 `visual_review.continuity_review`，见 [跨集连续性记录](continuity-self-review.md)。缺全剧来源范围/证据、来源文件或账本哈希变化、任一检查非PASS，均阻止新提交；历史任务查询/下载不受此新增要求影响。程序只验记录完整性和版本，实际阅读、看图及剧情判断由助手完成。

所有尚未接受任务的视频还需完成 [资产视觉自查](pre-generation-asset-visual-review.md) 并在 shot 填写 `visual_review`。只读计划以 `visual_review_pending` 列问题、`generation_ready` 列通过项；`ready` 仍为结构和任务状态检查结果。缺记录或资产、文字、剧本变更时 `--submit` 会在收费操作前停止。完成真实看图后更新记录，或另建只含通过项的子批；既有已提交清单保持不变，历史查询和下载不补造检查记录。此程序只核验视觉记录，不自行看图或判定场景/服装颜色。

1. 回读任务与同一画布的节点，核验清单、提示词、参数、顺序和引用。原图资产必须已经就绪。
2. 已排队、等待并发、运行或完成的节点进入 `existing`，不重复提交。发现失败、未知任务或画布修改时停止本批并报告具体节点。
3. 去重人物资产，全部完成官方检测且为 ACTIVE 后再继续。PROCESSING 不反复提交视频；等待检测后重跑检查。
4. 再次回读，防止用户刚手动提交的节点被重复提交。执行 `group unuse` 清除旧活动组筛选，再创建唯一的本地组，并核验组成员和 dry-run 的精确UUID列表；避免CLI 1.3.0跨画布仍按旧组筛选而报节点不存在。
5. 正式提交前原子保存 `SUBMITTING` 记录，一次 `group run`，核对每个目标任务编号。响应不全记录 `RECONCILE_REQUIRED`。
6. 同一记录目录再运行时只查询，不自动再提交。网络超时也保留提交标记。若崩溃留下 `submit.lock`，先读服务端任务及记录，确认没有进行中的本地执行后由 Codex处理锁；不得盲目删锁再提交。

平台已接受的任务交给平台排队，统一轮询，不按两个一组等待。已明确未接受的剩余节点，经核对后编译为新的待提交子批；未知状态先查清，不把响应缺项当作未提交。

## 能力边界

普通生成完成后的2.5超分由 [网页提交与批量回读](upscale-browser-and-readback.md) 接续。原片 `submission.json` 保持其生成任务身份；在同批记录目录的 `upscale/` 下另存 `upscale-batch.json` 与回读、下载、验收记录。不要把超分任务UUID写成原生成任务UUID，也不要让本提交器重生成原片来补超分失败。

官方组提交已在线完成10张图片，20积分。后续第17集通过本封装一次提交10条Seedance 2.0 Fast视频，全部生成和下载、技术检查通过，没有用户代点；同时修复跨批次旧活动组筛选，10项离线回归通过。程序仍只负责已保存节点，不自动解析剧本或操作全部网页。画面抽检发现个别文字和道具外形偏差，不能声称严格成片质量全部通过，也不能声称并发上限已测出。

资产绑定执行副本：新2.5清单用asset_mentions_shot_anchors_v2和显式body_mentions，另有权威源路径／哈希、带指定名称的bindings、binding_labels、binding_edits、bound_prompt_sha256。保存回读与执行副本全文一致；预检从未变源及锚点计划重编译，只允许指定区token和已登记正文名称后的引用插入，台词／表演／普通文字变更即停止。历史asset_mentions_only_v1仍只允许指定区，缺旧证据的清单保留其严格校验；新策略不迁移已提交任务的记录，不全局允许任意正文token。
