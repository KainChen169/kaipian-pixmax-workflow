# TK补充图片：欧美地域、美术与画面语言

> B13.4.24：先按[项目制作类型](project-style-routing.md)选动画／真人。动画沿用已定美术、物种和角色结构，不把下文真人演员选型或实拍材质后缀套到非人类动画角色；地域／时代、英文文字、来源身份及资产复用等通用要求继续。与当前项目明确设定有冲突时报告，不擅自改画风或人种／物种。

2026-10-16用户要求。适用于本Pixmax工作流新补、派生或修复的人物、场景、道具图片，包括图片里可见的背景人物与陈设；不是改编剧本、换掉已锁定人物或批量返修历史资产的授权。当前不生成媒体、不恢复视频／超分／剪辑台阶段。

## 先定项目地域，不用笼统“西方”替代设计

从正式剧本、已确认设定、正确原母图确定既定国家／地区、时代、场所用途及角色身份，再写具体可见的设计。美国、英国和欧洲大陆不混成一套道路、车牌、制服、插座或文件制度；现代、年代戏和西方奇幻也不串时代。来源未细分国家时沿用已确认美术基准，不每张图重新猜一个国家，不为执行本条重算昼夜。

| 图片类别 | 必须落实的内容 |
|---|---|
| 人物 | 选用符合已定角色年龄、身份、气质与欧美选角方向的非亚洲演员面孔；不生成亚洲人物，画面确需背景人物时也按同一要求选型。继承正确同角色身份／当前造型／必要变身参考，不靠英文姓名或“欧美风”几个字认定合格。不把“非亚洲”扩写成未经要求的其他族群排除，也不把所有角色改为同一张脸。 |
| 场景／街道 | 建筑、街道路制、门窗、店面、车辆、标识形制、家具及生活陈设符合既定欧美地区和时代，不混入中国街景、中文店招、中国式牌匾／灯笼／传统中式装饰等中国视觉元素；正常派生仍保持正确母图布局。空景保持无人，不为地域展示新增群演。 |
| 道具 | 文件、证件、警用／医疗设备、家具、电器、车辆、包装和日用品等按项目国家／时代的西方外形、规格和用法设计；不以中国制式、中文标签或中式传统物件充当泛用替代。保留剧情实体、数量、关键结构、实例流转与尺度。不以制造产地或品牌国籍猜测“是否西方”，核对画面设计与故事功能。 |

## 文字与Prompt

- 补图／编辑的生成Prompt正文用完整英文，写清具体国家／时代、主体、参考职责和必要动作状态；中文条目标题、文件路径、制作记录、剧本和阅读附件可以保留中文，不做全工作区中文扫描禁用。
- 图片不出现中文、汉字或仿中文乱码。默认无需文字就保持无文字；无Logo／品牌／水印及视频无可读文字等原约束不变。“必须英文”不等于每张图都要添加英文招牌、字幕或标签。
- 剧情确需可读文字且该用途已允许时，只用自然、正确的英文，按[完整补充资产](complete-asset-generation.md)尽量直接在AIGC补图／编辑中准确完成，不预设人工P字或后期合成。不能用英文乱码冒充证据，不在锁定的视频词中擅自补写可读英文。
- 用正向的具体描述控制美术，末尾简洁补充必要的排除项，不堆大段与本图无关的国家／风格否定词。

示例只是写词方式，不作为新资产需求或固定附加模板：

```text
Character: An original non-Asian Western actress portraying the established character, retaining her identity from the supplied reference and the required current transformation. [Describe the actual age, role, expression and required design in English.] No Chinese writing, logos or watermark.
Scene: An empty contemporary suburban street in the established US setting, with [the actual required road, houses and entrances]. Retain the supplied location reference's layout and camera view. No people, Chinese writing or Chinese decorative motifs; no readable signage unless explicitly required.
Prop: [The actual story object] in the established Western setting and period, with [the required structure, scale and material]. Neutral product reference, no people or hands, no Chinese writing, logo or watermark; no text unless required.
```

不能把方括号示例原样提交，不机械追加美国设定到英国剧或欧洲年代戏。

## 放入现有执行链，不新增昂贵关卡

1. **必要性与选参考**：先按资产规划复用正确原母图、轻微状态用镜头文字；无叙事作用的细节不建图片需求。确需补图时，在已有需求／调用记录中注明项目地域时代、美术基准及英文Prompt，检查参考是否本身含不合适的地域／文字元素，避免错误参考压过提示词。不新建第二套长表或收费“风格样张”。
2. **生成前**：在原Prompt和参数核对中检查上述三类要求。资产合规ACTIVE、人名英文或文件名匹配不证明美术正确。发现明确源稿／锁定角色与本条冲突时只暂缓受影响项并说明，不擅自换脸、改剧本或重写LOCK；其他独立工作继续。
3. **看图验收**：合并到现有导入分析／生成前资产看图中，实际查看有无中文／乱码、地域和时代明显错置、错误参考导致的身份或形态漂移，记录在既有 requirement／observation 字段；已有同图哈希的真实观察可复用。人物选型按已确认人设、参考来源及具体外形要求核对，不凭真人照片臆断其实际族裔；不确定时如实记录，不给脚本增加“自动族裔识别”。
4. **失败修正**：优先换用已有合适资产，必要编辑只改受影响层，保留同一身份、必要变身、场景布局和道具实例。仍按原图片授权、共享认领与最多两次追加尝试执行，不因地域检查重新计数，也不以新规则为由自动收费返修旧项目。

本条是Agent选图／写词／看图的执行标准。现有程序只校验视觉证据的完整性，不会自动识别图中中文、人物选型或欧美审美；离线测试不能证明图片符合要求，输入通过不等于成片通过。
