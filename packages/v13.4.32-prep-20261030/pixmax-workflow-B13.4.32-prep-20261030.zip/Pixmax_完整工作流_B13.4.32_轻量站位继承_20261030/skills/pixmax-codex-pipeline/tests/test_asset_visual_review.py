import copy
import unittest
from test_saved_batch import fixtures
from asset_visual_review import validate_visual_review
from pixmax_pipeline import PipelineError


class AssetVisualReviewTests(unittest.TestCase):
    def setUp(self):
        self.manifest,self.nodes=fixtures()
        self.shot=self.manifest['shots'][0]
        self.by_node={n['uuid']:n for n in self.nodes}

    def test_complete_evidence_passes(self):
        validate_visual_review(self.shot,self.by_node)

    def test_same_node_new_asset_invalidates_review(self):
        self.by_node['scene-1']['defaultAsset']['assetsUuid']='replacement-night-room'
        with self.assertRaises(PipelineError): validate_visual_review(self.shot,self.by_node)

    def test_prompt_and_script_hash_changes_invalidate_review(self):
        original=copy.deepcopy(self.shot)
        self.shot['params']['prompt']+='new requirement'
        with self.assertRaises(PipelineError): validate_visual_review(self.shot,self.by_node)
        self.shot=original; self.shot['visual_review']['script_sha256']='stale'
        with self.assertRaises(PipelineError): validate_visual_review(self.shot,self.by_node)

    def test_unseen_unclear_or_missing_images_cannot_pass(self):
        original=copy.deepcopy(self.shot['visual_review'])
        for key,value in [('viewed',False),('status','UNCERTAIN'),('observation','')]:
            self.shot['visual_review']=copy.deepcopy(original)
            self.shot['visual_review']['images'][0][key]=value
            with self.assertRaises(PipelineError): validate_visual_review(self.shot,self.by_node)
        self.shot['visual_review']=original
        self.shot['visual_review']['images'].pop()
        with self.assertRaises(PipelineError): validate_visual_review(self.shot,self.by_node)

    def test_order_and_node_identity_are_bound_to_review(self):
        self.shot['visual_review']['images'].reverse()
        with self.assertRaises(PipelineError): validate_visual_review(self.shot,self.by_node)
        self.shot['visual_review']['images'].reverse()
        self.shot['visual_review']['node_uuid']='other-node'
        with self.assertRaises(PipelineError): validate_visual_review(self.shot,self.by_node)
