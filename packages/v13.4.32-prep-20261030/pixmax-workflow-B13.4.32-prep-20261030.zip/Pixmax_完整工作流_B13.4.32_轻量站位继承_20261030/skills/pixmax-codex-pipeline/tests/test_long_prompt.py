import copy
import hashlib
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
sys.path.insert(0, str(ROOT / 'runtime-overlay'))
from fast_bind import compile_batch, compile_mentions, apply_binding_edits
from submit_saved_batch import validate_shot, PipelineError
from resolve_saved_batch import resolve
from pixmax.prompt_file import expand_prompt_file
from pixmax.pixmax_cli import _validate_model_params


class LongPromptTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name) / 'prompt with spaces.md'
        self.raw = ('# 第01集\r\n总时长：30秒｜画幅：9:16竖屏\r\n'
            '## 1. 人物指定\r\n**林夕：** 左臂受伤。\r\n继续维持人物状态。\r\n'
            '## 2. 场景指定\r\n**客厅｜夜｜内：** 窗在右侧。\r\n'
            '## 3. 道具指定\r\n**信纸：** 右手持有。\r\n'
            '## 4. 时间线镜头设计\r\n林夕说：“请留下。”\r\n' + '动作与对白保持原文。' * 1100 + '\r\n')
        self.path.write_bytes(self.raw.encode('utf-8'))
        self.refs = [{'category': c, 'node_uuid': uid, 'designation': name} for c,uid,name in
                     [('character','c','林夕'), ('scene','s','客厅'), ('prop','p','信纸')]]
        self.nodes = [{'uuid': x['node_uuid'], 'label': x['designation'], 'type': 'BASE_IMAGE',
                       'defaultAsset': {'assetsUuid':'asset-'+x['node_uuid']}} for x in self.refs]
        self.shot = {'id':'EP01_S001', 'label':'test long', 'prompt_file':str(self.path),
                     'prompt_role':'seedance25_30s', 'bindings':self.refs, 'max_image_inputs':30,
                     'max_prompt_chars':1024, 'supported_durations':list(range(4,31)),
                     'params':{'nodeType':'GENERATE_VIDEO','model':'PIXDANCE_2_5_DRAFT', 'duration':'30',
                               'count':'1','referModel':'referToVideo'}}

    def record(self):
        manifest,_ = compile_batch({'file_uuid':'test','shots':[self.shot]}, self.nodes)
        row=manifest['shots'][0]
        actual={'uuid':row['node_uuid'],'label':row['label'],'params':copy.deepcopy(row['params']),
                'prevNodeUuids':row['prevNodeUuids']}
        return manifest,row,actual

    def test_long_v12_preserves_text_and_requires_exact_saved_text(self):
        manifest,row,actual=self.record()
        self.assertGreater(len(row['params']['prompt']),10000)
        self.assertTrue(row['prompt_length_check']['exceeds_schema_hint'])
        self.assertEqual(apply_binding_edits(self.raw,row['binding_edits']),row['params']['prompt'])
        self.assertEqual(self.path.read_bytes(),self.raw.encode('utf-8'))
        self.assertEqual(row['source_sha256'],hashlib.sha256(self.path.read_bytes()).hexdigest())
        self.assertIn('**林夕：** %%@[林夕][image][0](c)%%',row['params']['prompt'])
        validate_shot(row,actual)
        resolved=resolve(manifest,[actual])
        self.assertTrue(resolved['shots'][0]['prompt_length_check']['save_verified'])
        actual['params']['prompt']=actual['params']['prompt'][:1024]
        with self.assertRaises(PipelineError): validate_shot(row,actual)

    def test_rebinding_v12_is_idempotent(self):
        _,row,_=self.record()
        bound,_,edits=compile_mentions(row['params']['prompt'],self.refs,row['binding_labels'],'seedance25_30s')
        self.assertEqual(bound,row['params']['prompt'])
        self.assertEqual(edits,[])

    def test_no_silent_new_length_limit(self):
        del self.shot['max_prompt_chars']
        _,row,_=self.record()
        self.assertIsNone(row['prompt_length_check']['schema_max_characters'])

    def test_wrong_duration_or_model_still_fails(self):
        for key,value in [('duration','15'),('model','PIXDANCE_2_FAST')]:
            with self.subTest(key=key):
                old=self.shot['params'][key]
                self.shot['params'][key]=value
                with self.assertRaises(PipelineError): self.record()
                self.shot['params'][key]=old

    def test_outside_designation_mention_still_fails(self):
        self.path.write_bytes((self.raw+'%%@[Wrong][image][0](c)%%').encode('utf-8'))
        with self.assertRaises(PipelineError): self.record()

    def test_file_transport_preserves_more_than_windows_command_limit(self):
        text=self.raw*5
        self.path.write_bytes(text.encode('utf-8'))
        expanded=expand_prompt_file(['node','create','test','--prompt-file',str(self.path),'--dry-run'])
        self.assertEqual(expanded[4],text)
        self.assertGreater(len(expanded[4]),32767)
        self.assertEqual(expanded[-1],'--dry-run')

    def test_module_entry_accepts_file_before_calling_main(self):
        self.path.write_bytes((self.raw * 5).encode('utf-8'))
        env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONIOENCODING='utf-8')
        env['PYTHONPATH'] = os.pathsep.join([str(ROOT / 'runtime-overlay'), env.get('PYTHONPATH', '')])
        result = subprocess.run([sys.executable, '-m', 'pixmax', 'node', 'create', '--help',
                                 '--prompt-file', str(self.path)], env=env,
                                capture_output=True, timeout=20)
        self.assertEqual(result.returncode, 0, result.stderr.decode('utf-8', errors='replace'))
        self.assertIn('--prompt', result.stdout.decode('utf-8'))

    def test_file_transport_rejects_conflicting_prompt_and_invalid_text(self):
        for extra in [['--prompt','other'],['--set','prompt=other'],['--prompt-file',str(self.path)]]:
            with self.assertRaises(ValueError): expand_prompt_file(['--prompt-file',str(self.path)]+extra)
        for text in ['', '\ufefftext', 'a\x00b']:
            self.path.write_bytes(text.encode('utf-8'))
            with self.assertRaises(ValueError): expand_prompt_file(['--prompt-file='+str(self.path)])

    def test_cli_only_defers_prompt_length(self):
        schema={'modelCode':'test','canvasNodeType':'GENERATE_VIDEO','modelConfig':{'params':[
            {'name':'prompt','type':'text','length':'[0,1024]'},
            {'name':'otherText','type':'text','length':'[0,4]'},
            {'name':'resolution','type':'select','options':[{'value':'720P'}]}]}}
        self.assertEqual(_validate_model_params(schema,{'prompt':self.raw},node_type='GENERATE_VIDEO'),[])
        errors=_validate_model_params(schema,{'prompt':self.raw,'otherText':'too long','resolution':'BAD'},node_type='GENERATE_IMAGE')
        self.assertEqual(len(errors),3)


if __name__=='__main__': unittest.main()
