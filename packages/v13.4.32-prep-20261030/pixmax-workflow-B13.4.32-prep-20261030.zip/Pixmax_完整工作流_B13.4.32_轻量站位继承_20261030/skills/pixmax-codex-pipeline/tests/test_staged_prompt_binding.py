"""Staged director format must not expand asset edits into geometry or dialogue."""
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
from fast_bind import compile_mentions, apply_binding_edits

PROMPT = '''# 测试
总时长：6秒｜画幅：9:16竖屏｜构图模式
## 1. 人物指定
**林夕：** 清醒，紧张而克制。
**周远：** 态度坚决。
## 2. 场景指定
**大厅｜日｜内：** 侧窗冷光。
## 3. 道具指定
本段无剧情道具。
## 4. 人物开场站位
林夕靠入口，周远在台阶旁，两人面向对方，摄影机从入口朝台阶。
## 5. 时间线镜头设计
**整段剧情概述：** 周远告知离开，林夕回应。
### 镜头01｜0–3秒｜景别：全景｜周远作出决定｜固定
**构图：** 全程二人全身可见。背景：台阶。
**画面内容：** [0–3秒，镜内] 周远（现场对白）说：“我明天就走。”
### 镜头02｜3–6秒｜景别：上半身近景｜林夕回应｜固定
**构图：** 林夕胸部以上。背景：入口。
**画面内容：** [0–3秒，镜内] 林夕(现场对白):"看着我。"
## 6. 声音安排
室内环境声。
## 7. 输出要求
无字幕。
'''


class StagedPromptBinding(unittest.TestCase):
    def test_only_three_asset_sections_are_bound_and_source_is_reversible(self):
        refs = [{'category': 'character', 'node_uuid': 'person-a', 'designation': '林夕'},
                {'category': 'character', 'node_uuid': 'person-b', 'designation': '周远'},
                {'category': 'scene', 'node_uuid': 'scene-a', 'designation': '大厅'}]
        bound, _, edits = compile_mentions(PROMPT, refs,
            {'person-a': '林夕', 'person-b': '周远', 'scene-a': '大厅'}, 'seedance25_v134')
        start = PROMPT.index('## 4. 人物开场站位')
        self.assertEqual(PROMPT[start:], bound[bound.index('## 4. 人物开场站位'):])
        self.assertEqual(3, len(edits))
        reverse = []
        shift = 0
        for edit in edits:
            begin = edit['start'] + shift
            reverse.append({'start': begin, 'end': begin + len(edit['after']),
                            'before': edit['after'], 'after': edit['before']})
            shift += len(edit['after']) - (edit['end'] - edit['start'])
        self.assertEqual(PROMPT, apply_binding_edits(bound, reverse))


if __name__ == '__main__':
    unittest.main()
