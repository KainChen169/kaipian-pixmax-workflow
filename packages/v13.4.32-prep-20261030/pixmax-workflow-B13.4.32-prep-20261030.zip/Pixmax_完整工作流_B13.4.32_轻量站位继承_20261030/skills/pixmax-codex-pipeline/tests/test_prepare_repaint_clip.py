import importlib.util
import math
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest

spec=importlib.util.spec_from_file_location('prepare_repaint_clip',Path(__file__).resolve().parents[1]/'scripts/prepare_repaint_clip.py')
clipper=importlib.util.module_from_spec(spec);spec.loader.exec_module(clipper)


class MappingTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='pixmax-repaint-map-')
        self.root=Path(self.tmp.name);self.source=self.root/'source.mp4';self.source.write_bytes(b'local-source-for-plan')
    def tearDown(self):self.tmp.cleanup()
    def test_source_to_clip_mapping(self):
        p=clipper.make_plan(self.source,5,11,6,10)
        self.assertEqual(p['repair_window_clip_seconds'],[1,5])
        self.assertEqual(p['requested_cut_duration_seconds'],6)
        self.assertFalse(p['paid_generation_submitted'])
    def test_bad_windows_rejected(self):
        for args in [(5,11,4,10),(5,11,6,12),(0,3,0,2),(-1,5,0,3),(0,31,1,2),(0,9,math.nan,2)]:
            with self.subTest(args=args),self.assertRaises(ValueError):clipper.make_plan(self.source,*args)
    def test_dynamic_input_limits(self):
        self.assertEqual(clipper.make_plan(self.source,0,31,1,2,4,40)['requested_cut_duration_seconds'],31)
    def test_prompt_and_source_changes_invalidate_plan(self):
        prompt=self.root/'prompt.txt';prompt.write_text('original dialogue',encoding='utf-8')
        first=clipper.make_plan(self.source,0,9,0,2.25,prompt=prompt)
        prompt.write_text('different dialogue',encoding='utf-8')
        second=clipper.make_plan(self.source,0,9,0,2.25,prompt=prompt)
        self.assertNotEqual(first['plan_sha256'],second['plan_sha256'])
        self.source.write_bytes(b'updated-source')
        third=clipper.make_plan(self.source,0,9,0,2.25,prompt=prompt)
        self.assertNotEqual(second['plan_sha256'],third['plan_sha256'])


FFMPEG=os.environ.get('FFMPEG_BINARY') or shutil.which('ffmpeg')
@unittest.skipUnless(FFMPEG,'Set FFMPEG_BINARY to run real video cutting tests')
class CuttingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory(prefix='pixmax-repaint-video-');cls.root=Path(cls.tmp.name);cls.source=cls.root/'source.mp4'
        subprocess.run([FFMPEG,'-hide_banner','-loglevel','error','-nostdin','-n','-f','lavfi','-i','testsrc2=size=120x200:rate=24:duration=12','-f','lavfi','-i','sine=frequency=440:sample_rate=16000:duration=12','-c:v','libx264','-preset','ultrafast','-pix_fmt','yuv420p','-c:a','aac','-shortest',str(cls.source)],check=True,capture_output=True,timeout=60)
    @classmethod
    def tearDownClass(cls):cls.tmp.cleanup()
    def test_real_cut_mapping_audio_and_cache(self):
        p=clipper.make_plan(self.source,5,11,6,10);out=self.root/'valid-cut'
        first=clipper.prepare(p,out,FFMPEG)
        self.assertEqual(first['clip_media']['decoded_video_frames'],144)
        self.assertEqual(first['clip_media']['video_seconds_from_frames_and_rate'],6)
        self.assertEqual((first['clip_media']['width'],first['clip_media']['height']),(120,200))
        self.assertTrue(first['clip_media']['has_audio'])
        mtime=(out/'repaint-reference.mp4').stat().st_mtime_ns
        second=clipper.prepare(p,out,'no-such-ffmpeg-must-not-be-invoked')
        self.assertTrue(second['reused_existing_clip'])
        self.assertEqual((out/'repaint-reference.mp4').stat().st_mtime_ns,mtime)
        changed=clipper.make_plan(self.source,0,9,0,2.25)
        with self.assertRaises(ValueError):clipper.prepare(changed,out,FFMPEG)
        self.assertEqual(clipper.sha256(out/'repaint-reference.mp4'),first['clip_sha256'])
    def test_untracked_clip_preserved(self):
        out=self.root/'untracked';out.mkdir();file=out/'repaint-reference.mp4';file.write_bytes(b'keep me')
        with self.assertRaises(ValueError):clipper.prepare(clipper.make_plan(self.source,0,9,0,2.25),out,FFMPEG)
        self.assertEqual(file.read_bytes(),b'keep me')
    def test_cut_beyond_actual_media_rejected(self):
        p=clipper.make_plan(self.source,9,13,10,11)
        with self.assertRaises(ValueError):clipper.prepare(p,self.root/'out-of-bounds',FFMPEG)
        self.assertFalse((self.root/'out-of-bounds').exists())


if __name__=='__main__':unittest.main()
