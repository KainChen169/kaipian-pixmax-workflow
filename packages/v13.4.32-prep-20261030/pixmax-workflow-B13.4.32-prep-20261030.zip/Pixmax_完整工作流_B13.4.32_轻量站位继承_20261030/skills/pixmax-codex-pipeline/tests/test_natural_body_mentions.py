"""Offline native-reference round trips for natural visual/performance fields."""
import copy
import unittest
from pathlib import Path
from test_shot_body_mentions import RAW, POINTS, REFS, LABELS, point
import test_shot_body_mentions as legacy
from fast_bind import apply_binding_edits
from shot_body_mentions import body_edits
from submit_saved_batch import validate_shot, PipelineError

NEW = RAW.replace('整段剧情概述', '导演指导').replace('**构图：**', '**画面：**').replace('**画面内容：**', '**表演：**')

class NaturalBodyMentions(unittest.TestCase):
    def setUp(self):
        legacy.ShotBodyBindingTests.setUp(self)
        self.path.write_bytes(NEW.encode())
        self.shot['body_mentions'] = copy.deepcopy(POINTS)
        for p in self.shot['body_mentions']:
            p['field'] = {'构图':'画面', '画面内容':'表演'}[p['field']]

    record = legacy.ShotBodyBindingTests.record

    def test_current_director_example_roundtrip_without_rewriting(self):
        source = Path(__file__).resolve().parents[2] / 'ab-test-seedance25-director-compiler-v13-4-0/assets/examples/natural_performance.prompt.md'
        raw = source.read_text()
        self.path.write_text(raw)
        refs = [dict(category='character',node_uuid=u,designation=n) for u,n in [('a','林夕'),('b','周远'),('c','陈宁')]]
        refs.append(dict(category='scene',node_uuid='s',designation='大厅'))
        self.shot['bindings'] = refs
        self.shot['params']['duration'] = 8
        self.shot['body_mentions'] = [point(1,'大厅','s','画面'),point(1,'林夕','a','画面'),point(1,'周远','b','画面'),point(2,'林夕','a','画面'),point(3,'周远','b','画面'),point(3,'林夕','a','画面')]
        self.nodes = [dict(uuid=b['node_uuid'],label=b['designation'],type='BASE_IMAGE',defaultAsset={'assetsUuid':'asset-'+b['node_uuid']}) for b in refs]
        _,row,actual = self.record()
        validate_shot(row,actual)
        bound = row['params']['prompt']
        self.assertEqual(4,len(row['prevNodeUuids']))
        self.assertEqual(10,bound.count('%%@'))
        for quote in ('“I leave tomorrow.”','“Look at me.”'):
            self.assertIn(quote,bound)
        for line in raw.splitlines():
            if line.startswith('**导演指导：**') or line.startswith('摄影机从入口'):
                self.assertIn(line,bound)
        reverse=[];delta=0
        for edit in row['binding_edits']:
            start=edit['start']+delta
            reverse.append(dict(start=start,end=start+len(edit['after']),before=edit['after'],after=edit['before']))
            delta+=len(edit['after'])-len(edit['before'])
        self.assertEqual(raw,apply_binding_edits(bound,reverse))
        self.assertEqual(raw,self.path.read_text())

    def test_compiles_and_readback_validates_all_assets_once_per_input(self):
        _,row,actual=self.record()
        validate_shot(row,actual)
        self.assertEqual(4,len(row['prevNodeUuids']))
        self.assertEqual(11,row['params']['prompt'].count('%%@'))
        self.assertEqual(NEW.encode(),self.path.read_bytes())

    def test_source_reversal_and_quotes_preserved(self):
        self.path.write_bytes(NEW.replace('\n','\r\n').encode())
        _,row,_=self.record()
        reverse=[];delta=0
        for edit in row['binding_edits']:
            start=edit['start']+delta
            reverse.append(dict(start=start,end=start+len(edit['after']),before=edit['after'],after=edit['before']))
            delta+=len(edit['after'])-len(edit['before'])
        restored=apply_binding_edits(row['params']['prompt'],reverse)
        self.assertEqual(self.path.read_bytes(),restored.encode())
        self.assertIn('“周远，看着我。”',row['params']['prompt'])

    def test_action_field_variants(self):
        for label in ('动作','动作与表演'):
            self.path.write_text(NEW.replace('**表演：**',f'**{label}：**'))
            for p in self.shot['body_mentions']:
                if p['field']!='画面':p['field']=label
            _,row,actual=self.record()
            validate_shot(row,actual)

    def test_duplicate_across_visual_and_performance_rejected(self):
        self.shot['body_mentions'].append(point(1,'林夕','a','画面'))
        with self.assertRaises(PipelineError):self.record()

    def test_guidance_staging_sound_and_dialogue_not_bindable(self):
        for start in [NEW.index('林夕在大厅'),NEW.index('林夕靠门'),
                      NEW.index('林夕与周远的对白'),NEW.index('周远，看着我')]:
            text='周远' if NEW[start:].startswith('周远') else '林夕'
            uid='b' if text=='周远' else 'a'
            anchor=dict(start=start,end=start+len(text),text=text,node_uuid=uid,purpose='visible_character')
            with self.assertRaises(PipelineError):body_edits(NEW,REFS,LABELS,[anchor])

    def test_fields_stop_before_nonshot_instruction(self):
        raw=NEW.replace('### 镜头02','**导演指导：** 林夕\n### 镜头02',1)
        start=raw.index('**导演指导：** 林夕\n')+len('**导演指导：** ')
        with self.assertRaises(PipelineError):
            body_edits(raw,REFS,LABELS,[dict(start=start,end=start+2,text='林夕',node_uuid='a',purpose='visible_character')])

    def test_offscreen_voice_not_visual_reference(self):
        for voice in ('画外对白','内心旁白','O.S.','V.O.'):
            raw=NEW.replace('林夕右手递出',f'林夕（{voice}）右手递出')
            with self.assertRaises(PipelineError):
                body_edits(raw,REFS,LABELS,[point(1,'林夕','a','表演')])

    def test_plain_field_and_alias_remain_supported(self):
        plain=NEW.replace('**画面：**','画面：').replace('**表演：**','表演：')
        self.assertTrue(body_edits(plain,REFS,LABELS,[point(1,'大厅','s','画面')]))

    def test_animation_original_speech_labels_are_protected_at_any_length(self):
        for label in ('原话（林夕／现场对白→周远）：「Wait.」',
                      '原话（林夕／现场对白→楼梯门口的周远和所有听众）〔声线：older/v1〕：「Wait.」'):
            raw = NEW.replace('### 镜头02', label + '\n### 镜头02', 1)
            for name, uid in [('林夕','a'), ('周远','b')]:
                start = raw.index(label) + label.index(name)
                with self.assertRaises(PipelineError):
                    body_edits(raw, REFS, LABELS, [dict(start=start,end=start+len(name),text=name,node_uuid=uid,purpose='visible_character')])
            # A selector cannot wander into the addressee in the long label.
            with self.assertRaises(PipelineError):
                body_edits(raw,REFS,LABELS,[point(1,'周远','b','表演',occurrence=2)])

if __name__=='__main__':unittest.main()
