"""Offline spec gates; no platform actions or generation."""
import copy
import json
import tempfile
import unittest
from pathlib import Path
from seedance25_contract import validate_video_spec, prepare_video_spec, DEFAULT_VIDEO_MODEL
from pixmax_pipeline import PipelineError, load_manifest
from submit_saved_batch import validate_shot, run
import test_dual_modules_v134 as dual


class VideoSpecTests(unittest.TestCase):
    def params(self):
        return dict(nodeType='GENERATE_VIDEO', model='PIXDANCE_2_5_DRAFT', resolution='480P',
                    aspectRatio='9:16', includeAudio=True)

    def fixture(self):
        case=dual.DualModuleTests(methodName='test_integer_prompt_has_no_tail_extension')
        case.setUp(); self.addCleanup(case.doCleanups)
        return case

    def test_defaults_in_new_copy_are_explicit_and_do_not_touch_input(self):
        case=self.fixture()
        for key in ('resolution','aspectRatio','includeAudio'):del case.plan['shots'][0]['params'][key]
        before=copy.deepcopy(case.plan)
        row=case.compile()
        self.assertEqual(row['params']['resolution'],'480P')
        self.assertEqual(row['params']['aspectRatio'],'9:16')
        self.assertIs(row['params']['includeAudio'],True)
        self.assertEqual(case.plan,before)

    def test_boolean_or_cli_true_audio_pass(self):
        for value in (True,'true'):
            params=self.params();params['includeAudio']=value;validate_video_spec(params)

    def test_standard_480p_is_not_draft_and_is_not_silently_switched(self):
        params=self.params();params['model']='PIXDANCE_2_5'
        before=copy.deepcopy(params)
        for check in (validate_video_spec, prepare_video_spec):
            with self.assertRaisesRegex(PipelineError, 'DRAFT'):check(params)
        self.assertEqual(params,before)

    def test_live_action_missing_model_defaults_in_copy_only(self):
        case=self.fixture();del case.plan['shots'][0]['params']['model']
        before=copy.deepcopy(case.plan)
        self.assertEqual(case.compile()['params']['model'],DEFAULT_VIDEO_MODEL)
        self.assertEqual(case.plan,before)

    def test_explicit_standard_live_action_plan_is_blocked(self):
        case=self.fixture();case.plan['shots'][0]['params']['model']='PIXDANCE_2_5'
        with self.assertRaisesRegex(PipelineError, 'DRAFT'):case.compile()
        self.assertEqual(case.plan['shots'][0]['params']['model'],'PIXDANCE_2_5')

    def test_saved_standard_model_is_blocked_even_when_plan_also_standard(self):
        case=self.fixture();row=case.compile()
        for also_change_plan in (False,True):
            bad=copy.deepcopy(row)
            actual=dict(uuid=bad['node_uuid'],params=copy.deepcopy(bad['params']),prevNodeUuids=bad['prevNodeUuids'])
            actual['params']['model']='PIXDANCE_2_5'
            if also_change_plan:bad['params']['model']='PIXDANCE_2_5'
            with self.assertRaisesRegex(PipelineError,'DRAFT'):validate_shot(bad,actual)

    def test_required_seedance_role_cannot_bypass_with_other_or_missing_model(self):
        for model in (None,'PIXDANCE_2_FAST','unknown'):
            params=self.params()
            if model is None:del params['model']
            else:params['model']=model
            with self.assertRaises(PipelineError):validate_video_spec(params,required=True)

    def test_model_omitted_in_manifest_defaults_to_draft_with_sound(self):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'manifest.json'
            base=dict(run_id='draft-test',project_name='draft-test',canvas_name='draft-test',episode='EP01',
                      shots=[dict(id='S01',prompt='Synthetic fixture')])
            path.write_text(json.dumps(base),encoding='utf-8')
            result=load_manifest(path)[0]['shots'][0]
            self.assertEqual((result['model'],result['resolution'],result['aspect_ratio'],result['audio']),
                             (DEFAULT_VIDEO_MODEL,'480P','9:16',True))
            base['shots'][0]['model']='PIXDANCE_2_5'
            path.write_text(json.dumps(base),encoding='utf-8')
            with self.assertRaisesRegex(PipelineError,'DRAFT'):load_manifest(path)

    def test_reasonable_short_and_twenty_second_segments_are_not_blocked(self):
        for duration in (4,5,6,9,10,12,23,27.6,30):
            params=self.params();params['duration']=duration;validate_video_spec(params)

    def test_over_30_rejected_even_when_schema_might_allow_more(self):
        params=self.params();params['duration']=31
        with self.assertRaises(PipelineError):validate_video_spec(params)

    def test_wrong_or_missing_saved_settings_fail(self):
        for field,values in {'resolution':('720P','1080P',None),
                             'aspectRatio':('16:9','3:4',None),
                             'includeAudio':(False,'false',None,1,'1')}.items():
            for value in values:
                with self.subTest(field=field,value=value):
                    params=self.params();params[field]=value
                    with self.assertRaises(PipelineError):validate_video_spec(params)
                    del params[field]
                    with self.assertRaises(PipelineError):validate_video_spec(params)

    def test_explicit_wrong_plan_not_silently_normalized(self):
        case=self.fixture();case.plan['shots'][0]['params']['resolution']='720P'
        with self.assertRaises(PipelineError):case.compile()
        self.assertEqual(case.plan['shots'][0]['params']['resolution'],'720P')

    def test_readback_rejects_wrong_settings_even_if_plan_also_wrong(self):
        case=self.fixture();row=case.compile()
        for key,value in (('resolution','720P'),('aspectRatio','16:9'),('includeAudio',False)):
            bad=copy.deepcopy(row);bad['params'][key]=value
            actual=dict(uuid=bad['node_uuid'],params=copy.deepcopy(bad['params']),prevNodeUuids=bad['prevNodeUuids'])
            with self.assertRaises(PipelineError):validate_shot(bad,actual)

    def test_readback_rejects_template_or_platform_drift(self):
        case=self.fixture();row=case.compile()
        for key,value in (('resolution','720P'),('aspectRatio','16:9'),('includeAudio',False)):
            actual=dict(uuid=row['node_uuid'],params=copy.deepcopy(row['params']),prevNodeUuids=row['prevNodeUuids'])
            actual['params'][key]=value
            with self.assertRaises(PipelineError):validate_shot(row,actual)

    def test_non_video_and_other_models_not_changed(self):
        for params in (dict(nodeType='GENERATE_IMAGE',model='PIXDANCE_2_5_DRAFT',resolution='1K'),
                       dict(nodeType='GENERATE_VIDEO',model='PIXDANCE_2_FAST',resolution='720P')):
            before=copy.deepcopy(params);prepare_video_spec(params);self.assertEqual(params,before)

    def test_legacy_manifest_defaults_and_explicit_bad_values(self):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'manifest.json'
            base=dict(run_id='spec-test',project_name='spec-test',canvas_name='spec-test',episode='EP01',
                      shots=[dict(id='S01',prompt='Synthetic fixture',model='PIXDANCE_2_5_DRAFT')])
            path.write_text(json.dumps(base),encoding='utf-8')
            normalized,_,_=load_manifest(path)
            shot=normalized['shots'][0]
            self.assertEqual(shot['resolution'],'480P');self.assertEqual(shot['aspect_ratio'],'9:16')
            self.assertIs(shot['audio'],True)
            for key,value in (('resolution','720P'),('aspect_ratio','16:9'),('audio',False),('audio','false')):
                bad=copy.deepcopy(base);bad['shots'][0][key]=value
                path.write_text(json.dumps(bad),encoding='utf-8')
                with self.assertRaises(PipelineError):load_manifest(path)

    def test_status_only_can_reconcile_historical_720_without_writing_nodes(self):
        case=self.fixture();row=case.compile();row['params'].update(model='PIXDANCE_2_5',resolution='720P')
        def api(*args):
            self.assertEqual(args[:2],('tasks','progress'))
            return {'data':[{'nodeUuid':row['node_uuid'],'taskUuid':'old-task','status':'COMPLETE'}]}
        with tempfile.TemporaryDirectory() as directory:
            result=run({'file_uuid':'canvas','shots':[row]},Path(directory),status_only=True,api=api)
        self.assertEqual(result['mode'],'reconcile');self.assertFalse(result['resubmitted'])

if __name__=='__main__':unittest.main()
