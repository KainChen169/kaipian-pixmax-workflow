"""Scoped repeated references preserve raw story, unique wiring and old manifests."""
import copy
import hashlib
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
from fast_bind import compile_batch, compile_for_policy, compile_mentions, apply_binding_edits
from shot_body_mentions import POLICY, LEGACY, body_edits
from submit_saved_batch import validate_shot, PipelineError
from resolve_saved_batch import resolve

RAW = '''# EP01
总时长：6秒｜画幅：9:16竖屏
## 1. 人物指定
**林夕：** 紧张。
**周远：** 克制。
## 2. 场景指定
**大厅｜夜｜内：** 室内灯光。
## 3. 道具指定
**信封：** 林夕右手持有。
## 4. 人物开场站位
林夕靠门，周远靠台阶。
## 5. 时间线镜头设计
**整段剧情概述：** 林夕在大厅交出信封。
### 镜头01｜0–3秒｜景别：全景｜林夕递信封｜固定
**构图：** 大厅中林夕与周远分居两侧。背景：台阶。
**画面内容：** 林夕右手递出信封，对周远说：“周远，看着我。”
### 镜头02｜3–6秒｜景别：上半身近景｜周远接信封｜固定
**构图：** 周远面部清楚。背景：大厅的入口虚化。
**画面内容：** 周远接住信封，林夕松手。周远说："Don't leave, 林夕."
## 6. 声音安排
林夕与周远的对白，衣料声。
## 7. 输出要求
无字幕。
'''
REFS = [{'category': c, 'node_uuid': u, 'designation': n} for c, u, n in
        [('character', 'a', '林夕'), ('character', 'b', '周远'), ('scene', 's', '大厅'), ('prop', 'p', '信封')]]
LABELS = {b['node_uuid']: b['designation'] for b in REFS}


def point(shot, text, uid, field='画面内容', **extra):
    purpose = {'a': 'visible_character', 'b': 'visible_character', 's': 'scene', 'p': 'visible_prop'}[uid]
    return dict(subshot=shot, field=field, text=text, node_uuid=uid, purpose=purpose, **extra)


POINTS = [point(1, '大厅', 's', '构图'), point(1, '林夕', 'a'), point(1, '周远', 'b'),
          point(1, '信封', 'p'), point(2, '周远', 'b'), point(2, '林夕', 'a'), point(2, '信封', 'p')]


class ShotBodyBindingTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name) / 'source.md'
        self.path.write_bytes(RAW.encode())
        self.shot = dict(id='EP01_S001', label='new video', prompt_file=str(self.path),
                         prompt_role='seedance25_v134', binding_policy=POLICY,
                         body_mentions=copy.deepcopy(POINTS), bindings=copy.deepcopy(REFS),
                         max_image_inputs=4, supported_durations=list(range(4, 31)),
                         params=dict(nodeType='GENERATE_VIDEO', model='PIXDANCE_2_5_DRAFT', duration=6, count=1, referModel='referToVideo'))
        self.nodes = [dict(uuid=b['node_uuid'], label=b['designation'], type='BASE_IMAGE',
                           defaultAsset={'assetsUuid': 'asset-' + b['node_uuid']}) for b in REFS]

    def record(self):
        manifest, _ = compile_batch(dict(file_uuid='canvas', shots=[self.shot]), self.nodes)
        row = manifest['shots'][0]
        return manifest, row, dict(uuid=row['node_uuid'], label=row['label'],
                                   params=copy.deepcopy(row['params']), prevNodeUuids=row['prevNodeUuids'])

    def test_v2_all_three_categories_and_repeat_uuid_share_four_inputs(self):
        _, row, actual = self.record()
        self.assertEqual(4, len(row['prevNodeUuids']))
        self.assertEqual(11, row['params']['prompt'].count('%%@'))
        self.assertEqual(row['params']['prompt'].count('(b)%%'), 3)
        validate_shot(row, actual)
        self.assertEqual(self.path.read_bytes(), RAW.encode())
        self.assertIn('“周远，看着我。”', actual['params']['prompt'])
        self.assertIn('"Don\'t leave, 林夕."', actual['params']['prompt'])

    def test_reverse_edits_restore_every_byte_crlf_and_daynight(self):
        self.path.write_bytes(RAW.replace('\n', '\r\n').encode())
        _, row, actual = self.record()
        raw = self.path.read_bytes().decode()
        self.assertEqual(apply_binding_edits(raw, row['binding_edits']), row['params']['prompt'])
        reverse, delta = [], 0
        for e in row['binding_edits']:
            pos = e['start'] + delta
            reverse.append(dict(start=pos, end=pos + len(e['after']), before=e['after'], after=e['before']))
            delta += len(e['after']) - len(e['before'])
        self.assertEqual(apply_binding_edits(row['params']['prompt'], reverse).encode(), self.path.read_bytes())
        self.assertIn('大厅｜夜｜内', row['params']['prompt'])
        validate_shot(row, actual)

    def test_recompile_is_deterministic(self):
        first = self.record()[1]
        second = self.record()[1]
        for key in ('params', 'binding_edits', 'mention_ranges', 'bound_prompt_sha256', 'body_mentions'):
            self.assertEqual(first[key], second[key])

    def test_resolver_preserves_body_plan_with_platform_assigned_uuid(self):
        manifest, row, actual = self.record()
        actual['uuid'] = 'saved-new-id'
        saved = resolve(manifest, [actual])['shots'][0]
        self.assertEqual(saved['node_uuid'], 'saved-new-id')
        self.assertEqual(saved['body_mentions'], row['body_mentions'])

    def test_extra_missing_wrong_uuid_index_and_label_fail_even_with_new_hash(self):
        mutations = [lambda s: s + ' %%@[林夕][image][0](a)%%',
                     lambda s: s.replace(' %%@[林夕][image][0](a)%%', '', 1),
                     lambda s: s.replace('[0](a)', '[0](b)'),
                     lambda s: s.replace('[0](a)', '[9](a)'),
                     lambda s: s.replace('%%@[林夕]', '%%@[周远]')]
        for mutate in mutations:
            _, row, actual = self.record()
            row['params']['prompt'] = mutate(row['params']['prompt'])
            row['bound_prompt_sha256'] = hashlib.sha256(row['params']['prompt'].encode()).hexdigest()
            actual['params'] = copy.deepcopy(row['params'])
            with self.assertRaises(PipelineError):
                validate_shot(row, actual)

    def test_dialogue_performance_and_daynight_tampering_still_fail(self):
        for before, after in [('看着我', '离开我'), ('接住信封', '扔掉信封'), ('夜｜内', '日｜内')]:
            _, row, actual = self.record()
            row['params']['prompt'] = row['params']['prompt'].replace(before, after)
            actual['params'] = copy.deepcopy(row['params'])
            with self.assertRaises(PipelineError):
                validate_shot(row, actual)

    def test_changed_source_and_forged_ledger_fail(self):
        _, row, actual = self.record()
        row['binding_edits'][-1]['after'] += 'new action'
        with self.assertRaises(PipelineError): validate_shot(row, actual)
        _, row, actual = self.record()
        self.path.write_text(RAW + '\nchanged')
        with self.assertRaises(PipelineError): validate_shot(row, actual)

    def test_duplicate_same_asset_within_shot_fails(self):
        self.shot['body_mentions'].append(point(1, '周远', 'b', '构图'))
        with self.assertRaisesRegex(PipelineError, 'Duplicate body'): self.record()

    def test_quoted_names_never_receive_reference(self):
        for quote in ['“林夕”', '"林夕"', "'林夕'", '「林夕」', '『林夕』']:
            raw = RAW.replace('林夕松手。', '林夕松手。' + quote)
            start = raw.index(quote) + 1
            anchors = [dict(start=start, end=start+2, text='林夕', node_uuid='a', purpose='visible_character')]
            with self.assertRaisesRegex(PipelineError, 'protected dialogue'):
                body_edits(raw, REFS, LABELS, anchors)

    def test_selector_does_not_select_name_inside_dialogue(self):
        self.shot['body_mentions'] = [point(2, '林夕', 'a', occurrence=2)]
        with self.assertRaisesRegex(PipelineError, 'No unquoted'): self.record()

    def test_only_subshot_fields_not_summary_staging_title_or_sound(self):
        for needle in ['林夕靠门', '林夕在大厅', '林夕递信封', '林夕与周远的对白']:
            start = RAW.index(needle)
            anchors = [dict(start=start, end=start+2, text='林夕', node_uuid='a', purpose='visible_character')]
            with self.assertRaisesRegex(PipelineError, 'sub-shot'): body_edits(RAW, REFS, LABELS, anchors)

    def test_offscreen_and_unbound_or_wrong_variant_not_automatically_bound(self):
        for change in [dict(purpose='mentioned_only'), dict(purpose='offscreen'), dict(node_uuid='unbound'), dict(node_uuid='p')]:
            self.shot['body_mentions'] = [dict(point(1, '林夕', 'a'), **change)]
            with self.assertRaises(PipelineError): self.record()

    def test_source_offsets_must_match_and_not_be_partial(self):
        for anchors in [[dict(start=0, end=2, text='林夕', node_uuid='a', purpose='visible_character')],
                        [dict(start=0, text='林夕', node_uuid='a', purpose='visible_character')]]:
            self.shot['body_mentions'] = anchors
            with self.assertRaises(PipelineError): self.record()

    def test_explicit_offscreen_speaker_cannot_be_claimed_visible(self):
        self.path.write_text(RAW.replace('林夕右手递出', '林夕（O.S.）右手递出'))
        self.shot['body_mentions'] = [point(1, '林夕', 'a')]
        with self.assertRaisesRegex(PipelineError, 'offscreen'): self.record()

    def test_english_name_prefix_does_not_bind_a_different_name(self):
        raw = RAW.replace('林夕右手递出', 'Lina右手递出')
        self.path.write_text(raw)
        self.shot['bindings'][0]['body_aliases'] = ['Lin']
        self.shot['body_mentions'] = [point(1, 'Lin', 'a')]
        with self.assertRaisesRegex(PipelineError, 'longer name'): self.record()

    def test_alias_requires_explicit_mapping(self):
        raw = RAW.replace('林夕右手递出', '小夕右手递出')
        self.path.write_text(raw)
        self.shot['body_mentions'] = [point(1, '小夕', 'a')]
        with self.assertRaisesRegex(PipelineError, 'reviewed alias'): self.record()
        self.shot['bindings'][0]['body_aliases'] = ['小夕']
        _, row, actual = self.record()
        self.assertIn('小夕 %%@[林夕]', row['params']['prompt'])
        validate_shot(row, actual)

    def test_v1_historical_copy_unchanged_and_body_token_still_rejected(self):
        self.shot.pop('body_mentions')
        self.shot['binding_policy'] = LEGACY
        _, row, actual = self.record()
        self.assertEqual(row['params']['prompt'].count('%%@'), 4)
        validate_shot(row, actual)
        bound = row['params']['prompt'] + '\n%%@[林夕][image][0](a)%%'
        with self.assertRaises(PipelineError): compile_mentions(bound, REFS, LABELS, 'seedance25_v134')

    def test_v2_is_explicit_nonempty_and_not_a_legacy_role_upgrade(self):
        for role in ['original_15s', 'seedance25_30s']:
            with self.assertRaises(PipelineError): compile_for_policy(RAW, REFS, LABELS, role, POLICY, POINTS)
        for points in [None, [], 'all names']:
            with self.assertRaises(PipelineError): compile_for_policy(RAW, REFS, LABELS, 'seedance25_v134', POLICY, points)
        with self.assertRaises(PipelineError): compile_for_policy(RAW, REFS, LABELS, 'seedance25_v134', LEGACY, POINTS)

    def test_unique_wiring_order_and_limit_remain_enforced(self):
        self.shot['bindings'].append(copy.deepcopy(REFS[0]))
        with self.assertRaises(PipelineError): self.record()
        self.shot['bindings'] = copy.deepcopy(REFS)
        self.shot['max_image_inputs'] = 3
        with self.assertRaises(PipelineError): self.record()


if __name__ == '__main__':
    unittest.main()
