import importlib.util
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

SCRIPT = Path(__file__).resolve().parents[1] / 'scripts/review_prompt_repetition.py'
spec = importlib.util.spec_from_file_location('repetition_review', SCRIPT)
review = importlib.util.module_from_spec(spec)
spec.loader.exec_module(review)


def shot(number, visual, performance, prefix='###', duration='0.0—0.6'):
    return f'{prefix} 镜头{number:02d}｜{duration}秒｜景别：近景｜固定\n画面：{visual}\n表演：{performance}\n'


class PromptReviewTests(unittest.TestCase):
    def test_adjacent_exact_visual_returns_question_not_failure(self):
        result = review.inspect_text(shot(1, '固定看门口。', 'Mara抬手。') + shot(2, '固定看门口。', 'Mara放手。'))
        self.assertEqual('REVIEW_HINTS_ONLY', result['status'])
        self.assertEqual(['ADJACENT_VISUAL_COPY'], [h['kind'] for h in result['hints']])

    def test_same_window_copy(self):
        result = review.inspect_text(shot(1, '钥匙落下。', '钥匙落下。'))
        self.assertEqual('SAME_WINDOW_COPY', result['hints'][0]['kind'])

    def test_fixed_camera_and_short_shots_are_not_flags(self):
        result = review.inspect_text(shot(1, '固定近景看Mara交钥匙。', 'Mara松手。') + shot(2, '固定特写看Noah接钥匙的手。', '钥匙轻碰掌心。'))
        self.assertEqual([], result['hints'])
        self.assertEqual(2, result['paired_fields'])

    def test_no_cross_pack_repeated_heading_comparison(self):
        text = '# P01\n' + shot(1, '固定看门。', '她说话。') + '# P02\n' + shot(1, '固定看门。', '她继续说话。')
        self.assertEqual([], review.inspect_text(text)['hints'])

    def test_native_mentions_do_not_hide_repeated_prose(self):
        text = shot(1, 'Mara %%@one%% 在门边。', '她抬头。') + shot(2, 'Mara %%@two%% 在门边。', '她低头。')
        self.assertEqual(1, len(review.inspect_text(text)['hints']))

    def test_animation_and_legacy_bold_fields(self):
        text = shot(1, '手部近景。', '爪子松开钥匙。', prefix='####').replace('画面：', '**构图：**').replace('表演：', '**画面内容：**')
        self.assertEqual('recognized_shots_paired_fields_complete', review.inspect_text(text)['coverage'])

    def test_multiline_and_action_fields(self):
        text = shot(1, '钥匙近景。\n落点在桌面。', '钥匙落到桌面。').replace('表演：', '动作与表演：')
        self.assertEqual(1, review.inspect_text(text)['paired_fields'])

    def test_sound_and_guidance_do_not_count_as_shots_or_fields(self):
        text = shot(1, '门框近景。', 'Mara关门。') + '## 声音\n画面：无关同名字段。\n表演：无关同名字段。'
        self.assertEqual([], review.inspect_text(text)['hints'])
        self.assertEqual(1, review.inspect_text(text)['parsed_shots'])

    def test_unknown_format_and_missing_fields_are_not_clean_pass(self):
        for text in ('任何非支持格式', '### 镜头01｜0—1秒\n画面：门。'):
            result = review.inspect_text(text)
            self.assertEqual('partial_or_unrecognized', result['coverage'])
            self.assertNotEqual('PASS', result['status'])

    def test_mixed_format_does_not_claim_whole_document_coverage(self):
        result = review.inspect_text(shot(1, '门框近景。', '她关门。') + 'P01，镜头2，固定近景；画面：窗边。')
        self.assertEqual(1, result['parsed_shots'])
        self.assertEqual('recognized_shots_paired_fields_complete', result['coverage'])
        self.assertIn('不证明全文覆盖', result['coverage_scope'])

    def test_cli_hint_exit_zero_source_bytes_untouched(self):
        with tempfile.TemporaryDirectory() as folder:
            source = Path(folder) / 'prompt.md'
            raw = shot(1, '门。', '门。').replace('\n', '\r\n').encode()
            source.write_bytes(raw)
            result = subprocess.run([sys.executable, '-B', str(SCRIPT), str(source)], capture_output=True)
            self.assertEqual(0, result.returncode)
            self.assertIn(b'SAME_WINDOW_COPY', result.stdout)
            self.assertEqual(raw, source.read_bytes())


if __name__ == '__main__':
    unittest.main()
