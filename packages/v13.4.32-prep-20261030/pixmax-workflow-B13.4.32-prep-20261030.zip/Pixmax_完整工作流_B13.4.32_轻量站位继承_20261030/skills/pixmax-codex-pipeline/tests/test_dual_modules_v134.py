"""Synthetic offline integration checks; no platform requests or paid generation."""
import copy
import tempfile
import unittest
from pathlib import Path
from fast_bind import compile_batch, apply_binding_edits
from submit_saved_batch import validate_shot
from seedance25_contract import validate_duration
from pixmax_pipeline import PipelineError
from asset_visual_review import validate_visual_review
from test_saved_batch import fixtures
import test_scene_blocking_review_v2


class DualModuleTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name)/'prompt.md'
        self.raw = ('# 第03集\n总时长：27秒｜画幅：9:16\n'
                    '## 1. 人物指定\n**林夕：** 左臂包扎，项链佩戴。\n'
                    '## 2. 场景指定\n**客厅｜夜｜内：** 窗在右侧。\n'
                    '## 3. 道具指定\n**信纸：** 右手持有。\n'
                    '## 4. 时间线镜头设计\n')
        self.raw += '\n'.join(f'### 镜头{i+1}｜{i*2.25:g}–{(i+1)*2.25:g}秒｜中景\n构图：面向林夕。\n画面内容：动作持续。' for i in range(12))
        self.path.write_bytes(self.raw.encode('utf-8'))
        self.refs = [{'category':c, 'node_uuid':u, 'designation':n} for c,u,n in
                     [('character','c','林夕'),('scene','s','客厅'),('prop','p','信纸')]]
        self.nodes = [{'uuid':r['node_uuid'],'label':r['designation'],'type':'BASE_IMAGE',
                       'defaultAsset':{'assetsUuid':'asset-'+r['node_uuid']}} for r in self.refs]
        self.plan = {'file_uuid':'canvas','shots':[{'id':'EP03_S001','label':'EP03_S001',
                    'prompt_file':str(self.path),'prompt_role':'seedance25_v134','bindings':self.refs,
                    'max_image_inputs':30,'supported_durations':list(range(4,31)),
                    'params':{'nodeType':'GENERATE_VIDEO','model':'PIXDANCE_2_5_DRAFT','duration':'27',
                              'count':'1','referModel':'referToVideo','resolution':'480P',
                              'aspectRatio':'9:16','includeAudio':True}}]}

    def compile(self):
        m,_=compile_batch(self.plan,self.nodes)
        return m['shots'][0]

    def test_27_seconds_without_blocking_image_roundtrip_and_review_pending(self):
        row=self.compile()
        self.assertEqual(row['prevNodeUuids'],['c','s','p'])
        self.assertIn('[image][0](c)',row['params']['prompt'])
        self.assertNotIn('(b)%%',row['params']['prompt'])
        self.assertEqual(apply_binding_edits(self.raw,row['binding_edits']),row['params']['prompt'])
        self.assertEqual(self.path.read_text(encoding='utf-8'),self.raw)
        self.assertEqual(row['visual_review']['continuity_review']['status'],'PENDING')
        self.assertEqual(row['supported_durations'],list(range(4,31)))
        validate_shot(row,{'uuid':row['node_uuid'],'params':copy.deepcopy(row['params']),'prevNodeUuids':row['prevNodeUuids']})

    def test_single_segment_without_board_starts_character_at_zero(self):
        row=self.compile()
        self.assertIn('[image][0](c)',row['params']['prompt'])

    def test_new_role_rejects_legacy_last_board(self):
        self.plan['shots'][0]['bindings']=self.refs+[{'category':'blocking_reference','node_uuid':'b'}]
        with self.assertRaises(PipelineError): self.compile()

    def test_duration_parameter_cannot_override_prompt(self):
        self.plan['shots'][0]['params']['duration']='30'
        with self.assertRaises(PipelineError): self.compile()

    def fractional_prompt(self, seconds):
        self.raw = self.raw.replace('总时长：27秒', f'总时长：{seconds}秒')
        self.raw = self.raw.replace('24.75–27秒', f'24.75–{seconds}秒')
        self.path.write_bytes(self.raw.encode('utf-8'))

    def test_fractional_duration_rounds_up_without_rewriting_source(self):
        self.fractional_prompt(27.6)
        self.plan['shots'][0]['params']['duration'] = '27.6'
        row = self.compile()
        self.assertEqual(row['params']['duration'], '28')
        self.assertEqual(self.plan['shots'][0]['params']['duration'], '27.6')
        self.assertEqual(self.path.read_text(encoding='utf-8'), self.raw)
        self.assertEqual(apply_binding_edits(self.raw, row['binding_edits']), row['params']['prompt'])
        self.assertIn('24.75–27.6秒', row['params']['prompt'])
        self.assertEqual(row['duration_adaptation']['tail_extension_seconds'], 0.4)
        validate_shot(row, {'uuid':row['node_uuid'], 'params':copy.deepcopy(row['params']),
                            'prevNodeUuids':row['prevNodeUuids']})

    def test_decimal_float_parameter_and_already_rounded_value_are_allowed(self):
        self.fractional_prompt(27.6)
        for requested in (27.6, 28, '28'):
            self.plan['shots'][0]['params']['duration'] = requested
            self.assertEqual(float(self.compile()['params']['duration']), 28)

    def test_24_point_2_ceils_to_25(self):
        raw = '# 第03集\n总时长：24.2秒\n## 时间线镜头设计\n### 镜头1｜0–24.2秒｜近景\n画面内容：动作自然持续。'
        params = dict(self.plan['shots'][0]['params'], duration='25')
        self.assertEqual(validate_duration(raw, params, list(range(4,31))), 25)

    def test_fractional_floor_or_extra_second_is_rejected(self):
        self.fractional_prompt(27.6)
        for requested in ('27', '29', '30'):
            self.plan['shots'][0]['params']['duration'] = requested
            with self.assertRaises(PipelineError): self.compile()

    def test_rounding_does_not_relax_source_timeline_match(self):
        self.fractional_prompt(27.6)
        params = dict(self.plan['shots'][0]['params'], duration='28')
        for bad in (self.raw.replace('24.75–27.6', '24.75–28'),
                    self.raw.replace('24.75–27.6', '24.75–27.5')):
            with self.assertRaises(PipelineError): validate_duration(bad, params, list(range(4,31)))

    def test_over_30_rounding_is_not_clamped(self):
        self.fractional_prompt(30.2)
        self.plan['shots'][0]['params']['duration'] = '30.2'
        with self.assertRaises(PipelineError): self.compile()

    def test_invalid_duration_parameter_is_not_silently_coerced(self):
        for requested in (True, False, 0, -1, 'nan', 'inf', None):
            self.plan['shots'][0]['params']['duration'] = requested
            with self.assertRaises(PipelineError): self.compile()

    def test_fractional_final_node_parameter_is_rejected(self):
        self.fractional_prompt(27.6)
        params = dict(self.plan['shots'][0]['params'], duration='27.6')
        with self.assertRaises(PipelineError): validate_duration(self.raw, params, list(range(4,31)))

    def test_integer_prompt_has_no_tail_extension(self):
        row = self.compile()
        self.assertEqual(row['params']['duration'], '27')
        self.assertEqual(row['duration_adaptation']['tail_extension_seconds'], 0)

    def test_schema_disallows_unsupported_duration(self):
        self.plan['shots'][0]['supported_durations']=[15,30]
        with self.assertRaises(PipelineError): self.compile()

    def test_gap_and_missing_last_end_rejected(self):
        params=self.plan['shots'][0]['params']
        for bad in (self.raw.replace('0–2.25','0–1'),self.raw.replace('2.25–4.5','3–4.5'),self.raw.replace('24.75–27','24.75–26')):
            with self.subTest(bad=bad[-80:]):
                with self.assertRaises(PipelineError): validate_duration(bad,params,list(range(4,31)))

    def test_continuous_short_insert_is_allowed_and_roundtrips(self):
        self.raw = self.raw.replace('0–2.25', '0–0.5').replace('2.25–4.5', '0.5–4.5')
        self.path.write_bytes(self.raw.encode('utf-8'))
        row = self.compile()
        self.assertEqual(row['params']['duration'], '27')
        self.assertEqual(apply_binding_edits(self.raw, row['binding_edits']), row['params']['prompt'])
        self.assertNotIn('episode_blocking_review_file', row)

    def test_overlap_and_nonpositive_shot_remain_rejected(self):
        params = self.plan['shots'][0]['params']
        for bad in (self.raw.replace('2.25–4.5', '2–4.5'), self.raw.replace('0–2.25', '0–0')):
            with self.assertRaises(PipelineError):
                validate_duration(bad, params, list(range(4,31)))

    def test_saved_parameter_tampering_rejected(self):
        row=self.compile()
        actual={'uuid':row['node_uuid'],'params':copy.deepcopy(row['params']),'prevNodeUuids':row['prevNodeUuids']}
        actual['params']['duration']='30'
        with self.assertRaises(PipelineError):validate_shot(row,actual)

    def test_existing_fixed_30_role_remains_fixed_without_blocking_input(self):
        self.plan['shots'][0]['prompt_role']='seedance25_30s'
        with self.assertRaises(PipelineError):self.compile()
        self.plan['shots'][0]['params']['duration']='30'
        row=self.compile()
        self.assertEqual(row['prevNodeUuids'][0],'c')
        self.plan['shots'][0]['bindings']=self.refs+[{'category':'blocking_reference','node_uuid':'b'}]
        with self.assertRaises(PipelineError):self.compile()

    def test_new_20_workflow_policy_requires_shared_continuity_evidence(self):
        m,nodes=fixtures();shot=m['shots'][0]
        shot['workflow_policy']='pixmax_dual_modules_v1'
        with self.assertRaisesRegex(PipelineError,'continuity evidence'):
            validate_visual_review(shot,{n['uuid']:n for n in nodes})

    def test_v134_scene_review_checks_first_board_and_plan_duration(self):
        base=test_scene_blocking_review_v2.SceneV2Tests();base.setUp();self.addCleanup(base.doCleanups)
        base.select(0)
        base.shot['prompt_role']='seedance25_v134'
        base.shot['params']['duration']='27'
        base.plan['segments'][0]['actual_duration']=27
        base.shot['bindings'].append({'category':'character','node_uuid':'person'})
        base.shot['prevNodeUuids'].append('person')
        base.flush();base.check()
        base.shot['bindings'].reverse();base.shot['prevNodeUuids'].reverse()
        with self.assertRaises(PipelineError):base.check()
        base.shot['bindings'].reverse();base.shot['prevNodeUuids'].reverse()
        base.plan['segments'][0]['actual_duration']=30;base.flush()
        with self.assertRaises(PipelineError):base.check()

    def test_new_compilation_drops_stale_image_review_fields(self):
        self.plan['shots'][0].update(episode_segment_id='old', episode_blocking_review_file='missing.json', episode_blocking_review_sha256='old')
        row=self.compile()
        self.assertNotIn('episode_blocking_review_file',row)
        self.assertEqual(row['prevNodeUuids'],['c','s','p'])

    def test_video_preflight_has_no_blocking_image_gate(self):
        from unittest.mock import patch
        from submit_saved_batch import run
        row=self.compile()
        actual={'uuid':row['node_uuid'],'params':copy.deepcopy(row['params']),'prevNodeUuids':row['prevNodeUuids']}
        def api(*args):
            if args[:2]==('tasks','progress'):return {'data':[]}
            if args[:2]==('canvas','nodes'):return [actual,*self.nodes]
            raise AssertionError('No generation or image API is allowed in this read-only test')
        with patch('submit_saved_batch.visual_review_errors',return_value=[]):
            result=run({'file_uuid':'canvas','shots':[row]},Path(self.tmp.name)/'preflight',api=api)
        self.assertEqual(result['generation_ready'],[row['node_uuid']])
        self.assertFalse(result['generation_submitted'])


if __name__=='__main__':unittest.main()
