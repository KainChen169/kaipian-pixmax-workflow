"""Offline checks for a top-mentioned six-panel reference and first unmentioned blocking image."""

import copy
import hashlib
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from fast_bind import compile_batch, compile_shot
from submit_saved_batch import validate_shot, PipelineError
from test_blocking_reference import bindings, image_nodes
CHAR = "%%@[Hero][image][0](char-1)%%"
SCENE = "%%@[Room][image][1](scene-1)%%"
PROMPT = f"**人物指定：**\nHero {CHAR}\n\n**场景指定：**\nRoom {SCENE}\n\n**时间线镜头设计：**\n镜头1｜全景"

BOARD_TOKEN = "%%@[Six Panel][image][2](board-1)%%"
BOARD_PROMPT = f"**六宫格首帧引用：** 六宫格参考图 {BOARD_TOKEN}，逐格参考首帧。\n\n{PROMPT}"


class StoryboardReferenceTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.video = Path(self.temp.name) / "video.md"
        self.storyboard = Path(self.temp.name) / "storyboard.txt"
        self.video.write_bytes(BOARD_PROMPT.encode("utf-8"))
        self.storyboard.write_bytes(b"CHARACTER REFERENCES: Hero\nSCENE REFERENCE: Room, day\nPANEL 1 through PANEL 6")
        self.bundle = Path(self.temp.name) / "episode.md"
        self.bundle.write_bytes(b"authoritative episode bundle")
        self.nodes = image_nodes() | {
            "board-1": {"uuid": "board-1", "type": "GENERATE_IMAGE", "label": "Six Panel",
                        "defaultAsset": {"assetsUuid": "asset-board"}}
        }
        self.refs = bindings()[1:] + [
            {"category": "storyboard_reference", "node_uuid": "board-1"}]

    def shot(self):
        return {"id": "S01", "label": "video-1", "prompt_file": str(self.video),
                "prompt_role": "original_15s", "bindings": self.refs,
                "storyboard_prompt_file": str(self.storyboard),
                "storyboard_sha256": hashlib.sha256(self.storyboard.read_bytes()).hexdigest(),
                "episode_bundle_file": str(self.bundle),
                "episode_bundle_sha256": hashlib.sha256(self.bundle.read_bytes()).hexdigest(),
                "max_image_inputs": 3, "max_prompt_chars": 5000,
                "supported_durations": [15],
                "params": {"nodeType": "GENERATE_VIDEO", "model": "PIXDANCE_2_FAST",
                           "duration": "15", "count": "1", "referModel": "referToVideo"}}

    def test_six_panel_after_characters_and_scene_preserves_video_text(self):
        compiled, _, _, _, _ = compile_shot(self.shot(), self.nodes)
        self.assertEqual(compiled, BOARD_PROMPT)
        manifest, _ = compile_batch({"file_uuid": "file-1", "shots": [self.shot()]}, list(self.nodes.values()))
        record = manifest["shots"][0]
        self.assertEqual(record["prevNodeUuids"], ["char-1", "scene-1", "board-1"])
        self.assertEqual(record["params"]["prompt"], BOARD_PROMPT)
        self.assertEqual(record["storyboard_sha256"], self.shot()["storyboard_sha256"])
        actual = {"uuid": record["node_uuid"], "params": copy.deepcopy(record["params"]),
                  "prevNodeUuids": record["prevNodeUuids"]}
        validate_shot(record, actual)

    def test_board_must_be_mentioned_once_in_first_paragraph(self):
        for text in (PROMPT,
                     BOARD_PROMPT.replace(BOARD_TOKEN, BOARD_TOKEN + ' ' + BOARD_TOKEN),
                     PROMPT + "\n\n**六宫格首帧引用：** " + BOARD_TOKEN):
            self.video.write_text(text, encoding="utf-8")
            with self.assertRaises(PipelineError):
                compile_shot(self.shot(), self.nodes)
        self.video.write_bytes(BOARD_PROMPT.encode("utf-8"))

    def test_new_automation_source_compiles_one_top_board_at(self):
        source = BOARD_PROMPT.replace(BOARD_TOKEN, "〈六宫格真实@待绑定〉")
        source = source.replace(" " + CHAR, "").replace(" " + SCENE, "")
        self.video.write_bytes(source.encode("utf-8"))
        shot = self.shot()
        shot["prompt_role"] = "automation_15s"
        compiled, ranges, _, role, _ = compile_shot(shot, self.nodes)
        self.assertEqual(role, "automation_15s")
        self.assertEqual(compiled, BOARD_PROMPT)
        self.assertTrue(any(start == 0 for start, _ in ranges))

    def test_missing_or_changed_storyboard_source_fails(self):
        shot = self.shot()
        shot.pop("storyboard_sha256")
        with self.assertRaisesRegex(PipelineError, "storyboard prompt file"):
            compile_batch({"file_uuid": "file-1", "shots": [shot]}, list(self.nodes.values()))
        shot = self.shot()
        self.storyboard.write_text("changed", encoding="utf-8")
        with self.assertRaisesRegex(PipelineError, "storyboard prompt changed"):
            compile_batch({"file_uuid": "file-1", "shots": [shot]}, list(self.nodes.values()))

    def test_changed_episode_bundle_fails_even_if_extracted_files_match(self):
        shot = self.shot()
        self.bundle.write_bytes(b"changed source bundle")
        with self.assertRaisesRegex(PipelineError, "episode source bundle"):
            compile_batch({"file_uuid": "file-1", "shots": [shot]}, list(self.nodes.values()))

    def test_wrong_order_duplicate_and_limit_fail(self):
        shot = self.shot()
        for refs in (shot["bindings"][:-2] + shot["bindings"][-1:] + shot["bindings"][-2:-1],
                     shot["bindings"] + [shot["bindings"][-2]]):
            with self.assertRaises(PipelineError):
                compile_shot({**shot, "bindings": refs}, self.nodes)
        with self.assertRaises(PipelineError):
            compile_shot({**shot, "max_image_inputs": 2}, self.nodes)


if __name__ == "__main__":
    unittest.main()
