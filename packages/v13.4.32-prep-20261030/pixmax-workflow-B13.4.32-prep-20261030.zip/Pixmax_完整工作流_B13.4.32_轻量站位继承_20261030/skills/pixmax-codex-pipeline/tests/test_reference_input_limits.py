import copy
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
from pixmax_pipeline import load_manifest, validate_reference_limits, run, PipelineError


def model_schema(model='PIXDANCE_2_5_DRAFT', image_max=30, total_max=50):
    return {'modelCode': model, 'nodeType': 'GENERATE_VIDEO', 'restricted': False,
            'params': [{'name': 'referModel', 'options': ['referToVideo', 'firstAndLastFrame', 'imageToVideo']}],
            'inputRules': [{'codes': ['BASE_IMAGE', 'GENERATE_IMAGE', 'GENERATE_STORYBOARD'], 'min': 0, 'max': image_max},
                           {'codes': ['BASE_VIDEO', 'GENERATE_VIDEO'], 'min': 0, 'max': 10},
                           {'codes': ['BASE_AUDIO', 'GENERATE_AUDIO'], 'min': 0, 'max': 10},
                           {'codes': ['BASE_IMAGE', 'GENERATE_IMAGE', 'BASE_VIDEO', 'GENERATE_VIDEO', 'BASE_AUDIO', 'GENERATE_AUDIO'], 'min': 0, 'max': total_max}]}


def shot(count=10, model='PIXDANCE_2_5_DRAFT', mode='referToVideo'):
    return {'id': 'S001', 'model': model, 'reference_images': [str(i) for i in range(count)], 'refer_model': mode}


class ReferenceLimitsTest(unittest.TestCase):
    def test_ten_images_accepted_for_25(self):
        validate_reference_limits(shot(10), model_schema())

    def test_thirty_images_accepted_for_25(self):
        validate_reference_limits(shot(30), model_schema())

    def test_thirty_one_images_not_mistaken_for_fifty(self):
        source = shot(31)
        before = copy.deepcopy(source)
        with self.assertRaisesRegex(PipelineError, 'current group allows 0-30'):
            validate_reference_limits(source, model_schema())
        self.assertEqual(source, before)

    def test_nine_limit_applies_only_when_schema_says_so(self):
        validate_reference_limits(shot(9, 'PIXDANCE_2'), model_schema('PIXDANCE_2', 9, 15))
        with self.assertRaises(PipelineError):
            validate_reference_limits(shot(10, 'PIXDANCE_2'), model_schema('PIXDANCE_2', 9, 15))

    def test_changed_dynamic_limit_is_respected(self):
        validate_reference_limits(shot(35), model_schema(image_max=40))
        with self.assertRaises(PipelineError):
            validate_reference_limits(shot(20), model_schema(image_max=18))

    def test_combined_group_is_also_checked(self):
        with self.assertRaises(PipelineError):
            validate_reference_limits(shot(25), model_schema(total_max=20))

    def test_first_last_requires_two(self):
        validate_reference_limits(shot(2, mode='firstAndLastFrame'), model_schema())
        with self.assertRaises(PipelineError):
            validate_reference_limits(shot(10, mode='firstAndLastFrame'), model_schema())

    def test_unknown_or_invalid_limits_stop(self):
        for rules in [None, [], [{'codes': ['BASE_IMAGE'], 'min': 0, 'max': '30'}]]:
            with self.subTest(rules=rules), self.assertRaises(PipelineError):
                validate_reference_limits(shot(), {**model_schema(), 'inputRules': rules})

    def test_wrong_model_or_mode_stops(self):
        with self.assertRaises(PipelineError):
            validate_reference_limits(shot(), model_schema('PIXDANCE_2'))
        with self.assertRaises(PipelineError):
            validate_reference_limits(shot(mode='videoEdit'), model_schema())

    def test_local_plan_accepts_over_nine_without_claiming_platform_support(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            images = []
            for i in range(30):
                image = root / f'{i}.png'
                image.write_bytes(b'fixture')
                images.append(image.name)
            source = root / 'manifest.json'
            source.write_text(json.dumps({'run_id': 'test', 'project_name': 'Test', 'canvas_name': 'EP02', 'episode': 'EP02',
                                         'shots': [{**shot(30), 'prompt': 'Original dialogue.', 'reference_images': images}]}))
            data, _, _ = load_manifest(source)
            self.assertEqual(len(data['shots']), 1)
            self.assertEqual(len(data['shots'][0]['reference_images']), 30)
            self.assertEqual(data['shots'][0]['prompt'], 'Original dialogue.')
            original = json.loads(source.read_text())
            original['shots'][0]['refer_model'] = 'firstAndLastFrame'
            source.write_text(json.dumps(original))
            with self.assertRaisesRegex(PipelineError, 'exactly two'):
                load_manifest(source)

    def test_prepare_checks_capacity_before_remote_writes(self):
        calls = []
        def cli(*args):
            calls.append(args)
            if args == ('config', 'show'):
                return {'effective': {'environment': 'cn'}}
            if args == ('doctor', '--online'):
                return {'ok': True}
            if args == ('model', 'explain', 'PIXDANCE_2_5_DRAFT', '--type', 'GENERATE_VIDEO'):
                return model_schema()
            raise AssertionError('Unexpected remote mutation: ' + str(args))
        with tempfile.TemporaryDirectory() as td, patch('pixmax_pipeline.cli', cli), patch('pixmax_pipeline.ensure_project') as create:
            with self.assertRaises(PipelineError):
                run({'shots': [shot(31)]}, Path(td), 'fixture', prepare_only=True)
            create.assert_not_called()
        self.assertEqual(len(calls), 3)
