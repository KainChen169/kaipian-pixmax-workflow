import copy
import json
from pathlib import Path
import sys
import tempfile
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from collect_saved_outputs import collect, PipelineError

class DeliveryTest(unittest.TestCase):
    def setUp(self):
        self.manifest={'file_uuid':'canvas-example','shots':[{'id':'EP01_S001','node_uuid':'video-example'}]}
        self.submission={'file_uuid':'canvas-example','tasks':[{'nodeUuid':'video-example','taskUuid':'task-example'}]}
        self.status='COMPLETE';self.task='task-example';self.downloads=0;self.empty=False
    def api(self,*args):
        if args[:2]==('tasks','progress'):
            return {'data':[] if self.empty else [{'nodeUuid':'video-example','taskUuid':self.task,'status':self.status}]}
        if args[:2]==('canvas','nodes'):
            return [{'uuid':'video-example','taskUuid':self.task,'defaultAsset':{'assetsUuid':'asset-example','extension':'mp4'}}]
        if args[:2]==('assets','download'):
            self.downloads+=1;Path(args[args.index('--output')+1]).write_bytes(b'\x00\x00\x00\x18ftypmp42'+b'0'*100)
            return {'success':True}
        raise AssertionError('Unexpected command: '+str(args))
    def test_download_is_reused_and_relative(self):
        with tempfile.TemporaryDirectory() as td:
            out=collect(self.manifest,self.submission,td,api=self.api)
            self.assertEqual(out['shots']['EP01_S001']['relative_path'],'EP01/视频/EP01_S001_v01.mp4')
            collect(self.manifest,self.submission,td,api=self.api)
            self.assertEqual(self.downloads,1)
    def test_episode_eleven_uses_uppercase_folder(self):
        self.manifest['shots'][0]['id']='EP11_S001'
        with tempfile.TemporaryDirectory() as td:
            out=collect(self.manifest,self.submission,td,api=self.api)
            self.assertEqual(out['shots']['EP11_S001']['relative_path'],'EP11/视频/EP11_S001_v01.mp4')
            self.assertTrue((Path(td)/'EP11'/'视频'/'EP11_S001_v01.mp4').is_file())
    def test_failure_does_not_download_or_generate(self):
        self.status='FAILED'
        with tempfile.TemporaryDirectory() as td:
            out=collect(self.manifest,self.submission,td,api=self.api)
            self.assertEqual(out['shots']['EP01_S001']['status'],'FAILED');self.assertEqual(self.downloads,0)
    def test_crash_before_rename_resumes_without_redownload(self):
        with tempfile.TemporaryDirectory() as td:
            out=collect(self.manifest,self.submission,td,api=self.api)
            row=out['shots']['EP01_S001'];p=Path(td)/row['relative_path']
            p.rename(p.with_suffix('.partial.mp4'));row['download']='DOWNLOADED'
            Path(out['record']).write_text(json.dumps(out['shots']),encoding='utf-8')
            collect(self.manifest,self.submission,td,api=self.api)
            self.assertTrue(p.is_file());self.assertEqual(self.downloads,1)
    def test_changed_current_task_requires_history(self):
        self.task='new-user-task'
        with tempfile.TemporaryDirectory() as td:
            out=collect(self.manifest,self.submission,td,api=self.api)
            self.assertEqual(out['shots']['EP01_S001']['status'],'NEED_HISTORY_LOOKUP');self.assertEqual(self.downloads,0)
    def test_empty_progress_is_unknown(self):
        self.empty=True
        with tempfile.TemporaryDirectory() as td:
            out=collect(self.manifest,self.submission,td,api=self.api)
            self.assertEqual(out['shots']['EP01_S001']['status'],'UNKNOWN');self.assertEqual(self.downloads,0)
    def test_wrong_canvas_rejected(self):
        self.submission['file_uuid']='other'
        with tempfile.TemporaryDirectory() as td:
            with self.assertRaises(PipelineError):collect(self.manifest,self.submission,td,api=self.api)
    def test_changed_download_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            out=collect(self.manifest,self.submission,td,api=self.api)
            row=out['shots']['EP01_S001'];(Path(td)/row['relative_path']).write_bytes(b'changed')
            with self.assertRaises(PipelineError):collect(self.manifest,self.submission,td,api=self.api)

if __name__=='__main__': unittest.main()
