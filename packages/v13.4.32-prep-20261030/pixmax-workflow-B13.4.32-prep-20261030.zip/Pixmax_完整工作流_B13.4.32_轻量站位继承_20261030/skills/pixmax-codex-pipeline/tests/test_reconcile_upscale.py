import copy
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
from reconcile_upscale import reconcile, reconcile_batch, ReconcileError


class UpscaleReconcileTests(unittest.TestCase):
    def setUp(self):
        self.record = {'file_uuid': 'f', 'source_asset_uuid': 's', 'target_resolution': '1080P'}
        self.task = {'taskUuid': 't', 'modelCode': 'VIDEO_UPSCALE', 'status': 'COMPLETE',
                     'inputTexts': ['1080P'], 'inputAssets': [{'assetsUuid': 's'}],
                     'resultAssets': [{'assetsUuid': 'o', 'width': 480, 'height': 854,
                                       'metaData': {'width': 1080, 'height': 1920}}]}
        self.canvas = {'success': True, 'data': {'fileUuid': 'f', 'revision': 'r',
                                                'nodes': [{'uuid': 'n', 'generationTask': self.task}]}}

    def test_completed_uses_task_asset_and_real_metadata(self):
        actual = reconcile(self.record, self.canvas)
        self.assertEqual(actual['upscale_asset_uuid'], 'o')
        self.assertTrue(actual['metadata_resolution_matches'])
        self.assertEqual(actual['technical_qa'], 'PENDING')

    def test_empty_never_authorizes_resubmission(self):
        self.canvas['data']['nodes'] = []
        actual = reconcile(self.record, self.canvas)
        self.assertFalse(actual['automatic_resubmit_allowed'])
        self.assertEqual(actual['phase'], 'NOT_FOUND_IN_CANVAS')

    def test_wrong_scope_is_rejected(self):
        self.canvas['data']['fileUuid'] = 'other'
        with self.assertRaises(ReconcileError): reconcile(self.record, self.canvas)

    def test_two_paid_tasks_require_explicit_task_identity(self):
        other = copy.deepcopy(self.canvas['data']['nodes'][0])
        other['generationTask']['taskUuid'] = 't2'
        self.canvas['data']['nodes'].append(other)
        with self.assertRaises(ReconcileError): reconcile(self.record, self.canvas)
        self.record['upscale_task_uuid'] = 't'
        self.assertEqual(reconcile(self.record, self.canvas)['upscale_task_uuid'], 't')

    def test_copied_node_with_same_task_is_not_a_second_submission(self):
        other = copy.deepcopy(self.canvas['data']['nodes'][0]); other['uuid'] = 'copy'
        self.canvas['data']['nodes'].append(other)
        self.assertEqual(reconcile(self.record, self.canvas)['upscale_task_uuid'], 't')

    def test_pinned_task_must_match_source_and_resolution(self):
        self.record['upscale_task_uuid'] = 't'
        self.task['inputAssets'][0]['assetsUuid'] = 'wrong'
        with self.assertRaises(ReconcileError): reconcile(self.record, self.canvas)

    def test_running_keeps_identity_without_claiming_output(self):
        self.task['status'] = 'PROCESSING'; self.task['resultAssets'] = []
        actual = reconcile(self.record, self.canvas)
        self.assertEqual(actual['phase'], 'TASK_PROCESSING')
        self.assertNotIn('upscale_asset_uuid', actual)

    def test_batch_error_does_not_hide_other_results(self):
        wrong = dict(self.record, file_uuid='other')
        actual = reconcile_batch({'records': [wrong, self.record]}, self.canvas)
        self.assertEqual(actual['error_count'], 1)
        self.assertEqual(actual['records'][0]['phase'], 'RECONCILE_REQUIRED')
        self.assertEqual(actual['records'][1]['upscale_task_uuid'], 't')
        self.assertFalse(actual['automatic_resubmit_allowed'])

    def test_invalid_batch_is_rejected(self):
        with self.assertRaises(ReconcileError): reconcile_batch({'records': []}, self.canvas)


if __name__ == '__main__': unittest.main()
