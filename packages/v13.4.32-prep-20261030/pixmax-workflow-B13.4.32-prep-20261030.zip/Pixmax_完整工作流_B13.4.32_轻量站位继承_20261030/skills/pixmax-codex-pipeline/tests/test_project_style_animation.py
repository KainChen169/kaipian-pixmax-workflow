"""Local style selection and animation compile/readback; no platform or media calls."""
import copy
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
from project_style import POLICY, inspect_project, validate_decision, validate_route
from animation_contract import animation_validator
from fast_bind import compile_batch, apply_binding_edits
from submit_saved_batch import validate_shot
from resolve_saved_batch import resolve
from pixmax_pipeline import PipelineError, run
from shot_body_mentions import POLICY as BODY

EX = Path(__file__).resolve().parents[2] / 'seedance25-animation-director' / 'assets' / 'examples'


class StyleAnimationTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.spec = self.root / '项目说明.md'
        self.spec.write_text('制作类型：动画。白天鹅口语角色；使用项目已定3D动画资产。')
        self.decision = dict(policy=POLICY, project_name=self.root.name,
            production_style='animation', status='CONFIRMED', conflicts=[],
            reason='制作说明明确动画，已阅读当前项目说明。', reviewed_by='offline test',
            evidence=[dict(file=self.spec.name, kind='project_spec',
                sha256=self.hash(self.spec), excerpt='制作类型：动画。', observation='制作方式明确为动画。')])
        self.decision_file = self.root / '制作类型判定.json'
        self.route = dict(project_root=str(self.root), decision_file=str(self.decision_file),
            production_style='animation', prompt_role='seedance25_animation', director_skill='seedance25-animation-director')
        self.save_decision()
        self.voices = json.loads((EX / 'voice_scene.voices.json').read_text())
        self.dialogue = json.loads((EX / 'voice_scene.dialogue.json').read_text())
        raw = (EX / 'voice_scene.prompt.md').read_text()
        self.setup_episode(raw)

    @staticmethod
    def hash(path):
        return hashlib.sha256(path.read_bytes()).hexdigest()

    def save_json(self, name, value):
        p = self.root / name
        p.write_text(json.dumps(value, ensure_ascii=False))
        return p

    def file_fields(self, key, path):
        return {key + '_file': str(path), key + '_sha256': self.hash(path)}

    def save_decision(self):
        self.save_json(self.decision_file.name, self.decision)
        self.route['decision_sha256'] = self.hash(self.decision_file)

    def setup_episode(self, full, number=1):
        self.full = full
        episode = self.root / '第01集_动画提示词.md'; episode.write_bytes(full.encode())
        spans = list(animation_validator().SEGMENT.finditer(full))
        piece = full[spans[number - 1].start():spans[number].start() if number < len(spans) else len(full)]
        prompt = self.root / '单包.md'; prompt.write_bytes(piece.encode())
        script = self.root / '正式剧本.md'; script.write_text('虚构测试：Mira在镜墙前，Ren只在门外发声，Mira最后没有迈步。')
        md = self.root / '整场调度.md'; md.write_text('镜墙在后，门在Mira右前方；双蹼原位承重；纯声源Ren不入画。')
        natural = 10.2 if '时长：10.2秒' in piece else 10
        rows = [dict(id=f'EP01_S{n:03}', segment_number=n, actual_duration=natural,
                     opening_state={'Mira': '镜墙前双蹼原位'}, movements=[], exit_state={'Mira': '仍在镜墙前'}) for n in range(1, len(spans) + 1)]
        plan = self.save_json('调度.json', dict(policy='animation_scene_plan_v1', episode_id='EP01', script_sha256=self.hash(script), segments=rows))
        self.stage = dict(policy='animation_staging_text_v1', status='PASS', episode_id='EP01', reviewed_at='2026-10-26', reviewed_by='offline test',
            episode_prompt_sha256=self.hash(episode), checks={k: {'status': 'PASS', 'observation': '虚构用例：喙、支撑、镜墙与门口关系及包间原位衔接已经文本核对。'} for k in ('body_support', 'landmark_background', 'cross_segment', 'performance_camera')},
            **self.file_fields('script', script), **self.file_fields('blocking_text', md), **self.file_fields('blocking_plan', plan))
        stage = self.save_json('调度复核.json', self.stage)
        dialogue = self.save_json('独立英文源.json', self.dialogue)
        voices = self.save_json('声音档案.json', self.voices)
        self.shot = dict(id=f'EP01_S{number:03}', label='animation test', prompt_file=str(prompt),
            prompt_role='seedance25_animation', binding_policy=BODY, max_image_inputs=30,
            supported_durations=list(range(4, 31)),
            params=dict(nodeType='GENERATE_VIDEO', model='PIXDANCE_2_5_DRAFT', referModel='referToVideo', duration=natural, count=1),
            bindings=[dict(category='character', node_uuid='mira', designation='Mira'), dict(category='scene', node_uuid='room', designation='排练室')],
            body_mentions=[dict(subshot=n, field='表演', text='Mira', node_uuid='mira', purpose='visible_character') for n in (1, 2, 3)] + [dict(subshot=1, field='画面', text='排练室', node_uuid='room', purpose='scene')],
            animation_source=dict(segment_number=number, **self.file_fields('episode_prompt', episode), **self.file_fields('source_dialogue', dialogue), **self.file_fields('voice_cast', voices)),
            **self.file_fields('animation_staging_review', stage))
        self.nodes = [dict(uuid='mira', label='Mira', type='BASE_IMAGE', defaultAsset={'assetsUuid': 'fake-mira-asset'}), dict(uuid='room', label='排练室', type='BASE_IMAGE', defaultAsset={'assetsUuid': 'fake-room-asset'})]

    def record(self):
        manifest, _ = compile_batch(dict(file_uuid='fake-canvas', project_route=self.route, shots=[self.shot]), self.nodes)
        row = manifest['shots'][0]
        actual = dict(uuid=row['node_uuid'], label=row['label'], params=copy.deepcopy(row['params']), prevNodeUuids=row['prevNodeUuids'])
        return manifest, row, actual

    def test_animation_defaults_to_draft_without_mutating_source_plan(self):
        del self.shot['params']['model']
        before=copy.deepcopy(self.shot)
        _, row, actual=self.record()
        self.assertEqual(row['params']['model'],'PIXDANCE_2_5_DRAFT')
        self.assertEqual(self.shot,before)
        validate_shot(row,actual)

    def test_animation_rejects_standard_or_readback_model_drift(self):
        _, row, actual=self.record()
        actual['params']['model']='PIXDANCE_2_5'
        with self.assertRaises(PipelineError):validate_shot(row,actual)
        self.shot['params']['model']='PIXDANCE_2_5'
        with self.assertRaises(PipelineError):self.record()

    def test_inspection_does_not_infer_animation_from_animals(self):
        self.spec.write_text('一只会说话的狼和天鹅，富豪宴会。')
        result = inspect_project(self.root)
        self.assertEqual(result['status'], 'NEEDS_AGENT_REVIEW')
        self.assertNotIn('production_style', result)

    def test_live_action_can_include_talking_animals(self):
        self.spec.write_text('制作类型：真人电影实拍；包含会说话的狼。')
        self.decision.update(production_style='live_action')
        self.decision['evidence'][0].update(sha256=self.hash(self.spec), excerpt='制作类型：真人电影实拍；', observation='明确实拍，动物不改变媒介判断。')
        result = validate_decision(self.root, self.decision)
        self.assertEqual(result['prompt_role'], 'seedance25_v134')

    def test_conflict_unknown_and_mixed_are_blocked(self):
        for style, conflicts in [('unknown', []), ('mixed', []), ('animation', ['素材与项目说明冲突'])]:
            with self.subTest(style=style), self.assertRaises(PipelineError):
                validate_decision(self.root, {**self.decision, 'production_style': style, 'conflicts': conflicts})

    def test_absent_or_unseen_evidence_blocked(self):
        for evidence in [[], [{**self.decision['evidence'][0], 'kind': 'asset_image', 'viewed': False}]]:
            with self.assertRaises(PipelineError): validate_decision(self.root, {**self.decision, 'evidence': evidence})

    def test_false_quote_and_escaping_path_blocked(self):
        for patch_value in [dict(excerpt='不存在的制作说明'), dict(file='../outside.md')]:
            bad = copy.deepcopy(self.decision);bad['evidence'][0].update(patch_value)
            with self.assertRaises(PipelineError): validate_decision(self.root, bad)

    def test_changed_evidence_blocks_before_any_cli_call(self):
        self.spec.write_text('制作类型现已不同。')
        with patch('pixmax_pipeline.cli') as cli:
            with self.assertRaises(PipelineError): run({'project_route': self.route}, self.root / 'new-delivery', 'fake', prepare_only=True)
            cli.assert_not_called()
        self.assertFalse((self.root / 'new-delivery').exists())

    def test_wrong_director_role_and_wrong_project_blocked(self):
        for field, value in [('prompt_role', 'seedance25_v134'), ('director_skill', 'ab-test-seedance25-director-compiler-v13-4-0')]:
            with self.assertRaises(PipelineError): validate_route({'project_route': {**self.route, field: value}})
        bad = {**self.decision, 'project_name': 'different-project'}
        with self.assertRaises(PipelineError): validate_decision(self.root, bad)

    def test_animation_compile_bind_and_readback(self):
        _, row, actual = self.record()
        self.assertEqual(row['director_skill'], 'seedance25-animation-director')
        self.assertEqual(row['params']['resolution'], '480P')
        self.assertEqual(row['params']['aspectRatio'], '9:16')
        self.assertIs(row['params']['includeAudio'], True)
        self.assertEqual(row['prevNodeUuids'], ['mira', 'room'])
        self.assertNotIn('%%@[Ren]', row['params']['prompt'])
        self.assertEqual(row['params']['prompt'].count('%%@'), 6)
        raw = Path(self.shot['prompt_file']).read_bytes().decode()
        self.assertEqual(apply_binding_edits(raw, row['binding_edits']), row['params']['prompt'])
        reverse, delta = [], 0
        for e in row['binding_edits']:
            pos = e['start'] + delta
            reverse.append(dict(start=pos, end=pos + len(e['after']), before=e['after'], after=e['before']))
            delta += len(e['after']) - len(e['before'])
        self.assertEqual(apply_binding_edits(row['params']['prompt'], reverse), raw)
        self.assertFalse(row['animation_text_check']['actual_voiceprint_verified'])
        validate_shot(row, actual)

    def test_animation_legacy_format_still_compiles(self):
        raw = (EX / 'legacy_voice_scene.prompt.md').read_text().replace('构图：Mira完整', '构图：排练室内，Mira完整', 1)
        self.setup_episode(raw)
        for p in self.shot['body_mentions']:
            p['field'] = {'画面':'构图', '表演':'画面内容'}[p['field']]
        _, row, actual = self.record()
        validate_shot(row, actual)

    def test_animation_new_actions_keep_dialogue_and_deduplicate_inputs(self):
        for field in ('动作', '动作与表演'):
            self.setup_episode(self.full.replace('表演：', field + '：'))
            for p in self.shot['body_mentions']:
                if p['field'] == '表演': p['field'] = field
            _, row, actual = self.record()
            self.assertEqual(row['prevNodeUuids'], ['mira', 'room'])
            self.assertIn('原话（Mira／现场对白→门口）：「I\'m ready.」', row['params']['prompt'])
            validate_shot(row, actual)
            self.full = self.full.replace(field + '：', '表演：')

    def test_animation_guidance_is_not_binding_body(self):
        self.shot['body_mentions'] = [dict(subshot=1, field='导演指导', text='Mira', node_uuid='mira', purpose='visible_character')]
        with self.assertRaises(PipelineError): self.record()

    def test_animation_same_asset_cross_field_duplicate_rejected(self):
        self.shot['body_mentions'].append(dict(subshot=1, field='画面', text='Mira', node_uuid='mira', purpose='visible_character'))
        with self.assertRaises(PipelineError): self.record()

    def test_no_route_and_legacy_binding_policy_cannot_bypass_animation(self):
        with self.assertRaises(PipelineError): compile_batch(dict(file_uuid='fake', shots=[self.shot]), self.nodes)
        self.shot['binding_policy'] = 'asset_mentions_only_v1'
        with self.assertRaises(PipelineError): self.record()

    def test_different_per_shot_route_cannot_mix_in_canvas(self):
        self.shot['project_route'] = {**self.route, 'production_style': 'live_action'}
        with self.assertRaises(PipelineError): self.record()

    def test_offscreen_speaker_cannot_acquire_image_binding(self):
        self.shot['bindings'].insert(1, dict(category='character', node_uuid='ren', designation='Ren'))
        self.nodes.append(dict(uuid='ren', label='Ren', type='BASE_IMAGE', defaultAsset={'assetsUuid': 'fake-ren'}))
        with self.assertRaises(PipelineError): self.record()

    def test_wrong_model_and_wrong_resolution_blocked(self):
        for key, value in [('model', 'PIXDANCE_2'), ('resolution', '720P')]:
            original = copy.deepcopy(self.shot)
            self.shot['params'][key] = value
            with self.assertRaises(PipelineError): self.record()
            self.shot = original

    def test_decimal_duration_is_ceil_with_source_untouched(self):
        full = self.full.replace('时长：10秒', '时长：10.2秒').replace('6.0–10.0秒', '6.0–10.2秒')
        self.setup_episode(full)
        _, row, actual = self.record()
        self.assertEqual(row['params']['duration'], 11)
        self.assertAlmostEqual(row['duration_adaptation']['tail_extension_seconds'], .8)
        self.assertIn('6.0–10.2秒', row['params']['prompt'])
        validate_shot(row, actual)

    def test_real_schema_duration_restriction_is_not_bypassed(self):
        self.shot['supported_durations'] = [15, 30]
        with self.assertRaises(PipelineError): self.record()

    def test_full_episode_and_selected_second_segment(self):
        piece = self.full.split('## 第01段', 1)[1]
        full = self.full + '\n## 第02段' + piece
        self.dialogue['utterances'] *= 2
        self.setup_episode(full, number=2)
        _, row, actual = self.record()
        self.assertEqual(row['animation_source']['segment_number'], 2)
        self.assertEqual(row['params']['prompt'].count('## 第02段'), 1)
        self.assertNotIn('## 第01段', row['params']['prompt'])
        validate_shot(row, actual)

    def test_one_node_cannot_receive_whole_episode_or_rewritten_slice(self):
        p = Path(self.shot['prompt_file'])
        for bad in (self.full, p.read_text().replace('Mira压住紧张', 'Mira离开房间')):
            p.write_text(bad)
            with self.assertRaises(PipelineError): self.record()

    def test_voice_file_changed_or_rehashed_drift_still_blocked(self):
        p = Path(self.shot['animation_source']['voice_cast_file'])
        data = json.loads(p.read_text());data['voices'][0]['identity'] = '另一条不同的幼态高音'
        p.write_text(json.dumps(data))
        with self.assertRaises(PipelineError): self.record()
        self.shot['animation_source']['voice_cast_sha256'] = self.hash(p)
        with self.assertRaises(PipelineError): self.record()

    def test_dialogue_source_change_is_not_binding_permission(self):
        p = Path(self.shot['animation_source']['source_dialogue_file'])
        data = json.loads(p.read_text());data['utterances'][0]['text'] = 'Different words.'
        p.write_text(json.dumps(data));self.shot['animation_source']['source_dialogue_sha256'] = self.hash(p)
        with self.assertRaises(PipelineError): self.record()

    def test_live_action_instruction_rejected_by_animation_validator(self):
        self.setup_episode(self.full + '\n真人电影实拍，真实人类毛孔。\n')
        with self.assertRaises(PipelineError): self.record()

    def test_missing_stale_or_failed_staging_review_blocked(self):
        original = copy.deepcopy(self.shot)
        self.shot.pop('animation_staging_review_file')
        with self.assertRaises(PipelineError): self.record()
        self.shot = original
        p = Path(self.shot['animation_staging_review_file'])
        p.write_text(json.dumps({**self.stage, 'status': 'FAIL'}))
        with self.assertRaises(PipelineError): self.record()
        self.shot['animation_staging_review_sha256'] = self.hash(p)
        with self.assertRaises(PipelineError): self.record()

    def test_staging_md_change_and_duration_mismatch_blocked(self):
        p = Path(self.stage['blocking_text_file']);p.write_text('changed landmarks')
        with self.assertRaises(PipelineError): self.record()
        self.stage['blocking_text_sha256'] = self.hash(p)
        plan = Path(self.stage['blocking_plan_file']);data = json.loads(plan.read_text());data['segments'][0]['actual_duration'] = 12
        plan.write_text(json.dumps(data));self.stage['blocking_plan_sha256'] = self.hash(plan)
        report = self.save_json('调度复核.json', self.stage)
        self.shot.update(self.file_fields('animation_staging_review', report))
        with self.assertRaises(PipelineError): self.record()

    def test_saved_platform_id_preserves_route_and_source(self):
        manifest, row, actual = self.record();actual['uuid'] = 'saved-platform-id'
        resolved = resolve(manifest, [actual])['shots'][0]
        self.assertEqual(resolved['node_uuid'], 'saved-platform-id')
        self.assertEqual(resolved['project_route'], row['project_route'])
        self.assertEqual(resolved['animation_source'], row['animation_source'])

    def test_readback_cannot_hide_narrative_change(self):
        _, row, actual = self.record()
        actual['params']['prompt'] = actual['params']['prompt'].replace("I'm ready.", "I'm leaving.")
        with self.assertRaises(PipelineError): validate_shot(row, actual)

    def test_legacy_live_action_records_remain_compatible(self):
        self.assertIsNone(validate_route({'prompt_role': 'seedance25_v134'}))

    def test_blocked_cli_returns_structured_result_without_traceback(self):
        self.decision.update(production_style='unknown', status='BLOCKED')
        self.save_decision()
        script = Path(__file__).resolve().parents[1] / 'scripts' / 'project_style.py'
        result = subprocess.run([sys.executable, str(script), 'validate', '--project-root', str(self.root), '--decision', str(self.decision_file)], capture_output=True, text=True, env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'})
        self.assertEqual(result.returncode, 1)
        self.assertEqual(json.loads(result.stdout)['stage'], 'style_blocked')
        self.assertNotIn('project_route', json.loads(result.stdout))
        self.assertNotIn('Traceback', result.stderr)

    def test_cli_rejects_decision_file_outside_project(self):
        script = Path(__file__).resolve().parents[1] / 'scripts' / 'project_style.py'
        project = self.root / 'project';project.mkdir()
        (project / self.spec.name).write_bytes(self.spec.read_bytes())
        self.decision['project_name'] = project.name
        self.save_decision()
        result = subprocess.run([sys.executable, str(script), 'validate', '--project-root', str(project), '--decision', str(self.decision_file)], capture_output=True, text=True, env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'})
        self.assertEqual(result.returncode, 1)
        self.assertEqual(json.loads(result.stdout)['stage'], 'style_blocked')


if __name__ == '__main__':
    unittest.main(verbosity=2)
