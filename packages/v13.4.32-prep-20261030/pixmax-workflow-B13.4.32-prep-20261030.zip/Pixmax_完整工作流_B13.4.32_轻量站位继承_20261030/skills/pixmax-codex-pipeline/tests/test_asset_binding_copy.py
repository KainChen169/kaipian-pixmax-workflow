"""Binding changes are allowed; dialogue/body changes cannot pass the saved-node gate."""
import copy
import hashlib
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
from fast_bind import compile_batch, compile_shot, compile_mentions, apply_binding_edits
from resolve_saved_batch import resolve
from submit_saved_batch import validate_shot, PipelineError

RAW = ('# 第04集\r\n\r\n**人物指定：**\r\n'
       'Seren｜伤心转为愤怒。\r\nTorin｜疑惑，右手留在身侧。\r\n\r\n'
       '**场景指定：**\r\n禁林｜日，树根与林路的位置固定。\r\n\r\n'
       '**道具指定：**\r\n胸徽｜胸前，Seren指向它。\r\n\r\n'
       '## 时间线镜头设计\r\n镜头1｜0—15秒\r\n'
       'Seren看向Torin，急切地说：“Stay with me.”\r\n她捂住手臂，视线停在他的脸上。\r\n')


class AssetBindingCopyTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.source = Path(self.temp.name) / 'source.md'
        self.source.write_bytes(RAW.encode('utf-8'))
        self.refs = [{'category': category, 'node_uuid': uid, 'designation': name}
                     for category, uid, name in [('character', 'seren', 'Seren'),
                        ('character', 'torin', 'Torin'), ('scene', 'forest', '禁林'),
                        ('prop', 'crest', '胸徽')]]
        self.nodes = {ref['node_uuid']: {'uuid': ref['node_uuid'], 'type': 'BASE_IMAGE',
                     'label': ref['designation'], 'defaultAsset': {'assetsUuid': 'asset-' + ref['node_uuid']}}
                     for ref in self.refs}

    def shot(self):
        return {'id': 'S01', 'label': 'video', 'prompt_file': str(self.source),
                'prompt_role': 'original_15s', 'bindings': self.refs,
                'max_image_inputs': 4, 'max_prompt_chars': 5000, 'supported_durations': [15],
                'params': {'nodeType': 'GENERATE_VIDEO', 'model': 'test', 'count': 1,
                           'duration': 15, 'referModel': 'referToVideo'}}

    def compiled_record(self):
        manifest, _ = compile_batch({'file_uuid': 'canvas', 'shots': [self.shot()]}, list(self.nodes.values()))
        record = manifest['shots'][0]
        actual = {'uuid': record['node_uuid'], 'label': record['label'],
                  'params': copy.deepcopy(record['params']), 'prevNodeUuids': record['prevNodeUuids']}
        return manifest, record, actual

    def test_plain_original_binds_all_assets_and_preserves_body_crlf(self):
        original_bytes = self.source.read_bytes()
        _, record, actual = self.compiled_record()
        prompt = record['params']['prompt']
        self.assertEqual(prompt.count('%%@'), 4)
        self.assertEqual(prompt[prompt.index('## 时间线'):], RAW[RAW.index('## 时间线'):])
        self.assertEqual(self.source.read_bytes(), original_bytes)
        self.assertEqual(record['source_sha256'], hashlib.sha256(original_bytes).hexdigest())
        self.assertEqual(apply_binding_edits(RAW, record['binding_edits']), prompt)
        validate_shot(record, actual)

    def test_rebinds_old_uuid_label_and_index_without_changing_description(self):
        old = RAW.replace('Seren｜', 'Seren %%@[Old][image][7](old-canvas)%%｜')
        self.source.write_bytes(old.encode('utf-8'))
        _, record, actual = self.compiled_record()
        self.assertIn('Seren %%@[Seren][image][0](seren)%%｜伤心转为愤怒。', record['params']['prompt'])
        self.assertEqual(record['binding_edits'][0]['before'], '%%@[Old][image][7](old-canvas)%%')
        self.assertEqual(self.source.read_bytes(), old.encode('utf-8'))
        validate_shot(record, actual)

    def test_correct_tokens_are_idempotent(self):
        _, record, _ = self.compiled_record()
        self.source.write_bytes(record['params']['prompt'].encode('utf-8'))
        _, rebound, actual = self.compiled_record()
        self.assertEqual(rebound['binding_edits'], [])
        self.assertEqual(rebound['params']['prompt'], record['params']['prompt'])
        validate_shot(rebound, actual)

    def test_partial_existing_binding_does_not_duplicate_tokens(self):
        self.source.write_bytes(RAW.replace('Torin｜', 'Torin %%@[Torin][image][1](torin)%%｜').encode('utf-8'))
        _, record, actual = self.compiled_record()
        self.assertEqual(len(record['binding_edits']), 3)
        self.assertEqual(record['params']['prompt'].count('(torin)%%'), 1)
        validate_shot(record, actual)

    def test_cannot_hide_dialogue_edit_in_manifest_and_saved_node(self):
        _, record, actual = self.compiled_record()
        record['params']['prompt'] = record['params']['prompt'].replace('Stay with me.', 'Leave me.')
        actual['params'] = copy.deepcopy(record['params'])
        record['bound_prompt_sha256'] = hashlib.sha256(record['params']['prompt'].encode('utf-8')).hexdigest()
        with self.assertRaisesRegex(PipelineError, 'outside permitted asset'):
            validate_shot(record, actual)

    def test_cannot_hide_performance_or_whitespace_edit(self):
        for before, after in [('急切地说', '冷漠地说'), ('\r\n', '\n')]:
            _, record, actual = self.compiled_record()
            record['params']['prompt'] = record['params']['prompt'].replace(before, after)
            actual['params'] = copy.deepcopy(record['params'])
            with self.assertRaises(PipelineError):
                validate_shot(record, actual)

    def test_forged_edit_ledger_is_rejected(self):
        _, record, actual = self.compiled_record()
        record['binding_edits'].append({'start': 0, 'end': 0, 'before': '', 'after': 'new story'})
        with self.assertRaisesRegex(PipelineError, 'ledger'):
            validate_shot(record, actual)

    def test_changed_source_rejected_even_if_saved_node_unchanged(self):
        _, record, actual = self.compiled_record()
        self.source.write_bytes(RAW.replace('Stay with me.', 'Leave me.').encode('utf-8'))
        with self.assertRaisesRegex(PipelineError, 'source changed'):
            validate_shot(record, actual)

    def test_real_token_in_timeline_is_not_removed_or_rewritten(self):
        self.source.write_bytes((RAW + '%%@[Extra][image][0](seren)%%').encode('utf-8'))
        with self.assertRaisesRegex(PipelineError, 'outside mapped'):
            compile_shot(self.shot(), self.nodes)

    def test_duplicate_tokens_on_asset_line_rejected(self):
        self.source.write_bytes(RAW.replace('Seren｜', 'Seren %%@[A][image][0](seren)%% %%@[B][image][0](seren)%%｜').encode('utf-8'))
        with self.assertRaisesRegex(PipelineError, 'Multiple asset'):
            compile_shot(self.shot(), self.nodes)

    def test_resolver_uses_bound_copy_and_actual_saved_uuid(self):
        manifest, record, actual = self.compiled_record()
        actual['uuid'] = 'platform-new-uuid'
        result = resolve(manifest, [actual])
        self.assertEqual(result['shots'][0]['node_uuid'], 'platform-new-uuid')
        self.assertEqual(result['shots'][0]['binding_edits'], record['binding_edits'])

    def test_board_missing_token_and_old_index_can_be_bound_in_existing_header(self):
        refs = self.refs + [{'category': 'storyboard_reference', 'node_uuid': 'board'}]
        labels = {uid: node['label'] for uid, node in self.nodes.items()} | {'board': 'Board'}
        for old in ['', '〈六宫格真实@待绑定〉', '%%@[Old][image][99](old-board)%%']:
            raw = '**六宫格首帧引用：** 六宫格参考图' + old + '，逐格参考。\r\n\r\n' + RAW
            bound, _, edits = compile_mentions(raw, refs, labels, 'original_15s')
            self.assertEqual(bound.count('%%@[Board][image][4](board)%%'), 1)
            self.assertEqual(apply_binding_edits(raw, edits), bound)
            self.assertEqual(bound[bound.index('# 第04集'):].split('## 时间线')[1], RAW.split('## 时间线')[1])


if __name__ == '__main__':
    unittest.main()
