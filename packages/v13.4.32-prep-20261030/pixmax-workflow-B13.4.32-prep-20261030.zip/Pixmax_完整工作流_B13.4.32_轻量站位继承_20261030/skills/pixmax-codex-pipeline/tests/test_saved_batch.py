"""Offline regression tests for duplicate-charge and binding risks; no network."""
import copy
import hashlib
import json
import sys
import tempfile
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'scripts'))
from submit_saved_batch import run, preflight, validate_shot, PipelineError

def fixtures():
    shot={'id':'S01','node_uuid':'video-1','params':{'nodeType':'GENERATE_VIDEO','model':'PIXDANCE_2_FAST','prompt':'人物指定：%%@[A][image][0](char-1)%%\n场景指定：%%@[Room][image][1](scene-1)%%\n正文','count':1},'prevNodeUuids':['char-1','scene-1'],'bindings':[{'category':'character','node_uuid':'char-1'},{'category':'scene','node_uuid':'scene-1'}],'character_asset_uuids':['asset-char'],'mention_ranges':[[0,67]]}
    shot['mention_ranges']=[[0,shot['params']['prompt'].index('正文')]]
    nodes=[{'uuid':'video-1','params':copy.deepcopy(shot['params']),'prevNodeUuids':shot['prevNodeUuids'],'taskUuid':None},{'uuid':'char-1','defaultAsset':{'assetsUuid':'asset-char'}},{'uuid':'scene-1','defaultAsset':{'assetsUuid':'asset-scene'}}]
    # Synthetic review records for offline tests; not production review evidence.
    shot['visual_review']={'policy':'asset_visual_review_v1','status':'PASS','node_uuid':'video-1',
        'prompt_sha256':hashlib.sha256(shot['params']['prompt'].encode()).hexdigest(),
        'script_file':str(Path(__file__).resolve()), 'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'script_location':'Synthetic scene 1','shot_assessment':'Synthetic fixture is suitable',
        'reviewed_at':'2026-10-02T00:00:00Z',
        'images':[{'node_uuid':b['node_uuid'],'category':b['category'],'asset_uuid':nodes[i+1]['defaultAsset']['assetsUuid'],
                   'viewed':True,'status':'PASS','view_evidence':'Synthetic test pixels',
                   'requirement':'Synthetic required state','observation':'Synthetic matching state'} for i,b in enumerate(shot['bindings'])]}
    return {'file_uuid':'canvas','shots':[shot]},nodes

class Fake:
    def __init__(self, nodes, timeout=False, check='ACTIVE', extra=False):
        self.nodes=nodes; self.timeout=timeout; self.check=check; self.extra=extra
        self.runs=0; self.tasks=[]; self.calls=[]; self.active_group=True
    def __call__(self,*args):
        self.calls.append(args)
        if args[:2]==('tasks','progress'): return {'data':self.tasks}
        if args[:2]==('canvas','nodes'): return self.nodes
        if args[:2]==('assets','compliance-check'): return {'data':{'complianceStatus':self.check}}
        if args[:2]==('group','unuse'):
            self.active_group=False
            return {'groupUnbound':True}
        if args[:2]==('group','bind'):
            if self.active_group: raise PipelineError('Node not found: filtered by stale active group')
            return {'nodeUuids':['video-1']+(['wrong-node'] if self.extra else [])}
        if '--dry-run' in args: return {'dryRun':True,'endpoint':'/generate/batch','payload':{'fileUuid':'canvas','nodeUuids':['video-1'],'nodes':['video-1']}}
        if args[:2]==('group','run'):
            self.runs+=1
            self.tasks=[{'nodeUuid':'video-1','taskUuid':'paid-task','status':'QUEUE'}]
            if self.timeout: raise TimeoutError('Response lost after acceptance')
            return {'success':True,'data':self.tasks}
        raise AssertionError(args)

class SavedBatchTest(unittest.TestCase):
    def test_duplicate_scene_token_is_rejected(self):
        m,n=fixtures(); s=m['shots'][0]
        s['params']['prompt']='%%@[Room][image][1](scene-1)%%'+s['params']['prompt']
        n[0]['params']=copy.deepcopy(s['params'])
        with self.assertRaises(PipelineError): validate_shot(s,n[0])
    def test_swapped_inputs_without_reindexed_mentions_are_rejected(self):
        m,n=fixtures(); n[0]['prevNodeUuids']=['scene-1','char-1']
        with self.assertRaises(PipelineError): preflight(m,n,[])
    def test_timeout_after_acceptance_does_not_charge_twice(self):
        m,n=fixtures(); api=Fake(n,timeout=True)
        with tempfile.TemporaryDirectory() as folder:
            with self.assertRaises(TimeoutError): run(m,folder,submit=True,api=api)
            result=run(m,folder,submit=True,api=api)
            self.assertFalse(result['resubmitted']); self.assertEqual(api.runs,1)
    def test_same_batch_can_only_submit_once(self):
        m,n=fixtures(); api=Fake(n)
        with tempfile.TemporaryDirectory() as folder:
            self.assertEqual(run(m,folder,submit=True,api=api)['phase'],'SUBMITTED')
            run(m,folder,submit=True,api=api)
            self.assertEqual(api.runs,1)
    def test_prior_active_group_is_cleared_before_binding(self):
        m,n=fixtures(); api=Fake(n)
        with tempfile.TemporaryDirectory() as folder:
            run(m,folder,submit=True,api=api)
            commands=[c[:2] for c in api.calls]
            self.assertLess(commands.index(('group','unuse')),commands.index(('group','bind')))
            self.assertEqual(api.runs,1)
    def test_processing_character_stops_before_generation(self):
        m,n=fixtures(); api=Fake(n,check='PROCESSING')
        with tempfile.TemporaryDirectory() as folder:
            with self.assertRaises(PipelineError): run(m,folder,submit=True,api=api)
            self.assertEqual(api.runs,0)
    def test_group_contamination_cannot_generate_extra_node(self):
        m,n=fixtures(); api=Fake(n,extra=True)
        with tempfile.TemporaryDirectory() as folder:
            with self.assertRaises(PipelineError): run(m,folder,submit=True,api=api)
            self.assertEqual(api.runs,0)
    def test_completed_tasks_are_skipped_even_with_new_record_folder(self):
        m,n=fixtures(); api=Fake(n); api.tasks=[{'nodeUuid':'video-1','taskUuid':'existing','status':'COMPLETE'}]
        with tempfile.TemporaryDirectory() as folder:
            self.assertEqual(run(m,folder,submit=True,api=api)['ready'],[])
            self.assertEqual(api.runs,0)
    def test_plan_makes_no_compliance_or_group_mutations(self):
        m,n=fixtures(); api=Fake(n)
        with tempfile.TemporaryDirectory() as folder:
            self.assertEqual(run(m,folder,api=api)['ready'],['video-1'])
            self.assertEqual(api.runs,0)
            self.assertTrue(all(c[:2] in [('tasks','progress'),('canvas','nodes')] for c in api.calls))
    def test_scene_edit_requires_real_mother_image_without_video_mentions(self):
        m,n=fixtures(); s=m['shots'][0]
        s['params']={'nodeType':'GENERATE_IMAGE','model':'PIXIMAGE_2','prompt':'Change daylight to night; preserve the room layout.','count':1}
        s['prevNodeUuids']=['scene-1']; s['bindings']=[{'category':'scene','node_uuid':'scene-1'}]
        s['character_asset_uuids']=[]; s['mention_ranges']=[]
        n[0]['params']=copy.deepcopy(s['params']); n[0]['prevNodeUuids']=['scene-1']
        self.assertEqual(preflight(m,n,[])[0],['video-1'])
        n[2]['defaultAsset']={}
        with self.assertRaises(PipelineError): preflight(m,n,[])

    def test_unreviewed_video_cannot_submit_or_trigger_compliance(self):
        m,n=fixtures(); m['shots'][0].pop('visual_review'); api=Fake(n)
        with tempfile.TemporaryDirectory() as folder:
            plan=run(m,folder,api=api)
            self.assertEqual(plan['generation_ready'],[])
            self.assertEqual(len(plan['visual_review_pending']),1)
            with self.assertRaises(PipelineError): run(m,folder,submit=True,api=api)
        self.assertTrue(all(c[:2] in [('tasks','progress'),('canvas','nodes')] for c in api.calls))

    def test_existing_task_does_not_require_retroactive_visual_review(self):
        m,n=fixtures(); m['shots'][0].pop('visual_review'); api=Fake(n)
        api.tasks=[{'nodeUuid':'video-1','taskUuid':'existing','status':'COMPLETE'}]
        with tempfile.TemporaryDirectory() as folder:
            self.assertEqual(run(m,folder,submit=True,api=api)['existing'][0]['task_uuid'],'existing')
        self.assertEqual(api.runs,0)

    def test_asset_changed_during_preflight_cannot_reach_group_submission(self):
        m,n=fixtures(); api=Fake(n)
        def concurrent_change(*args):
            result=api(*args)
            if args[:2]==('assets','compliance-check'):
                n[2]['defaultAsset']['assetsUuid']='new-unreviewed-scene'
            return result
        with tempfile.TemporaryDirectory() as folder:
            with self.assertRaises(PipelineError): run(m,folder,submit=True,api=concurrent_change)
        self.assertEqual(api.runs,0)
        self.assertFalse(any(c[:2]==('group','bind') for c in api.calls))

if __name__=='__main__': unittest.main()
