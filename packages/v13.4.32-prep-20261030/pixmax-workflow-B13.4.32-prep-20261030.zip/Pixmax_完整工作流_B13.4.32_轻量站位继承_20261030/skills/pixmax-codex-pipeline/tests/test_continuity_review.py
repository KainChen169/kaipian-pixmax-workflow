"""Offline provenance checks; synthetic evidence never represents real visual review."""
import copy
import hashlib
from pathlib import Path
import tempfile
import unittest
from test_saved_batch import fixtures
from asset_visual_review import validate_visual_review, visual_review_errors
from pixmax_pipeline import PipelineError


class ContinuityReviewTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        root = Path(self.temp.name)
        self.previous = root/'previous.txt'
        self.previous.write_text('Earlier scene: coat removed.', encoding='utf-8')
        self.ledger = root/'continuity.md'
        self.ledger.write_text('Synthetic: coat remains off until a documented change.', encoding='utf-8')
        self.manifest, self.nodes = fixtures()
        self.shot = self.manifest['shots'][0]
        self.shot['params']['model'] = 'PIXDANCE_2_5_DRAFT'
        self.by_node = {n['uuid']: n for n in self.nodes}
        script = Path(self.shot['visual_review']['script_file'])
        self.evidence = {
            'policy': 'cross_episode_continuity_v1', 'status': 'PASS',
            'scope': 'Synthetic previous and current scene context',
            'sources': [{'file': str(p), 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in (script, self.previous)],
            'ledger_file': str(self.ledger), 'ledger_sha256': hashlib.sha256(self.ledger.read_bytes()).hexdigest(),
            'checks': {k: {'status': 'PASS', 'observation': 'Synthetic evidence: '+k} for k in
                       ('character_state','scene_daynight','blocking_facing','prop_continuity')}
        }
        self.shot['visual_review']['continuity_review'] = self.evidence

    def test_current_complete_evidence_passes(self):
        validate_visual_review(self.shot, self.by_node)

    def test_previous_episode_change_invalidates_unchanged_current_shot(self):
        self.previous.write_text('Earlier scene revised: coat put back on.', encoding='utf-8')
        with self.assertRaisesRegex(PipelineError, 'cross-episode script change'):
            validate_visual_review(self.shot, self.by_node)

    def test_ledger_change_invalidates_review(self):
        self.ledger.write_text('State changed', encoding='utf-8')
        with self.assertRaisesRegex(PipelineError, 'ledger is missing or changed'):
            validate_visual_review(self.shot, self.by_node)

    def test_each_unresolved_category_blocks(self):
        original = copy.deepcopy(self.evidence)
        for category in original['checks']:
            for update in ({'status':'UNCERTAIN'}, {'observation':''}):
                with self.subTest(category=category, update=update):
                    candidate = copy.deepcopy(original)
                    candidate['checks'][category].update(update)
                    self.shot['visual_review']['continuity_review'] = candidate
                    with self.assertRaises(PipelineError): validate_visual_review(self.shot, self.by_node)

    def test_new_25_shot_without_context_is_not_ready(self):
        self.shot['visual_review'].pop('continuity_review')
        errors = visual_review_errors(self.manifest, self.nodes, [self.shot['node_uuid']])
        self.assertEqual(len(errors), 1)

    def test_history_outside_new_ready_set_does_not_require_retroactive_evidence(self):
        self.shot['visual_review'].pop('continuity_review')
        self.assertEqual(visual_review_errors(self.manifest, self.nodes, []), [])

    def test_current_script_cannot_be_omitted_from_sources(self):
        self.evidence['sources'] = self.evidence['sources'][1:]
        with self.assertRaisesRegex(PipelineError, 'include the reviewed shot script'):
            validate_visual_review(self.shot, self.by_node)

    def test_missing_source_file_blocks(self):
        self.previous.unlink()
        with self.assertRaises(PipelineError): validate_visual_review(self.shot, self.by_node)

    def test_legacy_branch_remains_compatible(self):
        self.shot['params']['model'] = 'PIXDANCE_2_FAST'
        self.shot['visual_review'].pop('continuity_review')
        validate_visual_review(self.shot, self.by_node)

    def test_role_also_requires_context(self):
        self.shot['params']['model'] = 'OTHER_MODEL'
        self.shot['prompt_role'] = 'seedance25_30s'
        self.shot['visual_review'].pop('continuity_review')
        with self.assertRaises(PipelineError): validate_visual_review(self.shot, self.by_node)

    def test_binding_25_initializes_pending_without_manufacturing_approval(self):
        from fast_bind import compile_batch
        path = Path(self.temp.name)/'prompt.md'
        text = ('# 第01集\n总时长：30秒｜画幅：9:16竖屏\n'
                '## 1. 人物指定\n**林夕：** 左臂有纱布。\n'
                '## 2. 场景指定\n**客厅｜夜｜内：** 窗在右侧。\n'
                '## 3. 道具指定\n**信纸：** 右手持有。\n'
                '## 4. 时间线镜头设计\n林夕说：“请留下。”\n')
        path.write_text(text, encoding='utf-8')
        refs = [{'category':c, 'node_uuid':uid, 'designation':name} for c,uid,name in
                [('character','c','林夕'),('scene','s','客厅'),('prop','p','信纸')]]
        nodes = [{'uuid':r['node_uuid'],'label':r['designation'],'type':'BASE_IMAGE',
                  'defaultAsset':{'assetsUuid':'asset-'+r['node_uuid']}} for r in refs]
        shot = {'id':'EP01_S001','label':'EP01_S001','prompt_file':str(path),
                'prompt_role':'seedance25_30s','bindings':refs,'max_image_inputs':30,
                'supported_durations':list(range(4,31)),
                'params':{'nodeType':'GENERATE_VIDEO','model':'PIXDANCE_2_5_DRAFT',
                          'duration':'30','count':'1','referModel':'referToVideo'}}
        manifest,_ = compile_batch({'file_uuid':'test','shots':[shot]}, nodes)
        review = manifest['shots'][0]['visual_review']
        self.assertEqual(review['status'], 'PENDING')
        self.assertEqual(review['continuity_review']['status'], 'PENDING')
        self.assertEqual(path.read_text(encoding='utf-8'), text)


if __name__ == '__main__': unittest.main()
