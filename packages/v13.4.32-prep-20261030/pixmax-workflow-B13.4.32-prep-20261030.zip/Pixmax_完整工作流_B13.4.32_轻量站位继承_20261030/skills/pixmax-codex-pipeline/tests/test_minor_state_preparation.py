"""Offline behavior cases with synthetic evidence, not generated-image QA.

The agent chooses necessity from the script; validators check those recorded
decisions and provenance. No network, image/video generation or historical edits.
"""
import copy
import hashlib
import json
from pathlib import Path
import tempfile
import unittest

from test_saved_batch import fixtures, Fake
from submit_saved_batch import run, PipelineError
from validate_character_states import validate
from state_board_review import validate_state_board_review


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


class MinorStatePreparationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.script = self.root / 'script.md'
        self.ledger = self.root / 'continuity.md'
        self.script.write_text('Synthetic script', encoding='utf-8')
        self.ledger.write_text('Synthetic reviewed state plan', encoding='utf-8')
        self.manifest, self.nodes = fixtures()
        self.shot = self.manifest['shots'][0]
        self.shot['params'].update(model='PIXDANCE_2_5_DRAFT', duration=25,
                                  resolution='480P', aspectRatio='9:16', includeAudio=True)
        self.nodes[0]['params'] = copy.deepcopy(self.shot['params'])
        review = self.shot['visual_review']
        review.update(script_file=str(self.script), script_sha256=digest(self.script))
        review['images'][0].update(
            requirement='Identity and principal outfit mother; shot text handles minor state',
            observation='Synthetic mother is clean, correct identity/outfit. No wound claimed.')
        review['continuity_review'] = {
            'policy': 'cross_episode_continuity_v1', 'status': 'PASS',
            'scope': 'Synthetic relevant present/earlier/flashback story scope',
            'sources': [{'file': str(self.script), 'sha256': digest(self.script)}],
            'ledger_file': str(self.ledger), 'ledger_sha256': digest(self.ledger),
            'checks': {key: {'status': 'PASS', 'observation': 'Synthetic reviewed '+key}
                       for key in ('character_state', 'scene_daynight', 'blocking_facing', 'prop_continuity')}}

    def plan(self, state_text, observation):
        self.shot['params']['prompt'] += '\n' + state_text
        self.shot['visual_review']['prompt_sha256'] = hashlib.sha256(
            self.shot['params']['prompt'].encode()).hexdigest()
        self.shot['visual_review']['continuity_review']['checks']['character_state']['observation'] = observation
        self.nodes[0]['params'] = copy.deepcopy(self.shot['params'])
        api = Fake(self.nodes)
        result = run(self.manifest, self.root/'records', submit=False, api=api)
        self.assertEqual(api.runs, 0)
        self.assertTrue(all(c[:2] in [('tasks','progress'), ('canvas','nodes')] for c in api.calls))
        return result

    def assert_prepared(self, text, decision):
        result = self.plan(text, decision)
        self.assertEqual(result['generation_ready'], ['video-1'])
        self.assertEqual(result['visual_review_pending'], [])
        self.assertFalse(result['generation_submitted'])
        self.assertEqual(self.shot['prevNodeUuids'], ['char-1','scene-1'])
        self.assertNotIn('state_board_review', self.shot['visual_review']['images'][0])

    def test_minor_scrape_in_medium_close_shot_needs_no_board(self):
        self.assert_prepared('A small left forearm scrape remains during the rescue.',
                             'Script scrape retained in shot text; clean mother only locks identity/outfit; output unverified.')

    def test_non_narrative_sleeve_tear_and_dirt_are_not_image_dependencies(self):
        self.assert_prepared('She turns to the doorway.',
                             'Unspecified minor dirt/sleeve wear not evidence or identification; tolerance, not a new image requirement.')

    def test_past_injury_dialogue_does_not_make_present_scar_dependency(self):
        self.assert_prepared('A says: "You bit me last winter."',
                             'Past injury mentioned, no present mark display; no scar invented in current mother or prompt.')

    def test_small_rescue_blood_is_retained_without_full_body_remake(self):
        self.assert_prepared('A small blood spot remains on her right cuff as she supports him.',
                             'Current continuous rescue: right cuff spot in text, identity mother reused; no new board.')

    def test_mid_segment_scratch_is_not_in_opening_state(self):
        self.assert_prepared('0-3s clean wrist; 3-4s branch scratches wrist; 4-25s small scratch remains.',
                             'Clean opening mother; triggered scratch only after 3s; text state timing preserved; output unverified.')

    def test_key_identification_mark_unresolved_still_blocks(self):
        check = self.shot['visual_review']['continuity_review']['checks']['character_state']
        check['status'] = 'UNCERTAIN'
        result = self.plan('Close-up of the exact two-dot clue on her right hand.',
                           'Identification depends on precise dots; actual reference lacks sufficient local detail.')
        self.assertEqual(result['generation_ready'], [])
        self.assertEqual(len(result['visual_review_pending']), 1)

    def test_transformation_body_shape_or_severe_posture_gap_still_blocks(self):
        for state in ('zombie face', 'changed abdominal silhouette', 'severe injury posture'):
            with self.subTest(state=state):
                self.shot['visual_review']['images'][0]['status'] = 'NEEDS_FIX'
                result = self.plan('Required '+state, 'Actual mother lacks required '+state+' support.')
                self.assertEqual(result['generation_ready'], [])

    def test_wrong_face_main_outfit_scene_or_time_domain_still_blocks(self):
        for index, mismatch in ((0,'wrong face'), (0,'wrong main outfit'),
                                (1,'wrong room'), (1,'wrong story time domain')):
            with self.subTest(mismatch=mismatch):
                for row in self.shot['visual_review']['images']: row['status'] = 'PASS'
                self.shot['visual_review']['images'][index]['status'] = 'NEEDS_FIX'
                result = self.plan('Return to the current rescue.', 'Recorded mismatch: '+mismatch)
                self.assertEqual(result['generation_ready'], [])

    def test_nonrequired_old_fail_history_unchanged_and_not_connected(self):
        history = self.root/'asset-history.json'
        history.write_text(json.dumps({'status':'FAILED','task_uuid':'old-task',
                                     'attempts':3,'cost':50}), encoding='utf-8')
        before = history.read_bytes()
        self.assert_prepared('Minor dirt handled in text.',
                             'Old failed dirt board is unnecessary; remove current dependency only, keep history.')
        self.assertEqual(history.read_bytes(), before)

    def test_queued_task_reused_without_submission(self):
        api = Fake(self.nodes)
        api.tasks = [{'nodeUuid':'video-1','taskUuid':'existing','status':'QUEUE'}]
        result = run(self.manifest, self.root/'queue', api=api)
        self.assertEqual(result['ready'], [])
        self.assertEqual(result['existing'][0]['task_uuid'], 'existing')
        self.assertEqual(api.runs, 0)

    def test_unknown_existing_task_requires_reconciliation_not_resubmit(self):
        api = Fake(self.nodes)
        api.tasks = [{'nodeUuid':'video-1','taskUuid':'existing','status':'UNKNOWN'}]
        with self.assertRaises(PipelineError): run(self.manifest, self.root/'unknown', api=api)
        self.assertEqual(api.runs, 0)


class LegacyStatePlanTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.prompt = self.root/'prompt.md'
        self.prompt.write_text('# 第01集｜镜头01｜救援｜15秒完整视频执行提示词\n', encoding='utf-8')
        self.mother = self.root/'mother.png'
        self.mother.write_bytes(b'synthetic identity mother, not real pixels')
        self.state = self.root/'state.png'
        self.state.write_bytes(b'synthetic state evidence, not real pixels')
        self.row = {'shot_id':'EP01_S001', 'character':'A', 'from_state':'clean',
                    'to_state':'small scrape', 'trigger':'branch contact at 3s',
                    'visible_from':'3s','visible_until':'15s',
                    'mother_image':'mother.png','mother_sha256':digest(self.mother),
                    'state_image':'state.png','state_sha256':digest(self.state),
                    'review':{k:'PASS' for k in ('same_face','same_person','outfit_continuity','script_state','non_graphic')}}
        self.ledger = {'episode_prompt_files':[{'path':'prompt.md','sha256':digest(self.prompt)}],
                       'reviewed_shots':['EP01_S001'], 'transitions':[self.row]}

    def nonimage(self, mode):
        self.row['implementation'] = mode
        self.row['reason'] = 'Minor non-identifying state; correct mother locks identity/outfit.'
        self.row['prompt_state'] = 'Clean until branch at 3s; small left wrist scrape persists afterwards.'
        self.row.pop('state_image'); self.row.pop('state_sha256')
        self.state.unlink()

    def test_prompt_plan_without_state_image_passes(self):
        self.nonimage('prompt')
        result = validate(self.ledger, self.root)
        self.assertTrue(result['ready'])
        self.assertEqual(result['transitions'][0]['asset'], 'mother.png')

    def test_tolerance_plan_without_state_image_passes(self):
        self.nonimage('tolerance')
        self.assertTrue(validate(self.ledger, self.root)['ready'])

    def test_legacy_state_image_plan_still_requires_actual_image(self):
        self.assertTrue(validate(self.ledger, self.root)['ready'])
        self.state.unlink()
        with self.assertRaises(PipelineError): validate(self.ledger, self.root)

    def test_nonimage_plan_requires_decision_and_shot_expression(self):
        self.nonimage('prompt')
        for field in ('reason','prompt_state'):
            value = self.row.pop(field)
            with self.assertRaises(PipelineError): validate(self.ledger, self.root)
            self.row[field] = value

    def test_wrong_mother_or_unresolved_key_state_cannot_pass(self):
        self.nonimage('prompt')
        for key in ('same_face','outfit_continuity','script_state'):
            self.row['review'][key] = 'NEEDS_FIX'
            with self.assertRaises(PipelineError): validate(self.ledger, self.root)
            self.row['review'][key] = 'PASS'
        self.row['mother_sha256'] = 'stale'
        with self.assertRaises(PipelineError): validate(self.ledger, self.root)


class ActualStateBoardGateTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        path = Path(self.temp.name)/'board.png'
        path.write_bytes(b'synthetic board, not pixels')
        anchor = {'body_side':'right','surface':'front waist','height_reference':'waist seam'}
        boxes = {'front':[0,0,.2,1], 'profile':[.2,0,.4,1],
                 'face_closeup':[.4,0,.6,.4], 'state_closeup':[.6,0,1,.4]}
        review = {'policy':'character_state_board_v3','status':'PASS',
                  'asset_uuid':'asset-board','image_sha256':digest(path),
                  'viewed_at_full_resolution':True,
                  'views':{name:{'status':'PASS','observation':'Synthetic '+name,
                                 'image_region':box} for name,box in boxes.items()},
                  'state_items':[{'anchor':anchor,'count':1,'by_view':{
                      name:{**anchor,'count':1,'status':'PASS','observation':'Synthetic anchored item',
                            'occlusion':'none','shape_scale_orientation_matches':True}
                      for name in ('front','profile','state_closeup')}}]}
        review['views']['face_closeup']['identity_matches_original'] = True
        review['views']['profile'].update(body_side='right', facing_in_board='screen_right')
        self.row = {'node_uuid':'board','asset_uuid':'asset-board', 'view_evidence':str(path),
                    'reference_kind':'character_state_board','state_board_review':review}

    def test_required_complete_board_still_passes(self):
        self.assertIsNotNone(validate_state_board_review(self.row))

    def test_required_board_wrong_identity_side_or_missing_view_still_fails(self):
        baseline = copy.deepcopy(self.row)
        for kind in ('identity','side','view'):
            row = copy.deepcopy(baseline)
            views = row['state_board_review']['views']
            if kind=='identity': views['face_closeup']['identity_matches_original'] = False
            elif kind=='side': views['profile']['facing_in_board'] = 'screen_left'
            else: views.pop('state_closeup')
            with self.subTest(kind=kind), self.assertRaises(PipelineError): validate_state_board_review(row)

    def test_normal_identity_mother_not_subject_to_board_views(self):
        self.assertIsNone(validate_state_board_review({'node_uuid':'mother','asset_uuid':'identity'}))


if __name__ == '__main__': unittest.main()
