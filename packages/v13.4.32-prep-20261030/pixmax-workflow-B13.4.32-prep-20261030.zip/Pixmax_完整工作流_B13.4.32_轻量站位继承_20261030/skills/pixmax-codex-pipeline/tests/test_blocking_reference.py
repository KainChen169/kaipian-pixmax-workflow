"""Offline checks for an unmentioned first blocking image; no Pixmax network calls."""
import copy
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from fast_bind import compile_shot, compile_batch
from submit_saved_batch import validate_shot, preflight, PipelineError

CHAR = "%%@[Hero][image][1](char-1)%%"
SCENE = "%%@[Room][image][2](scene-1)%%"
PROMPT = f"**人物指定：**\nHero {CHAR}\n\n**场景指定：**\nRoom {SCENE}\n\n**时间线镜头设计：**\n镜头1｜全景"


def image_nodes():
    return {
        "char-1": {"uuid": "char-1", "type": "BASE_IMAGE", "label": "Hero", "defaultAsset": {"assetsUuid": "asset-char"}},
        "scene-1": {"uuid": "scene-1", "type": "BASE_IMAGE", "label": "Room", "defaultAsset": {"assetsUuid": "asset-scene"}},
        "blocking-1": {"uuid": "blocking-1", "type": "GENERATE_IMAGE", "label": "Blocking", "defaultAsset": {"assetsUuid": "asset-blocking"}},
    }


def bindings():
    return [
        {"category": "blocking_reference", "node_uuid": "blocking-1"},
        {"category": "character", "node_uuid": "char-1", "designation": "Hero"},
        {"category": "scene", "node_uuid": "scene-1", "designation": "Room"},
    ]


class BlockingReferenceTest(unittest.TestCase):
    def test_original_prompt_unchanged_and_first_image_unmentioned(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "original.md"
            path.write_bytes(PROMPT.encode("utf-8"))
            compiled, ranges, characters, role, digest = compile_shot({
                "id": "S01", "prompt_file": str(path), "bindings": bindings(),
                "max_image_inputs": 3, "prompt_role": "original_15s",
            }, image_nodes())
            self.assertEqual(compiled, PROMPT)
            self.assertNotIn("blocking-1", compiled)
            self.assertEqual(characters, ["asset-char"])
            self.assertEqual(role, "original_15s")
            self.assertTrue(ranges)
            self.assertEqual(len(digest), 64)

    def test_missing_original_at_is_filled_without_changing_source(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "original.md"
            path.write_bytes(PROMPT.replace(SCENE, "").encode("utf-8"))
            before = path.read_bytes()
            compiled, _, _, _, _ = compile_shot({"id": "S01", "prompt_file": str(path), "bindings": bindings(),
                              "max_image_inputs": 3, "prompt_role": "original_15s"}, image_nodes())
            self.assertIn(SCENE, compiled)
            self.assertEqual(path.read_bytes(), before)

    def test_blocking_must_be_single_first_input_and_count_against_limit(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "original.md"
            path.write_bytes(PROMPT.encode("utf-8"))
            base = {"id": "S01", "prompt_file": str(path), "max_image_inputs": 3,
                    "prompt_role": "original_15s"}
            for bad in (bindings()[::-1], bindings() + [bindings()[-1]]):
                with self.assertRaises(PipelineError):
                    compile_shot({**base, "bindings": bad}, image_nodes())
            with self.assertRaises(PipelineError):
                compile_shot({**base, "bindings": bindings(), "max_image_inputs": 2}, image_nodes())

    def test_supplement_adds_only_designated_mentions(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "supplement.md"
            raw = "**人物指定：**\nHero\n\n**场景指定：**\nRoom\n\n**时间线镜头设计：**\n镜头1｜全景"
            path.write_bytes(raw.encode("utf-8"))
            compiled, _, _, role, _ = compile_shot({
                "id": "S01_CLOSEUP", "prompt_file": str(path), "bindings": bindings(),
                "max_image_inputs": 3, "prompt_role": "supplement",
            }, image_nodes())
            self.assertEqual(role, "supplement")
            self.assertIn(CHAR, compiled)
            self.assertIn(SCENE, compiled)
            self.assertNotIn("blocking-1", compiled)
            self.assertEqual(compiled.count("%%@"), 2)
    def test_new_batch_rejects_removed_blocking_workflow(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "original.md"
            path.write_bytes(PROMPT.encode("utf-8"))
            plan = {"file_uuid": "file-1", "shots": [{
                "id": "S01", "label": "video-1", "prompt_file": str(path),
                "prompt_role": "original_15s", "bindings": bindings(),
                "max_image_inputs": 3, "max_prompt_chars": 5000,
                "supported_durations": [15],
                "params": {"nodeType": "GENERATE_VIDEO", "model": "PIXDANCE_2_FAST",
                           "duration": "15", "count": "1", "referModel": "referToVideo"},
            }]}
            with self.assertRaisesRegex(PipelineError, 'workflow removed'):
                compile_batch(plan, list(image_nodes().values()))
    def test_saved_video_accepts_exact_first_unmentioned_image(self):
        order = ["blocking-1", "char-1", "scene-1"]
        prompt = PROMPT
        expected = {"node_uuid": "video-1", "params": {"nodeType": "GENERATE_VIDEO", "prompt": prompt, "count": 1},
                    "prevNodeUuids": order, "bindings": bindings(), "character_asset_uuids": ["asset-char"],
                    "mention_ranges": [[0, len(prompt)]]}
        actual = {"uuid": "video-1", "params": copy.deepcopy(expected["params"]),
                  "prevNodeUuids": order, "taskUuid": None}
        validate_shot(expected, actual)
        nodes = [actual, *image_nodes().values()]
        self.assertEqual(preflight({"shots": [expected]}, nodes, [])[0], ["video-1"])
        bad = copy.deepcopy(expected)
        bad["params"]["prompt"] += " %%@[Blocking][image][2](blocking-1)%%"
        actual["params"] = copy.deepcopy(bad["params"])
        with self.assertRaises(PipelineError):
            validate_shot(bad, actual)

    def test_saved_video_rejects_nonfirst_or_duplicate_blocking(self):
        expected = {"node_uuid": "video-1", "params": {"nodeType": "GENERATE_VIDEO", "prompt": PROMPT, "count": 1},
                    "prevNodeUuids": ["blocking-1", "char-1", "scene-1"],
                    "bindings": bindings(), "character_asset_uuids": ["asset-char"],
                    "mention_ranges": [[0, len(PROMPT)]]}
        actual = {"uuid": "video-1", "params": copy.deepcopy(expected["params"]),
                  "prevNodeUuids": expected["prevNodeUuids"]}
        for ordered_bindings in (bindings()[::-1], bindings() + [bindings()[-1]]):
            bad = copy.deepcopy(expected)
            bad["bindings"] = ordered_bindings
            bad["prevNodeUuids"] = [b["node_uuid"] for b in ordered_bindings]
            actual["prevNodeUuids"] = bad["prevNodeUuids"]
            with self.assertRaises(PipelineError):
                validate_shot(bad, actual)


if __name__ == "__main__":
    unittest.main()