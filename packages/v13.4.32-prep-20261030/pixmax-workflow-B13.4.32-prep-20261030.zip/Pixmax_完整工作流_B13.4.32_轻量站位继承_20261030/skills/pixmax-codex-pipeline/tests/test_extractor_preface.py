"""The episode extractor must keep a per-shot pre-title board instruction."""

import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from extract_episode_bundle import parse_bundle


PANELS = "\n".join(f"PANEL {n}: Hero in the same room." for n in range(1, 7))
VIDEO = """# 第03集｜镜头08｜测试｜15秒完整视频执行提示词

**人物指定：**
Hero

**场景指定：**
Room
日景。

""" + "\n".join(f"### 镜头{n}｜{n}秒｜近景｜固定\n" for n in range(1, 7))
APPENDIX = """
<!-- PIXMAX_SIX_PANEL_APPENDIX_START -->
# 第03集｜六宫格分镜参考图英文提示词

## 镜头08｜六宫格英文提示词
```text
CHARACTER REFERENCES: Hero
SCENE REFERENCE: Room, day
GLOBAL LOCK: One room.
""" + PANELS + """
```
<!-- PIXMAX_SIX_PANEL_APPENDIX_END -->
"""


class ExtractorPrefaceTests(unittest.TestCase):
    def test_pretitle_instruction_is_part_of_the_shot(self):
        with tempfile.TemporaryDirectory() as folder:
            source = Path(folder) / "episode.md"
            source.write_text("**六宫格首帧引用：** 参考图〈六宫格真实@待绑定〉。\n\n" + VIDEO + APPENDIX,
                              encoding="utf-8")
            item = parse_bundle(source)["records"][0]
            self.assertTrue(item["video_text"].startswith("**六宫格首帧引用：**"))
            self.assertIn("# 第03集｜镜头08", item["video_text"])

    def test_legacy_title_first_still_parses(self):
        with tempfile.TemporaryDirectory() as folder:
            source = Path(folder) / "episode.md"
            source.write_text(VIDEO + APPENDIX, encoding="utf-8")
            self.assertTrue(parse_bundle(source)["records"][0]["video_text"].startswith("# 第03集"))


if __name__ == "__main__":
    unittest.main()
