"""No network: add exactly one edge without adding a token, shot or second."""
import copy
import hashlib
import tempfile
import unittest
from pathlib import Path

from test_shot_body_mentions import RAW, REFS, POINTS, POLICY
from test_saved_batch import fixtures
from fast_bind import compile_batch
from submit_saved_batch import validate_shot, preflight, PipelineError
from resolve_saved_batch import resolve
from asset_visual_review import validate_visual_review
from black_video_reference import POLICY as BLACK_POLICY, SHA256, SOURCE


def black():
    return dict(policy=BLACK_POLICY, node_uuid='black', asset_uuid='asset-black',
                source_sha256=SHA256, duration_seconds=2)


def video_node():
    return dict(uuid='black', type='BASE_VIDEO', label='Black 2s',
                defaultAsset={'assetsUuid': 'asset-black'})


class BlackVideoReferenceTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name) / 'source.md'
        self.path.write_bytes(RAW.encode())
        self.shot = dict(id='EP01_S001', label='new video', prompt_file=str(self.path),
                         prompt_role='seedance25_v134', binding_policy=POLICY,
                         body_mentions=copy.deepcopy(POINTS), bindings=copy.deepcopy(REFS),
                         max_image_inputs=4, supported_durations=list(range(4, 31)),
                         params=dict(nodeType='GENERATE_VIDEO', model='PIXDANCE_2_5_DRAFT',
                                     duration=6, count=1, referModel='referToVideo'))
        self.nodes = [dict(uuid=b['node_uuid'], label=b['designation'], type='BASE_IMAGE',
                           defaultAsset={'assetsUuid': 'asset-' + b['node_uuid']}) for b in REFS]
        self.nodes.append(video_node())
        self.plan = dict(file_uuid='canvas', shots=[self.shot], connection_only_video=black(),
                         reference_input_limits=dict(max_video_inputs=10, max_total_inputs=50))

    def compile(self, template=None):
        manifest, clip = compile_batch(self.plan, self.nodes, template)
        row = manifest['shots'][0]
        actual = dict(uuid=row['node_uuid'], label=row['label'], params=copy.deepcopy(row['params']),
                      prevNodeUuids=list(row['prevNodeUuids']))
        return manifest, row, actual, clip

    def test_append_preserves_every_existing_parameter_prompt_token_and_image(self):
        legacy, _ = compile_batch(dict(file_uuid='canvas', shots=[self.shot]), self.nodes)
        _, row, actual, _ = self.compile()
        old = legacy['shots'][0]
        for key in ('params', 'binding_edits', 'mention_ranges', 'bindings', 'character_asset_uuids',
                    'source_sha256', 'bound_prompt_sha256', 'body_mentions', 'duration_adaptation'):
            self.assertEqual(row[key], old[key], key)
        self.assertEqual(row['prevNodeUuids'], old['prevNodeUuids'] + ['black'])
        self.assertNotIn('[video]', row['params']['prompt'])
        self.assertEqual(self.path.read_bytes(), RAW.encode())
        validate_shot(row, actual)

    def test_one_shared_video_is_added_to_every_shot_once(self):
        second = copy.deepcopy(self.shot)
        second.update(id='EP01_S002', label='second video')
        self.plan['shots'].append(second)
        manifest, _ = compile_batch(self.plan, self.nodes)
        self.assertEqual(len(manifest['shots']), 2)
        for row in manifest['shots']:
            self.assertEqual(row['prevNodeUuids'].count('black'), 1)
            self.assertEqual(row['prevNodeUuids'][-1], 'black')

    def test_native_clipboard_gets_additional_edge_without_new_video_generation(self):
        template = dict(meta={'schemaVersion': 1}, edges=[], nodes=[
            dict(type='video-gen', data={'params': {'nodeType': 'GENERATE_VIDEO'}})])
        _, row, _, clip = self.compile(template)
        self.assertEqual(len(clip['nodes']), 1)
        self.assertEqual(len(clip['inboundExternalEdges']), 5)
        self.assertEqual(clip['inboundExternalEdges'][-1], dict(source='black', target=row['node_uuid']))

    def test_missing_duplicate_reordered_extra_or_wrong_input_fails(self):
        _, row, actual, _ = self.compile()
        for order in (row['prevNodeUuids'][:-1], row['prevNodeUuids'] + ['black'],
                      ['black'] + row['prevNodeUuids'][:-1], row['prevNodeUuids'] + ['other']):
            changed = copy.deepcopy(actual)
            changed['prevNodeUuids'] = order
            with self.subTest(order=order), self.assertRaises(PipelineError):
                validate_shot(row, changed)

    def test_preflight_checks_actual_video_asset_not_name(self):
        manifest, _, actual, _ = self.compile()
        preflight(manifest, self.nodes + [actual], [])
        for key, value in [('type', 'BASE_IMAGE'), ('type', 'GENERATE_VIDEO'),
                           ('defaultAsset', {'assetsUuid': 'different-video'})]:
            nodes = copy.deepcopy(self.nodes)
            nodes[-1][key] = value
            with self.subTest(key=key, value=value), self.assertRaises(PipelineError):
                preflight(manifest, nodes + [actual], [])

    def test_missing_asset_node_fails_before_compilation(self):
        for nodes in (self.nodes[:-1], self.nodes[:-1] + [dict(uuid='black', type='BASE_VIDEO')]):
            with self.assertRaises(PipelineError):
                compile_batch(self.plan, nodes)

    def test_capacity_separates_images_from_video_and_combined(self):
        self.plan['reference_input_limits'] = dict(max_video_inputs=1, max_total_inputs=5)
        self.compile()  # Four images still satisfy max_image_inputs=4.
        for limits in (dict(max_video_inputs=0, max_total_inputs=5),
                       dict(max_video_inputs=1, max_total_inputs=4), None):
            self.plan['reference_input_limits'] = limits
            with self.assertRaises(PipelineError):
                self.compile()

    def test_source_hash_duration_and_uuid_alias_are_not_arbitrary(self):
        for key, value in [('source_sha256', '0' * 64), ('duration_seconds', 3),
                           ('duration_seconds', True), ('node_uuid', 'a'), ('asset_uuid', '')]:
            self.plan['connection_only_video'] = {**black(), key: value}
            with self.subTest(key=key, value=value), self.assertRaises(PipelineError):
                self.compile()

    def test_batch_cannot_silently_skip_or_substitute_one_node(self):
        for value in (None, {**black(), 'node_uuid': 'different'}):
            self.shot['connection_only_video'] = value
            with self.assertRaises(PipelineError):
                self.compile()

    def test_resolver_keeps_video_and_accepts_platform_assigned_target_uuid(self):
        manifest, _, actual, _ = self.compile()
        actual['uuid'] = 'saved-video-id'
        result = resolve(manifest, [actual])
        self.assertEqual(result['shots'][0]['node_uuid'], 'saved-video-id')
        self.assertEqual(result['shots'][0]['connection_only_video'], black())
        self.assertEqual(result['shots'][0]['prevNodeUuids'][-1], 'black')

    def test_video_is_not_an_image_or_character_review_and_images_still_checked(self):
        manifest, nodes = fixtures()
        row = manifest['shots'][0]
        row['connection_only_video'] = black()
        row['reference_input_limits'] = dict(max_video_inputs=1, max_total_inputs=3)
        row['prevNodeUuids'] = row['prevNodeUuids'] + ['black']
        nodes[0]['prevNodeUuids'] = list(row['prevNodeUuids'])
        nodes.append(video_node())
        by_node = {n['uuid']: n for n in nodes}
        validate_visual_review(row, by_node)
        preflight(manifest, nodes, [])
        self.assertEqual(len(row['visual_review']['images']), 2)
        self.assertEqual(row['character_asset_uuids'], ['asset-char'])
        by_node['scene-1']['defaultAsset']['assetsUuid'] = 'wrong-scene'
        with self.assertRaises(PipelineError):
            validate_visual_review(row, by_node)

    def test_historical_batches_are_unchanged_and_bundled_source_exact(self):
        manifest, nodes = fixtures()
        validate_shot(manifest['shots'][0], nodes[0])
        preflight(manifest, nodes, [])
        self.assertEqual(hashlib.sha256(SOURCE.read_bytes()).hexdigest(), SHA256)
        self.assertEqual(SOURCE.stat().st_size, 28788)

    def test_no_extra_video_mention_or_story_rewrite_is_permitted(self):
        _, row, actual, _ = self.compile()
        for text in (' %%@[Black][video][0](black)%%', ' 开场黑场2秒。'):
            changed = copy.deepcopy(actual)
            changed['params']['prompt'] += text
            with self.assertRaises(PipelineError):
                validate_shot(row, changed)
