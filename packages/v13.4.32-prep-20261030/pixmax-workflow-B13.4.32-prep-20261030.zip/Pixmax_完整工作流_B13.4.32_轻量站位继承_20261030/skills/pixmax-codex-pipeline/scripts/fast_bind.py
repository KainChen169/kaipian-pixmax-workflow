"""Compile preapproved shot/asset bindings into one native Pixmax paste batch.

No network, image generation, or prompt writing. Requires a native clipboard
template copied from the *current* signed-in canvas/browser session.
"""
from __future__ import annotations
import argparse
import base64
import copy
import hashlib
import json
import re
import uuid
from pathlib import Path

from pixmax_pipeline import PipelineError, atomic_json
from seedance25_contract import ROLE as V134_ROLE, DEFAULT_VIDEO_MODEL, validate_input_order, validate_duration, generation_duration, natural_duration, prepare_video_spec
from shot_body_mentions import POLICY as BODY_POLICY, LEGACY as LEGACY_POLICY, body_edits
from black_video_reference import expected_order
from project_style import ANIMATION_ROLE, validate_route
from animation_contract import (validate_source as validate_animation_source,
    validate_duration as validate_animation_duration, natural_duration as animation_natural_duration,
    validate_staging as validate_animation_staging)

CATEGORIES = ('character', 'scene', 'prop', 'storyboard_reference', 'blocking_reference')
UNMENTIONED = ('blocking_reference',)
BOARD_MARKER = '〈六宫格真实@待绑定〉'
BOARD_PREFIX = '**六宫格首帧引用：**'
HEADINGS = {'character': ('人物指定',), 'scene': ('场景指定',), 'prop': ('重要道具', '道具指定')}
TOKEN = re.compile(r'%%@\[[^\]]+\]\[(?:image|video|audio|text)\]\[\d+\]\([^)]+\)%%')
HEADER = re.compile(r'^\*\*([^*：]+)：\*\*\s*$', re.M)
MARKDOWN_DESIGNATION = re.compile(r'^#{1,6}[ \t]+(?:\d+[.、．][ \t]*)?(人物指定|场景指定|重要道具|道具指定)[ \t]*\r?$', re.M)


def sections(prompt: str):
    parts = sorted([*HEADER.finditer(prompt), *MARKDOWN_DESIGNATION.finditer(prompt)], key=lambda m: m.start())
    found = {}
    for i, header in enumerate(parts):
        for category, names in HEADINGS.items():
            if header.group(1).strip() in names:
                if category in found:
                    raise PipelineError('Repeated designation section: '+category)
                found[category] = (header.end(), min([h.start() for h in parts[i+1:]] + [m.start() for m in re.finditer(r'(?m)^#{1,6}[ \t]+\S', prompt) if m.start() > header.end()] + [len(prompt)]))
    if 'character' not in found or 'scene' not in found:
        raise PipelineError('人物指定 and 场景指定 sections required')
    return found


def first_line_match(block: str, anchor: str):
    # Director Compiler v12 puts the name and colon inside a bold label.
    bold = list(re.finditer(r'(?m)^[ \t]*\*\*'+re.escape(anchor)+r'(?=[：:｜|])[^*\r\n]*[：:]\*\*', block))
    matches = list(re.finditer(r'(?m)^[ \t]*'+re.escape(anchor)+r'(?=\s|[：:（(，,、。；;｜|]|$)',block))
    matches += bold
    if len(matches)!=1:
        raise PipelineError(f'Expected one designation line for {anchor!r}; found {len(matches)}')
    return matches[0]


def node_asset(node: dict):
    asset=node.get('defaultAsset') or {}
    return asset.get('assetsUuid') or node.get('defaultAssetUuid') or node.get('assetsUuid')


def apply_binding_edits(raw: str, edits: list):
    """Apply a reversible ledger of source-offset edits, never a body rewrite."""
    cursor = 0
    pieces = []
    for edit in edits:
        start, end = edit['start'], edit['end']
        if not (cursor <= start <= end <= len(raw)) or raw[start:end] != edit['before']:
            raise PipelineError('Invalid or overlapping binding edit')
        pieces.extend((raw[cursor:start], edit['after']))
        cursor = end
    pieces.append(raw[cursor:])
    return ''.join(pieces)


def compile_mentions(raw: str, refs: list, labels: dict, role: str):
    """Insert/rebind image tokens only on designation lines or existing board header."""
    if role not in ('original_15s', 'supplement', 'automation_15s', 'seedance25_30s', V134_ROLE, ANIMATION_ROLE):
        raise PipelineError('Invalid prompt_role')
    spans = sections(raw)
    edits, covered, seen = [], set(), set()
    person_start, person_end = spans['character']
    person_lines = [line.strip() for line in raw[person_start:person_end].splitlines()
                    if line.strip() and line.strip() not in ('无', '无人物')]
    if role in ('seedance25_30s', V134_ROLE, ANIMATION_ROLE):
        person_lines = re.findall(r'(?m)^[ \t]*\*\*[^*\r\n]+[：:]\*\*', raw[person_start:person_end])
    if len(person_lines) != sum(b['category'] == 'character' for b in refs):
        raise PipelineError('Character lines and bound assets differ')
    board_token = None
    for index, binding in enumerate(refs):
        category, uid = binding['category'], binding['node_uuid']
        if category in UNMENTIONED:
            continue
        label = labels.get(uid)
        if not label or any(ch in label for ch in '[]()\r\n'):
            raise PipelineError('Unsafe/missing image node label: ' + uid)
        token = f'%%@[{label}][image][{index}]({uid})%%'
        if category == 'storyboard_reference':
            if not raw.startswith(BOARD_PREFIX):
                raise PipelineError('Six-panel instruction must already be the first paragraph; do not add instruction text')
            paragraph_break = re.search(r'\r?\n\r?\n', raw)
            if not paragraph_break:
                raise PipelineError('Missing break after top six-panel instruction')
            start, end = 0, paragraph_break.start()
            anchor_end = len(BOARD_PREFIX)
            board_token = token
        else:
            anchor = binding.get('designation')
            if category not in spans or not anchor or (category, anchor) in seen:
                raise PipelineError('Missing section or duplicate/empty designation')
            seen.add((category, anchor))
            block_start, block_end = spans[category]
            block = raw[block_start:block_end]
            match = first_line_match(block, anchor)
            start = block_start + match.start()
            newline = raw.find('\n', block_start + match.end(), block_end)
            end = newline if newline >= 0 else block_end
            anchor_end = block_start + match.end()
        existing = list(TOKEN.finditer(raw, start, end))
        if len(existing) > 1:
            raise PipelineError('Multiple asset mentions on one designation line')
        marker_at = raw.find(BOARD_MARKER, start, end) if category == 'storyboard_reference' else -1
        if marker_at >= 0:
            if existing or raw.count(BOARD_MARKER) != 1:
                raise PipelineError('One top six-panel marker required')
            left, right, before, after = marker_at, marker_at + len(BOARD_MARKER), BOARD_MARKER, token
        elif existing:
            found = existing[0]
            covered.add((found.start(), found.end()))
            left, right, before, after = found.start(), found.end(), found.group(), token
        else:
            left, right, before, after = anchor_end, anchor_end, '', ' ' + token
        if before != after:
            edits.append({'start': left, 'end': right, 'before': before, 'after': after,
                          'category': category, 'node_uuid': uid})
    if role == 'automation_15s' and not board_token:
        raise PipelineError('Automation prompt requires a six-panel binding')
    if BOARD_MARKER in raw and not board_token:
        raise PipelineError('Six-panel marker has no binding')
    if {(m.start(), m.end()) for m in TOKEN.finditer(raw)} != covered:
        raise PipelineError('Asset mention outside mapped designation lines; reconcile misplaced/extra mentions')
    edits.sort(key=lambda e: (e['start'], e['end']))
    compiled = apply_binding_edits(raw, edits)
    if len(TOKEN.findall(compiled)) != sum(b['category'] not in UNMENTIONED for b in refs):
        raise PipelineError('Wrong token count')
    # Reverse exact edits (including any old tokens), preserving all whitespace.
    restored, delta = compiled, 0
    located = []
    for edit in edits:
        position = edit['start'] + delta
        located.append((position, position + len(edit['after']), edit['before']))
        delta += len(edit['after']) - len(edit['before'])
    for start, end, before in reversed(located):
        restored = restored[:start] + before + restored[end:]
    if restored != raw:
        raise PipelineError('Prompt text changed outside binding edits')
    final_sections = sections(compiled)
    ranges = [[start, end] for start, end in final_sections.values()]
    if board_token:
        ranges.append([0, re.search(r'\r?\n\r?\n', compiled).start()])
    return compiled, ranges, edits


def compile_for_policy(raw, refs, labels, role, policy=LEGACY_POLICY, body_mentions=None):
    if policy not in (LEGACY_POLICY, BODY_POLICY):
        raise PipelineError('Unknown binding policy')
    if policy == LEGACY_POLICY:
        if body_mentions is not None:
            raise PipelineError('Body anchors require the explicit v2 policy')
        return compile_mentions(raw, refs, labels, role)
    if role not in (V134_ROLE, ANIMATION_ROLE):
        raise PipelineError('Shot-body v2 requires a supported live-action or animation 2.5 role')
    _, _, edits = compile_mentions(raw, refs, labels, role)
    edits += body_edits(raw, refs, labels, body_mentions)
    edits.sort(key=lambda e: (e['start'], e['end']))
    compiled = apply_binding_edits(raw, edits)
    ranges = [list(pair) for pair in sections(compiled).values()]
    if raw.startswith(BOARD_PREFIX):
        ranges.append([0, re.search(r'\r?\n\r?\n', compiled).start()])
    reverse, delta = [], 0
    for edit in edits:
        position = edit['start'] + delta
        right = position + len(edit['after'])
        reverse.append({'start': position, 'end': right, 'before': edit['after'], 'after': edit['before']})
        if edit.get('scope') == 'shot_body':
            # Leading space is an insertion too; only the actual token is a mention range.
            ranges.append([position + 1, right])
        delta += len(edit['after']) - len(edit['before'])
    if apply_binding_edits(compiled, reverse) != raw:
        raise PipelineError('Body binding failed exact reverse-source check')
    if len(TOKEN.findall(compiled)) != sum(b['category'] not in UNMENTIONED for b in refs) + len(body_mentions):
        raise PipelineError('Wrong scoped mention count')
    return compiled, ranges, edits


def shot_binding_policy(shot):
    return shot.get('binding_policy', BODY_POLICY if 'body_mentions' in shot else LEGACY_POLICY)


def compile_shot(shot: dict, nodes: dict):
    source_bytes = Path(shot['prompt_file']).read_bytes()
    raw = source_bytes.decode('utf-8')
    role = shot.get('prompt_role', 'original_15s')
    validate_route(shot, required=role == ANIMATION_ROLE)
    if role == ANIMATION_ROLE:
        if shot_binding_policy(shot) != BODY_POLICY:
            raise PipelineError('Animation requires the explicit shot-body v2 binding plan')
        validate_animation_source(shot, raw)
    refs = shot['bindings']
    if not refs or any(x.get('category') not in CATEGORIES for x in refs):
        raise PipelineError('Invalid bindings')
    validate_input_order(refs, role)
    if not any(x['category'] == 'scene' for x in refs):
        raise PipelineError('Scene input required')
    ids = [x['node_uuid'] for x in refs]
    if len(set(ids)) != len(ids):
        raise PipelineError('Duplicate input')
    cap = shot.get('max_image_inputs')
    if type(cap) != int or cap < 1 or len(refs) > cap:
        raise PipelineError('Invalid/missing current model image limit')
    labels = {}
    for binding in refs:
        uid = binding['node_uuid']
        if uid not in nodes:
            raise PipelineError('Missing canvas node: ' + uid)
        node = nodes[uid]
        if node.get('type') not in ('BASE_IMAGE', 'GENERATE_IMAGE') or not node_asset(node):
            raise PipelineError('Image node has no ready asset: ' + uid)
        labels[uid] = node.get('label') or (node.get('metaData') or {}).get('data', {}).get('label')
    compiled, ranges, _ = compile_for_policy(raw, refs, labels, role,
        shot_binding_policy(shot), shot.get('body_mentions'))
    return compiled, ranges, [node_asset(nodes[b['node_uuid']]) for b in refs if b['category'] == 'character'], role, hashlib.sha256(source_bytes).hexdigest()


def compile_batch(plan: dict, canvas_nodes: list[dict], template: dict | None=None):
    if not plan.get('file_uuid') or not isinstance(plan.get('shots'),list) or not plan['shots']:
        raise PipelineError('file_uuid and shots required')
    validate_route(plan, required=any(s.get('prompt_role') == ANIMATION_ROLE for s in plan['shots']))
    nodes={n['uuid']:n for n in canvas_nodes}
    if len(nodes)!=len(canvas_nodes):raise PipelineError('Duplicate canvas UUIDs')
    template_node=None
    if template is not None:
        if len(template.get('nodes',[]))!=1 or not template.get('meta') or template.get('edges'):
            raise PipelineError('Copy exactly one native blank video node in the current account')
        template_node=template['nodes'][0]
        if template_node.get('type')!='video-gen' or template_node.get('data',{}).get('params',{}).get('nodeType')!='GENERATE_VIDEO':
            raise PipelineError('Native clipboard template must be a video-gen node')
    labels=set();ids=set();out=[];paste=[];edges=[]
    for position,shot in enumerate(plan['shots']):
        shot = dict(shot)
        if 'project_route' in plan:
            if 'project_route' in shot and shot['project_route'] != plan['project_route']:
                raise PipelineError('A canvas batch cannot mix project style decisions')
            shot['project_route'] = copy.deepcopy(plan['project_route'])
        if shot['id'] in ids or shot['label'] in labels:raise PipelineError('Duplicate shot id/label')
        ids.add(shot['id']);labels.add(shot['label'])
        if any(n.get('label')==shot['label'] for n in canvas_nodes):
            raise PipelineError('Canvas already has label '+shot['label']+'; reconcile rather than paste again')
        if any(b.get('category') == 'blocking_reference' for b in shot.get('bindings', [])):
            raise PipelineError(shot['id']+': standing-reference image workflow removed; use character/scene/prop and enabled storyboard inputs for new nodes')
        prompt,ranges,characters,role,source_hash=compile_shot(shot,nodes)
        storyboard_binding=any(b['category']=='storyboard_reference' for b in shot['bindings'])
        storyboard_file=shot.get('storyboard_prompt_file')
        storyboard_hash=shot.get('storyboard_sha256')
        if storyboard_binding:
            if not storyboard_file or not storyboard_hash:
                raise PipelineError(shot['id']+': storyboard prompt file and reviewed hash required')
            storyboard_bytes=Path(storyboard_file).read_bytes()
            if hashlib.sha256(storyboard_bytes).hexdigest()!=storyboard_hash:
                raise PipelineError(shot['id']+': storyboard prompt changed after planning')
            bundle_file=shot.get('episode_bundle_file')
            bundle_hash=shot.get('episode_bundle_sha256')
            if not bundle_file or not bundle_hash or hashlib.sha256(Path(bundle_file).read_bytes()).hexdigest()!=bundle_hash:
                raise PipelineError(shot['id']+': episode source bundle missing or changed after planning')
        # Schema prompt length is advisory, matching official CLI build100014.
        # Save the full text and require exact server readback before submission.
        prompt_limit=shot.get('max_prompt_chars',plan.get('max_prompt_chars'))
        if prompt_limit is not None and (type(prompt_limit)!=int or prompt_limit<1):
            raise PipelineError(shot['id']+': invalid schema prompt length')
        if not prompt.strip():
            raise PipelineError(shot['id']+': empty prompt')
        params=copy.deepcopy(shot['params']);params['prompt']=prompt
        prepare_video_spec(params, required=role in (V134_ROLE, ANIMATION_ROLE, 'seedance25_30s'))
        if role in (V134_ROLE, ANIMATION_ROLE):
            requested = params.get('duration')
            rounded = generation_duration(requested)
            params['duration'] = str(rounded) if isinstance(requested, str) else rounded
        supported=shot.get('supported_durations',plan.get('supported_durations'))
        if not isinstance(supported,list) or not supported or any(
                not isinstance(value,int) or isinstance(value,bool) or value<1 for value in supported):
            raise PipelineError(shot['id']+': supported_durations from current model schema required')
        try:
            duration=int(params.get('duration'))
        except (TypeError,ValueError):
            raise PipelineError(shot['id']+': invalid duration') from None
        if params.get('nodeType')!='GENERATE_VIDEO' or duration not in supported or str(params.get('count'))!='1':
            raise PipelineError(shot['id']+': invalid video params or unsupported duration')
        if role=='original_15s' and duration!=15:
            raise PipelineError(shot['id']+': original_15s must be exactly 15 seconds')
        if role=='seedance25_30s' and (duration!=30 or params.get('model')!=DEFAULT_VIDEO_MODEL):
            raise PipelineError(shot['id']+': seedance25_30s requires PIXDANCE_2_5_DRAFT and 30 seconds')
        if role == V134_ROLE:
            validate_duration(prompt, params, supported, shot.get('legacy_timeline_origin'))
        elif role == ANIMATION_ROLE:
            if shot.get('legacy_timeline_origin') is not None:
                raise PipelineError('Animation cannot use a live-action legacy timeline exception')
            validate_animation_duration(prompt, params, supported)
        if str(params.get('referModel'))!='referToVideo':raise PipelineError('Expected multi-reference video mode')
        temporary=str(uuid.uuid4());x=int(plan.get('layout_x',0))+(position%3)*1300;y=int(plan.get('layout_y',0))+(position//3)*1300
        record={'id':shot['id'],'episode':shot.get('episode'),'node_uuid':temporary,'label':shot['label'],'params':params,
                'prompt_role':role,'source_prompt_file':str(Path(shot['prompt_file']).resolve()),'source_sha256':source_hash,
                'prevNodeUuids':[b['node_uuid'] for b in shot['bindings']],
                'bindings':[dict(b) for b in shot['bindings']],
                'character_asset_uuids':characters,'mention_ranges':ranges}
        extra = shot.get('connection_only_video', plan.get('connection_only_video'))
        if ('connection_only_video' in plan and 'connection_only_video' in shot and
                shot['connection_only_video'] != plan['connection_only_video']):
            raise PipelineError('A batch must share the same supplied black video')
        if extra is not None:
            record['connection_only_video'] = copy.deepcopy(extra)
            record['reference_input_limits'] = copy.deepcopy(
                shot.get('reference_input_limits', plan.get('reference_input_limits')))
            record['prevNodeUuids'] = expected_order(record, nodes)
        binding_labels = {b['node_uuid']: (nodes[b['node_uuid']].get('label') or
                          (nodes[b['node_uuid']].get('metaData') or {}).get('data', {}).get('label'))
                          for b in shot['bindings']}
        verified_prompt, _, binding_edits = compile_for_policy(
            Path(shot['prompt_file']).read_bytes().decode('utf-8'), shot['bindings'], binding_labels, role,
            shot_binding_policy(shot), shot.get('body_mentions'))
        if verified_prompt != prompt:
            raise PipelineError('Source changed during binding compilation')
        record.update(binding_policy=shot_binding_policy(shot), binding_labels=binding_labels,
                      binding_edits=binding_edits,
                      bound_prompt_sha256=hashlib.sha256(prompt.encode('utf-8')).hexdigest())
        if record['binding_policy'] == BODY_POLICY:
            record['body_mentions'] = copy.deepcopy(shot['body_mentions'])
        record['prompt_length_check'] = {'characters': len(prompt), 'schema_max_characters': prompt_limit,
            'exceeds_schema_hint': prompt_limit is not None and len(prompt)>prompt_limit,
            'policy': 'server_enforced_exact_readback', 'save_verified': False}
        record['visual_review'] = {'policy': 'asset_visual_review_v1', 'status': 'PENDING'}
        record['workflow_policy'] = 'pixmax_dual_modules_v1'
        record['visual_review']['continuity_review'] = {'policy': 'cross_episode_continuity_v1', 'status': 'PENDING'}
        if 'project_route' in shot:
            record['project_route'] = copy.deepcopy(shot['project_route'])
        if role in (V134_ROLE, ANIMATION_ROLE):
            record['supported_durations'] = list(supported)
            natural = animation_natural_duration(prompt) if role == ANIMATION_ROLE else natural_duration(prompt)
            record['duration_adaptation'] = {
                'policy': 'ceil_integer_preserve_timeline_v1',
                'prompt_duration_seconds': natural,
                'generation_duration_seconds': duration,
                'tail_extension_seconds': round(duration - natural, 10),
                'tail_behavior': 'natural_continuation_of_final_shot_no_new_content'}
            if shot.get('legacy_timeline_origin') is not None:
                record['legacy_timeline_origin'] = copy.deepcopy(shot['legacy_timeline_origin'])
            record['director_skill'] = 'seedance25-animation-director' if role == ANIMATION_ROLE else 'ab-test-seedance25-director-compiler-v13-4-0'
        if role == ANIMATION_ROLE:
            record['animation_source'] = copy.deepcopy(shot['animation_source'])
            record['animation_text_check'] = validate_animation_source(shot, Path(shot['prompt_file']).read_bytes().decode('utf-8'))
            for key in ('animation_staging_review_file', 'animation_staging_review_sha256'):
                if key in shot:
                    record[key] = shot[key]
            validate_animation_staging(record)
        if storyboard_binding:
            record['storyboard_prompt_file']=str(Path(storyboard_file).resolve())
            record['storyboard_sha256']=storyboard_hash
            record['episode_bundle_file']=str(Path(bundle_file).resolve())
            record['episode_bundle_sha256']=bundle_hash
        out.append(record)
        if template_node is not None:
            node=copy.deepcopy(template_node);node['id']=temporary;node['position']={'x':x,'y':y}
            data=node['data'];data.update(label=shot['label'],status='idle',errMsg='',userConcurrencyWaiting=False,
                                         url='',assetsId='',params=params,verifyStatus='NONE',verifyErrMsg='',assets=[])
            for key in ('taskUuid','defaultAsset','defaultAssetUuid'):
                data.pop(key,None)
            paste.append(node)
            edges.extend({'source':uid,'target':temporary} for uid in record['prevNodeUuids'])
    clip={'nodes':paste,'edges':[],'inboundExternalEdges':edges,'meta':template['meta']} if template is not None else None
    return {'file_uuid':plan['file_uuid'],'shots':out},clip


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--plan',type=Path,required=True);p.add_argument('--canvas',type=Path,required=True)
    p.add_argument('--native-template',type=Path,help='Native clipboard JSON copied from current browser session')
    p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    plan=json.loads(a.plan.read_text(encoding='utf-8-sig'))
    for shot in plan.get('shots',[]):
        prompt=Path(shot['prompt_file'])
        if not prompt.is_absolute():shot['prompt_file']=str((a.plan.parent/prompt).resolve())
    canvas=json.loads(a.canvas.read_text(encoding='utf-8-sig'))
    if isinstance(canvas,dict):canvas=canvas.get('nodes',canvas.get('data'))
    if not isinstance(canvas,list):raise PipelineError('Canvas snapshot must contain nodes array')
    template=json.loads(a.native_template.read_text(encoding='utf-8-sig')) if a.native_template else None
    manifest,clip=compile_batch(plan,canvas,template)
    a.output.mkdir(parents=True,exist_ok=True)
    for shot in manifest['shots']:
        (a.output/(shot['id']+'.md')).write_bytes(shot['params']['prompt'].encode('utf-8'))
    atomic_json(a.output/'planned-manifest.json',manifest)
    if clip is not None:
        atomic_json(a.output/'native-clipboard.json',clip)
        encoded=base64.urlsafe_b64encode(json.dumps(clip,ensure_ascii=False,separators=(',',':')).encode()).decode().rstrip('=')
        (a.output/'clipboard.html').write_text('<div data-t="pixmax-clipboard" data-v="base64url:'+encoded+'"> </div>',encoding='utf-8')
    print(json.dumps({'shots':len(manifest['shots']),'edges':sum(len(s['prevNodeUuids']) for s in manifest['shots']),
                      'clipboard_ready':clip is not None,'output':str(a.output)},ensure_ascii=False))

if __name__=='__main__':main()
