"""Check dialogue and binding invariants between two saved shot manifests.

Read-only. This does not determine whether imagery is acceptable or promise
provider approval; shot-level speaker staging still needs semantic review.
"""
import argparse,hashlib,json,re
from pathlib import Path

def shot(path,sid):
 data=json.loads(Path(path).read_text(encoding='utf-8-sig'))
 if 'shots' not in data:return data
 found=[s for s in data['shots'] if s['id']==sid]
 if len(found)!=1:raise ValueError(f'Expected one shot {sid}')
 return found[0]

def audit(before,after):
 a=before['params']['prompt'];b=after['params']['prompt']
 def speech(text):
  m=re.search(r'\*\*对白：\*\*(.*?)\*\*字幕：\*\*',text,re.S)
  if not m:raise ValueError('Missing dialogue/VO block')
  return m[1].strip()
 checks={
  'same_shot':before['id']==after['id'],
  'dialogue_and_speaker_block_exact':speech(a)==speech(b),
  'timeline_quoted_lines_exact':re.findall('“([^”]+)”',a)==re.findall('“([^”]+)”',b),
  'ordered_inputs_exact':before['prevNodeUuids']==after['prevNodeUuids'],
  'bindings_exact':before['bindings']==after['bindings'],
  'character_assets_exact':before['character_asset_uuids']==after['character_asset_uuids'],
  'model_and_format_exact':{k:v for k,v in before['params'].items() if k!='prompt'}=={k:v for k,v in after['params'].items() if k!='prompt'},
  'mentions_exact':re.findall(r'%%@.*?%%',a)==re.findall(r'%%@.*?%%',b),
 }
 result={'id':before['id'],'pass':all(checks.values()),'checks':checks,'source_prompt_sha256':hashlib.sha256(a.encode()).hexdigest(),'revised_prompt_sha256':hashlib.sha256(b.encode()).hexdigest(),'semantic_review_required':'画面、说话镜头归属、剧情和非血腥呈现须按实际内容人工核对。'}
 return result

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--before',required=True);p.add_argument('--after',required=True);p.add_argument('--shot',required=True);p.add_argument('--output');args=p.parse_args()
 r=audit(shot(args.before,args.shot),shot(args.after,args.shot));text=json.dumps(r,ensure_ascii=False,indent=2)
 if args.output:Path(args.output).write_text(text,encoding='utf-8')
 print(text);raise SystemExit(0 if r['pass'] else 1)
