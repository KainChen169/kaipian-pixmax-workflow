"""Resolve native paste's actual node UUIDs and verify every saved binding."""
import argparse
import json
from pathlib import Path
from pixmax_pipeline import PipelineError, atomic_json
from submit_saved_batch import validate_shot


def resolve(planned, canvas):
    if isinstance(canvas,dict):canvas=canvas.get('nodes',canvas.get('data'))
    if not isinstance(canvas,list):raise PipelineError('Expected canvas nodes array')
    result={'file_uuid':planned['file_uuid'],'shots':[]}
    for shot in planned['shots']:
        matches=[n for n in canvas if n.get('label')==shot['label']]
        if len(matches)!=1:raise PipelineError(shot['id']+': expected exactly one saved node by label')
        actual=matches[0]
        if actual.get('taskUuid'):raise PipelineError(shot['id']+': node already has task; reconcile first')
        row={**shot,'node_uuid':actual['uuid']}
        validate_shot(row,actual)
        if row.get('prompt_length_check'):
            row['prompt_length_check'] = {**row['prompt_length_check'], 'save_verified': True}
        result['shots'].append(row)
    return result


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--planned',type=Path,required=True);p.add_argument('--canvas',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args()
    value=resolve(json.loads(a.planned.read_text(encoding='utf-8-sig')),json.loads(a.canvas.read_text(encoding='utf-8-sig')))
    atomic_json(a.output,value)
    print(json.dumps({'verified':len(value['shots']),'file_uuid':value['file_uuid'],'output':str(a.output)},ensure_ascii=False))
