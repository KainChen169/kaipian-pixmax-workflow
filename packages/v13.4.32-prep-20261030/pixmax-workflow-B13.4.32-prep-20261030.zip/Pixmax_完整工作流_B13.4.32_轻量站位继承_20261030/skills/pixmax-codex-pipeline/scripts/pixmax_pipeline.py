#!/usr/bin/env python3
"""Checkpointed Pixmax video batch runner. Python 3.10+, standard library only."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


class PipelineError(RuntimeError):
    pass


def stamp() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def safe_name(value: str, field: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise PipelineError(f"{field} must be a nonempty string")
    result = re.sub(r"[^\w.-]+", "_", value.strip(), flags=re.UNICODE).strip("._")
    if not result or result in {".", ".."} or len(result) > 80:
        raise PipelineError(f"{field} is not a safe filename: {value!r}")
    return result


def load_manifest(path: Path) -> tuple[dict[str, Any], Path, str]:
    from seedance25_contract import DEFAULT_VIDEO_MODEL, SEEDANCE25_MODELS, validate_video_spec, PipelineError as SpecError
    path = path.resolve()
    raw = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(raw, dict):
        raise PipelineError("manifest root must be an object")
    for key in ("run_id", "project_name", "canvas_name", "episode"):
        if not isinstance(raw.get(key), str) or not raw[key].strip():
            raise PipelineError(f"missing {key}")
    run_id = safe_name(raw["run_id"], "run_id")
    episode = safe_name(raw["episode"], "episode")
    project_part = safe_name(raw["project_name"], "project_name")
    output_root = (path.parent / raw.get("output_root", "./deliveries")).resolve()
    delivery_dir = output_root / project_part / episode / run_id
    shots = raw.get("shots")
    if not isinstance(shots, list) or not shots:
        raise PipelineError("shots must be a nonempty array")
    seen: set[str] = set()
    normalized: list[dict[str, Any]] = []
    for index, shot in enumerate(shots, 1):
        if not isinstance(shot, dict):
            raise PipelineError(f"shot {index} must be an object")
        shot_id = safe_name(shot.get("id", ""), f"shot {index} id")
        if shot_id in seen:
            raise PipelineError(f"duplicate shot id: {shot_id}")
        seen.add(shot_id)
        prompt = shot.get("prompt")
        if not isinstance(prompt, str) or not prompt.strip():
            raise PipelineError(f"shot {shot_id} has no prompt")
        ref = shot.get("reference_image")
        ref_path = (path.parent / ref).resolve() if ref else None
        if ref_path and (not ref_path.is_file() or ref_path.suffix.lower() not in {".png", ".jpg", ".jpeg", ".webp"}):
            raise PipelineError(f"shot {shot_id} reference image missing or unsupported: {ref_path}")
        multi_refs = shot.get("reference_images")
        if multi_refs is not None:
            if ref or not isinstance(multi_refs, list) or len(multi_refs) < 2:
                raise PipelineError(f"shot {shot_id} reference_images requires at least two paths and cannot be combined with reference_image")
            if any(not isinstance(item, str) or not item.strip() for item in multi_refs):
                raise PipelineError(f"shot {shot_id} reference_images must contain paths")
            multi_paths = [(path.parent / item).resolve() for item in multi_refs]
            if len(set(multi_paths)) != len(multi_paths):
                raise PipelineError(f"shot {shot_id} has duplicate reference images")
            for item in multi_paths:
                if not item.is_file() or item.suffix.lower() not in {".png", ".jpg", ".jpeg", ".webp"}:
                    raise PipelineError(f"shot {shot_id} reference image missing or unsupported: {item}")
            refer_model = shot.get("refer_model")
            if refer_model not in {"firstAndLastFrame", "referToVideo"}:
                raise PipelineError(f"shot {shot_id} must select refer_model for ordered reference_images")
            if refer_model == "firstAndLastFrame" and len(multi_paths) != 2:
                raise PipelineError(f"shot {shot_id} firstAndLastFrame requires exactly two ordered images")
        model = str(shot.get('model', DEFAULT_VIDEO_MODEL))
        item = {
            "id": shot_id,
            "prompt": prompt.strip(),
            "reference_image": str(ref_path) if ref_path else None,
            "reference_sha256": sha256(ref_path) if ref_path else None,
            "model": model,
            "resolution": str(shot.get("resolution", "480P")),
            "aspect_ratio": str(shot.get("aspect_ratio", "9:16" if model in SEEDANCE25_MODELS else "3:4")),
            "duration": str(shot.get("duration", "7")),
            "audio": bool(shot.get("audio", model in SEEDANCE25_MODELS)),
        }
        if multi_refs is not None:
            item["reference_images"] = [{"path": str(value), "sha256": sha256(value)} for value in multi_paths]
            item["refer_model"] = refer_model
        if "output_format" in shot:
            if not isinstance(shot["output_format"], str) or not shot["output_format"].strip():
                raise PipelineError(f"shot {shot_id} output_format must be a nonempty string")
            item["output_format"] = shot["output_format"].strip().lower()
        if "bitrate_mode" in shot:
            if not isinstance(shot["bitrate_mode"], str) or not shot["bitrate_mode"].strip():
                raise PipelineError(f"shot {shot_id} bitrate_mode must be a nonempty string")
            item["bitrate_mode"] = shot["bitrate_mode"].strip()
        if item['model'] in SEEDANCE25_MODELS:
            try:
                validate_video_spec({'nodeType':'GENERATE_VIDEO', 'model':item['model'],
                                     'resolution':item['resolution'], 'aspectRatio':item['aspect_ratio'],
                                     'includeAudio':shot.get('audio', True), 'duration':item['duration']})
            except SpecError as error:
                raise PipelineError(str(error)) from None
        normalized.append(item)
    manifest = {
        "run_id": run_id,
        "project_name": raw["project_name"].strip(),
        "remote_project_name": f"{raw['project_name'].strip()}__{run_id}",
        "canvas_name": raw["canvas_name"].strip(),
        "episode": episode,
        "delivery_dir": str(delivery_dir),
        "shots": normalized,
    }
    if 'project_route' in raw:
        from project_style import validate_route
        manifest['project_route'] = raw['project_route']
        validate_route(manifest)
    fingerprint = hashlib.sha256(json.dumps(manifest, ensure_ascii=False, sort_keys=True).encode("utf-8")).hexdigest()
    return manifest, delivery_dir, fingerprint


def validate_reference_limits(shot: dict[str, Any], model_info: dict[str, Any]) -> None:
    """Check image-only inputs against current model groups; never split a shot."""
    if model_info.get("modelCode") != shot["model"] or model_info.get("nodeType") != "GENERATE_VIDEO" or model_info.get("restricted") is True:
        raise PipelineError(f"video model unavailable or mismatched: {shot['model']}")
    count = len(shot["reference_images"]) if "reference_images" in shot else int(bool(shot.get("reference_image")))
    mode = shot.get("refer_model") or ("imageToVideo" if count else "textToVideo")
    if mode == "firstAndLastFrame" and count != 2:
        raise PipelineError(f"shot {shot['id']} firstAndLastFrame requires exactly two ordered images")
    for spec in model_info.get("params", []):
        if spec.get("name") == "referModel" and spec.get("options") and mode not in spec["options"]:
            raise PipelineError(f"shot {shot['id']} reference mode unavailable: {mode}")
    image_codes = {"BASE_IMAGE", "GENERATE_IMAGE", "GENERATE_STORYBOARD"}
    rules = model_info.get("inputRules")
    if not isinstance(rules, list) or not rules:
        raise PipelineError(f"shot {shot['id']} current model input limits unavailable")
    image_rule_found = False
    for rule in rules:
        if not isinstance(rule, dict) or not isinstance(rule.get("codes"), list) or not all(isinstance(code, str) for code in rule["codes"]):
            raise PipelineError(f"shot {shot['id']} invalid current model input rule")
        codes = set(rule["codes"])
        minimum, maximum = rule.get("min"), rule.get("max")
        if type(minimum) is not int or type(maximum) is not int or not 0 <= minimum <= maximum:
            raise PipelineError(f"shot {shot['id']} invalid current model input bounds")
        if codes & image_codes and codes <= image_codes:
            image_rule_found = True
        actual = count if codes & image_codes else 0
        if not minimum <= actual <= maximum:
            raise PipelineError(f"shot {shot['id']} {shot['model']} inputs={actual}, current group allows {minimum}-{maximum}; keep source and references, do not automatically split")
    if not image_rule_found:
        raise PipelineError(f"shot {shot['id']} current model image limit unavailable")


def atomic_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def cli_command() -> list[str]:
    custom = os.environ.get("PIXMAX_CLI")
    if custom:
        return [custom]
    found = shutil.which("pixmax") or shutil.which("pixmax.cmd")
    if found:
        return [found]
    scripts = Path.home() / "AppData" / "Roaming" / "Python" / f"Python{sys.version_info.major}{sys.version_info.minor}" / "Scripts" / "pixmax.cmd"
    if scripts.is_file():
        return [str(scripts)]
    raise PipelineError("Pixmax CLI not found; set PIXMAX_CLI to the installed pixmax.cmd path")


def cli(*args: str) -> Any:
    command = [*cli_command(), "--json", *args]
    process = subprocess.run(command, capture_output=True, text=True, encoding="utf-8", errors="replace", check=False)
    if process.returncode:
        # CLI errors may contain request IDs; token and signed URLs are deliberately excluded.
        raise PipelineError(f"Pixmax CLI failed at {' '.join(args[:2])}: exit {process.returncode}; inspect CLI locally for details")
    try:
        return json.loads(process.stdout)
    except json.JSONDecodeError as exc:
        raise PipelineError(f"Pixmax CLI returned non-JSON output at {' '.join(args[:2])}") from exc


def successful(result: Any, stage: str) -> Any:
    if not isinstance(result, dict) or result.get("success") is False or result.get("ok") is False:
        raise PipelineError(f"Pixmax response failed at {stage}")
    return result


def checked_plan(result: Any, stage: str, expected_endpoint: str) -> None:
    if not isinstance(result, dict) or result.get("dryRun") is not True:
        raise PipelineError(f"{stage} did not return a dry-run plan")
    plans = result.get("plans")
    if plans is None and result.get("endpoint"):
        plans = [result]
    if not isinstance(plans, list) or not any(isinstance(item, dict) and item.get("endpoint") == expected_endpoint for item in plans):
        raise PipelineError(f"{stage} plan lacks {expected_endpoint}")


def records(value: Any) -> list[dict[str, Any]]:
    if isinstance(value, list):
        return [item for item in value if isinstance(item, dict)]
    if isinstance(value, dict):
        for key in ("data", "list", "items", "records", "rows", "projects", "files"):
            found = value.get(key)
            if found is not None:
                return records(found)
    return []


def uuid_from(value: Any) -> str | None:
    if isinstance(value, dict):
        for key in ("uuid", "projectUuid", "fileUuid", "nodeKey", "assetUuid", "assetsUuid"):
            candidate = value.get(key)
            if isinstance(candidate, str) and candidate.strip():
                return candidate
        return uuid_from(value.get("data"))
    if isinstance(value, str) and value.strip():
        return value
    return None


def unique_named(items: list[dict[str, Any]], name: str, stage: str) -> str | None:
    matches = [item for item in items if item.get("name") == name or item.get("label") == name]
    if len(matches) > 1:
        raise PipelineError(f"ambiguous {stage}: {name}")
    if not matches:
        return None
    result = uuid_from(matches[0])
    if not result:
        raise PipelineError(f"{stage} lacks UUID: {name}")
    return result


def project_lookup(name: str) -> str | None:
    for page in range(1, 51):
        batch = records(successful(cli("project", "list", "--page", str(page), "--page-size", "100"), "project list"))
        found = unique_named(batch, name, "project")
        if found:
            return found
        if len(batch) < 100:
            return None
    raise PipelineError("project list exceeded 50 pages; cannot safely reconcile")


def ensure_project(manifest: dict[str, Any], state: dict[str, Any], save: Any) -> str:
    if state.get("project_uuid"):
        return state["project_uuid"]
    name = manifest["remote_project_name"]
    found = project_lookup(name)
    if not found:
        checked_plan(cli("project", "save", "--name", name, "--dry-run"), "project create", "/project/createOrUpdate")
        result = successful(cli("project", "save", "--name", name), "project create")
        found = uuid_from(result) or project_lookup(name)
    if not found:
        raise PipelineError("project created but its UUID could not be resolved; inspect Pixmax before retry")
    state["project_uuid"] = found
    save()
    return found


def ensure_canvas(manifest: dict[str, Any], state: dict[str, Any], save: Any) -> str:
    if state.get("canvas_uuid"):
        return state["canvas_uuid"]
    project_uuid = state["project_uuid"]
    name = manifest["canvas_name"]
    found = unique_named(records(successful(cli("project", "files", "--project", project_uuid), "project files")), name, "canvas")
    if not found:
        checked_plan(cli("project", "file", "create", "--project", project_uuid, "--name", name, "--dry-run"), "canvas create", "/project/file/create")
        result = successful(cli("project", "file", "create", "--project", project_uuid, "--name", name), "canvas create")
        found = uuid_from(result)
        if not found:
            found = unique_named(records(successful(cli("project", "files", "--project", project_uuid), "project files")), name, "canvas")
    if not found:
        raise PipelineError("canvas created but its UUID could not be resolved")
    state["canvas_uuid"] = found
    save()
    return found


def canvas_nodes(file_uuid: str) -> list[dict[str, Any]]:
    result = cli("canvas", "nodes", "--file", file_uuid)
    if not isinstance(result, list):
        raise PipelineError("canvas nodes returned an unexpected shape")
    return [item for item in result if isinstance(item, dict)]


def ensure_reference(shot: dict[str, Any], manifest: dict[str, Any], state: dict[str, Any], save: Any) -> str | None:
    source = shot["reference_image"]
    if not source:
        return None
    row = state["shots"].setdefault(shot["id"], {})
    if row.get("reference_node_uuid"):
        return row["reference_node_uuid"]
    label = f"REF__{manifest['run_id']}__{shot['id']}"
    existing = unique_named(canvas_nodes(state["canvas_uuid"]), label, "reference node")
    if existing:
        raise PipelineError(f"reference node {label} exists without checkpoint; inspect asset identity before adopting")
    args = ("assets", "upload", source, "--project", state["project_uuid"], "--file-uuid", state["canvas_uuid"], "--asset-type", "IMG", "--as-node", label)
    checked_plan(cli(*args, "--dry-run"), f"upload {shot['id']}", "/assets/oss/authorize")
    result = successful(cli(*args), f"upload {shot['id']}")
    node_uuid = result.get("nodeKey")
    asset_uuid = result.get("assetUuid")
    if not node_uuid or not asset_uuid:
        raise PipelineError(f"upload {shot['id']} returned no node/asset UUID; inspect Pixmax")
    row.update({"reference_node_uuid": node_uuid, "reference_asset_uuid": asset_uuid, "reference_sha256": shot["reference_sha256"]})
    save()
    return node_uuid


def ensure_ordered_references(shot: dict[str, Any], manifest: dict[str, Any], state: dict[str, Any], save: Any) -> list[str]:
    if "reference_images" not in shot:
        node_uuid = ensure_reference(shot, manifest, state, save)
        return [node_uuid] if node_uuid else []
    row = state["shots"].setdefault(shot["id"], {})
    nodes = row.setdefault("reference_nodes", [])
    for index, source in enumerate(shot["reference_images"], 1):
        if index <= len(nodes):
            recorded = nodes[index - 1]
            if recorded.get("sha256") != source["sha256"] or recorded.get("path") != source["path"]:
                raise PipelineError(f"shot {shot['id']} reference {index} differs from checkpoint")
            continue
        label = f"REF__{manifest['run_id']}__{shot['id']}__{index:02d}"
        if unique_named(canvas_nodes(state["canvas_uuid"]), label, "reference node"):
            raise PipelineError(f"reference node {label} exists without checkpoint; inspect before adopting")
        args = ("assets", "upload", source["path"], "--project", state["project_uuid"], "--file-uuid", state["canvas_uuid"], "--asset-type", "IMG", "--as-node", label)
        checked_plan(cli(*args, "--dry-run"), f"upload {shot['id']} reference {index}", "/assets/oss/authorize")
        result = successful(cli(*args), f"upload {shot['id']} reference {index}")
        if not result.get("nodeKey") or not result.get("assetUuid"):
            raise PipelineError(f"upload {shot['id']} reference {index} returned no node/asset UUID")
        nodes.append({"path": source["path"], "sha256": source["sha256"], "node_uuid": result["nodeKey"], "asset_uuid": result["assetUuid"]})
        save()
    return [item["node_uuid"] for item in nodes]


def generation_args(shot: dict[str, Any], manifest: dict[str, Any], state: dict[str, Any]) -> tuple[str, ...]:
    label = f"VID__{manifest['run_id']}__{shot['id']}"
    if "reference_images" in shot or "output_format" in shot:
        row = state["shots"].get(shot["id"], {})
        if "reference_images" in shot:
            nodes = [item["node_uuid"] for item in row.get("reference_nodes", [])]
            if len(nodes) != len(shot["reference_images"]):
                raise PipelineError(f"shot {shot['id']} ordered reference upload is incomplete")
        else:
            nodes = [row["reference_node_uuid"]] if shot["reference_image"] and row.get("reference_node_uuid") else []
            if shot["reference_image"] and not nodes:
                raise PipelineError(f"shot {shot['id']} reference upload is incomplete")
        refer_model = shot.get("refer_model") or ("imageToVideo" if nodes else "textToVideo")
        args = ["node", "create", label, "-t", "GENERATE_VIDEO", "--file", state["canvas_uuid"], "--prompt", shot["prompt"], "--model", shot["model"]]
        settings = [("resolution", shot["resolution"]), ("aspectRatio", shot["aspect_ratio"]), ("duration", shot["duration"]), ("referModel", refer_model), ("includeAudio", str(shot["audio"]).lower()), ("count", "1")]
        if "output_format" in shot:
            settings.append(("outputFormat", shot["output_format"]))
        if "bitrate_mode" in shot:
            settings.append(("bitrateMode", shot["bitrate_mode"]))
        for name, value in settings:
            args += ["-s", f"{name}={value}"]
        for node_uuid in nodes:
            args += ["--left", node_uuid]
        return tuple(args)
    mode = "image-to-video" if shot["reference_image"] else "text-to-video"
    args = ["video", mode, label, "--file", state["canvas_uuid"], "--prompt", shot["prompt"], "--model", shot["model"], "--resolution", shot["resolution"], "--aspect-ratio", shot["aspect_ratio"], "--duration", shot["duration"], "--include-audio" if shot["audio"] else "--no-audio"]
    if shot["reference_image"]:
        args += ["--image-node", state["shots"][shot["id"]]["reference_node_uuid"]]
    return tuple(args)


def ensure_generation(shot: dict[str, Any], manifest: dict[str, Any], state: dict[str, Any], save: Any) -> str:
    row = state["shots"].setdefault(shot["id"], {})
    if row.get("video_node_uuid"):
        return row["video_node_uuid"]
    label = f"VID__{manifest['run_id']}__{shot['id']}"
    existing = unique_named(canvas_nodes(state["canvas_uuid"]), label, "video node")
    if existing:
        progress = cli("tasks", "progress", existing)
        if not records(progress):
            raise PipelineError(f"video node {label} exists without a task; inspect before resubmitting")
        row["video_node_uuid"] = existing
        save()
        return existing
    args = generation_args(shot, manifest, state)
    plan = cli(*args, "--dry-run")
    checked_plan(plan, f"generate {shot['id']}", "/canvas/node/batch")
    batch = next(item["payload"] for item in plan["plans"] if item.get("endpoint") == "/canvas/node/batch")
    if not isinstance(batch, dict) or not isinstance(batch.get("baseRevision"), str):
        raise PipelineError("cli_protocol_gap: video dry-run omits baseRevision; stop before generation and request an updated Pixmax CLI")
    created = batch.get("create")
    if not isinstance(created, list) or len(created) != 1 or not isinstance(created[0], dict):
        raise PipelineError("cli_protocol_gap: video dry-run must contain exactly one create item")
    node = created[0]
    if node.get("type") != "GENERATE_VIDEO" or any(key in node for key in ("fileUuid", "isGenerateNode", "metaDataPatch")):
        raise PipelineError("cli_protocol_gap: video create item violates the Pixmax generation-node protocol")
    if not isinstance(node.get("metaData"), str) or not isinstance(node.get("params"), dict) or not isinstance(node.get("prevNodeUuids"), list) or node.get("defaultAssetUuid") != "":
        raise PipelineError("cli_protocol_gap: video create item lacks required metadata, params, upstreams or empty defaultAssetUuid")
    row = state["shots"].get(shot["id"], {})
    expected_prev = ([item["node_uuid"] for item in row.get("reference_nodes", [])]
                     if "reference_images" in shot else
                     ([row["reference_node_uuid"]] if shot["reference_image"] else []))
    if node["prevNodeUuids"] != expected_prev:
        raise PipelineError(f"cli_protocol_gap: shot {shot['id']} video dry-run changed ordered reference inputs")
    params = node["params"]
    expected_params = {"model": shot["model"], "prompt": shot["prompt"],
                       "resolution": shot["resolution"], "aspectRatio": shot["aspect_ratio"],
                       "duration": shot["duration"], "includeAudio": str(shot["audio"]).lower()}
    if "reference_images" in shot:
        expected_params["referModel"] = shot["refer_model"]
    if "output_format" in shot:
        expected_params["outputFormat"] = shot["output_format"]
    for field, wanted in expected_params.items():
        if str(params.get(field)).lower() != str(wanted).lower():
            raise PipelineError(f"cli_protocol_gap: shot {shot['id']} video dry-run changed {field}")
    submit_args = ("--run", "--no-wait") if "reference_images" in shot or "output_format" in shot else ("--no-wait",)
    result = successful(cli(*args, *submit_args), f"generate {shot['id']}")
    node_uuid = result.get("nodeKey")
    if not node_uuid or not isinstance(result.get("submit"), dict) or result["submit"].get("success") is False:
        raise PipelineError(f"generation {shot['id']} lacks confirmed node or submission")
    row["video_node_uuid"] = node_uuid
    row["submitted_at"] = stamp()
    save()
    return node_uuid


def wait_and_assets(shot: dict[str, Any], state: dict[str, Any], save: Any) -> list[str]:
    row = state["shots"][shot["id"]]
    if row.get("asset_uuids"):
        return row["asset_uuids"]
    result = cli("tasks", "wait", row["video_node_uuid"], "--timeout", "3600", "--interval", "10", "--allow-failed")
    if not isinstance(result, dict) or result.get("ok") is not True or result.get("status") != "COMPLETE":
        raise PipelineError(f"generation {shot['id']} did not complete: {result.get('status') if isinstance(result, dict) else 'unknown'}")
    assets = result.get("resultAssets")
    if not isinstance(assets, list) or not assets:
        raise PipelineError(f"generation {shot['id']} completed without result assets")
    uuids = [uuid_from(asset) for asset in assets]
    if any(not value for value in uuids):
        raise PipelineError(f"generation {shot['id']} returned an asset without UUID")
    row["asset_uuids"] = uuids
    row["completed_at"] = stamp()
    save()
    return uuids


def video_extension(path: Path) -> str:
    with path.open("rb") as stream:
        head = stream.read(16)
    if len(head) >= 12 and head[4:8] == b"ftyp":
        if head[8:12] == b"qt  ":
            return ".mov"
        return ".mp4"
    if head.startswith(b"\x1a\x45\xdf\xa3"):
        return ".webm"
    raise PipelineError(f"download is not a recognized MP4/MOV/WebM video: {path.name}")


def ensure_downloads(shot: dict[str, Any], manifest: dict[str, Any], state: dict[str, Any], save: Any, delivery: Path) -> None:
    row = state["shots"][shot["id"]]
    outputs = row.setdefault("outputs", [])
    for index, asset_uuid in enumerate(row["asset_uuids"], 1):
        previous = next((item for item in outputs if item["asset_uuid"] == asset_uuid), None)
        if previous:
            target = delivery / previous["file"]
            if target.is_file() and sha256(target) == previous["sha256"]:
                continue
            raise PipelineError(f"existing output missing or changed: {target}")
        stem = f"{manifest['episode']}_{shot['id']}_v{index:02d}_{safe_name(shot['model'], 'model')}"
        partial = delivery / (stem + ".partial")
        if partial.exists():
            partial.unlink()
        cli("assets", "download", asset_uuid, "--output", str(partial), "--kind", "web")
        if not partial.is_file() or partial.stat().st_size == 0:
            raise PipelineError(f"download {asset_uuid} produced no file")
        extension = video_extension(partial)
        target = delivery / (stem + extension)
        if target.exists():
            raise PipelineError(f"refusing to replace existing output: {target}")
        checksum = sha256(partial)
        size = partial.stat().st_size
        os.replace(partial, target)
        outputs.append({"asset_uuid": asset_uuid, "file": target.name, "sha256": checksum, "bytes": size})
        save()


def run(manifest: dict[str, Any], delivery: Path, fingerprint: str, *, prepare_only: bool = False) -> None:
    from project_style import validate_route
    validate_route(manifest)
    if manifest.get('project_route', {}).get('production_style') == 'animation' and not prepare_only:
        raise PipelineError('Animation uses fast_bind/resolve_saved_batch for source-locked preparation; this legacy run path cannot submit animation')
    delivery.mkdir(parents=True, exist_ok=True)
    state_path = delivery / "state.json"
    if state_path.exists():
        state = json.loads(state_path.read_text(encoding="utf-8"))
        if state.get("fingerprint") != fingerprint:
            raise PipelineError("manifest or source asset changed for this run_id; use a new run_id")
    else:
        state = {"fingerprint": fingerprint, "created_at": stamp(), "shots": {}}
        atomic_json(state_path, state)

    def save() -> None:
        state["updated_at"] = stamp()
        atomic_json(state_path, state)

    config = cli("config", "show")
    if not isinstance(config, dict) or (config.get("effective") or {}).get("environment") != "cn":
        raise PipelineError("CLI environment is not cn; check Pixmax account/region before running")
    doctor = cli("doctor", "--online")
    if not isinstance(doctor, dict) or doctor.get("ok") is not True:
        raise PipelineError("Pixmax CLI is not logged in; run pixmax auth login web")
    # Also preflight prepare-only batches before any project/canvas/asset writes.
    reference_models = {}
    for shot in manifest["shots"]:
        if "reference_images" not in shot and not shot.get("reference_image"):
            continue
        model = shot["model"]
        if model not in reference_models:
            reference_models[model] = successful(cli("model", "explain", model, "--type", "GENERATE_VIDEO"), f"model {model}")
        validate_reference_limits(shot, reference_models[model])
    if not prepare_only:
        if doctor.get("version") == "1.3.0":
            raise PipelineError("cli_protocol_gap: Pixmax CLI 1.3.0 video dry-run violates its generation-node protocol (baseRevision and create fields); video generation was not started. Use prepare to create the project, canvas and reference nodes")
        for model in sorted({shot["model"] for shot in manifest["shots"]}):
            model_info = successful(cli("model", "explain", model), f"model {model}")
            if model_info.get("nodeType") != "GENERATE_VIDEO" or model_info.get("restricted") is True:
                raise PipelineError(f"video model unavailable: {model}")
            specs = {item.get("name"): item for item in model_info.get("params", []) if isinstance(item, dict)}
            for shot in (item for item in manifest["shots"] if item["model"] == model):
                for key, field in (("resolution", "resolution"), ("aspect_ratio", "aspectRatio"), ("duration", "duration")):
                    options = specs.get(field, {}).get("options") or []
                    if options and shot[key] not in options:
                        raise PipelineError(f"shot {shot['id']} {key}={shot[key]} is unavailable for {model}")
                if "output_format" in shot:
                    options = specs.get("outputFormat", {}).get("options") or []
                    if shot["output_format"] not in options:
                        raise PipelineError(f"shot {shot['id']} output_format={shot['output_format']} is unavailable for {model}")
                if "bitrate_mode" in shot:
                    options = specs.get("bitrateMode", {}).get("options") or []
                    if shot["bitrate_mode"] not in options:
                        raise PipelineError(f"shot {shot['id']} bitrate_mode={shot['bitrate_mode']} is unavailable for {model}")
    atomic_json(delivery / "run.manifest.json", manifest)
    ensure_project(manifest, state, save)
    ensure_canvas(manifest, state, save)
    if prepare_only:
        for shot in manifest["shots"]:
            ensure_ordered_references(shot, manifest, state, save)
        print(json.dumps({"ok": True, "stage": "prepared", "delivery": str(delivery), "project_uuid": state["project_uuid"], "canvas_uuid": state["canvas_uuid"], "reference_nodes": sum(len(shot.get("reference_images", [])) if "reference_images" in shot else bool(state["shots"].get(shot["id"], {}).get("reference_node_uuid")) for shot in manifest["shots"])}, ensure_ascii=False, indent=2))
        return
    for shot in manifest["shots"]:
        ensure_ordered_references(shot, manifest, state, save)
        ensure_generation(shot, manifest, state, save)
        wait_and_assets(shot, state, save)
        ensure_downloads(shot, manifest, state, save, delivery)
    delivery_info = {
        "run_id": manifest["run_id"], "project_uuid": state["project_uuid"], "canvas_uuid": state["canvas_uuid"],
        "remote_project_name": manifest["remote_project_name"], "completed_at": stamp(),
        "shots": [{"id": shot["id"], "model": shot["model"], "video_node_uuid": state["shots"][shot["id"]]["video_node_uuid"], "outputs": state["shots"][shot["id"]]["outputs"]} for shot in manifest["shots"]],
    }
    atomic_json(delivery / "delivery.json", delivery_info)
    print(json.dumps({"ok": True, "delivery": str(delivery), "project_uuid": state["project_uuid"], "canvas_uuid": state["canvas_uuid"], "videos": sum(len(s["outputs"]) for s in delivery_info["shots"])}, ensure_ascii=False, indent=2))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("plan", "prepare", "run"))
    parser.add_argument("--manifest", type=Path, required=True)
    options = parser.parse_args()
    try:
        manifest, delivery, fingerprint = load_manifest(options.manifest)
        if options.mode == "plan":
            print(json.dumps({"mode": "plan", "fingerprint": fingerprint, **manifest}, ensure_ascii=False, indent=2))
        else:
            run(manifest, delivery, fingerprint, prepare_only=options.mode == "prepare")
        return 0
    except (PipelineError, OSError, json.JSONDecodeError) as exc:
        print(f"[pixmax-pipeline] {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
