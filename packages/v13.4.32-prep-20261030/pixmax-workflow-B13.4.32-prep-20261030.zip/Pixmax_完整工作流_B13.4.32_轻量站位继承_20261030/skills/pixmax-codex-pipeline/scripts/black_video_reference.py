"""A pinned connection-only video; never edits prompts or generates media."""
import hashlib
from pathlib import Path
from pixmax_pipeline import PipelineError

POLICY = 'connection_only_black_video_v1'
SOURCE = Path(__file__).resolve().parents[1] / 'assets' / 'black-2s.mp4'
SHA256 = 'b7ae7afdd2f44519b01e6852d5c8bb5589cdd4be90e70d3a1810bc01b235add1'


def validate_reference(reference, image_ids, limits, nodes=None):
    """Return zero/one appended UUID; absence preserves historical manifests."""
    if reference is None:
        return []
    if not isinstance(reference, dict) or reference.get('policy') != POLICY:
        raise PipelineError('Invalid connection-only black video policy')
    if (reference.get('source_sha256') != SHA256 or
            type(reference.get('duration_seconds')) not in (int, float) or
            reference['duration_seconds'] != 2):
        raise PipelineError('Black video must be the supplied unchanged two-second source')
    if not SOURCE.is_file() or hashlib.sha256(SOURCE.read_bytes()).hexdigest() != SHA256:
        raise PipelineError('Bundled black video is missing or changed')
    uid, asset = reference.get('node_uuid'), reference.get('asset_uuid')
    if not isinstance(uid, str) or not uid.strip() or not isinstance(asset, str) or not asset.strip():
        raise PipelineError('Black video requires actual node and asset UUIDs')
    if uid in image_ids:
        raise PipelineError('Black video must not duplicate an image input')
    if (not isinstance(limits, dict) or
            any(type(limits.get(k)) != int or limits[k] < 1
                for k in ('max_video_inputs', 'max_total_inputs'))):
        raise PipelineError('Current video and combined input limits required')
    if len(image_ids) + 1 > limits['max_total_inputs']:
        raise PipelineError('Black video exceeds current combined input limit; do not remove images')
    if nodes is not None:
        node = nodes.get(uid, {})
        actual = (node.get('defaultAsset') or {}).get('assetsUuid')
        if node.get('type') != 'BASE_VIDEO' or actual != asset:
            raise PipelineError('Black video must resolve to its actual uploaded BASE_VIDEO asset')
    return [uid]


def expected_order(shot, nodes=None):
    images = [b['node_uuid'] for b in shot.get('bindings', [])]
    extra = validate_reference(shot.get('connection_only_video'), images,
                               shot.get('reference_input_limits'), nodes)
    if extra and shot.get('params', {}).get('nodeType') != 'GENERATE_VIDEO':
        raise PipelineError('Connection-only black video is for video generation nodes only')
    return images + extra
