"""Check recorded whole-episode staging evidence, not pixels or physical geometry."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
from pixmax_pipeline import PipelineError

POLICY = 'seedance25_opening_blocking_v1'


def requires_blocking_review(shot):
    params = shot.get('params', {})
    return params.get('nodeType') == 'GENERATE_VIDEO' and (
        shot.get('prompt_role') in ('seedance25_30s', 'seedance25_v134') or (
            str(params.get('model', '')).startswith('PIXDANCE_2_5') and
            params.get('referModel') != 'videoEdit'))


def validate_episode_blocking_review(shot, nodes):
    if not requires_blocking_review(shot):
        return
    if shot.get('prompt_role') == 'seedance25_animation':
        from animation_contract import validate_staging
        validate_staging(shot)
        return
    uid = shot['node_uuid']

    def fail(message):
        raise PipelineError(uid + ': episode blocking review ' + message)

    def text(value, message):
        if not isinstance(value, str) or not value.strip():
            fail(message)
        return value

    def file_bytes(record, path_key, hash_key):
        path = Path(text(record.get(path_key), 'requires ' + path_key))
        if not path.is_absolute() or not path.is_file():
            fail('requires a real absolute file: ' + path_key)
        data = path.read_bytes()
        if hashlib.sha256(data).hexdigest() != record.get(hash_key):
            fail('is stale or has a mismatched hash: ' + path_key)
        return data

    raw = file_bytes(shot, 'episode_blocking_review_file', 'episode_blocking_review_sha256')
    try:
        report = json.loads(raw.decode('utf-8-sig'))
    except (ValueError, UnicodeError):
        fail('requires readable JSON')
    if not isinstance(report, dict):
        fail('report must be an object')
    if shot.get('prompt_role') == 'seedance25_v134' and report.get('policy') != 'seedance25_opening_blocking_v2':
        fail('v134 requires the scene-master v2 report')

    if report.get('policy') == 'seedance25_opening_blocking_v2':
        from scene_blocking_review_v2 import validate_scene_review
        validate_scene_review(shot, nodes, report, fail, file_bytes, text)
        return
    if report.get('policy') != POLICY or report.get('status') != 'PASS':
        fail('is missing or not PASS; inspect every actual opening image first')
    text(report.get('episode_id'), 'requires episode_id')
    text(report.get('reviewed_at'), 'requires the actual review time')
    file_bytes(report, 'script_file', 'script_sha256')
    plan_raw = file_bytes(report, 'blocking_plan_file', 'blocking_plan_sha256')
    try:
        plan = json.loads(plan_raw.decode('utf-8-sig'))
    except (ValueError, UnicodeError):
        fail('requires a readable pre-authoring blocking plan JSON')
    if (not isinstance(plan, dict) or plan.get('policy') != 'seedance25_episode_blocking_plan_v1' or
            plan.get('episode_id') != report['episode_id'] or
            plan.get('script_sha256') != report.get('script_sha256')):
        fail('plan episode or script version does not match the review')
    for key in ('transition_review', 'projection_review', 'cross_segment_review'):
        entry = report.get(key)
        if not isinstance(entry, dict) or entry.get('status') != 'PASS':
            fail('requires PASS for ' + key)
        text(entry.get('observation'), 'requires concrete observations: ' + key)
    expected = report.get('expected_segment_ids')
    if not isinstance(expected, list) or not expected:
        fail('requires the locked whole-episode segment list')
    for item in expected:
        text(item, 'segment IDs must be nonempty strings')
    if len(set(expected)) != len(expected):
        fail('contains duplicate segment IDs')
    if plan.get('expected_segment_ids') != expected:
        fail('review does not cover the locked pre-authoring episode plan')
    planned = plan.get('segments')
    if (not isinstance(planned, list) or any(not isinstance(row, dict) for row in planned) or
            [row.get('id') for row in planned] != expected):
        fail('plan must contain every segment in order')
    for entry in planned:
        for key in ('opening_state', 'exit_state'):
            if not isinstance(entry.get(key), dict) or not entry[key]:
                fail('plan requires ' + key + ': ' + entry['id'])
        if not isinstance(entry.get('movements'), list):
            fail('plan requires an explicit movements list: ' + entry['id'])
    segments = report.get('segments')
    if not isinstance(segments, list) or any(not isinstance(row, dict) for row in segments):
        fail('segment reviews must be objects')
    if [row.get('id') for row in segments] != expected:
        fail('must cover every planned segment in order, even for a submission subset')
    # The plan is the prior authoring artefact; semantic completeness is reviewed
    # by the agent. This check cannot prove that an author recorded it beforehand.
    segment_id = text(shot.get('episode_segment_id'), 'requires episode_segment_id')
    current = None
    seen_nodes, seen_assets = set(), set()
    for row in segments:
        for path_key, hash_key in (
            ('source_prompt_file', 'source_sha256'),
            ('opening_prompt_file', 'opening_prompt_sha256'),
            ('opening_image_file', 'opening_image_sha256'),
        ):
            data = file_bytes(row, path_key, hash_key)
            if path_key == 'opening_image_file':
                image_header = (data.startswith(b'\x89PNG\r\n\x1a\n') or
                                data.startswith(b'\xff\xd8\xff') or
                                (data.startswith(b'RIFF') and data[8:12] == b'WEBP'))
                if not image_header:
                    fail('opening evidence must be a downloaded PNG/JPEG/WebP image')
        if row.get('viewed') is not True or row.get('status') != 'PASS':
            fail('contains an unseen, unclear or failed opening image: ' + row['id'])
        if row.get('color') is not True or row.get('shot_scale') != 'wide':
            fail('requires color wide opening images: ' + row['id'])
        text(row.get('camera_look'), 'requires the reviewed cinematic camera look')
        text(row.get('aspect_ratio'), 'requires the reviewed aspect ratio')
        text(row.get('opening_match_observation'), 'requires an actual image observation')
        opening_node = text(row.get('opening_node_uuid'), 'requires opening_node_uuid')
        opening_asset = text(row.get('opening_asset_uuid'), 'requires opening_asset_uuid')
        if opening_node in seen_nodes or opening_asset in seen_assets:
            fail('each segment requires its own opening image mapping')
        seen_nodes.add(opening_node)
        seen_assets.add(opening_asset)
        node = nodes.get(opening_node, {})
        if (node.get('defaultAsset') or {}).get('assetsUuid') != opening_asset:
            fail('opening node is missing or its actual image has changed: ' + row['id'])
        if row['id'] == segment_id:
            current = row
    if current is None:
        fail('does not include the current video segment')
    if Path(current['source_prompt_file']).resolve() != Path(shot.get('source_prompt_file', '')).resolve():
        fail('belongs to another source prompt')
    if current['source_sha256'] != shot.get('source_sha256'):
        fail('belongs to an older source prompt version')
    bindings = shot.get('bindings') or []
    blocking = [row for row in bindings if row.get('category') == 'blocking_reference']
    if (len(blocking) != 1 or not bindings or bindings[0] != blocking[0] or
            blocking[0].get('node_uuid') != current['opening_node_uuid'] or
            not shot.get('prevNodeUuids') or
            shot['prevNodeUuids'][0] != current['opening_node_uuid']):
        fail('requires this segment\'s approved opening image as the first input')
    ratio = shot.get('params', {}).get('aspectRatio')
    if ratio and str(ratio) != current['aspect_ratio']:
        fail('opening image aspect ratio differs from the video')


def blocking_review_errors(manifest, nodes, ready):
    by_node = {node['uuid']: node for node in nodes}
    ready_set = set(ready)
    errors = []
    for shot in manifest['shots']:
        if shot['node_uuid'] not in ready_set:
            continue
        try:
            validate_episode_blocking_review(shot, by_node)
        except (PipelineError, OSError, ValueError) as exc:
            errors.append({'node_uuid': shot['node_uuid'], 'reason': str(exc)})
    return errors
