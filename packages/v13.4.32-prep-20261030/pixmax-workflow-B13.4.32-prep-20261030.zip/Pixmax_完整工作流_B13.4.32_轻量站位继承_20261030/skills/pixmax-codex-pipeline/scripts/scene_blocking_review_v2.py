"""Validate recorded scene-master evidence. Does not approve pixels."""
from pathlib import Path
import hashlib,json,re

def validate_scene_review(shot,nodes,report,fail,file_bytes,text):
    if report.get('status')!='PASS': fail('v2 report not PASS')
    text(report.get('episode_id'),'requires episode_id')
    text(report.get('reviewed_at'),'requires actual review time')
    file_bytes(report,'script_file','script_sha256')
    plan=json.loads(file_bytes(report,'blocking_plan_file','blocking_plan_sha256').decode('utf-8-sig'))
    if (plan.get('policy')!='seedance25_episode_blocking_plan_v1' or
        plan.get('episode_id')!=report['episode_id'] or plan.get('script_sha256')!=report.get('script_sha256')):
        fail('plan episode/script mismatch')
    for k in ('transition_review','projection_review','cross_segment_review'):
        e=report.get(k) or {}
        if e.get('status')!='PASS':fail('requires PASS for '+k)
        text(e.get('observation'),'requires concrete '+k+' observation')
    expected=report.get('expected_segment_ids')
    if not isinstance(expected,list) or not expected or any(not isinstance(i,str) or not i for i in expected) or len(set(expected))!=len(expected):
        fail('requires complete unique segment IDs')
    if plan.get('expected_segment_ids')!=expected:fail('coverage differs from locked plan')
    planned=plan.get('segments');rows=report.get('segments')
    if (not isinstance(planned,list) or not isinstance(rows,list) or
        any(not isinstance(r,dict) for r in planned+rows) or
        [r.get('id') for r in planned]!=expected or [r.get('id') for r in rows]!=expected):
        fail('must cover every planned segment in order')
    runs=plan.get('scene_runs')
    if not isinstance(runs,list) or any(not isinstance(r,dict) for r in runs):fail('requires planned scene_runs')
    runmap={r.get('key'):r for r in runs}
    if len(runmap)!=len(runs) or not all(isinstance(k,str) and k for k in runmap):fail('scene run keys must be unique')
    covered=[]
    for run in runs:
        ids=run.get('segment_ids')
        if not isinstance(ids,list) or not ids or any(not isinstance(i,str) or not i for i in ids) or len(set(ids))!=len(ids):fail('invalid scene run segments')
        covered+=ids
    if len(set(covered))!=len(covered):fail('segment in multiple scene runs')
    if any(i not in covered for i in expected):fail('scene runs miss an episode segment')
    requirements={}
    from blocking_complexity import assess_complexity
    for key,run in runmap.items():
        if run.get('blocking_complexity_assessment') is not None:
            try:requirements[key]=assess_complexity(run)
            except ValueError as exc:fail(str(exc))
        else:requirements[key]={'image_required':len(run['segment_ids'])>1,'reason':'legacy_single_segment' if len(run['segment_ids'])==1 else 'legacy_multisegment'}
    masters=report.get('scene_masters',[])
    if not isinstance(masters,list) or any(not isinstance(m,dict) for m in masters):fail('invalid scene_masters')
    mm={m.get('scene_run_key'):m for m in masters}
    if len(mm)!=len(masters):fail('duplicate scene master')
    def image_file(row):
        data=file_bytes(row,'opening_image_file','opening_image_sha256')
        if not (data.startswith(b'\x89PNG\r\n\x1a\n') or data.startswith(b'\xff\xd8\xff') or (data.startswith(b'RIFF') and data[8:12]==b'WEBP')):
            fail('evidence must be PNG/JPEG/WebP')
    for key,master in mm.items():
        run=runmap.get(key)
        if not run or not requirements[key]['image_required'] or master.get('id')!=run['segment_ids'][0]:fail('master is not multi-segment scene first opening')
        if master.get('viewed') is not True or master.get('status')!='PASS':fail('master not actually viewed/PASS')
        text(master.get('camera_look'),'requires actual master film-look observation')
        image_file(master)
        n=nodes.get(master.get('opening_node_uuid'),{})
        if (n.get('defaultAsset') or {}).get('assetsUuid')!=master.get('opening_asset_uuid') or not master.get('opening_asset_uuid'):
            fail('scene master asset is stale/missing')
    current=None;seen_nodes=set();seen_assets=set();reviewed={}
    planned_by_id={p['id']:p for p in planned}
    for p,r in zip(planned,rows):
        if not isinstance(p.get('opening_state'),dict) or not p['opening_state'] or not isinstance(p.get('exit_state'),dict) or not p['exit_state'] or not isinstance(p.get('movements'),list):
            fail('requires opening, movement and exit plan')
        key=p.get('scene_run_key');run=runmap.get(key)
        if not run or r.get('scene_run_key')!=key or r['id'] not in run['segment_ids']:fail('segment scene run mismatch')
        file_bytes(r,'source_prompt_file','source_sha256')
        if r.get('status')!='PASS':fail('segment not PASS: '+r['id'])
        text(r.get('opening_match_observation'),'requires actual opening/exception observation')
        mode=r.get('reference_mode')
        if not requirements[key]['image_required']:
            expected_mode='NOT_REQUIRED_SINGLE_SEGMENT_SCENE' if len(run['segment_ids'])==1 else 'NOT_REQUIRED_TWO_CHARACTER_SCENE'
            if mode!=expected_mode or r.get('opening_node_uuid') or r.get('opening_asset_uuid'):
                fail('single-segment scene must be explicitly exempt without image mapping')
        else:
            required='MASTER' if r['id']==run['segment_ids'][0] else 'DERIVED'
            if mode!=required and not (required=='DERIVED' and mode=='REUSED'):fail('invalid mother/derivative/reuse mode')
            file_bytes(r,'opening_prompt_file','opening_prompt_sha256');image_file(r)
            if r.get('viewed') is not True or r.get('color') is not True or r.get('shot_scale')!='wide':fail('requires actually viewed color wide image')
            if r.get('aspect_ratio')!='16:9' or r.get('resolution')!='1K':fail('new opening images require 1K 16:9')
            text(r.get('camera_look'),'requires actual film-look observation')
            uid=text(r.get('opening_node_uuid'),'requires opening node');asset=text(r.get('opening_asset_uuid'),'requires opening asset')
            if mode!='REUSED':
                if uid in seen_nodes or asset in seen_assets:fail('duplicate opening image requires an explicit verified REUSED mapping')
                seen_nodes.add(uid);seen_assets.add(asset)
            n=nodes.get(uid,{})
            if (n.get('defaultAsset') or {}).get('assetsUuid')!=asset:fail('opening image changed/missing')
            if n.get('type')=='GENERATE_IMAGE':
                params=n.get('params') or {}
                if params.get('resolution')!='1K' or params.get('aspectRatio')!='16:9':fail('saved image node parameters differ from reviewed spec')
            master=mm.get(key)
            if not master:fail('missing scene master evidence')
            if mode=='MASTER':
                if uid!=master['opening_node_uuid'] or asset!=master['opening_asset_uuid'] or r['opening_image_sha256']!=master['opening_image_sha256']:
                    fail('master segment version differs from scene master')
            elif mode=='REUSED':
                reused_id=text(r.get('reuse_of_segment_id'),'requires reuse_of_segment_id')
                previous=reviewed.get(reused_id)
                if not previous or previous.get('scene_run_key')!=key or previous.get('reference_mode') not in ('MASTER','DERIVED'):
                    fail('reuse must point directly to an earlier approved image in the same scene run')
                previous_plan=planned_by_id[reused_id]
                signature=p.get('spatial_signature')
                if not isinstance(signature,dict) or not signature or signature!=previous_plan.get('spatial_signature'):
                    fail('reuse spatial conditions differ from the approved image plan')
                if p.get('reuse_of_segment_id')!=reused_id or p.get('additional_character_assets',[])!=previous_plan.get('additional_character_assets',[]):
                    fail('reuse mapping or additional identities differ from the locked plan')
                for field in ('opening_node_uuid','opening_asset_uuid','opening_image_sha256','opening_prompt_sha256'):
                    if r.get(field)!=previous.get(field):fail('reuse image version differs: '+field)
                reuse=r.get('reuse_review') or {}
                if reuse.get('status')!='PASS':fail('reuse requires actual spatial-equivalence review')
                for field in ('spatial_equivalence_observation','pose_only_differences_observation'):
                    text(reuse.get(field),'requires concrete reuse observation: '+field)
                depth=r.get('depth_consistency_review') or {}
                if depth.get('status')!='PASS' or depth.get('source_sha256')!=r['source_sha256'] or depth.get('opening_image_sha256')!=r['opening_image_sha256']:
                    fail('reuse requires current source/image three-way depth review')
                for field in ('body_side','camera_near_far','image_occlusion_observation','designation_observation','first_shot_camera_and_foreground_observation','horizontal_consistency_observation'):
                    text(depth.get(field),'requires concrete reuse depth observation: '+field)
            else:
                for field,value in (('scene_master_id',master['id']),('scene_master_node_uuid',master['opening_node_uuid']),('scene_master_asset_uuid',master['opening_asset_uuid']),('scene_master_image_sha256',master['opening_image_sha256'])):
                    if r.get(field)!=value:fail('derivative mother lineage is stale: '+field)
                additions=p.get('additional_character_assets',[])
                refs=r.get('additional_character_references',[])
                if not isinstance(additions,list) or not isinstance(refs,list) or any(not isinstance(x,dict) for x in additions+refs):
                    fail('new-character plan/evidence must be lists of objects')
                if len(additions)!=len(refs):fail('new-character reference evidence missing or excessive')
                extra_nodes=[];extra_assets=[]
                master_cast=run.get('master_character_asset_uuids',[])
                if additions and (not isinstance(master_cast,list) or not master_cast or any(not isinstance(a,str) or not a for a in master_cast) or len(set(master_cast))!=len(master_cast)):
                    fail('new identities require actual master character asset list')
                mother_inputs=nodes.get(master['opening_node_uuid'],{}).get('prevNodeUuids',[])
                existing_assets={(nodes.get(u,{}) .get('defaultAsset') or {}).get('assetsUuid') for u in mother_inputs}
                for planned_ref,ref in zip(additions,refs):
                    name=text(planned_ref.get('designation'),'requires new character designation')
                    original_asset=text(planned_ref.get('asset_uuid'),'requires new original character asset')
                    if planned_ref.get('visible_at_opening') is not True:fail('new reference must belong to this opening, not a later entrance')
                    if ref.get('designation')!=name or ref.get('asset_uuid')!=original_asset:fail('new identity differs from locked plan')
                    if original_asset in master_cast or original_asset in existing_assets:fail('do not reattach existing master identities')
                    if original_asset in extra_assets:fail('duplicate new identity reference')
                    source_uid=text(ref.get('node_uuid'),'requires original new character node')
                    source=nodes.get(source_uid,{})
                    if source.get('type')!='BASE_IMAGE' or (source.get('defaultAsset') or {}).get('assetsUuid')!=original_asset:
                        fail('new reference is not current original character asset')
                    if ref.get('status')!='PASS' or ref.get('viewed') is not True:fail('new identity has not actually been viewed and passed')
                    text(ref.get('observation'),'requires actual new identity observation')
                    raw=file_bytes(ref,'image_file','image_sha256')
                    if not (raw.startswith(b'\x89PNG\r\n\x1a\n') or raw.startswith(b'\xff\xd8\xff') or (raw.startswith(b'RIFF') and raw[8:12]==b'WEBP')):
                        fail('new identity evidence must be an actual image')
                    extra_nodes.append(source_uid);extra_assets.append(original_asset)
                if n.get('prevNodeUuids')!=extra_nodes+[master['opening_node_uuid']]:
                    fail('derivative requires planned original new identities then direct first master')
        reviewed[r['id']]=r
        if r['id']==shot.get('episode_segment_id'):current=r
    if current is None:fail('missing current segment')
    if shot.get('prompt_role') == 'seedance25_v134':
        from seedance25_contract import generation_duration
        planned_current = next(p for p in planned if p['id'] == current['id'])
        if generation_duration(planned_current.get('actual_duration')) != float(shot['params']['duration']):
            fail('staging actual_duration differs from video duration')
    if Path(current['source_prompt_file']).resolve()!=Path(shot.get('source_prompt_file','')).resolve() or current['source_sha256']!=shot.get('source_sha256'):
        fail('current source version differs')
    bindings=shot.get('bindings') or [];blocking=[b for b in bindings if b.get('category')=='blocking_reference']
    if current['reference_mode'] in ('NOT_REQUIRED_SINGLE_SEGMENT_SCENE','NOT_REQUIRED_TWO_CHARACTER_SCENE'):
        if blocking or any(u in {m['opening_node_uuid'] for m in masters} for u in shot.get('prevNodeUuids',[])):fail('exempt segment must not have blocking input')
    else:
        uid=current['opening_node_uuid']
        index = 0
        if len(blocking)!=1 or bindings[index]!=blocking[0] or blocking[0].get('node_uuid')!=uid or not shot.get('prevNodeUuids') or shot['prevNodeUuids'][index]!=uid:
            fail('requires corresponding approved opening in the module-defined video input position')
        if re.search(r'%%@\[[^\]]+\]\[image\]\[\d+\]\('+re.escape(uid)+r'\)%%',(shot.get('params') or {}).get('prompt','')):
            fail('blocking image must be wired without @')
