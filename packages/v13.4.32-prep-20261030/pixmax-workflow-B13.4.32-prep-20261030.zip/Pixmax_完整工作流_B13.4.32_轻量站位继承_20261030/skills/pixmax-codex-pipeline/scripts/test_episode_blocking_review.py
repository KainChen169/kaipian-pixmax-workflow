"""Offline evidence-gate regressions; fixtures do not represent visual approval."""
import base64
import hashlib
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from episode_blocking_review import validate_episode_blocking_review, blocking_review_errors
from pixmax_pipeline import PipelineError
import submit_saved_batch as runner


class BlockingReviewTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.report = {'policy': 'seedance25_opening_blocking_v1', 'episode_id': 'EP03',
                       'status': 'PASS', 'reviewed_at': '2026-10-03T10:00:00+08:00',
                       'expected_segment_ids': ['EP03_01','EP03_02','EP03_03','EP03_04'],
                       'segments': []}
        self.nodes = {}
        self.report.update(self.file('script', 'source story', 'script_file', 'script_sha256'))
        self.plan = {'policy': 'seedance25_episode_blocking_plan_v1', 'episode_id': 'EP03',
                     'script_sha256': self.report['script_sha256'],
                     'expected_segment_ids': list(self.report['expected_segment_ids']),
                     'segments': [{'id': sid, 'opening_state': {'Seren': 'behind Alaric'},
                                   'movements': [], 'exit_state': {'Seren': 'behind Alaric'}}
                                  for sid in self.report['expected_segment_ids']]}
        self.report.update(self.file('plan.json', json.dumps(self.plan), 'blocking_plan_file', 'blocking_plan_sha256'))
        for key in ('transition_review', 'projection_review', 'cross_segment_review'):
            self.report[key] = {'status': 'PASS', 'observation': 'Offline fixture observation, not an image review'}
        png = base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jE8cAAAAASUVORK5CYII=')
        for i,sid in enumerate(self.report['expected_segment_ids']):
            row = {'id': sid, 'opening_node_uuid': 'image-'+str(i), 'opening_asset_uuid': 'asset-'+str(i),
                   'viewed': True, 'status': 'PASS', 'color': True, 'shot_scale': 'wide',
                   'aspect_ratio': '9:16', 'camera_look': 'ARRI-style',
                   'opening_match_observation': 'Synthetic regression fixture; not visual approval'}
            row.update(self.file(sid+'.md', 'source '+sid, 'source_prompt_file', 'source_sha256'))
            row.update(self.file(sid+'_image.md', 'static '+sid, 'opening_prompt_file', 'opening_prompt_sha256'))
            row.update(self.file(sid+'.png', png, 'opening_image_file', 'opening_image_sha256'))
            self.report['segments'].append(row)
            self.nodes[row['opening_node_uuid']] = {'uuid': row['opening_node_uuid'],
                'defaultAsset': {'assetsUuid': row['opening_asset_uuid']}}
        row = self.report['segments'][2]
        self.shot = {'node_uuid': 'video', 'prompt_role': 'seedance25_30s',
                     'episode_segment_id': row['id'], 'source_prompt_file': row['source_prompt_file'],
                     'source_sha256': row['source_sha256'],
                     'params': {'nodeType': 'GENERATE_VIDEO', 'model': 'PIXDANCE_2_5_DRAFT', 'duration': 30,
                                'aspectRatio': '9:16'},
                     'bindings': [{'category': 'blocking_reference','node_uuid': row['opening_node_uuid']}],
                     'prevNodeUuids': [row['opening_node_uuid']]}
        self.write_report()

    def file(self, name, content, path_key, hash_key):
        data = content if isinstance(content, bytes) else content.encode('utf-8')
        path = self.root/name
        path.write_bytes(data)
        return {path_key: str(path), hash_key: hashlib.sha256(data).hexdigest()}

    def write_report(self):
        self.shot.update(self.file('review.json', json.dumps(self.report),
            'episode_blocking_review_file', 'episode_blocking_review_sha256'))

    def check(self):
        validate_episode_blocking_review(self.shot, self.nodes)

    def test_complete_evidence_passes(self):
        self.check()

    def test_missing_report_blocks(self):
        self.shot.pop('episode_blocking_review_file')
        with self.assertRaises(PipelineError): self.check()

    def test_missing_other_segment_image_blocks_subset(self):
        self.report['segments'][0]['viewed'] = False
        self.write_report()
        with self.assertRaises(PipelineError): self.check()

    def test_incomplete_coverage_blocks(self):
        self.report['segments'].pop()
        self.write_report()
        with self.assertRaises(PipelineError): self.check()

    def test_shrinking_report_to_subset_cannot_bypass_plan(self):
        self.report['expected_segment_ids'] = ['EP03_03']
        self.report['segments'] = [self.report['segments'][2]]
        self.write_report()
        with self.assertRaises(PipelineError): self.check()

    def test_actual_upstream_replacement_in_another_segment_blocks(self):
        self.nodes['image-0']['defaultAsset']['assetsUuid'] = 'replacement'
        with self.assertRaises(PipelineError): self.check()

    def test_image_bytes_change_blocks(self):
        Path(self.report['segments'][0]['opening_image_file']).write_bytes(b'changed')
        with self.assertRaises(PipelineError): self.check()

    def test_prompt_change_in_another_segment_blocks(self):
        Path(self.report['segments'][0]['source_prompt_file']).write_text('changed', encoding='utf8')
        with self.assertRaises(PipelineError): self.check()

    def test_background_projection_unreviewed_blocks(self):
        self.report['projection_review']['status'] = 'UNCERTAIN'
        self.write_report()
        with self.assertRaises(PipelineError): self.check()

    def test_wrong_segment_image_blocks(self):
        self.shot['bindings'][0]['node_uuid'] = 'image-0'
        self.shot['prevNodeUuids'] = ['image-0']
        with self.assertRaises(PipelineError): self.check()

    def test_shared_image_between_segments_blocks(self):
        self.report['segments'][1]['opening_node_uuid'] = 'image-0'
        self.report['segments'][1]['opening_asset_uuid'] = 'asset-0'
        self.write_report()
        with self.assertRaises(PipelineError): self.check()

    def test_unlabelled_25_30s_is_still_checked(self):
        self.shot.pop('prompt_role')
        self.shot.pop('episode_blocking_review_file')
        with self.assertRaises(PipelineError): self.check()

    def test_legacy_15s_not_retroactively_blocked(self):
        self.shot['prompt_role'] = 'original_15s'
        self.shot['params'].update(model='PIXDANCE_2_FAST', duration=15)
        self.shot.pop('episode_blocking_review_file')
        self.check()

    def test_binding_preserves_episode_evidence_and_narrative(self):
        from fast_bind import compile_batch
        prompt = '## 1. 人物指定\n**Seren：** 站在Alaric身后。\n## 2. 场景指定\n**Courtyard：** 台阶下平地。\n## 3. 道具指定\n本段无剧情道具。\n## 4. 时间线镜头设计\nSeren绕过Alaric靠展示台一侧，再转身面对Alaric。'
        path = self.root/'binding.md'
        path.write_text(prompt, encoding='utf8')
        nodes = [{'uuid': node, 'type':'BASE_IMAGE','label': node,
                  'defaultAsset':{'assetsUuid':asset}}
                 for node,asset in [('person','person-asset'),('scene','scene-asset'),('image-2','asset-2')]]
        fields = {key:self.shot[key] for key in (
            'episode_segment_id','episode_blocking_review_file','episode_blocking_review_sha256')}
        plan = {'file_uuid':'canvas','shots':[dict(
            id='EP03_03',label='EP03_03',prompt_role='seedance25_30s',prompt_file=str(path),
            max_image_inputs=30,supported_durations=[30],
            bindings=[{'category':'blocking_reference','node_uuid':'image-2'},
                      {'category':'character','node_uuid':'person','designation':'Seren'},
                      {'category':'scene','node_uuid':'scene','designation':'Courtyard'}],
            params={'nodeType':'GENERATE_VIDEO','model':'PIXDANCE_2_5_DRAFT','duration':30,
                    'count':1,'referModel':'referToVideo'},**fields)]}
        manifest,_ = compile_batch(plan,nodes)
        result = manifest['shots'][0]
        self.assertEqual({key:result[key] for key in fields},fields)
        self.assertEqual(result['params']['prompt'].split('## 4.')[1], path.read_bytes().decode('utf8').split('## 4.')[1])
        self.assertNotIn('(image-2)',result['params']['prompt'])
        self.assertEqual(result['prevNodeUuids'][0],'image-2')

    def test_new_submission_stops_before_generation_when_review_missing(self):
        self.shot.pop('episode_blocking_review_file')
        calls = []
        def api(*args):
            calls.append(args)
            if args[:2] == ('tasks','progress'): return {'data': []}
            if args[:2] == ('canvas','nodes'): return list(self.nodes.values())
            raise AssertionError('Unexpected mutation/API: '+str(args))
        with patch.object(runner, 'preflight', return_value=(['video'], [])), \
             patch.object(runner, 'visual_review_errors', return_value=[]):
            with self.assertRaises(PipelineError):
                runner.run({'file_uuid':'canvas','shots':[self.shot]}, self.root/'submission', submit=True, api=api)
        self.assertTrue(all(call[:2] in [('tasks','progress'),('canvas','nodes')] for call in calls))

    def test_read_only_plan_reports_only_reviewed_generation_ready(self):
        self.report['segments'][0]['viewed'] = False
        self.write_report()
        def api(*args):
            if args[:2] == ('tasks','progress'): return {'data': []}
            if args[:2] == ('canvas','nodes'): return list(self.nodes.values())
            raise AssertionError(args)
        with patch.object(runner,'preflight',return_value=(['video'], [])), \
             patch.object(runner,'visual_review_errors',return_value=[]):
            result = runner.run({'file_uuid':'canvas','shots':[self.shot]},self.root/'plan',api=api)
        self.assertEqual(result['generation_ready'], [])
        self.assertEqual(len(result['blocking_review_pending']), 1)


if __name__ == '__main__':
    unittest.main()
