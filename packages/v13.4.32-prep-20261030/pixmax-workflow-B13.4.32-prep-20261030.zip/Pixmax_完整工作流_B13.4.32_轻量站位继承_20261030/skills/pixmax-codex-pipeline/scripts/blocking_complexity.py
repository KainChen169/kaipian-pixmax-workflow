"""Classify reviewed scene blocking; this does not inspect pixels or infer cast."""
def assess_complexity(run):
    a=run.get('blocking_complexity_assessment')
    if not isinstance(a,dict) or a.get('policy')!='blocking_complexity_v1':
        raise ValueError('requires blocking_complexity_v1 scene assessment')
    ids=run.get('segment_ids')
    if a.get('scene_segment_ids')!=ids or not isinstance(ids,list) or not ids or len(set(ids))!=len(ids):
        raise ValueError('complexity assessment must cover the entire scene run')
    cast=a.get('scene_cast')
    if not isinstance(cast,list) or not cast or any(not isinstance(x,str) or not x.strip() for x in cast) or len(set(cast))!=len(cast):
        raise ValueError('requires complete unique independently staged scene cast')
    if not isinstance(a.get('basis'),str) or not a['basis'].strip():
        raise ValueError('requires concrete script/blocking basis')
    movement=a.get('movement_kind')
    if movement not in ('none','local','reorganized'):raise ValueError('invalid movement kind')
    groups=a.get('spatial_phase_groups')
    if not isinstance(groups,list) or not groups:raise ValueError('requires spatial phase groups')
    covered=[];signatures=[]
    for g in groups:
        if not isinstance(g,dict) or not isinstance(g.get('segment_ids'),list) or not g['segment_ids'] or not isinstance(g.get('spatial_signature'),dict) or not g['spatial_signature']:
            raise ValueError('invalid spatial phase group')
        covered+=g['segment_ids'];signatures.append(g['spatial_signature'])
    if covered!=ids:raise ValueError('spatial phases must cover every scene segment once in order')
    opening_cast=a.get('opening_cast_by_segment')
    if len(ids)>1 and len(cast)>2 and opening_cast is None:
        raise ValueError('image-required scenes must declare opening cast for every segment; missing cast cannot bypass the new-actor gate')
    if opening_cast is not None:
        if not isinstance(opening_cast,dict) or set(opening_cast)!=set(ids):
            raise ValueError('opening cast must cover all scene segments')
        for sid,visible in opening_cast.items():
            if not isinstance(visible,list) or not visible or len(set(visible))!=len(visible) or any(x not in cast for x in visible):
                raise ValueError('invalid opening cast: '+sid)
        for g in groups:
            base=set(opening_cast[g['segment_ids'][0]])
            if any(set(opening_cast[sid])!=base for sid in g['segment_ids']):
                raise ValueError('new or departed actor requires a distinct spatial reference phase')
    exempt=len(ids)==1 or len(cast)<=2
    if exempt:level=0;images=0;reason='single_segment' if len(ids)==1 else 'one_or_two_characters'
    elif movement=='reorganized' or len(groups)>1:level=3;images=len(groups);reason='spatial_reorganization'
    else:level=1 if movement=='none' else 2;images=1;reason='stable_relationships'
    if a.get('level')!=level:raise ValueError('declared complexity level contradicts scene cast/movement/groups')
    if level in (1,2) and len(groups)!=1:raise ValueError('stable or local movement must use one spatial group')
    if any(signatures[i]==signatures[j] for i in range(len(signatures)) for j in range(i)):
        raise ValueError('identical spatial groups should be merged instead of creating duplicate images')
    return {'level':level,'image_required':not exempt,'planned_unique_images':images,'reason':reason,'actor_count':len(cast)}
