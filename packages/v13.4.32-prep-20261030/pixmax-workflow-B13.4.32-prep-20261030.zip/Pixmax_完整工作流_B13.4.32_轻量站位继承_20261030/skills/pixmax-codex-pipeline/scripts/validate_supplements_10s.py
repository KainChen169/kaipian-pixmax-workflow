"""Check selected 10-second, four-shot close-up supplements against source prompts.

This is a structural check. Shot continuity, action logic, and visual quality still
need a director's review. The script never submits a generation task.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path

from pixmax_pipeline import PipelineError, atomic_json

SOURCE = re.compile(r"^# 第(\d+)集｜镜头(\d+)｜[^\n]*15秒完整视频执行提示词\s*$", re.M)
SHOT = re.compile(r"^### 镜头(\d+)｜(\d+(?:\.\d+)?)—(\d+(?:\.\d+)?)秒｜([^\n]+)$", re.M)
ID = re.compile(r"EP(\d{2})_S(\d{3})$")


def _read(base: Path, value: str) -> str:
    path = Path(value)
    if not path.is_absolute():
        path = base / path
    return path.read_text(encoding="utf-8-sig")


def _sha(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def validate(index: dict, base: Path) -> dict:
    episodes = index.get("episode_prompt_files")
    entries = index.get("shots")
    if not isinstance(episodes, list) or not episodes or not isinstance(entries, list) or not entries:
        raise PipelineError("episode_prompt_files and selected shots are required")

    available: set[str] = set()
    episode_ids: set[str] = set()
    for filename in episodes:
        headings = SOURCE.findall(_read(base, filename))
        if not headings:
            raise PipelineError("No 15-second source prompt in " + filename)
        for ep, number in headings:
            sid = f"EP{int(ep):02d}_S{int(number):03d}"
            if sid in available:
                raise PipelineError("Duplicate source prompt " + sid)
            available.add(sid)
            episode_ids.add(sid[:4])

    seen: set[str] = set()
    checks: list[dict] = []
    per_episode: dict[str, int] = {}
    for entry in entries:
        sid = entry.get("id", "")
        if not ID.fullmatch(sid) or sid in seen or sid not in available:
            raise PipelineError("Invalid, duplicate, or unknown source ID " + sid)
        seen.add(sid)
        per_episode[sid[:4]] = per_episode.get(sid[:4], 0) + 1
        original = _read(base, entry["source"])
        supplement = _read(base, entry["supplement"])
        if sid not in {f"EP{int(ep):02d}_S{int(num):03d}" for ep, num in SOURCE.findall(original)}:
            raise PipelineError(sid + ": source file contains a different shot")
        source_hash = _sha(original)
        if source_hash != entry.get("source_sha256"):
            raise PipelineError(sid + ": source changed; review supplement")
        if not re.search(r"^# .+10秒[^\n]*提示词\s*$", supplement, re.M):
            raise PipelineError(sid + ": missing 10-second supplement title")
        for heading, value in (("源镜头", sid), ("时间锚点", None), ("开场站位", None), ("避免重复", None)):
            pattern = rf"^\*\*{heading}：\*\*\s*{re.escape(value) if value else r'\S+'}"
            if not re.search(pattern, supplement, re.M):
                raise PipelineError(sid + ": missing or wrong " + heading)
        shots = list(SHOT.finditer(supplement))
        if len(shots) != 4 or [int(m[1]) for m in shots] != [1, 2, 3, 4]:
            raise PipelineError(sid + ": exactly four numbered shots required")
        if abs(float(shots[0][2])) > 1e-3 or abs(float(shots[-1][3]) - 10.0) > 1e-3:
            raise PipelineError(sid + ": timeline must cover 0.0–10.0 seconds")
        for current, following in zip(shots, shots[1:]):
            if float(current[3]) <= float(current[2]) or abs(float(current[3]) - float(following[2])) > 1e-3:
                raise PipelineError(sid + ": timeline has a gap, overlap, or empty shot")
        if float(shots[-1][3]) <= float(shots[-1][2]):
            raise PipelineError(sid + ": final shot is empty")
        if "全景" not in shots[0][4] or "特写" in shots[0][4]:
            raise PipelineError(sid + ": first shot must be a wide establishing shot")
        if any("特写" not in m[4] or "全景" in m[4] for m in shots[1:]):
            raise PipelineError(sid + ": shots 2–4 must all be close-ups")
        old_titles = set(re.findall(r"^### 镜头\d+｜[^\n]+", original, re.M))
        if any(m[0] in old_titles for m in shots):
            raise PipelineError(sid + ": repeated original shot title")
        checks.append({"id": sid, "source_sha256": source_hash,
                       "supplement_sha256": _sha(supplement), "structure": "PASS",
                       "continuity_and_action_review": "REQUIRES_CODEX_REVIEW"})

    exceptions = index.get("episode_exceptions", {})
    for episode in episode_ids:
        count = per_episode.get(episode, 0)
        if count not in (3, 4):
            reason = exceptions.get(episode) if isinstance(exceptions, dict) else None
            if not (1 <= count < 3 and isinstance(reason, str) and reason.strip()):
                raise PipelineError(f"{episode}: select 3–4 distinct source shots, or record a reason for fewer")
    return {"selected": len(checks), "episodes": per_episode, "shots": checks,
            "structural_check": "PASS", "semantic_and_visual_review": "REQUIRES_CODEX_REVIEW"}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--index", type=Path, required=True)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = validate(json.loads(args.index.read_text(encoding="utf-8-sig")), args.index.parent)
    if args.output:
        atomic_json(args.output, result)
    print(json.dumps(result, ensure_ascii=False, indent=2))
