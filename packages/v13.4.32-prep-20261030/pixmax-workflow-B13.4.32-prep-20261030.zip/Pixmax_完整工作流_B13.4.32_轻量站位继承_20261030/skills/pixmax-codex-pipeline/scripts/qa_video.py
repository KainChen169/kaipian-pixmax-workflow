"""Decode and sample a local video; no generation and no dialogue verification."""
import argparse
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
from pixmax_pipeline import atomic_json, sha256

def executable():
    found=os.environ.get('FFMPEG_BINARY') or shutil.which('ffmpeg')
    if found: return found
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except ImportError: raise RuntimeError('Install FFmpeg or python -m pip install imageio-ffmpeg')

def inspect(video, output, width=720, height=1280, seconds=15, require_audio=True):
    video=Path(video).resolve(); output=Path(output); output.mkdir(parents=True,exist_ok=True)
    ff=executable()
    cmd=[ff,'-hide_banner','-nostdin','-i',str(video)]
    if require_audio: cmd+=['-af','volumedetect']
    proc=subprocess.run(cmd+['-f','null','-'],capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=300)
    (output/'decode.log').write_text(proc.stderr,encoding='utf-8')
    d=re.search(r'Duration: (\d+):(\d+):(\d+(?:\.\d+)?)',proc.stderr)
    duration=int(d[1])*3600+int(d[2])*60+float(d[3]) if d else None
    line=next((l for l in proc.stderr.splitlines() if 'Video:' in l),'')
    volume=re.search(r'max_volume: ([-\w.]+) dB',proc.stderr)
    checks={'decode':proc.returncode==0,'size':bool(re.search(r'\b'+str(width)+'x'+str(height)+r'\b',line)),
            'duration':duration is not None and abs(duration-seconds)<=0.6,
            'audio':not require_audio or ('Audio:' in proc.stderr and bool(volume) and volume[1]!='-inf')}
    frames=[]
    if proc.returncode==0 and duration:
        for i,fraction in enumerate([0.05,0.35,0.65,0.95],1):
            out=output/f'frame-{i}.png'
            r=subprocess.run([ff,'-hide_banner','-loglevel','error','-nostdin','-ss',str(duration*fraction),'-i',str(video),'-vf','scale=360:-2','-frames:v','1','-y',str(out)],capture_output=True,timeout=60)
            if r.returncode==0 and out.exists():frames.append(out.name)
    checks['four_samples']=len(frames)==4
    result={'sha256':sha256(video),'duration_seconds':duration,'checks':checks,'technical_qa':'PASS' if all(checks.values()) else 'FAIL','frames':frames,'visual_qa':'PENDING','dialogue_verified':False}
    atomic_json(output/'qa.json',result); return result

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('video',type=Path);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--width',type=int,default=720);p.add_argument('--height',type=int,default=1280);p.add_argument('--seconds',type=float,default=15);p.add_argument('--no-audio-required',action='store_true')
    a=p.parse_args();result=inspect(a.video,a.output,a.width,a.height,a.seconds,not a.no_audio_required)
    print(json.dumps(result,ensure_ascii=False,indent=2)); raise SystemExit(0 if result['technical_qa']=='PASS' else 2)
