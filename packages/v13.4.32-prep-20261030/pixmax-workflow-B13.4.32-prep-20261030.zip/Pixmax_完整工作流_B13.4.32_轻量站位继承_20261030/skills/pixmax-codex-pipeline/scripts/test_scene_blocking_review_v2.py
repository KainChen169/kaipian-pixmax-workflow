"""Synthetic evidence-only tests; fixtures never constitute visual approval."""
import json,unittest
from pathlib import Path
from test_episode_blocking_review import BlockingReviewTests
from episode_blocking_review import validate_episode_blocking_review
from pixmax_pipeline import PipelineError

class SceneV2Tests(unittest.TestCase):
    def setUp(self):
        base=BlockingReviewTests();base.setUp();self.addCleanup(base.temp.cleanup)
        self.root=base.root;self.file=base.file;self.plan=base.plan;self.report=base.report;self.shot=base.shot;self.nodes=base.nodes
        self.report['policy']='seedance25_opening_blocking_v2'
        self.plan['scene_runs']=[{'key':'scene-A','segment_ids':['EP03_01','EP03_02']},{'key':'scene-B','segment_ids':['EP03_03']},{'key':'scene-C','segment_ids':['EP03_04']}]
        for i,(p,r) in enumerate(zip(self.plan['segments'],self.report['segments'])):
            key='scene-A' if i<2 else 'scene-'+('B' if i==2 else 'C')
            p['scene_run_key']=r['scene_run_key']=key
            r['reference_mode']='MASTER' if i==0 else 'DERIVED' if i==1 else 'NOT_REQUIRED_SINGLE_SEGMENT_SCENE'
            if i<2:
                r.update(aspect_ratio='16:9',resolution='1K')
                self.nodes[r['opening_node_uuid']].update(type='GENERATE_IMAGE',params={'aspectRatio':'16:9','resolution':'1K'},prevNodeUuids=['asset-person','asset-scene'] if i==0 else ['image-0'])
            else:
                for k in list(r):
                    if k.startswith('opening_') and k!='opening_match_observation':del r[k]
        m=self.report['segments'][0]
        self.report['scene_masters']=[{k:m[k] for k in ('id','scene_run_key','opening_node_uuid','opening_asset_uuid','opening_image_file','opening_image_sha256','viewed','status','camera_look')}]
        self.report['segments'][1].update(scene_master_id=m['id'],scene_master_node_uuid=m['opening_node_uuid'],scene_master_asset_uuid=m['opening_asset_uuid'],scene_master_image_sha256=m['opening_image_sha256'])
        self.shot.update(bindings=[],prevNodeUuids=[])
        self.flush()
    def flush(self):
        self.report.update(self.file('plan.json',json.dumps(self.plan),'blocking_plan_file','blocking_plan_sha256'))
        self.shot.update(self.file('review.json',json.dumps(self.report),'episode_blocking_review_file','episode_blocking_review_sha256'))
    def check(self):validate_episode_blocking_review(self.shot,self.nodes)
    def select(self,i):
        r=self.report['segments'][i]
        self.shot.update(episode_segment_id=r['id'],source_prompt_file=r['source_prompt_file'],source_sha256=r['source_sha256'],bindings=[{'category':'blocking_reference','node_uuid':r['opening_node_uuid']}],prevNodeUuids=[r['opening_node_uuid']])
    def test_single_scene_exempt_but_whole_episode_reviewed(self):self.check()
    def test_master_and_direct_derivative_with_horizontal_image_vertical_video(self):
        self.select(0);self.check();self.select(1);self.check()
    def test_derivative_extra_character_input_rejected(self):
        self.nodes['image-1']['prevNodeUuids'].append('asset-person')
        with self.assertRaises(PipelineError):self.check()
    def test_stale_mother_asset_rejected(self):
        self.nodes['image-0']['defaultAsset']['assetsUuid']='new-asset'
        with self.assertRaises(PipelineError):self.check()
    def test_multi_segment_cannot_claim_single_exemption(self):
        self.report['segments'][1]['reference_mode']='NOT_REQUIRED_SINGLE_SEGMENT_SCENE';self.flush()
        with self.assertRaises(PipelineError):self.check()
    def test_derivative_old_mother_hash_rejected(self):
        self.report['segments'][1]['scene_master_image_sha256']='old';self.flush()
        with self.assertRaises(PipelineError):self.check()
    def test_unviewed_mother_blocks(self):
        self.report['scene_masters'][0]['viewed']=False;self.flush()
        with self.assertRaises(PipelineError):self.check()
    def test_2k_node_rejected(self):
        self.nodes['image-1']['params']['resolution']='2K'
        with self.assertRaises(PipelineError):self.check()
    def test_exempt_segment_with_blocking_input_rejected(self):
        self.shot['bindings']=[{'category':'blocking_reference','node_uuid':'image-0'}];self.shot['prevNodeUuids']=['image-0']
        with self.assertRaises(PipelineError):self.check()
    def test_blocking_at_token_rejected(self):
        self.select(1);self.shot['params']['prompt']='%%@[opening][image][0](image-1)%%'
        with self.assertRaises(PipelineError):self.check()
    def test_new_mother_input_does_not_allow_prior_derivative(self):
        self.nodes['image-1']['prevNodeUuids']=['image-prior']
        with self.assertRaises(PipelineError):self.check()

if __name__=='__main__':unittest.main()
