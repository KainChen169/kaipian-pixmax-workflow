"""One read/download pass over accepted tasks. Never starts generation."""
import argparse
import hashlib
import json
import re
from pathlib import Path
from pixmax_pipeline import atomic_json, PipelineError, sha256
from submit_saved_batch import call

def collect(manifest, submission, output, version='v01', api=call):
    if not re.fullmatch(r'[A-Za-z0-9_-]{1,50}',version): raise PipelineError('Unsafe version')
    output=Path(output).resolve(); output.mkdir(parents=True,exist_ok=True)
    if submission.get('file_uuid')!=manifest['file_uuid']: raise PipelineError('Canvas mismatch')
    expected={t['nodeUuid']:t['taskUuid'] for t in submission.get('tasks',[]) if t.get('taskUuid')}
    shots=manifest['shots']; ids=[s['node_uuid'] for s in shots]
    if len(set(ids))!=len(ids) or len({s['id'] for s in shots})!=len(shots): raise PipelineError('Duplicate IDs')
    if set(expected)-set(ids): raise PipelineError('Submission contains nodes outside manifest')
    for s in shots:
        if not re.fullmatch(r'EP\d+_S\d+(?:_[A-Za-z0-9_-]+)?',s['id']): raise PipelineError('Use EP01_S001 style IDs')
    identity=hashlib.sha256(json.dumps({'file':manifest['file_uuid'],'tasks':expected,'version':version},sort_keys=True).encode()).hexdigest()[:16]
    record=output/'执行记录'/('download-'+identity+'.json')
    old=json.loads(record.read_text(encoding='utf-8')) if record.exists() else {}
    tasks=api('tasks','progress',*ids).get('data',[])
    observed={t['nodeUuid']:t for t in tasks if t.get('taskUuid')}
    nodes={n['uuid']:n for n in api('canvas','nodes','--file',manifest['file_uuid'])}
    rows={}
    for s in shots:
        uid=s['node_uuid']; tid=expected.get(uid); prior=old.get(s['id'],{})
        row={'id':s['id'],'node_uuid':uid,'task_uuid':tid,'status':'NOT_ACCEPTED'}
        if prior.get('download') in ('DOWNLOADED','VERIFIED') and prior.get('task_uuid')==tid:
            p=output/prior['relative_path']
            if prior['download']=='DOWNLOADED' and not p.exists():
                partial=p.with_suffix('.partial.mp4')
                if partial.is_file() and sha256(partial)==prior['sha256']:
                    partial.rename(p)
            if not p.is_file() or sha256(p)!=prior['sha256']: raise PipelineError('Existing file missing or changed: '+str(p))
            prior.update(download='VERIFIED',technical_qa=prior.get('technical_qa','PENDING'),visual_qa=prior.get('visual_qa','PENDING'))
            rows[s['id']]=prior; continue
        if tid:
            n=nodes.get(uid,{})
            if n.get('taskUuid')!=tid: row['status']='NEED_HISTORY_LOOKUP'
            else:
                task=observed.get(uid,{})
                if task and task.get('taskUuid')!=tid: raise PipelineError('Observed task changed')
                # Empty historical progress is unknown, never permission to resubmit.
                row['status']=task.get('status','UNKNOWN')
                row['error']=task.get('replaceProviderErrorMsg') or task.get('providerErrorMsg')
                if row['status']=='COMPLETE':
                    asset=n.get('defaultAsset') or {}
                    if not asset.get('assetsUuid') or asset.get('extension','mp4').lower().lstrip('.')!='mp4':
                        raise PipelineError('No verified MP4 asset: '+s['id'])
                    ep=int(s.get('episode') or re.match(r'EP(\d+)',s['id'])[1])
                    relative=Path(f'EP{ep:02d}')/'视频'/f"{s['id']}_{version}.mp4"
                    final=output/relative; final.parent.mkdir(parents=True,exist_ok=True)
                    if final.exists(): raise PipelineError('Untracked target exists; reconcile before overwrite: '+str(final))
                    partial=final.with_suffix('.partial.mp4')
                    if partial.exists(): raise PipelineError('Partial download exists; inspect/recover before retry: '+str(partial))
                    api('assets','download',asset['assetsUuid'],'--output',str(partial),'--kind','web')
                    if not partial.is_file(): raise PipelineError('Download produced no file')
                    with partial.open('rb') as f: header=f.read(32)
                    if b'ftyp' not in header or partial.stat().st_size<100: raise PipelineError('Invalid MP4 header')
                    # Checkpoint before rename permits a crash to be reconciled explicitly.
                    row.update(download='DOWNLOADED',relative_path=relative.as_posix(),asset_uuid=asset['assetsUuid'],sha256=sha256(partial))
                    rows[s['id']]=row; atomic_json(record,{**old,**rows})
                    partial.rename(final)
                    row.update(download='VERIFIED',technical_qa='PENDING',visual_qa='PENDING')
        rows[s['id']]=row; atomic_json(record,{**old,**rows})
    atomic_json(record,rows)
    return {'record':str(record),'shots':rows,'generation_submitted':False}

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--manifest',type=Path,required=True);p.add_argument('--submission',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--version',default='v01')
    a=p.parse_args()
    print(json.dumps(collect(json.loads(a.manifest.read_text(encoding='utf-8-sig')),json.loads(a.submission.read_text(encoding='utf-8-sig')),a.output,a.version),ensure_ascii=False,indent=2))
