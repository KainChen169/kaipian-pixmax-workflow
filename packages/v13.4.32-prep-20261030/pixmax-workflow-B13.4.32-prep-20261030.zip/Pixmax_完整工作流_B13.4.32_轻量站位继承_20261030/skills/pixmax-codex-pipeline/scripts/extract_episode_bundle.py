#!/usr/bin/env python3
"""Split one episode MD into locked 15s video prompts and 6-panel image prompts."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path


START = "<!-- PIXMAX_SIX_PANEL_APPENDIX_START -->"
END = "<!-- PIXMAX_SIX_PANEL_APPENDIX_END -->"
VIDEO_TITLE = re.compile(
    r"(?m)^# 第(?P<episode>\d+)集｜镜头(?P<shot>\d+)｜[^\r\n]+｜15秒完整视频执行提示词\r?$"
)
BOARD_PREFACE = re.compile(
    r"(?m)^\*\*六宫格首帧引用：\*\*[^\r\n]*\r?\n\r?\n(?=# 第\d+集｜镜头\d+)"
)
IMAGE_TITLE = re.compile(r"(?m)^## 镜头(?P<shot>\d+)｜六宫格英文提示词\r?$")
FENCE = re.compile(r"\A\s*```text\r?\n(?P<prompt>.*?)\r?\n```\s*\Z", re.S)
ASSET_TOKEN = re.compile(r"%%@\[[^\]]+\]\[image\]\[\d+\]\([^)]+\)%%")


class BundleError(ValueError):
    pass


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def chinese_count(value: str) -> int:
    return len(re.findall(r"[\u3400-\u9fff]", value))


def line_value(prompt: str, label: str) -> str:
    match = re.search(rf"(?mi)^{re.escape(label)}:[ \t]*(\S[^\r\n]*)\r?$", prompt)
    if not match:
        raise BundleError(f"英文六宫格提示词缺少非空 {label}: 行")
    return match.group(1).strip()


def required_video_field(video: str, label: str) -> str:
    match = re.search(
        rf"(?ms)^\*\*{re.escape(label)}：\*\*\s*(.*?)(?=^\*\*[^*\r\n]+：\*\*|^##\s|\Z)",
        video,
    )
    if not match or not match.group(1).strip():
        raise BundleError(f"视频正文缺少 {label}")
    return match.group(1).strip()


def parse_bundle(source: Path) -> dict:
    raw = source.read_bytes()
    try:
        body = raw.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise BundleError(f"分集文件不是 UTF-8：{exc}") from exc
    if body.startswith("\ufeff"):
        raise BundleError("分集文件含 UTF-8 BOM；请保存为无 BOM UTF-8 后重新审核源哈希")
    if body.count(START) != 1 or body.count(END) != 1:
        raise BundleError("文件末尾必须且只允许一对六宫格附录起止标记")
    start = re.search(rf"(?m)^{re.escape(START)}\r?$", body)
    end = re.search(rf"(?m)^{re.escape(END)}\r?$", body)
    if not start or not end or start.end() >= end.start() or body[end.end():].strip():
        raise BundleError("六宫格附录边界无效，结束标记后不得有正文")
    video_part = body[: start.start()]
    image_part = body[start.end(): end.start()]

    video_matches = list(VIDEO_TITLE.finditer(video_part))
    prefaces = list(BOARD_PREFACE.finditer(video_part))
    starts = []
    for index, match in enumerate(video_matches):
        previous_title_end = video_matches[index - 1].end() if index else 0
        candidates = [p for p in prefaces if previous_title_end <= p.start() < match.start()
                      and p.end() == match.start()]
        if len(candidates) > 1:
            raise BundleError("视频标题前六宫格首帧引用段重复")
        starts.append(candidates[0].start() if candidates else match.start())
    if not video_matches or video_part[: starts[0]].strip():
        raise BundleError("文件须从第一段正式15秒视频标题或其六宫格首帧引用段开始")
    videos: dict[int, str] = {}
    episode = None
    for index, match in enumerate(video_matches):
        current_episode = int(match.group("episode"))
        shot = int(match.group("shot"))
        if episode is None:
            episode = current_episode
        if current_episode != episode or shot in videos:
            raise BundleError("正式视频集号必须相同且镜号不得重复")
        stop = starts[index + 1] if index + 1 < len(video_matches) else len(video_part)
        block = video_part[starts[index]:stop]
        if len(re.findall(r"(?m)^### 镜头\d+｜", block)) != 6:
            raise BundleError(f"镜头{shot:02d}不是六个子镜头")
        videos[shot] = block
    if list(videos) != sorted(videos):
        raise BundleError("正式视频镜号须按升序排列")

    header = re.match(r"\s*# 第(?P<episode>\d+)集｜六宫格分镜参考图英文提示词\r?\n", image_part)
    if not header or int(header.group("episode")) != episode:
        raise BundleError("英文附录标题集号与视频集号不一致")
    image_matches = list(IMAGE_TITLE.finditer(image_part))
    if not image_matches or image_part[header.end():image_matches[0].start()].strip():
        raise BundleError("英文附录须在标题之后直接按镜号列出六宫格条目")
    images: dict[int, str] = {}
    for index, match in enumerate(image_matches):
        shot = int(match.group("shot"))
        if shot in images:
            raise BundleError(f"六宫格镜头{shot:02d}重复")
        stop = image_matches[index + 1].start() if index + 1 < len(image_matches) else len(image_part)
        fenced = FENCE.fullmatch(image_part[match.end():stop])
        if not fenced:
            raise BundleError(f"六宫格镜头{shot:02d}必须只有一个 text 代码块")
        prompt = fenced.group("prompt")
        people = line_value(prompt, "CHARACTER REFERENCES")
        scene = line_value(prompt, "SCENE REFERENCE")
        line_value(prompt, "GLOBAL LOCK")
        panels = [int(value) for value in re.findall(r"(?mi)^.*?\bPANEL\s+(\d+)\s*:", prompt)]
        if panels != [1, 2, 3, 4, 5, 6]:
            raise BundleError(f"六宫格镜头{shot:02d}须依次且仅含 PANEL 1—6，实际{panels}")
        if re.search(r"\[(?:exact|same fields|single frozen|shot \d|complete independent)", prompt, re.I):
            raise BundleError(f"六宫格镜头{shot:02d}仍含模板占位符")
        images[shot] = prompt
        video = videos.get(shot)
        if video is not None:
            character_lines = required_video_field(video, "人物指定").splitlines()
            names = [ASSET_TOKEN.sub("", line.split("｜状态：", 1)[0]).strip(" -*\t")
                     for line in character_lines if line.strip()]
            missing = [name for name in names if name not in people]
            if missing:
                raise BundleError(f"六宫格镜头{shot:02d}人物指定缺少视频角色：{missing}")
            scene_name = ASSET_TOKEN.sub("", required_video_field(video, "场景指定").splitlines()[0]).strip()
            if scene_name not in scene:
                raise BundleError(f"六宫格镜头{shot:02d}场景指定缺少标准名：{scene_name}")
            if not re.search(r"\b(?:day|night)\b", scene, re.I):
                raise BundleError(f"六宫格镜头{shot:02d}场景指定须写 day 或 night")
    if set(videos) != set(images):
        raise BundleError(f"视频镜号{sorted(videos)}与六宫格镜号{sorted(images)}不一致")
    if list(images) != sorted(images):
        raise BundleError("英文六宫格条目须按镜号升序排列")

    records = []
    warnings = []
    for shot, video in videos.items():
        length = chinese_count(video)
        if not 1300 <= length <= 1700:
            warnings.append(f"镜头{shot:02d}中文视频正文约{length}汉字，偏离1500字目标；复核必要信息与冗余")
        records.append({
            "shot": shot,
            "video_sha256": digest(video.encode("utf-8")),
            "storyboard_sha256": digest(images[shot].encode("utf-8")),
            "video_chinese_characters": length,
            "video_text": video,
            "storyboard_text": images[shot],
        })
    return {"source": str(source.resolve()), "source_sha256": digest(raw), "episode": episode,
            "records": records, "warnings": warnings}


def write_bundle(parsed: dict, output: Path) -> dict:
    output.mkdir(parents=True, exist_ok=True)
    public = {key: value for key, value in parsed.items() if key != "records"}
    public["records"] = []
    candidates: list[tuple[Path, bytes]] = []
    for item in parsed["records"]:
        shot = item["shot"]
        files = ((output / f"镜头{shot:02d}_视频.md", item["video_text"].encode("utf-8")),
                 (output / f"镜头{shot:02d}_六宫格.txt", item["storyboard_text"].encode("utf-8")))
        candidates.extend(files)
        public["records"].append({key: value for key, value in item.items() if not key.endswith("_text")} |
                                 {"video_file": str(files[0][0].resolve()), "storyboard_file": str(files[1][0].resolve())})
    manifest = output / "episode_bundle_manifest.json"
    encoded = (json.dumps(public, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    candidates.append((manifest, encoded))
    for path, data in candidates:
        if path.exists() and path.read_bytes() != data:
            raise BundleError(f"已有提取文件内容不同，停止覆盖：{path}")
    for path, data in candidates:
        if not path.exists():
            path.write_bytes(data)
    return public


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("episode_file", type=Path)
    parser.add_argument("--output", type=Path, help="Save derived per-shot files and a hash manifest here")
    args = parser.parse_args(argv)
    try:
        parsed = parse_bundle(args.episode_file)
        result = write_bundle(parsed, args.output) if args.output else {
            **{key: value for key, value in parsed.items() if key != "records"},
            "records": [{key: value for key, value in item.items() if not key.endswith("_text")}
                        for item in parsed["records"]],
        }
    except (OSError, BundleError) as exc:
        print(str(exc), file=sys.stderr)
        return 1
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
