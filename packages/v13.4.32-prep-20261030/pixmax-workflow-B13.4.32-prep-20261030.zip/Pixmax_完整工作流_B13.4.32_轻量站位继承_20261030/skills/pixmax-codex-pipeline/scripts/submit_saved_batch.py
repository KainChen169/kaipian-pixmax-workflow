"""Plan/submit an exact group of already saved nodes. Never creates nodes.

Default mode is read-only plan. --submit requires authorization for this batch.
Ambiguous submissions are reconciled, never automatically submitted a second time.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
import re
import subprocess
from pathlib import Path
from datetime import datetime, timezone
from pixmax_pipeline import cli_command, atomic_json, PipelineError
from asset_visual_review import visual_review_errors
from black_video_reference import expected_order

TOKEN = re.compile(r'%%@\[([^\]]+)\]\[(image|video|audio|text)\]\[(\d+)\]\(([^)]+)\)%%')
ACTIVE = {'QUEUE', 'WAITING_CONCURRENCY', 'RUNNING', 'COMPLETE'}

def call(*args):
    command = json.loads(os.environ['PIXMAX_CLI_COMMAND_JSON']) if os.environ.get('PIXMAX_CLI_COMMAND_JSON') else cli_command()
    if not isinstance(command, list) or not command or any(not isinstance(x, str) for x in command):
        raise PipelineError('PIXMAX_CLI_COMMAND_JSON must be a command array')
    result = subprocess.run([*command, '--json', *map(str, args)], capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=120)
    if result.returncode:
        raise PipelineError('CLI failed: '+ ' '.join(args[:2]) + '; inspect task status before retry')
    value = json.loads(result.stdout)
    if isinstance(value, dict) and (value.get('success') is False or value.get('error')):
        raise PipelineError('CLI operation failed: '+ ' '.join(args[:2]))
    return value

def canonical(value):
    if isinstance(value, bool): return str(value).lower()
    return str(value)

from seedance25_contract import ROLE as V134_ROLE, DEFAULT_VIDEO_MODEL, validate_input_order, validate_duration, validate_video_spec
from shot_body_mentions import POLICY as BODY_POLICY, LEGACY as LEGACY_POLICY
from project_style import ANIMATION_ROLE, validate_route
from animation_contract import (validate_source as validate_animation_source,
    validate_duration as validate_animation_duration, validate_staging as validate_animation_staging)

def validate_shot(expected, actual):
    validate_route(expected, required=expected.get('prompt_role') == ANIMATION_ROLE)
    uid = expected['node_uuid']
    if actual['uuid'] != uid: raise PipelineError('Node UUID mismatch')
    ep, ap = expected['params'], actual['params']
    if ep.get('nodeType') not in ('GENERATE_IMAGE', 'GENERATE_VIDEO') or ap.get('nodeType') != ep['nodeType']:
        raise PipelineError(uid+': unsupported or mismatched node type')
    if not ep.get('prompt', '').strip(): raise PipelineError(uid+': empty prompt')
    required = expected.get('prompt_role') in (V134_ROLE, ANIMATION_ROLE, 'seedance25_30s')
    validate_video_spec(ep, required=required)
    validate_video_spec(ap, required=required)
    if expected.get('prompt_role') == V134_ROLE:
        validate_duration(ep['prompt'], ep, expected.get('supported_durations'), expected.get('legacy_timeline_origin'))
        if expected.get('binding_policy') not in (LEGACY_POLICY, BODY_POLICY):
            raise PipelineError(uid+': v134 requires reversible binding evidence')
    if expected.get('prompt_role') == ANIMATION_ROLE:
        if expected.get('binding_policy') != BODY_POLICY:
            raise PipelineError(uid+': animation requires reversible shot-body v2 bindings')
        source_bytes = Path(expected.get('source_prompt_file', '')).read_bytes()
        if hashlib.sha256(source_bytes).hexdigest() != expected.get('source_sha256'):
            raise PipelineError(uid+': animation segment source changed')
        validate_animation_source(expected, source_bytes.decode('utf-8'))
        validate_animation_duration(ep['prompt'], ep, expected.get('supported_durations'))
        validate_animation_staging(expected)

    if expected.get('prompt_role') == 'seedance25_30s':
        if canonical(ep.get('duration')) != '30' or ep.get('model') != DEFAULT_VIDEO_MODEL:
            raise PipelineError(uid+': seedance25_30s requires PIXDANCE_2_5_DRAFT and 30 seconds')
        if expected.get('binding_policy') != 'asset_mentions_only_v1':
            raise PipelineError(uid+': seedance25_30s requires a reversible binding manifest')
    if expected.get('prompt_role') in ('original_15s','automation_15s') or expected.get('binding_policy'):
        source_file, digest = expected.get('source_prompt_file'), expected.get('source_sha256')
        if not source_file or not digest:
            raise PipelineError(uid+': original 15s source file and hash required')
        source_bytes = Path(source_file).read_bytes()
        if hashlib.sha256(source_bytes).hexdigest() != digest:
            raise PipelineError(uid+': original 15s source changed after planning')
        if expected.get('binding_policy'):
            if expected['binding_policy'] not in (LEGACY_POLICY, BODY_POLICY):
                raise PipelineError(uid+': unknown binding policy')
            from fast_bind import compile_for_policy
            rebuilt, ranges, edits = compile_for_policy(source_bytes.decode('utf-8'),
                expected.get('bindings', []), expected.get('binding_labels', {}),
                expected.get('prompt_role', 'original_15s'), expected['binding_policy'],
                expected.get('body_mentions'))
            if rebuilt != ep['prompt'] or rebuilt != ap.get('prompt'):
                raise PipelineError(uid+': prompt changed outside permitted asset binding edits')
            if edits != expected.get('binding_edits') or ranges != expected.get('mention_ranges'):
                raise PipelineError(uid+': binding edit ledger/ranges mismatch')
            if hashlib.sha256(rebuilt.encode('utf-8')).hexdigest() != expected.get('bound_prompt_sha256'):
                raise PipelineError(uid+': bound prompt hash mismatch')
        elif expected.get('prompt_role') == 'original_15s' and (ep['prompt'].encode('utf-8') != source_bytes or ap.get('prompt', '').encode('utf-8') != source_bytes):
            raise PipelineError(uid+': legacy original prompt changed; compile a new binding manifest')
    for key in set(ep) | set(ap):
        if key == 'nodeType': continue
        if key not in ep or key not in ap or canonical(ep[key]) != canonical(ap[key]):
            raise PipelineError(uid+': changed parameter '+key)
    order = expected['prevNodeUuids']
    if uid in order or len(set(order)) != len(order) or actual.get('prevNodeUuids', []) != order:
        raise PipelineError(uid+': reference order mismatch or duplicate')
    bindings = expected.get('bindings', [])
    if expected_order(expected) != order:
        raise PipelineError(uid+': ordered image bindings and connection-only video differ')
    validate_input_order(bindings, expected.get('prompt_role'))
    blocking = [b for b in bindings if b['category']=='blocking_reference']
    storyboard = [b for b in bindings if b['category']=='storyboard_reference']
    if (blocking or storyboard) and ep['nodeType'] != 'GENERATE_VIDEO':
        raise PipelineError(uid+': storyboard/blocking inputs are video-only')
    if storyboard:
        storyboard_file, storyboard_hash = expected.get('storyboard_prompt_file'), expected.get('storyboard_sha256')
        if not storyboard_file or not storyboard_hash:
            raise PipelineError(uid+': storyboard prompt file and reviewed hash required')
        if hashlib.sha256(Path(storyboard_file).read_bytes()).hexdigest() != storyboard_hash:
            raise PipelineError(uid+': storyboard prompt changed after planning')
        bundle_file, bundle_hash = expected.get('episode_bundle_file'), expected.get('episode_bundle_sha256')
        if not bundle_file or not bundle_hash or hashlib.sha256(Path(bundle_file).read_bytes()).hexdigest() != bundle_hash:
            raise PipelineError(uid+': episode source bundle missing or changed after planning')
    mentioned_order = [b['node_uuid'] for b in bindings if b['category']!='blocking_reference']
    if canonical(ep.get('count')) != '1': raise PipelineError(uid+': this workflow requires count=1')
    # This focused helper handles the workflow's ordered image references only.
    tokens = list(TOKEN.finditer(ep['prompt']))
    if ep['nodeType']=='GENERATE_IMAGE' and not tokens:
        # Scene edits may use a real upstream mother image with an English prompt,
        # without the video's three designation blocks.
        if not isinstance(expected.get('character_asset_uuids'), list):
            raise PipelineError(uid+': explicit character asset list required')
        return
    body_count = len(expected.get('body_mentions', [])) if expected.get('binding_policy') == BODY_POLICY else 0
    if len(tokens) != len(mentioned_order) + body_count: raise PipelineError(uid+': missing or duplicated mentions')
    mentioned = []
    ranges = expected.get('mention_ranges', [])
    if mentioned_order and not ranges: raise PipelineError(uid+': designation ranges are required')
    for token in tokens:
        _, media, index, source = token.groups()
        if media != 'image' or source not in mentioned_order or int(index) != order.index(source):
            raise PipelineError(uid+': mention UUID/type/index mismatch')
        if storyboard and source == storyboard[0]['node_uuid']:
            prompt=ep['prompt']
            paragraph_break=re.search(r'\r?\n\r?\n',prompt)
            if not prompt.startswith('**六宫格首帧引用：**') or not paragraph_break or token.end()>paragraph_break.start():
                raise PipelineError(uid+': six-panel @ must appear in the first prompt paragraph')
        if not any(0 <= start <= token.start() and token.end() <= end <= len(ep['prompt']) for start, end in ranges):
            raise PipelineError(uid+': mention outside designation ranges')
        mentioned.append(source)
    if len(set(mentioned)) != len(mentioned_order): raise PipelineError(uid+': duplicate mentions')
    if not isinstance(expected.get('character_asset_uuids'), list):
        raise PipelineError(uid+': explicit character_asset_uuids list required (empty for no characters)')

def human_reference_assets(manifest, by_node, ready):
    """Include human-containing opening/reference images, even when wired without @."""
    assets=set();targets=set(ready)
    for shot in manifest['shots']:
        if shot['node_uuid'] not in targets:continue
        assets.update(shot['character_asset_uuids'])
        evidence={row.get('node_uuid'):row for row in (shot.get('visual_review') or {}).get('images',[])}
        for binding in shot.get('bindings',[]):
            uid=binding['node_uuid'];row=evidence.get(uid,{})
            if row.get('contains_humans') is True or (binding['category']=='blocking_reference' and row.get('contains_humans') is not False):
                asset=(by_node.get(uid,{}).get('defaultAsset') or {}).get('assetsUuid')
                if not asset:raise PipelineError('Human-containing reference asset is missing: '+uid)
                assets.add(asset)
    return assets

def preflight(manifest, nodes, tasks):
    shots = manifest['shots']
    ids = [s['node_uuid'] for s in shots]
    if not ids or len(set(ids)) != len(ids): raise PipelineError('Empty or duplicate target set')
    by_node = {n['uuid']:n for n in nodes}
    by_task = {t['nodeUuid']:t for t in tasks}
    ready, existing = [], []
    for shot in shots:
        uid = shot['node_uuid']
        if uid not in by_node: raise PipelineError(uid+': missing from target canvas')
        validate_shot(shot, by_node[uid])
        expected_order(shot, by_node)
        for source in shot['prevNodeUuids']:
            if source not in by_node: raise PipelineError(uid+': missing reference node')
            asset = by_node[source].get('defaultAsset') or {}
            if not asset.get('assetsUuid'): raise PipelineError(uid+': upstream image not generated/uploaded')
        expected_characters = {by_node[b['node_uuid']]['defaultAsset']['assetsUuid'] for b in shot.get('bindings', []) if b['category']=='character'}
        if set(shot['character_asset_uuids']) != expected_characters:
            raise PipelineError(uid+': character checks do not cover exact referenced character assets')
        task = by_task.get(uid, {})
        task_uuid = task.get('taskUuid') or by_node[uid].get('taskUuid')
        status = task.get('status')
        if task_uuid:
            if status not in ACTIVE: raise PipelineError(uid+': existing failed or unknown task; reconcile separately')
            existing.append({'node_uuid':uid,'task_uuid':task_uuid,'status':status})
        elif status:
            raise PipelineError(uid+': task state without task UUID')
        else:
            ready.append(uid)
    return ready, existing

def validate_group_plan(plan, file_uuid, ids):
    payload = plan.get('payload', {})
    if plan.get('dryRun') is not True or plan.get('endpoint') != '/generate/batch':
        raise PipelineError('Unexpected group submission plan')
    if payload.get('fileUuid') != file_uuid or payload.get('nodeUuids') != ids or payload.get('nodes') != ids:
        raise PipelineError('Group contains extra, missing, reordered or wrong-canvas targets')

def run(manifest, directory, submit=False, status_only=False, api=call):
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    state_path = directory/'submission.json'
    fingerprint = hashlib.sha256(json.dumps(manifest, ensure_ascii=False, sort_keys=True).encode()).hexdigest()
    previous = json.loads(state_path.read_text(encoding='utf-8')) if state_path.exists() else None
    if previous and previous['fingerprint'] != fingerprint:
        raise PipelineError('Manifest changed: preserve this record and use a new reviewed batch')
    ids = [s['node_uuid'] for s in manifest['shots']]
    tasks = api('tasks', 'progress', *ids)['data']
    compact = [{k:t.get(k) for k in ('nodeUuid','taskUuid','status','progress')} for t in tasks]
    # A previous attempt, even a timeout, must never trigger another group run.
    if status_only or previous:
        observed = {t['nodeUuid'] for t in tasks if t.get('taskUuid')}
        result = {'mode':'reconcile','tasks':compact,'missing_response_for':[u for u in ids if u not in observed], 'resubmitted':False}
        atomic_json(directory/'status.json', result)
        return result
    nodes = api('canvas', 'nodes', '--file', manifest['file_uuid'])
    ready, existing = preflight(manifest, nodes, tasks)
    review_errors = visual_review_errors(manifest, nodes, ready)
    blocked = {row['node_uuid'] for row in review_errors}
    result = {'mode':'plan','ready':ready,'existing':existing,'generation_submitted':False,
              'visual_review_pending':review_errors,
              'generation_ready':[uid for uid in ready if uid not in blocked]}
    atomic_json(directory/'plan.json', result)
    if not submit or not ready: return result
    if review_errors:
        raise PipelineError('Asset visual review incomplete/stale; inspect plan.json and submit a separately reviewed subset')
    # Lock survives a crash; normal exits release it. A crash requires reconciliation.
    lock = directory/'submit.lock'
    with lock.open('x', encoding='utf-8') as stream: stream.write(fingerprint)
    try:
        if state_path.exists():
            raise PipelineError('Another process already attempted this batch; use --status')
        characters = sorted(human_reference_assets(manifest, by_node={n['uuid']:n for n in nodes}, ready=ready))
        checks = []
        for asset_uuid in characters:
            response = api('assets','compliance-check',asset_uuid,'--no-poll')
            data = response.get('data', response)
            status = data.get('complianceStatus') or data.get('status')
            checks.append({'asset_uuid':asset_uuid,'status':status})
        atomic_json(directory/'character-checks.json', {'checks':checks})
        if any(c['status'] != 'ACTIVE' for c in checks):
            raise PipelineError('Character checks are not all ACTIVE; query checks before submitting')
        # Refresh after checks to catch manual generation or edits during preparation.
        fresh_nodes = api('canvas','nodes','--file',manifest['file_uuid'])
        fresh_tasks = api('tasks','progress',*ids)['data']
        ready, existing = preflight(manifest, fresh_nodes, fresh_tasks)
        if not ready: return {'mode':'plan','ready':[],'existing':existing,'generation_submitted':False}
        if visual_review_errors(manifest, fresh_nodes, ready):
            raise PipelineError('Asset visual review changed before submission; inspect current images again')
        suffix = hashlib.sha256(str(directory.resolve()).encode()).hexdigest()[:8]
        group_name = 'codex-'+fingerprint[:12]+'-'+suffix
        # CLI 1.3.0 resolves --node inside the active group even with --file.
        # Clear this local filter before binding an exact new target group.
        unbound = api('group','unuse')
        if unbound.get('groupUnbound') is not True:
            raise PipelineError('Cannot clear the previous active group filter')
        args = ['group','bind',group_name,'--file',manifest['file_uuid']]
        for uid in ready: args.extend(['--node',uid])
        bound = api(*args)
        if bound.get('nodeUuids') != ready: raise PipelineError('Existing local group differs from exact target list')
        plan = api('group','run',group_name,'--file',manifest['file_uuid'],'--dry-run')
        validate_group_plan(plan, manifest['file_uuid'], ready)
        atomic_json(directory/'group-plan.json', plan)
        record = {'fingerprint':fingerprint,'file_uuid':manifest['file_uuid'],'group':group_name,'targets':ready,'phase':'SUBMITTING','started_at':datetime.now(timezone.utc).isoformat()}
        atomic_json(state_path, record)
        response = api('group','run',group_name,'--file',manifest['file_uuid'])
        returned = response.get('data', [])
        record['tasks'] = [{k:t.get(k) for k in ('nodeUuid','taskUuid','status')} for t in returned]
        accepted = {t['nodeUuid'] for t in returned if t.get('taskUuid')}
        record['phase'] = 'SUBMITTED' if response.get('success') is True and accepted == set(ready) and len(returned) == len(ready) else 'RECONCILE_REQUIRED'
        atomic_json(state_path, record)
        return record
    finally:
        lock.unlink(missing_ok=True)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--records', type=Path, required=True)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument('--submit', action='store_true')
    mode.add_argument('--status', action='store_true')
    args = parser.parse_args()
    try:
        result = run(json.loads(args.manifest.read_text(encoding='utf-8-sig')), args.records, args.submit, args.status)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    except (PipelineError, OSError, ValueError, KeyError, subprocess.TimeoutExpired) as error:
        raise SystemExit('Stopped without an automatic generation retry: '+str(error))
