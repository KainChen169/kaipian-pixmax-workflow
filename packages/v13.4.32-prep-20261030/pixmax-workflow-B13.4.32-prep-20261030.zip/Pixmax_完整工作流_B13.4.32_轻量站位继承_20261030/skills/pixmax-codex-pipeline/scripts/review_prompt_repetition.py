"""Read-only review hints, not a creative validator or an acceptance gate."""
import argparse
import hashlib
import json
from pathlib import Path
import re

SHOT = re.compile(r'^#{3,4}\s*镜头\s*(?:\d+|[一二三四五六七八九十]+)\s*[｜|]')
FIELD = re.compile(r'^\s*(?:[-*]\s+)?(?:\*\*)?(画面|构图|表演|动作与表演|动作|画面内容)[：:](?:\*\*)?\s*(.*)$')
HEADING = re.compile(r'^#{1,6}\s')
OTHER_FIELD = re.compile(r'^\s*(?:[-*]\s+)?(?:\*\*)?[^：:\n]{1,24}[：:]')
TOKEN = re.compile(r'%%@[^\n]*?%%')


def normalized(text):
    # Compare wording only: native reference tokens and formatting are not prose.
    return re.sub(r'\s+', '', TOKEN.sub('', text).replace('**', ''))


def inspect_text(text):
    shots, current, active_field = [], None, None
    scope = ''
    for line_number, line in enumerate(text.splitlines(), 1):
        if SHOT.match(line):
            current = dict(scope=scope, heading=line, line=line_number, fields={})
            shots.append(current)
            active_field = None
            continue
        if HEADING.match(line):
            # Stop before sound/output sections; scope also prevents cross-pack
            # comparisons from repeated numbering such as 镜头01.
            scope = line
            current, active_field = None, None
            continue
        if current is None:
            continue
        match = FIELD.match(line)
        if match:
            active_field = match[1]
            current['fields'][active_field] = match[2]
        elif OTHER_FIELD.match(line):
            active_field = None
        elif active_field:
            current['fields'][active_field] += '\n' + line

    hints, covered = [], 0
    previous = None
    for shot in shots:
        fields = shot['fields']
        visual = fields.get('画面', fields.get('构图', ''))
        performance = next((fields[k] for k in ('表演', '动作与表演', '动作', '画面内容') if k in fields), '')
        if visual.strip() and performance.strip():
            covered += 1
            if normalized(visual) == normalized(performance):
                hints.append(dict(kind='SAME_WINDOW_COPY', lines=[shot['line']],
                                  excerpt=visual.strip(),
                                  question='两栏是否只重复同一句，还是各有实际作用？结合本镜判断。'))
        if previous and previous['scope'] == shot['scope']:
            prior_visual = previous['fields'].get('画面', previous['fields'].get('构图', ''))
            if visual.strip() and normalized(visual) == normalized(prior_visual):
                hints.append(dict(kind='ADJACENT_VISUAL_COPY', lines=[previous['line'], shot['line']],
                                  excerpt=visual.strip(),
                                  question='观看重点或动作阶段是否改变？合理连续表演可保留，不为消除提示换词。'))
        previous = shot
    return dict(status='REVIEW_HINTS_ONLY', parsed_shots=len(shots), paired_fields=covered,
                coverage=('recognized_shots_paired_fields_complete' if shots and covered == len(shots) else 'partial_or_unrecognized'),
                coverage_scope='只统计识别到的镜头；未知标题可能漏读或并入前镜，不证明全文覆盖。',
                hints=hints,
                limitation='仅比较已解析文字，不检查原话、说话对象、动作时长、空间或表演质量；零提示不是内容通过。')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('prompt_file', type=Path)
    args = parser.parse_args()
    data = args.prompt_file.read_bytes()
    result = inspect_text(data.decode('utf-8-sig'))
    result.update(source_file=str(args.prompt_file.resolve()), source_sha256=hashlib.sha256(data).hexdigest())
    print(json.dumps(result, ensure_ascii=False, indent=2))
    # Hints never set failure exit status or mutate the input.


if __name__ == '__main__':
    main()
