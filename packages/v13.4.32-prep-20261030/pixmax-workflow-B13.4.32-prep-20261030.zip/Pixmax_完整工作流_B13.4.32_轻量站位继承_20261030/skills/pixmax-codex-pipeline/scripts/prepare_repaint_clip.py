"""Cut a local repaint reference and record source/clip time mapping. No Pixmax calls."""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import uuid


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def make_plan(source, start, end, repair_start, repair_end, minimum=4, maximum=30, prompt=None):
    numbers = [start, end, repair_start, repair_end, minimum, maximum]
    if not all(math.isfinite(x) for x in numbers):
        raise ValueError('Times and model limits must be finite numbers')
    if not 0 <= start < end or not 0 < minimum <= maximum:
        raise ValueError('Invalid cut or input duration limits')
    if not minimum <= end - start <= maximum:
        raise ValueError(f'Reference duration must be between {minimum} and {maximum} seconds')
    if not start <= repair_start < repair_end <= end:
        raise ValueError('Repair window must be contained in the selected source interval')
    source = Path(source).resolve(strict=True)
    if not source.is_file():
        raise ValueError('Input must be a local video file')
    plan = {
        'source_path': str(source), 'source_sha256': sha256(source),
        'source_cut_seconds': [start, end],
        'requested_cut_duration_seconds': end - start,
        'repair_window_source_seconds': [repair_start, repair_end],
        'repair_window_clip_seconds': [repair_start - start, repair_end - start],
        'input_duration_limits_seconds': [minimum, maximum],
        'paid_generation_submitted': False,
    }
    if prompt:
        prompt = Path(prompt).resolve(strict=True)
        plan.update(prompt_path=str(prompt), prompt_sha256=sha256(prompt))
    plan['plan_sha256'] = hashlib.sha256(json.dumps(plan, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
    return plan


def ffmpeg_path(explicit=None):
    candidate = explicit or os.environ.get('FFMPEG_BINARY') or shutil.which('ffmpeg')
    if candidate:
        return str(candidate)
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except ImportError as exc:
        raise RuntimeError('Provide --ffmpeg or FFMPEG_BINARY pointing to an existing FFmpeg executable') from exc


def run(args):
    result = subprocess.run(args, capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=300)
    if result.returncode:
        raise RuntimeError('FFmpeg failed: ' + result.stderr[-2000:])
    return result.stderr


def parse_media(log):
    duration = re.search(r'Duration: (\d+):(\d+):(\d+(?:\.\d+)?)', log)
    video = next((line for line in log.splitlines() if 'Video:' in line), '')
    dimensions = re.search(r'\b(\d{2,5})x(\d{2,5})\b', video)
    fps = re.search(r'(\d+(?:\.\d+)?) fps', video)
    frames = re.findall(r'frame=\s*(\d+)', log)
    result = {
        'container_duration_seconds': (int(duration[1]) * 3600 + int(duration[2]) * 60 + float(duration[3])) if duration else None,
        'width': int(dimensions[1]) if dimensions else None,
        'height': int(dimensions[2]) if dimensions else None,
        'declared_frame_rate': float(fps[1]) if fps else None,
        'decoded_video_frames': int(frames[-1]) if frames else None,
        'has_audio': 'Audio:' in log,
    }
    if result['declared_frame_rate'] and result['decoded_video_frames']:
        result['video_seconds_from_frames_and_rate'] = result['decoded_video_frames'] / result['declared_frame_rate']
        result['duration_note'] = 'Frame-count duration applies to constant frame rate; keep container duration separately.'
    return result


def prepare(plan, output_dir, ffmpeg):
    output_dir = Path(output_dir).resolve()
    record_path = output_dir / 'clip-record.json'
    clip = output_dir / 'repaint-reference.mp4'
    if record_path.exists():
        record = json.loads(record_path.read_text(encoding='utf-8'))
        if record.get('plan_sha256') != plan['plan_sha256']:
            raise ValueError('This directory contains a different source/window/prompt; choose a new output directory')
        if not clip.is_file() or sha256(clip) != record.get('clip_sha256'):
            raise ValueError('Cached clip is missing or changed; preserve records and use a new output directory')
        return {**record, 'reused_existing_clip': True}
    if clip.exists():
        raise ValueError('Untracked clip already exists; refusing to overwrite it')
    source_log = run([ffmpeg, '-hide_banner', '-nostdin', '-i', plan['source_path'], '-t', '0', '-f', 'null', '-'])
    source_media = parse_media(source_log)
    duration = source_media['container_duration_seconds']
    if duration is None or plan['source_cut_seconds'][1] > duration + 0.02:
        raise ValueError('Selected source interval exceeds the actual video duration')
    output_dir.mkdir(parents=True, exist_ok=True)
    temporary = output_dir / ('repaint-reference-' + uuid.uuid4().hex + '.tmp.mp4')
    try:
        log = run([
            ffmpeg, '-hide_banner', '-nostdin', '-n', '-ss', str(plan['source_cut_seconds'][0]),
            '-i', plan['source_path'], '-t', str(plan['requested_cut_duration_seconds']),
            '-map', '0:v:0', '-map', '0:a:0?', '-c:v', 'libx264', '-crf', '18',
            '-preset', 'veryfast', '-c:a', 'aac', '-b:a', '128k', '-movflags', '+faststart', str(temporary),
        ])
        (output_dir / 'cut.log').write_text(log, encoding='utf-8')
        decode_log = run([ffmpeg, '-hide_banner', '-nostdin', '-i', str(temporary), '-map', '0:v:0', '-an', '-f', 'null', '-'])
        (output_dir / 'decode.log').write_text(decode_log, encoding='utf-8')
        media = parse_media(decode_log)
        if not media['decoded_video_frames'] or not media['width'] or not media['height']:
            raise ValueError('Clip has no decodable video frames')
        temporary.rename(clip)
        record = {
            **plan, 'phase': 'LOCAL_CLIP_READY', 'clip_path': str(clip), 'clip_sha256': sha256(clip),
            'source_media': source_media, 'clip_media': media,
            'reused_existing_clip': False, 'visual_review': 'PENDING', 'dialogue_verified': False,
        }
        record_path.write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding='utf-8')
        return record
    finally:
        if temporary.exists():
            temporary.unlink()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, required=True)
    parser.add_argument('--start', type=float, required=True)
    parser.add_argument('--end', type=float, required=True)
    parser.add_argument('--repair-start', type=float, required=True, help='Repair start in original source seconds')
    parser.add_argument('--repair-end', type=float, required=True, help='Repair end in original source seconds')
    parser.add_argument('--min-seconds', type=float, default=4, help='Set from current model input rules')
    parser.add_argument('--max-seconds', type=float, default=30, help='Set from current model input rules')
    parser.add_argument('--prompt-file', type=Path)
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--ffmpeg')
    parser.add_argument('--plan-only', action='store_true', help='Print mapping without invoking FFmpeg or writing files')
    args = parser.parse_args()
    try:
        plan = make_plan(args.input, args.start, args.end, args.repair_start, args.repair_end, args.min_seconds, args.max_seconds, args.prompt_file)
        result = plan if args.plan_only else prepare(plan, args.output_dir, ffmpeg_path(args.ffmpeg))
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (OSError, ValueError, RuntimeError, subprocess.TimeoutExpired) as exc:
        print(json.dumps({'error': str(exc), 'paid_generation_submitted': False}, ensure_ascii=False), file=sys.stderr)
        return 2


if __name__ == '__main__':
    sys.exit(main())
