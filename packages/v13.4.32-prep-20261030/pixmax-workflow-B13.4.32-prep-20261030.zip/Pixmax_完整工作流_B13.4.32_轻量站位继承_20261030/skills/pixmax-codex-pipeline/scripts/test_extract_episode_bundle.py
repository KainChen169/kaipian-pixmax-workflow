"""Tests for the episode video/storyboard split boundary."""

import tempfile
import unittest
from pathlib import Path

from extract_episode_bundle import BundleError, parse_bundle, write_bundle


def sample_bundle() -> str:
    shots = "\n".join(
        f"### 镜头{index}｜{index - 1}.0—{index}.0秒｜近景｜缓推\n**入画角色：** 林岚\n**画面内容：** 林岚看向周远。"
        for index in range(1, 7)
    )
    picture = "\n".join(
        ["CHARACTER REFERENCES: 林岚 (Lin Lan), matching her supplied portrait and coat.",
         "SCENE REFERENCE: 会客室内, day, west entrance and east table.",
         "GLOBAL LOCK: Same world positions and camera axis across all six panels."]
        + [f"PANEL {index}: Lin Lan in one frozen performance moment." for index in range(1, 7)]
    )
    return (
        "# 第03集｜镜头01｜测试｜15秒完整视频执行提示词\n"
        "**人物指定：**\n林岚\n**重要道具：** 无。\n"
        "**场景指定：**\n会客室内\n日景。西侧入口，东侧长桌。\n"
        f"## 时间线镜头设计\n{shots}\n\n"
        "<!-- PIXMAX_SIX_PANEL_APPENDIX_START -->\n"
        "# 第03集｜六宫格分镜参考图英文提示词\n"
        "## 镜头01｜六宫格英文提示词\n```text\n"
        f"{picture}\n```\n"
        "<!-- PIXMAX_SIX_PANEL_APPENDIX_END -->\n"
    )


class BundleTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.source = Path(self.temp.name) / "EP03.md"
        self.source.write_text(sample_bundle(), encoding="utf-8")

    def test_valid_split_has_no_image_text_in_video(self):
        parsed = parse_bundle(self.source)
        self.assertEqual(parsed["episode"], 3)
        self.assertEqual(len(parsed["records"]), 1)
        video = parsed["records"][0]["video_text"]
        self.assertNotIn("CHARACTER REFERENCES", video)
        self.assertNotIn("APPENDIX_START", video)
        self.assertIn("GLOBAL LOCK", parsed["records"][0]["storyboard_text"])

    def test_missing_panel_fails(self):
        self.source.write_text(sample_bundle().replace("PANEL 6:", "MISSING 6:"), encoding="utf-8")
        with self.assertRaisesRegex(BundleError, "PANEL 1—6"):
            parse_bundle(self.source)

    def test_two_video_segments_match_two_storyboards(self):
        single = sample_bundle()
        first_video, appendix = single.split("<!-- PIXMAX_SIX_PANEL_APPENDIX_START -->", 1)
        second_video = first_video.replace("镜头01｜测试", "镜头02｜测试", 1)
        image_heading = "## 镜头01｜六宫格英文提示词"
        first_image, ending = appendix.split("<!-- PIXMAX_SIX_PANEL_APPENDIX_END -->", 1)
        second_image = first_image[first_image.index(image_heading):].replace(image_heading, "## 镜头02｜六宫格英文提示词", 1)
        self.source.write_text(first_video + second_video + "<!-- PIXMAX_SIX_PANEL_APPENDIX_START -->" +
                               first_image + second_image + "<!-- PIXMAX_SIX_PANEL_APPENDIX_END -->" + ending,
                               encoding="utf-8")
        parsed = parse_bundle(self.source)
        self.assertEqual([item["shot"] for item in parsed["records"]], [1, 2])

    def test_character_mismatch_fails(self):
        self.source.write_text(sample_bundle().replace("CHARACTER REFERENCES: 林岚", "CHARACTER REFERENCES: 周远"), encoding="utf-8")
        with self.assertRaisesRegex(BundleError, "人物指定缺少"):
            parse_bundle(self.source)

    def test_write_idempotent_and_preserves_source(self):
        before = self.source.read_bytes()
        parsed = parse_bundle(self.source)
        output = Path(self.temp.name) / "derived"
        first = write_bundle(parsed, output)
        second = write_bundle(parsed, output)
        self.assertEqual(first, second)
        self.assertEqual(self.source.read_bytes(), before)
        self.assertEqual((output / "镜头01_视频.md").read_bytes(), parsed["records"][0]["video_text"].encode())
        self.assertTrue((output / "episode_bundle_manifest.json").is_file())

    def test_modified_derived_video_is_not_overwritten(self):
        parsed = parse_bundle(self.source)
        output = Path(self.temp.name) / "derived"
        write_bundle(parsed, output)
        (output / "镜头01_视频.md").write_text("edited", encoding="utf-8")
        with self.assertRaisesRegex(BundleError, "停止覆盖"):
            write_bundle(parsed, output)


if __name__ == "__main__":
    unittest.main()
