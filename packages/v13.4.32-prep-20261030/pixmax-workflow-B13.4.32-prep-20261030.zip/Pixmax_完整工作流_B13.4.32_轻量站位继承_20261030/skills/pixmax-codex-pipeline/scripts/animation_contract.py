"""Seedance 2.5 animation branch: source, voice, duration and text-staging evidence.

Reads the installed sibling animation Skill; never imports a live-action validator.
No media generation or remote calls. All attestations remain agent text evidence.
"""
from __future__ import annotations
import hashlib
import importlib.util
import json
import math
import re
from pathlib import Path
from pixmax_pipeline import PipelineError
from project_style import ANIMATION_ROLE
from seedance25_contract import generation_duration, DEFAULT_VIDEO_MODEL

ROLE = ANIMATION_ROLE
SKILL = 'seedance25-animation-director'


def read_evidence(record, key):
    path_value = record.get(key + '_file')
    if not isinstance(path_value, str):
        raise PipelineError('Animation evidence requires ' + key + '_file')
    path = Path(path_value)
    if not path.is_absolute() or not path.is_file():
        raise PipelineError('Animation evidence requires an existing absolute file: ' + key)
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != record.get(key + '_sha256'):
        raise PipelineError('Animation evidence missing/stale hash: ' + key)
    return raw


def animation_validator():
    path = Path(__file__).resolve().parents[2] / SKILL / 'scripts' / 'validate_animation_prompt.py'
    if not path.is_file():
        raise PipelineError('Install the sibling seedance25-animation-director Skill before animation preparation')
    spec = importlib.util.spec_from_file_location('pixmax_animation_prompt_validator', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def validate_source(shot, source_text):
    source = shot.get('animation_source')
    if not isinstance(source, dict):
        raise PipelineError('Animation requires full episode animation_source and voice/source evidence')
    try:
        full = read_evidence(source, 'episode_prompt').decode('utf-8-sig')
        dialogue = json.loads(read_evidence(source, 'source_dialogue').decode('utf-8-sig'))
        voices = json.loads(read_evidence(source, 'voice_cast').decode('utf-8-sig'))
        module = animation_validator()
        result = module.check(full, dialogue, voices)
    except (UnicodeError, ValueError, OSError) as exc:
        raise PipelineError('Unreadable animation source evidence: ' + str(exc)) from exc
    if not result['passed']:
        raise PipelineError('Animation prompt/source/voice check failed: ' + '; '.join(result['errors']))
    segments = list(module.SEGMENT.finditer(full))
    number = source.get('segment_number')
    if type(number) is not int or not 1 <= number <= len(segments):
        raise PipelineError('Animation requires an actual episode segment_number')
    start = segments[number - 1].start()
    stop = segments[number].start() if number < len(segments) else len(full)
    if source_text != full[start:stop]:
        raise PipelineError('Animation node source must be the exact episode segment slice; no binding-time rewrite')
    return {'segments': len(segments), 'source_dialogue_checked': result['source_dialogue_checked'],
            'voice_identity_checked': result['voice_identity_checked'], 'actual_voiceprint_verified': False}


def natural_duration(prompt):
    header = prompt.split('###', 1)[0]
    found = re.findall(r'(?m)^时长[：:]\s*(\d+(?:\.\d+)?)秒\s*$', header)
    if len(found) != 1:
        raise PipelineError('Animation source must contain exactly one segment duration header')
    value = float(found[0])
    generation_duration(value)
    return value


def validate_duration(prompt, params, supported):
    if params.get('nodeType') != 'GENERATE_VIDEO' or params.get('model') != DEFAULT_VIDEO_MODEL or params.get('referModel') != 'referToVideo':
        raise PipelineError('Animation branch requires PIXDANCE_2_5_DRAFT multi-reference video mode')
    if not isinstance(supported, list) or not supported or any(type(v) is not int or v <= 0 for v in supported):
        raise PipelineError('Animation requires current schema supported_durations')
    value = params.get('duration')
    try:
        seconds = float(value)
    except (ValueError, TypeError, OverflowError):
        raise PipelineError('Invalid animation duration') from None
    if isinstance(value, bool) or not math.isfinite(seconds) or not seconds.is_integer() or seconds not in supported:
        raise PipelineError('Animation duration unsupported by the recorded model schema')
    natural = natural_duration(prompt)
    if natural > 30 or generation_duration(natural) != seconds:
        raise PipelineError('Animation source/header and ceil generation duration differ')
    pattern = animation_validator().SHOT
    shots = list(pattern.finditer(prompt))
    if not shots or len(shots) != len(re.findall(r'(?m)^####\s+镜头', prompt)):
        raise PipelineError('Animation requires parseable fourth-level shot timelines')
    end = 0.0
    for shot in shots:
        start, stop = float(shot[2]), float(shot[3])
        if abs(start - end) > 1e-6 or stop <= start:
            raise PipelineError('Animation timeline gap/overlap/non-positive duration')
        end = stop
    if abs(end - natural) > 1e-6:
        raise PipelineError('Animation timeline does not end at its natural duration')
    return int(seconds)


def validate_staging(shot):
    """Require scene text/JSON and concrete review, without standing images or opening quotas."""
    try:
        report = json.loads(read_evidence(shot, 'animation_staging_review').decode('utf-8-sig'))
        if not isinstance(report, dict):
            raise PipelineError('Animation staging review must be an object')
        if report.get('policy') != 'animation_staging_text_v1' or report.get('status') != 'PASS':
            raise PipelineError('Animation text staging review is not PASS')
        script = read_evidence(report, 'script')
        md = read_evidence(report, 'blocking_text')
        plan = json.loads(read_evidence(report, 'blocking_plan').decode('utf-8-sig'))
        if not isinstance(plan, dict):
            raise PipelineError('Animation staging plan must be an object')
        full = read_evidence(shot['animation_source'], 'episode_prompt').decode('utf-8-sig')
    except (UnicodeError, ValueError, OSError, KeyError, TypeError) as exc:
        raise PipelineError('Unreadable animation staging evidence: ' + str(exc)) from exc
    if not script.strip() or not md.strip():
        raise PipelineError('Animation staging requires nonempty script and pre-authoring MD')
    if report.get('episode_prompt_sha256') != shot['animation_source']['episode_prompt_sha256']:
        raise PipelineError('Animation staging review is stale after an episode prompt change')
    if plan.get('policy') != 'animation_scene_plan_v1' or plan.get('script_sha256') != report.get('script_sha256'):
        raise PipelineError('Animation staging plan/source version mismatch')
    if not isinstance(report.get('episode_id'), str) or not report['episode_id'].strip() or plan.get('episode_id') != report['episode_id']:
        raise PipelineError('Animation staging episode mismatch')
    for field in ('reviewed_at', 'reviewed_by'):
        if not isinstance(report.get(field), str) or not report[field].strip():
            raise PipelineError('Animation staging review requires ' + field)
    checks = report.get('checks')
    if not isinstance(checks, dict):
        raise PipelineError('Animation staging requires concrete semantic checks')
    for key in ('body_support', 'landmark_background', 'cross_segment', 'performance_camera'):
        row = checks.get(key)
        if not isinstance(row, dict) or row.get('status') != 'PASS' or not isinstance(row.get('observation'), str) or not row['observation'].strip():
            raise PipelineError('Animation staging requires reviewed ' + key)
    rows = plan.get('segments')
    count = len(list(animation_validator().SEGMENT.finditer(full)))
    if not isinstance(rows, list) or len(rows) != count or any(not isinstance(r, dict) for r in rows):
        raise PipelineError('Animation staging must cover every episode segment')
    ids = [r.get('id') for r in rows]
    if any(not isinstance(i, str) or not i.strip() for i in ids) or len(set(ids)) != len(ids):
        raise PipelineError('Animation staging segment IDs must be unique')
    for n, row in enumerate(rows, 1):
        if row.get('segment_number') != n or not isinstance(row.get('opening_state'), dict) or not row['opening_state'] or not isinstance(row.get('exit_state'), dict) or not row['exit_state'] or not isinstance(row.get('movements'), list):
            raise PipelineError('Animation staging requires ordered opening/movement/exit states')
    current = rows[shot['animation_source']['segment_number'] - 1]
    if current['id'] != shot.get('id') or generation_duration(current.get('actual_duration')) != float(shot['params']['duration']):
        raise PipelineError('Animation staging current segment/duration differs from saved node')
