"""Validate explicit source-span references; never infer identity or rewrite prose."""
import re
from pixmax_pipeline import PipelineError

POLICY = 'asset_mentions_shot_anchors_v2'
LEGACY = 'asset_mentions_only_v1'
SHOT = re.compile(r'(?m)^#{1,6}[ \t]+镜头[ \t]*(\d+)[ \t]*[｜|][^\r\n]*')
FIELD_NAMES = ('构图', '画面内容', '构图与画面内容', '构图及画面内容', '画面', '表演', '动作', '动作与表演')
FIELD = re.compile(r'(?m)^[ \t]*(?:\*\*)?(' + '|'.join(FIELD_NAMES) + r')[：:](?:\*\*)?[ \t]*')
ANY_FIELD = re.compile(r'(?m)^[ \t]*(?:\*\*[^*\r\n]+[：:]\*\*|[^\s：:*]{1,16}[：:])[ \t]*')
# Animation source labels may exceed generic field length. Protect the whole
# label (speaker, kind, addressee, voice stage), not just the quoted words.
SPOKEN_LINE = re.compile(r'(?m)^[ \t]*(?:\*\*)?原话[（(][^\r\n]*')
HEADING = re.compile(r'(?m)^#{1,6}[ \t]+\S[^\r\n]*')
PURPOSE = {'character': 'visible_character', 'scene': 'scene', 'prop': 'visible_prop'}


def quoted_ranges(text):
    """Protect quoted speech conservatively, including multi-line quoted content."""
    pairs = {'“': '”', '「': '」', '『': '』', '‘': '’', '"': '"'}
    stack, ranges = [], []
    for i, ch in enumerate(text):
        if ch == '"' and i and text[i-1] == '\\':
            continue
        if stack and ch == stack[-1][1]:
            start, _ = stack.pop()
            ranges.append((start, i + 1))
        elif ch in pairs:
            stack.append((i, pairs[ch]))
    ranges.extend((start, len(text)) for start, _ in stack)
    ranges.extend((m.start(), m.end()) for m in re.finditer(r'(?s)```.*?(?:```|\Z)|`[^`\r\n]*`', text))
    ranges.extend((m.start(), m.end()) for m in SPOKEN_LINE.finditer(text))
    # Single quotes used as speech delimiters, not apostrophes in words.
    ranges.extend((m.start(), m.end()) for m in re.finditer(r"(?<![A-Za-z0-9_])'(?:[^'\r\n]|(?<=[A-Za-z0-9_])'(?=[A-Za-z0-9_]))*'(?![A-Za-z0-9_])", text))
    return ranges


def body_fields(text):
    """Only explicit sub-shot narrative fields, never guidance/titles/sound fields."""
    result, numbers = [], set()
    headers = list(HEADING.finditer(text))
    timelines = [h for h in headers if re.search(r'(?:^|[ .、．])时间线(?:镜头设计)?[ \t\r]*$', h.group())]
    if len(timelines) != 1:
        raise PipelineError('One timeline section required for body bindings')
    timeline = timelines[0]
    level = len(re.match(r'#+', timeline.group()).group())
    stop = next((h.start() for h in headers if h.start() > timeline.end()
                 and len(re.match(r'#+', h.group()).group()) <= level), len(text))
    for shot in SHOT.finditer(text, timeline.end(), stop):
        number = int(shot.group(1))
        if number in numbers:
            raise PipelineError('Repeated sub-shot number in body binding source')
        numbers.add(number)
        following = HEADING.search(text, shot.end())
        end = min(following.start() if following else len(text), stop)
        fields = list(FIELD.finditer(text, shot.end(), end))
        for i, field in enumerate(fields):
            next_field = ANY_FIELD.search(text, field.end(), end)
            spoken = SPOKEN_LINE.search(text, field.end(), end)
            boundary = min(next_field.start() if next_field else end, spoken.start() if spoken else end)
            result.append((field.end(), boundary, number, field.group(1)))
    return result


def body_edits(raw, refs, labels, anchors):
    if not isinstance(anchors, list) or not anchors:
        raise PipelineError('v2 requires a nonempty explicit body_mentions plan')
    by_uid = {b['node_uuid']: (i, b) for i, b in enumerate(refs)}
    fields, protected = body_fields(raw), quoted_ranges(raw)
    edits, used = [], set()
    for point in anchors:
        if not isinstance(point, dict):
            raise PipelineError('Invalid body mention point')
        start, end, text, uid = (point.get(k) for k in ('start', 'end', 'text', 'node_uuid'))
        if 'start' not in point and 'end' not in point:
            # Scoped selector avoids hand-counting offsets or global name replacement.
            if type(point.get('subshot')) is not int or point.get('field') not in FIELD_NAMES or not isinstance(text, str) or not text:
                raise PipelineError('Body selector requires subshot, field and text')
            candidates = [(a + m.start(), a + m.end()) for a, b, s, f in fields
                          if s == point['subshot'] and f == point['field']
                          for m in re.finditer(re.escape(text), raw[a:b])
                          if not any(a + m.start() < y and a + m.end() > x for x, y in protected)]
            occurrence = point.get('occurrence', 1)
            if type(occurrence) is not int or occurrence < 1 or occurrence > len(candidates):
                raise PipelineError('No unquoted body anchor at selected occurrence')
            start, end = candidates[occurrence - 1]
        if type(start) is not int or type(end) is not int or not (0 <= start < end <= len(raw)) or raw[start:end] != text:
            raise PipelineError('Body anchor source span/text mismatch')
        match = [s for a, b, s, _ in fields if a <= start < end <= b]
        if len(match) != 1:
            raise PipelineError('Body anchor must be inside a sub-shot composition/content field')
        if any(start < b and end > a for a, b in protected):
            raise PipelineError('Body anchor is inside protected dialogue/quoted text')
        if uid not in by_uid:
            raise PipelineError('Body anchor refers to an unbound asset')
        index, binding = by_uid[uid]
        category = binding['category']
        if category not in PURPOSE or point.get('purpose') != PURPOSE[category]:
            raise PipelineError('Body anchor category/purpose mismatch; mentioned-only/offscreen is not visible')
        if category == 'character' and re.match(r'\s*[（(]\s*(?:O\.?S\.?|V\.?O\.?|画外(?:对白)?|内心旁白|旁白|VO)\s*[）)]', raw[end:], re.I):
            raise PipelineError('Explicit offscreen/voice-over speaker is not a visible body anchor')
        aliases = binding.get('body_aliases', [])
        if not isinstance(aliases, list) or any(not isinstance(a, str) or not a.strip() for a in aliases):
            raise PipelineError('Invalid explicitly reviewed body aliases')
        if text not in [binding.get('designation'), *aliases] or any(c in text for c in '\r\n[]()'):
            raise PipelineError('Body anchor name is not the mapped designation or reviewed alias')
        if (re.match(r'[A-Za-z0-9_]', text) and start and re.match(r'[A-Za-z0-9_]', raw[start-1])) or (re.search(r'[A-Za-z0-9_]$', text) and end < len(raw) and re.match(r'[A-Za-z0-9_]', raw[end])):
            raise PipelineError('Body anchor cuts through a longer name')
        if (match[0], uid) in used:
            raise PipelineError('Duplicate body asset reference within one sub-shot')
        used.add((match[0], uid))
        label = labels[uid]  # Header compiler already validates its syntax.
        edits.append({'start': end, 'end': end, 'before': '',
                      'after': f' %%@[{label}][image][{index}]({uid})%%',
                      'category': category, 'node_uuid': uid, 'scope': 'shot_body',
                      'subshot': match[0], 'anchor_start': start})
    spans = sorted((e['anchor_start'], e['start']) for e in edits)
    if any(left[1] > right[0] for left, right in zip(spans, spans[1:])):
        raise PipelineError('Overlapping body anchors')
    return edits
