"""Validate recorded state-board inspections, never infer correctness from pixels."""
import hashlib
from pathlib import Path
from pixmax_pipeline import PipelineError

POLICY = 'character_state_board_v3'
LEGACY_POLICY = 'character_state_board_v2'
VIEWS = ('front', 'profile', 'face_closeup', 'state_closeup')

def validate_state_board_review(row):
    if row.get('reference_kind') != 'character_state_board' and not row.get('state_board_required') and row.get('state_board_review') is None:
        return
    def fail(reason):
        raise PipelineError(str(row.get('node_uuid')) + ': state board ' + reason)
    review = row.get('state_board_review')
    if not isinstance(review, dict) or review.get('policy') not in (POLICY, LEGACY_POLICY) or review.get('status') != 'PASS':
        fail('requires a reviewed character state board')
    if review.get('asset_uuid') != row.get('asset_uuid'):
        fail('belongs to another asset')
    path = Path(row.get('view_evidence', ''))
    if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != review.get('image_sha256'):
        fail('image evidence changed or is missing')
    if review.get('viewed_at_full_resolution') is not True:
        fail('requires actual full-resolution inspection')
    legacy = review['policy'] == LEGACY_POLICY
    required_views = VIEWS + ('back',) if legacy else VIEWS
    views = review.get('views')
    if not isinstance(views, dict) or any(v not in views for v in required_views):
        fail('missing required full-body/face/state close-up views')
    if not legacy and 'back' in views:
        fail('new boards must not contain a back view; existing v2 boards remain valid')
    for name in views:
        view = views[name]
        if not isinstance(view, dict) or view.get('status') != 'PASS' or not str(view.get('observation', '')).strip():
            fail('unreviewed view: ' + name)
        box = view.get('image_region')
        if not isinstance(box, list) or len(box) != 4 or any(not isinstance(x, (int,float)) or isinstance(x,bool) or not 0 <= x <= 1 for x in box) or not (box[0] < box[2] and box[1] < box[3]):
            fail('requires a real normalized image region: ' + name)
    face = views['face_closeup']['image_region']
    for name in views:
        if name == 'face_closeup':
            continue
        b = views[name]['image_region']
        if max(face[0],b[0]) < min(face[2],b[2]) and max(face[1],b[1]) < min(face[3],b[3]):
            fail('face close-up must be a separate panel')
    if views['face_closeup'].get('identity_matches_original') is not True:
        fail('face identity not confirmed')
    profile = views['profile']
    side = profile.get('body_side')
    facing = profile.get('facing_in_board')
    if side not in ('left','right') or facing != {'left':'screen_left','right':'screen_right'}[side]:
        fail('profile anatomical side and face/foot direction conflict')
    items = review.get('state_items')
    if not isinstance(items,list) or not items:
        fail('requires concrete state items and anatomical anchors')
    for item in items:
        detail = item.get('detail_view','state_closeup')
        if detail not in views or detail in ('front','profile','back','face_closeup'):
            fail('state item requires its own inspected detail panel')
        target = item.get('anchor') or {}
        for key in ('body_side','surface','height_reference'):
            if not isinstance(target.get(key),str) or not target[key].strip():
                fail('missing fixed anatomical anchor: ' + key)
        observed = item.get('by_view') or {}
        for name in (('front','profile','back',detail) if legacy else ('front','profile',detail)):
            v = observed.get(name) or {}
            if v.get('status') != 'PASS' or not str(v.get('observation','')).strip():
                fail('missing per-view state observation: ' + name)
            if any(v.get(k) != target[k] for k in ('body_side','surface','height_reference')):
                fail('anatomical anchor drifts between views: ' + name)
            if v.get('count') != item.get('count') or v.get('occlusion') not in ('none','partial','full_explained'):
                fail('wrong count or unexplained occlusion: ' + name)
            if v.get('shape_scale_orientation_matches') is not True:
                fail('shape/scale/orientation changed: ' + name)
    return review
