"""Match a recorded upscale to an official canvas snapshot; never submit tasks."""
import argparse
import copy
import json
from pathlib import Path


class ReconcileError(ValueError):
    pass


def reconcile(record, snapshot):
    canvas = snapshot.get('data', snapshot)
    if snapshot.get('success') is False or not isinstance(canvas, dict):
        raise ReconcileError('Canvas request failed or returned an invalid payload')
    if not canvas.get('fileUuid') or canvas['fileUuid'] != record['file_uuid']:
        raise ReconcileError('Canvas file UUID does not match the recorded scope')
    source = record['source_asset_uuid']
    target = record['target_resolution']
    pinned = record.get('upscale_task_uuid')
    matches = {}
    for node in canvas.get('nodes', []):
        task = node.get('generationTask') or {}
        if task.get('modelCode') != 'VIDEO_UPSCALE':
            continue
        inputs = [a.get('assetsUuid') for a in task.get('inputAssets', [])]
        identity_matches = inputs == [source] and target in task.get('inputTexts', [])
        if pinned:
            if task.get('taskUuid') != pinned:
                continue
            if not identity_matches:
                raise ReconcileError('Pinned upscale task has different source or resolution')
        elif not identity_matches:
            continue
        task_id = task.get('taskUuid')
        if not task_id:
            raise ReconcileError('Matching task is missing taskUuid')
        # A copied node may expose the same task. Deduplicate by real task identity.
        if task_id in matches and matches[task_id][1] != task:
            raise ReconcileError('Conflicting copies of the same task in canvas')
        matches.setdefault(task_id, (node, task))
    result = copy.deepcopy(record)
    result['automatic_resubmit_allowed'] = False
    result['canvas_revision'] = canvas.get('revision')
    if not matches:
        result.update(phase='NOT_FOUND_IN_CANVAS', next_action='Inspect task history; do not resubmit')
        return result
    if len(matches) != 1:
        raise ReconcileError('Multiple upscale tasks match; pin the accepted task UUID before continuing')
    node, task = next(iter(matches.values()))
    result.update(upscale_node_uuid=node['uuid'], upscale_task_uuid=task['taskUuid'],
                  status=task.get('status'), observed_task_model=task['modelCode'])
    if task.get('status') != 'COMPLETE':
        result.update(phase='TASK_' + str(task.get('status') or 'UNKNOWN'),
                      next_action='Read task/canvas again; never submit as a polling action')
        return result
    outputs = task.get('resultAssets') or []
    if len(outputs) != 1 or not outputs[0].get('assetsUuid'):
        raise ReconcileError('Completed upscale does not identify exactly one output asset')
    output = outputs[0]
    media = output.get('metaData') or {}
    result.update(upscale_asset_uuid=output['assetsUuid'], output_media=media,
                  source_media=task['inputAssets'][0].get('metaData') or {},
                  phase='COMPLETE_PENDING_FILE_QA', next_action='Download exact output asset and decode; verify audio and dimensions')
    # The outer asset width/height can still carry the original dimensions.
    result['metadata_resolution_matches'] = (
        target == '1080P' and min(media.get('width') or 0, media.get('height') or 0) == 1080)
    result['technical_qa'] = 'PENDING'
    return result


def reconcile_batch(batch, snapshot):
    records = batch.get('records')
    if not isinstance(records, list) or not records:
        raise ReconcileError('Batch must contain a nonempty records array')
    results = []
    errors = 0
    for index, record in enumerate(records):
        try:
            if not isinstance(record, dict):
                raise ReconcileError('Each record must be an object')
            observed = reconcile(record, snapshot)
        except (ReconcileError, KeyError) as exc:
            errors += 1
            observed = copy.deepcopy(record) if isinstance(record, dict) else {}
            observed.update(phase='RECONCILE_REQUIRED', error=str(exc),
                            record_index=index, automatic_resubmit_allowed=False)
        results.append(observed)
    return {'records': results, 'record_count': len(results), 'error_count': errors,
            'automatic_resubmit_allowed': False}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    inputs = parser.add_mutually_exclusive_group(required=True)
    inputs.add_argument('--record', type=Path)
    inputs.add_argument('--batch', type=Path)
    parser.add_argument('--canvas', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    record_path = args.record or args.batch
    if args.output.resolve() in (record_path.resolve(), args.canvas.resolve()):
        parser.error('Output must not overwrite either evidence input')
    handler = reconcile if args.record else reconcile_batch
    result = handler(json.loads(record_path.read_text(encoding='utf-8-sig')),
                     json.loads(args.canvas.read_text(encoding='utf-8-sig')))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    temporary = args.output.with_suffix(args.output.suffix + '.tmp')
    temporary.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    temporary.replace(args.output)
    print(json.dumps(result, ensure_ascii=False, indent=2))
