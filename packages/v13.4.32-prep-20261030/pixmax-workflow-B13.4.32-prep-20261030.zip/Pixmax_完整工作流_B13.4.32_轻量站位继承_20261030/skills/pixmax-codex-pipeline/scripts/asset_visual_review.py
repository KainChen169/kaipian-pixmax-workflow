"""Validate human/agent image-review evidence; this module does not inspect pixels."""
import hashlib
from pathlib import Path
from pixmax_pipeline import PipelineError
from state_board_review import validate_state_board_review
from black_video_reference import expected_order
from seedance25_contract import SEEDANCE25_MODELS

POLICY = 'asset_visual_review_v1'


def validate_continuity_review(shot, review, fail):
    evidence = review.get('continuity_review')
    required = (shot.get('workflow_policy') == 'pixmax_dual_modules_v1' or
                shot['params'].get('model') in SEEDANCE25_MODELS or
                shot.get('prompt_role') in ('seedance25_30s', 'seedance25_v134'))
    if not required and evidence is None:
        return
    if not isinstance(evidence, dict) or evidence.get('policy') != 'cross_episode_continuity_v1' or evidence.get('status') != 'PASS':
        fail('requires completed cross-episode continuity evidence')
    if not isinstance(evidence.get('scope'), str) or not evidence['scope'].strip():
        fail('requires the actual reviewed story scope')
    sources = evidence.get('sources')
    if not isinstance(sources, list) or not sources:
        fail('requires all reviewed script sources')
    paths = set()
    for source in sources:
        if not isinstance(source, dict) or not isinstance(source.get('file'), str):
            fail('has an invalid continuity source')
        path = Path(source['file'])
        if not path.is_absolute() or not path.is_file():
            fail('requires an existing absolute continuity source path')
        if hashlib.sha256(path.read_bytes()).hexdigest() != source.get('sha256'):
            fail('is stale after a cross-episode script change')
        resolved = path.resolve()
        if resolved in paths:
            fail('has duplicate continuity sources')
        paths.add(resolved)
    if Path(review['script_file']).resolve() not in paths:
        fail('continuity sources must include the reviewed shot script')
    ledger_value = evidence.get('ledger_file')
    if not isinstance(ledger_value, str) or not ledger_value.strip():
        fail('requires a continuity ledger')
    ledger = Path(ledger_value)
    if not ledger.is_absolute() or not ledger.is_file() or hashlib.sha256(ledger.read_bytes()).hexdigest() != evidence.get('ledger_sha256'):
        fail('continuity ledger is missing or changed')
    checks = evidence.get('checks')
    if not isinstance(checks, dict):
        fail('requires continuity checks')
    for key in ('character_state', 'scene_daynight', 'blocking_facing', 'prop_continuity'):
        check = checks.get(key)
        if not isinstance(check, dict) or check.get('status') != 'PASS' or not isinstance(check.get('observation'), str) or not check['observation'].strip():
            fail('continuity check missing or unresolved: ' + key)


def validate_visual_review(shot, nodes):
    if shot['params'].get('nodeType') != 'GENERATE_VIDEO':
        return
    uid = shot['node_uuid']
    review = shot.get('visual_review') or {}
    def fail(message):
        raise PipelineError(uid + ': visual review ' + message)
    if review.get('policy') != POLICY or review.get('status') != 'PASS':
        fail('is missing or not PASS; inspect the actual connected images first')
    if review.get('node_uuid') != uid:
        fail('belongs to another video node')
    prompt_hash = hashlib.sha256(shot['params']['prompt'].encode('utf-8')).hexdigest()
    if review.get('prompt_sha256') != prompt_hash:
        fail('is stale after prompt changes')
    script = review.get('script_file')
    if not script or not Path(script).is_file():
        fail('requires the reviewed script file')
    if hashlib.sha256(Path(script).read_bytes()).hexdigest() != review.get('script_sha256'):
        fail('is stale after script changes')
    for key in ('script_location', 'shot_assessment', 'reviewed_at'):
        if not isinstance(review.get(key), str) or not review[key].strip():
            fail('requires ' + key)
    validate_continuity_review(shot, review, fail)
    images = review.get('images')
    bindings = shot.get('bindings', [])
    if expected_order(shot, nodes) != shot['prevNodeUuids']:
        fail('connection-only video or image input order changed')
    if not isinstance(images, list) or len(images) != len(bindings):
        fail('must cover every connected image, including reference boards')
    if any(not isinstance(row, dict) for row in images):
        fail('image records must be objects')
    if [row.get('node_uuid') for row in images] != [b['node_uuid'] for b in bindings]:
        fail('image order does not match current connections')
    for row, binding in zip(images, bindings):
        source = nodes.get(binding['node_uuid'], {})
        asset_uuid = (source.get('defaultAsset') or {}).get('assetsUuid')
        if not asset_uuid or row.get('asset_uuid') != asset_uuid:
            fail('is stale after an upstream image replacement')
        if row.get('category') != binding['category']:
            fail('image category does not match binding')
        if row.get('viewed') is not True or row.get('status') != 'PASS':
            fail('contains an unseen, unclear or mismatched image')
        if binding.get('reference_kind') == 'character_state_board' or source.get('reference_kind') == 'character_state_board':
            if row.get('reference_kind') != 'character_state_board':
                fail('state-board binding is missing its per-view review declaration')
        validate_state_board_review(row)
        for key in ('view_evidence', 'requirement', 'observation'):
            if not isinstance(row.get(key), str) or not row[key].strip():
                fail('image record requires ' + key)


def visual_review_errors(manifest, nodes, ready):
    by_node = {node['uuid']: node for node in nodes}
    ready_set = set(ready)
    errors = []
    for shot in manifest['shots']:
        if shot['node_uuid'] not in ready_set:
            continue
        try:
            validate_visual_review(shot, by_node)
        except (PipelineError, OSError) as exc:
            errors.append({'node_uuid': shot['node_uuid'], 'reason': str(exc)})
    return errors
