"""Offline contract for v13.4 prompt duration and first-image blocking input."""
import math
import re
from pixmax_pipeline import PipelineError

ROLE = 'seedance25_v134'
DEFAULT_VIDEO_MODEL = 'PIXDANCE_2_5_DRAFT'
SEEDANCE25_MODELS = frozenset(('PIXDANCE_2_5', DEFAULT_VIDEO_MODEL))
VIDEO_SPEC = {'resolution': '480P', 'aspectRatio': '9:16', 'includeAudio': True}


def validate_video_spec(params, *, required=False):
    """New/preflight Seedance 2.5 video nodes must carry explicit delivery settings.

    Does not mutate input or apply to image nodes, other models, or status queries.
    """
    if params.get('nodeType') != 'GENERATE_VIDEO':
        if required:
            raise PipelineError('Seedance 2.5 requires a GENERATE_VIDEO node')
        return
    model = params.get('model')
    if model not in SEEDANCE25_MODELS and not required:
        return
    if model != DEFAULT_VIDEO_MODEL:
        raise PipelineError('Seedance 2.5 requires model=' + DEFAULT_VIDEO_MODEL + ' (Draft); no standard-model fallback')
    for field in ('resolution', 'aspectRatio'):
        if params.get(field) != VIDEO_SPEC[field]:
            raise PipelineError('Seedance 2.5 requires explicit ' + field + '=' + VIDEO_SPEC[field])
    audio = params.get('includeAudio')
    if not (audio is True or (type(audio) is str and audio == 'true')):
        raise PipelineError('Seedance 2.5 requires explicit includeAudio=true (sound enabled)')
    if 'duration' in params:
        value = params['duration']
        try: seconds = float(value)
        except (ValueError, TypeError, OverflowError):
            raise PipelineError('Invalid Seedance 2.5 duration') from None
        if isinstance(value, bool) or not math.isfinite(seconds) or not 0 < seconds <= 30:
            raise PipelineError('Seedance 2.5 segment must be positive and at most 30 seconds')


def prepare_video_spec(params, *, required=False):
    """Fill omitted fields in a new execution copy; never normalize wrong values."""
    if required and params.get('nodeType') == 'GENERATE_VIDEO':
        params.setdefault('model', DEFAULT_VIDEO_MODEL)
    if params.get('nodeType') == 'GENERATE_VIDEO' and params.get('model') == DEFAULT_VIDEO_MODEL:
        for field, value in VIDEO_SPEC.items():
            params.setdefault(field, value)
    validate_video_spec(params, required=required)
    return params
SHOTS = re.compile(r'^###\s*镜头\s*\d+\s*[｜|]\s*(\d+(?:\.\d+)?)\s*[–—-]\s*(\d+(?:\.\d+)?)\s*秒', re.M)


def input_categories(role):
    ordinary = ('character', 'scene', 'prop', 'storyboard_reference')
    return ordinary


def validate_input_order(bindings, role):
    categories = input_categories(role)
    # Existing saved manifests keep their exact legacy input order for readback.
    if any(b.get('category') == 'blocking_reference' for b in bindings):
        categories = ('blocking_reference',) + categories
    if any(b.get('category') not in categories for b in bindings):
        raise PipelineError('Unknown input category')
    ranks = [categories.index(b['category']) for b in bindings]
    if ranks != sorted(ranks):
        raise PipelineError('Input order required: ' + ' -> '.join(categories))
    for category in ('blocking_reference', 'storyboard_reference'):
        if sum(b['category'] == category for b in bindings) > 1:
            raise PipelineError('At most one ' + category)




def validate_legacy_origin(origin, ranges):
    """Grandfather only a byte-locked delivered v13.3 source with real provenance."""
    import hashlib, json
    from pathlib import Path
    if not isinstance(origin,dict) or origin.get('policy') != 'locked_seedance25_v133' or origin.get('director_version') != '13.3.0':
        raise PipelineError('Invalid locked legacy timeline origin')
    def evidence(path_key,hash_key):
        p=Path(origin.get(path_key,''))
        if not p.is_absolute() or not p.is_file():raise PipelineError('Legacy origin file missing: '+path_key)
        raw=p.read_bytes()
        if hashlib.sha256(raw).hexdigest()!=origin.get(hash_key):raise PipelineError('Stale legacy origin: '+path_key)
        return p,raw
    record_path,raw=evidence('verification_file','verification_sha256')
    record=json.loads(raw.decode('utf-8-sig'))
    entries=[r for r in record.get('nodes',[]) if r.get('id')==origin.get('segment_id')]
    if len(entries)!=1 or record.get('authority')!='existing delivered local source; no narrative rewrite':
        raise PipelineError('Legacy origin must match a real delivered-source record')
    row=entries[0]
    source,source_bytes=evidence('source_prompt_file','source_sha256')
    authority,authority_bytes=evidence('authority_file','authority_sha256')
    if (Path(row.get('source_file','')).resolve()!=source.resolve() or Path(row.get('authority_file','')).resolve()!=authority.resolve()
        or row.get('source_sha256')!=origin['source_sha256'] or row.get('authority_sha256')!=origin['authority_sha256']
        or row.get('full_prompt_readback')!='PASS' or source_bytes!=authority_bytes):
        raise PipelineError('Legacy prompt differs from its locked delivered authority')
    authority_ranges=[(float(a),float(b)) for a,b in SHOTS.findall(authority_bytes.decode('utf-8-sig'))]
    if ranges!=authority_ranges:
        raise PipelineError('Legacy actual timeline differs from delivered source')
    return True


def generation_duration(value):
    """Ceil a positive natural duration; model-supported values are checked separately."""
    if isinstance(value, bool):
        raise PipelineError('Invalid duration')
    try:
        seconds = float(value)
    except (ValueError, TypeError, OverflowError):
        raise PipelineError('Invalid duration') from None
    if not math.isfinite(seconds) or seconds <= 0:
        raise PipelineError('Invalid duration')
    return math.ceil(seconds)


def natural_duration(prompt):
    header = prompt.split('\n## ', 1)[0]
    found = re.findall(r'(?:总时长|时长)\s*[：:｜|]?\s*(\d+(?:\.\d+)?)\s*秒', header)
    if len(found) != 1:
        raise PipelineError('Prompt requires one natural duration in header')
    value = float(found[0])
    generation_duration(value)
    return value


def validate_duration(prompt, params, supported, legacy_origin=None):
    if params.get('nodeType') != 'GENERATE_VIDEO' or params.get('model') != DEFAULT_VIDEO_MODEL or params.get('referModel') != 'referToVideo':
        raise PipelineError('seedance25_v134 requires PIXDANCE_2_5_DRAFT multi-reference video mode')
    if not isinstance(supported, list) or not supported or any(type(v) != int or v <= 0 for v in supported):
        raise PipelineError('Current schema supported_durations required')
    value = params.get('duration')
    if isinstance(value, bool): raise PipelineError('Invalid duration')
    try: seconds = float(value)
    except (ValueError, TypeError): raise PipelineError('Invalid duration') from None
    if not math.isfinite(seconds) or not seconds.is_integer() or int(seconds) not in supported:
        raise PipelineError('Duration is not supported by the recorded model schema')
    natural = natural_duration(prompt)
    if generation_duration(natural) != seconds:
        raise PipelineError('Prompt header and generation duration differ')
    ranges = [(float(a), float(b)) for a,b in SHOTS.findall(prompt)]
    if not ranges or len(ranges) != len(re.findall(r'^###\s*镜头\s*\d+', prompt, re.M)):
        raise PipelineError('Every actual shot needs a parseable timeline')
    if legacy_origin is not None:
        validate_legacy_origin(legacy_origin, ranges)
    end = 0.0
    for start, stop in ranges:
        if abs(start-end) > 1e-6 or stop <= start:
            raise PipelineError('Timeline gap/overlap or non-positive shot duration')
        end = stop
    if abs(end-natural) > 1e-6:
        raise PipelineError('Timeline end and prompt natural duration differ')
    return int(seconds)
