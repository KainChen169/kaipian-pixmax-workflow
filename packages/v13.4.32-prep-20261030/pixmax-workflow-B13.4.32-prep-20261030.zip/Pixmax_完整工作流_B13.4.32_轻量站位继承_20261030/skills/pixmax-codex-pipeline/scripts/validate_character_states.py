"""Validate recorded 15s state plans; never infer image necessity or inspect pixels.

Legacy rows default to state_image. Prompt/tolerance plans reuse a reviewed mother
image; their absence of a distinct state PNG is not a missing-image condition.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import re
from pathlib import Path
from pixmax_pipeline import PipelineError, atomic_json

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def validate(ledger: dict, base: Path):
    episode_files=ledger.get('episode_prompt_files')
    if not isinstance(episode_files,list) or not episode_files:
        raise PipelineError('episode_prompt_files with hashes required')
    expected=set()
    for item in episode_files:
        path=(base/item['path']).resolve()
        if not path.is_file() or sha(path)!=item['sha256']:
            raise PipelineError('Episode prompt changed/missing: '+item['path'])
        for ep,num in re.findall(r'^# 第(\d+)集｜镜头(\d+)｜[^\n]*15秒完整视频执行提示词\s*$',path.read_text(encoding='utf-8-sig'),re.M):
            sid=f'EP{int(ep):02d}_S{int(num):03d}'
            if sid in expected:raise PipelineError('Duplicate episode shot: '+sid)
            expected.add(sid)
    reviewed=ledger.get('reviewed_shots')
    if not expected or not isinstance(reviewed,list) or set(reviewed)!=expected or len(reviewed)!=len(expected):
        raise PipelineError('Each 15s shot needs an explicit character-state review')
    transitions=ledger.get('transitions')
    if not isinstance(transitions,list):raise PipelineError('transitions array required')
    checked=[];seen=set()
    for row in transitions:
        key=(row.get('shot_id'),row.get('character'),row.get('to_state'))
        if any(not x for x in key) or key in seen:raise PipelineError('Empty/duplicate state transition')
        if key[0] not in expected:raise PipelineError('Transition not in reviewed episode: '+str(key))
        seen.add(key)
        for field in ('from_state','trigger','visible_from','visible_until','mother_image','mother_sha256','review'):
            if not row.get(field):raise PipelineError(str(key)+': missing '+field)
        mode=row.get('implementation','state_image')
        if mode not in ('state_image','prompt','tolerance'):
            raise PipelineError(str(key)+': unknown state implementation')
        mother=(base/row['mother_image']).resolve()
        if not mother.is_file() or sha(mother)!=row['mother_sha256']:
            raise PipelineError(str(key)+': source image missing/changed')
        if not isinstance(row['review'],dict) or any(row['review'].get(k)!='PASS' for k in ('same_face','same_person','outfit_continuity','script_state','non_graphic')):
            raise PipelineError(str(key)+': visual review incomplete or failed')
        if mode=='state_image':
            for field in ('state_image','state_sha256'):
                if not row.get(field):raise PipelineError(str(key)+': missing '+field)
            target=(base/row['state_image']).resolve()
            if not target.is_file() or sha(target)!=row['state_sha256']:
                raise PipelineError(str(key)+': state image missing/changed')
            if mother==target:raise PipelineError(str(key)+': state_image plan requires a distinct asset; record a reviewed prompt/tolerance plan instead')
            asset=row['state_image']
        else:
            if not isinstance(row.get('reason'),str) or not row['reason'].strip():
                raise PipelineError(str(key)+': non-image plan needs a necessity/visibility reason')
            if mode=='prompt' and (not isinstance(row.get('prompt_state'),str) or not row['prompt_state'].strip()):
                raise PipelineError(str(key)+': prompt plan needs the corresponding shot state expression')
            asset=row['mother_image']
        checked.append({'shot_id':key[0],'character':key[1],'state':key[2],'asset':asset,
                        'implementation':mode,'ready':True})
    return {'reviewed_shots':len(expected),'transitions':checked,'ready':True,'face_check':'HUMAN_VISUAL_REVIEW_RECORDED'}

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--ledger',type=Path,required=True);p.add_argument('--output',type=Path)
    a=p.parse_args();result=validate(json.loads(a.ledger.read_text(encoding='utf-8-sig')),a.ledger.parent)
    if a.output:atomic_json(a.output,result)
    print(json.dumps(result,ensure_ascii=False,indent=2))
