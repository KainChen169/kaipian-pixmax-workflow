"""Portable launcher for the tested high-level Pixmax CLI 1.3.0 overlay."""
from __future__ import annotations
import os
import subprocess
import sys
from pathlib import Path

PACKAGE=Path(__file__).resolve().parent.parent
OVERLAY=PACKAGE/'runtime-overlay'
if not (OVERLAY/'pixmax/pixmax_cli.py').is_file():
    raise SystemExit('Missing runtime-overlay/pixmax/pixmax_cli.py')
runtime_root=Path(os.environ.get('PIXMAX_CLI_HOME',str(Path.home()/'.pixmax-cli')))/'runtime/versions'
candidate=runtime_root/'100012-1.3.0/vendor'
if not candidate.is_dir():
    raise SystemExit('Expected Pixmax CLI 1.3.0/build100012 installation. Install bundled official CLI first; do not run this overlay against another version.')
env=os.environ.copy()
env['PYTHONPATH']=os.pathsep.join((str(OVERLAY),str(candidate)))
env.setdefault('PIXMAX_CLI_HOME',str(Path.home()/'.pixmax-cli'))
env.setdefault('NO_PROXY','app.pixmax.cn,pixmax-prod.oss-accelerate.aliyuncs.com')
env.setdefault('PYTHONIOENCODING','utf-8')
raise SystemExit(subprocess.call([sys.executable,'-m','pixmax',*sys.argv[1:]],env=env))
