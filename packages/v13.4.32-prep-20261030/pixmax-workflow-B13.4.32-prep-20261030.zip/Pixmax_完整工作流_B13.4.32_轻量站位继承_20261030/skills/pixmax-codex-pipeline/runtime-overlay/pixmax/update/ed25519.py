"""Small, dependency-free Ed25519 verifier used by the bootstrap launcher.

The group operations are adapted from Brian Warner's MIT-licensed pure25519
0.0.1 implementation. The verifier additionally rejects non-canonical scalar
encodings. Keeping this code in the launcher avoids native dependencies while
the downloaded runtime is still untrusted.
"""

from __future__ import annotations

import hashlib

Q = 2**255 - 19
L = 2**252 + 27742317777372353535851937790883648493


class BadSignatureError(ValueError):
    """Raised when an Ed25519 signature is malformed or invalid."""


def _inverse(value: int) -> int:
    return pow(value, Q - 2, Q)


_D = -121665 * _inverse(121666) % Q
_I = pow(2, (Q - 1) // 4, Q)


def _recover_x(y: int) -> int:
    xx = (y * y - 1) * _inverse(_D * y * y + 1)
    x = pow(xx, (Q + 3) // 8, Q)
    if (x * x - xx) % Q:
        x = x * _I % Q
    if x & 1:
        x = Q - x
    return x


_BASE_Y = 4 * _inverse(5) % Q
_BASE_X = _recover_x(_BASE_Y)


def _to_extended(point: tuple[int, int]) -> tuple[int, int, int, int]:
    x, y = point
    return x % Q, y % Q, 1, x * y % Q


def _to_affine(point: tuple[int, int, int, int]) -> tuple[int, int]:
    x, y, z, _ = point
    inverse_z = _inverse(z)
    return x * inverse_z % Q, y * inverse_z % Q


def _double(point: tuple[int, int, int, int]) -> tuple[int, int, int, int]:
    x1, y1, z1, _ = point
    a = x1 * x1
    b = y1 * y1
    c = 2 * z1 * z1
    d = -a % Q
    e = ((x1 + y1) * (x1 + y1) - a - b) % Q
    g = (d + b) % Q
    f = (g - c) % Q
    h = (d - b) % Q
    return e * f % Q, g * h % Q, f * g % Q, e * h % Q


def _add(
    first: tuple[int, int, int, int],
    second: tuple[int, int, int, int],
) -> tuple[int, int, int, int]:
    x1, y1, z1, t1 = first
    x2, y2, z2, t2 = second
    a = (y1 - x1) * (y2 - x2) % Q
    b = (y1 + x1) * (y2 + x2) % Q
    c = t1 * (2 * _D) * t2 % Q
    d = z1 * 2 * z2 % Q
    e = (b - a) % Q
    f = (d - c) % Q
    g = (d + c) % Q
    h = (b + a) % Q
    return e * f % Q, g * h % Q, f * g % Q, e * h % Q


_ZERO = _to_extended((0, 1))
_BASE = _to_extended((_BASE_X, _BASE_Y))


def _scalar_multiply(
    point: tuple[int, int, int, int], scalar: int
) -> tuple[int, int, int, int]:
    if scalar < 0:
        raise ValueError("Ed25519 scalar must be non-negative")
    result = _ZERO
    addend = point
    while scalar:
        if scalar & 1:
            result = _add(result, addend)
        addend = _double(addend)
        scalar >>= 1
    return result


def _is_zero(point: tuple[int, int, int, int]) -> bool:
    x, y, z, _ = point
    return x % Q == 0 and y % Q == z % Q and y % Q != 0


def _decode_point(encoded: bytes) -> tuple[int, int, int, int]:
    if len(encoded) != 32:
        raise BadSignatureError("Ed25519 point must be 32 bytes")
    raw = int.from_bytes(encoded, "little")
    y = raw & ((1 << 255) - 1)
    if y >= Q:
        raise BadSignatureError("Ed25519 point encoding is not canonical")
    x = _recover_x(y)
    if bool(x & 1) != bool(raw & (1 << 255)):
        x = Q - x
    if (-x * x + y * y - 1 - _D * x * x * y * y) % Q:
        raise BadSignatureError("Ed25519 point is not on the curve")
    point = _to_extended((x, y))
    if _is_zero(point) or not _is_zero(_scalar_multiply(point, L)):
        raise BadSignatureError("Ed25519 point is not in the prime-order subgroup")
    return point


def _encode_point(point: tuple[int, int, int, int]) -> bytes:
    x, y = _to_affine(point)
    value = y | ((x & 1) << 255)
    return value.to_bytes(32, "little")


def verify(public_key: bytes, signature: bytes, message: bytes) -> None:
    """Verify an Ed25519 signature or raise :class:`BadSignatureError`."""
    if len(public_key) != 32:
        raise BadSignatureError("Ed25519 public key must be 32 bytes")
    if len(signature) != 64:
        raise BadSignatureError("Ed25519 signature must be 64 bytes")
    encoded_r = signature[:32]
    scalar_s = int.from_bytes(signature[32:], "little")
    if scalar_s >= L:
        raise BadSignatureError("Ed25519 signature scalar is not canonical")
    point_r = _decode_point(encoded_r)
    point_a = _decode_point(public_key)
    challenge = (
        int.from_bytes(
            hashlib.sha512(encoded_r + public_key + message).digest(), "little"
        )
        % L
    )
    left = _scalar_multiply(_BASE, scalar_s)
    right = _add(point_r, _scalar_multiply(point_a, challenge))
    if _encode_point(left) != _encode_point(right):
        raise BadSignatureError("Ed25519 signature verification failed")
