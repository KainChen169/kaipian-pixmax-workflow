"""Pixmax CLI package."""

__version__ = "1.3.0"
__build__ = 10200
