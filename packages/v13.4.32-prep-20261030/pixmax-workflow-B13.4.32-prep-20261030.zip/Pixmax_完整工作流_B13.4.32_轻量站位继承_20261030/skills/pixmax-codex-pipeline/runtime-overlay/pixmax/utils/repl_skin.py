"""Small REPL skin for the Pixmax CLI interactive mode."""

from __future__ import annotations

from pathlib import Path


class ReplSkin:
    """Minimal prompt-toolkit wrapper for the interactive REPL."""

    def __init__(self, name: str, version: str = "1.0.0"):
        self.name = name
        self.version = version

    def print_banner(self) -> None:
        print(f"{self.name} CLI {self.version}")
        skill_path = self.skill_path()
        if skill_path:
            print(f"Skill: {skill_path}")
        print("Type 'help' for commands, 'exit' to quit.")

    def skill_path(self) -> str | None:
        path = Path(__file__).resolve().parents[1] / "skills" / "SKILL.md"
        return str(path) if path.exists() else None

    def create_prompt_session(self):
        try:
            from prompt_toolkit import PromptSession

            return PromptSession()
        except Exception:
            return None

    def get_input(self, pt_session=None, project_name: str | None = None, modified: bool = False) -> str:
        marker = "*" if modified else ""
        prefix = f"{self.name}"
        if project_name:
            prefix += f":{project_name}"
        prompt = f"{prefix}{marker}> "
        if pt_session is not None:
            return pt_session.prompt(prompt)
        return input(prompt)

    def help(self, commands: dict[str, str]) -> None:
        for name, desc in commands.items():
            print(f"  {name:<22} {desc}")

    def success(self, message: str) -> None:
        print(f"OK: {message}")

    def error(self, message: str) -> None:
        print(f"Error: {message}")

    def warning(self, message: str) -> None:
        print(f"Warning: {message}")

    def info(self, message: str) -> None:
        print(message)

    def status(self, key: str, value) -> None:
        print(f"{key}: {value}")

    def print_goodbye(self) -> None:
        print("Goodbye.")
