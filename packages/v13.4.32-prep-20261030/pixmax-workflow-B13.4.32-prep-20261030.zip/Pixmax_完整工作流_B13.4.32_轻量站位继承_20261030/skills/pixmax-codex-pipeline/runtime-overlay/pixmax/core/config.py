"""Persistent CLI settings and runtime environment resolution."""

from __future__ import annotations

import json
import locale as system_locale
import os
from pathlib import Path
from typing import Any
from urllib.parse import urlparse


ENV_ENVIRONMENT = "PIXMAX_ENV"
ENV_LOCALE = "PIXMAX_LOCALE"
ENV_CONFIG_FILE = "PIXMAX_CONFIG_FILE"
ENV_CLI_HOME = "PIXMAX_CLI_HOME"

ENVIRONMENTS = {
    "cn": {
        "appUrl": "https://app.pixmax.cn",
        "apiBaseUrl": "https://app.pixmax.cn/user/api",
    },
    "global": {
        "appUrl": "https://console.pixmax.ai",
        "apiBaseUrl": "https://console.pixmax.ai/user/api",
    },
}

_ENVIRONMENT_ALIASES = {
    "cn": "cn",
    "china": "cn",
    "mainland": "cn",
    "global": "global",
    "international": "global",
    "intl": "global",
    "overseas": "global",
}


def normalize_environment(value: str | None) -> str | None:
    if value is None or not value.strip():
        return None
    normalized = _ENVIRONMENT_ALIASES.get(value.strip().lower())
    if not normalized:
        choices = ", ".join(ENVIRONMENTS)
        raise ValueError(f"Unknown Pixmax environment: {value}. Expected one of: {choices}.")
    return normalized


def environment_for_base_url(base_url: str | None) -> str | None:
    if not base_url:
        return None
    hostname = (urlparse(base_url).hostname or "").lower()
    if hostname == "app.pixmax.cn":
        return "cn"
    if hostname == "console.pixmax.ai":
        return "global"
    return None


def normalize_locale(value: str | None) -> str | None:
    if value is None or not value.strip():
        return None
    normalized = value.strip().replace("_", "-").split(".", 1)[0]
    if normalized.lower().startswith("zh"):
        return "zh-CN"
    return "en"


def detected_locale() -> str:
    for name in ("LC_ALL", "LC_MESSAGES", "LANG"):
        value = os.environ.get(name)
        if value:
            return normalize_locale(value) or "en"
    try:
        value = system_locale.getlocale()[0]
    except (ValueError, TypeError):
        value = None
    return normalize_locale(value) or "en"


class PixmaxConfig:
    """Small owner-only settings file, separate from environment-scoped session data."""

    def __init__(self, config_file: str | None = None):
        cli_home = Path(os.environ.get(ENV_CLI_HOME, Path.home() / ".pixmax-cli"))
        self.config_file = config_file or os.environ.get(ENV_CONFIG_FILE) or str(
            cli_home / "config.json"
        )
        self.environment: str | None = None
        self.locale: str | None = None
        self._load()

    def _load(self) -> None:
        try:
            with open(self.config_file, "r", encoding="utf-8") as fh:
                data = json.load(fh)
        except (FileNotFoundError, OSError, json.JSONDecodeError):
            return
        if not isinstance(data, dict):
            return
        try:
            self.environment = normalize_environment(data.get("environment"))
        except ValueError:
            self.environment = None
        self.locale = normalize_locale(data.get("locale"))

    def save(self) -> None:
        path = Path(self.config_file)
        path.parent.mkdir(parents=True, exist_ok=True)
        data = {
            "environment": self.environment,
            "locale": self.locale,
        }
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass

    def set(self, *, environment: str | None = None, locale: str | None = None) -> None:
        if environment is not None:
            self.environment = normalize_environment(environment)
        if locale is not None:
            self.locale = normalize_locale(locale)
        self.save()

    def initialize(self, *, environment: str | None = None, locale: str | None = None) -> bool:
        changed = False
        if self.environment is None and environment is not None:
            self.environment = normalize_environment(environment)
            changed = True
        if self.locale is None and locale is not None:
            self.locale = normalize_locale(locale)
            changed = True
        if changed:
            self.save()
        return changed

    def status(self) -> dict[str, Any]:
        return {
            "environment": self.environment,
            "locale": self.locale,
            "configFile": self.config_file,
        }


def resolve_environment(
    explicit: str | None,
    explicit_base_url: str | None,
    config: PixmaxConfig,
) -> str:
    return (
        environment_for_base_url(explicit_base_url)
        or normalize_environment(explicit)
        or environment_for_base_url(os.environ.get("PIXMAX_API_BASE_URL"))
        or normalize_environment(os.environ.get(ENV_ENVIRONMENT))
        or config.environment
        or "cn"
    )


def resolve_locale(explicit: str | None, config: PixmaxConfig) -> str:
    return (
        normalize_locale(explicit)
        or normalize_locale(os.environ.get(ENV_LOCALE))
        or config.locale
        or detected_locale()
    )
