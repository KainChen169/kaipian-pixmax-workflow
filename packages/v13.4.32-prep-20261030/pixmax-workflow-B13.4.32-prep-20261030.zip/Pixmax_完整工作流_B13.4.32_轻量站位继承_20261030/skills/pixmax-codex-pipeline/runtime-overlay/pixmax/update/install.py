"""Install the stable Pixmax launcher and its initial versioned runtime."""

from __future__ import annotations

import argparse
import contextlib
import hashlib
import importlib
import importlib.util
import json
import os
import shlex
import shutil
import site
import subprocess
import sys
import sysconfig
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from pixmax.update.launcher import (
    CURRENT_SCHEMA,
    LauncherPaths,
    UpdateError,
    _atomic_write,
    _atomic_write_json,
    _read_json,
    _run_doctor,
    _safe_extract,
    validate_launcher_config,
    validate_manifest,
    verify_manifest,
)
from pixmax.update.release import ReleaseBuildError, build_runtime


_RUNTIME_DEPENDENCIES = (
    "click",
    "requests",
    "urllib3",
    "certifi",
    "idna",
    "charset_normalizer",
)


class InstallError(RuntimeError):
    """Raised when the initial launcher installation cannot complete."""


def _default_bin_dir() -> Path:
    if os.name == "nt":
        value = sysconfig.get_path("scripts", "nt_user")
        if not value:
            raise InstallError("Cannot resolve the Windows user Scripts directory")
        return Path(value)
    return Path(site.getuserbase()) / "bin"


def _backup(path: Path, install_root: Path) -> str | None:
    if not path.exists():
        return None
    legacy = install_root / "legacy"
    legacy.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    destination = legacy / f"{path.name}.{timestamp}"
    counter = 1
    while destination.exists():
        destination = legacy / f"{path.name}.{timestamp}.{counter}"
        counter += 1
    shutil.move(str(path), destination)
    return str(destination)


def _write_shim(bin_dir: Path, install_root: Path) -> tuple[Path, list[str]]:
    bin_dir.mkdir(parents=True, exist_ok=True)
    launcher = install_root / "launcher" / "launcher.py"
    backups: list[str] = []
    if os.name == "nt":
        target = bin_dir / "pixmax.cmd"
        for conflicting in (
            bin_dir / "pixmax.exe",
            bin_dir / "pixmax-script.py",
            target,
        ):
            backup = _backup(conflicting, install_root)
            if backup:
                backups.append(backup)
        python = (
            str(Path(sys.executable).resolve()).replace("%", "%%").replace('"', '""')
        )
        launcher_arg = str(launcher).replace("%", "%%").replace('"', '""')
        home_arg = str(install_root).replace("%", "%%").replace('"', '""')
        content = (
            "@echo off\r\n"
            f'set "PIXMAX_CLI_HOME={home_arg}"\r\n'
            f'"{python}" "{launcher_arg}" %*\r\n'
        )
        try:
            encoded = content.encode("mbcs")
        except UnicodeError as exc:
            raise InstallError(
                "Windows command shim paths cannot be encoded in the active code page"
            ) from exc
        _atomic_write(target, encoded)
        return target, backups

    target = bin_dir / "pixmax"
    backup = _backup(target, install_root)
    if backup:
        backups.append(backup)
    content = (
        "#!/bin/sh\n"
        f"PIXMAX_CLI_HOME={shlex.quote(str(install_root))} "
        f"exec {shlex.quote(str(Path(sys.executable).resolve()))} "
        f'{shlex.quote(str(launcher))} "$@"\n'
    )
    _atomic_write(target, content.encode("utf-8"))
    target.chmod(0o755)
    return target, backups


def _copy_launcher(source_root: Path, install_root: Path) -> None:
    source = source_root / "pixmax" / "update"
    destination = install_root / "launcher"
    destination.mkdir(parents=True, exist_ok=True)
    for name in ("launcher.py", "ed25519.py", "THIRD_PARTY_NOTICES.md"):
        source_file = source / name
        if not source_file.is_file():
            raise InstallError(f"Installer package is missing {source_file}")
        temporary = destination / f".{name}.tmp"
        shutil.copy2(source_file, temporary)
        os.replace(temporary, destination / name)


def _prepare_runtime_archive(
    source_root: Path,
    temporary: Path,
) -> tuple[Path, dict[str, Any], dict[str, Any] | None]:
    packaged_runtime = source_root / "release" / "runtime.zip"
    packaged_config = source_root / "release" / "launcher-config.json"
    if packaged_runtime.is_file() != packaged_config.is_file():
        raise InstallError(
            "Release package must contain both runtime.zip and launcher-config.json"
        )
    if packaged_runtime.is_file():
        config = validate_launcher_config(_read_json(packaged_config))
        if not config.get("updateEnabled"):
            raise InstallError(
                "Packaged launcher-config.json is not a production configuration"
            )
        manifest_path = source_root / "release" / "manifest.json"
        signature_path = source_root / "release" / "manifest.sig"
        try:
            manifest_bytes = manifest_path.read_bytes()
            signature_bytes = signature_path.read_bytes()
        except OSError as exc:
            raise InstallError(
                "Release package is missing its bootstrap manifest/signature"
            ) from exc
        public_key = config.get("publicKey")
        if not isinstance(public_key, str):
            raise InstallError("Packaged launcher config has no update public key")
        try:
            verify_manifest(manifest_bytes, signature_bytes, public_key)
            manifest = validate_manifest(
                json.loads(manifest_bytes.decode("utf-8")),
                max_artifact_size=int(config.get("maxArtifactSize", 256 * 1024 * 1024)),
            )
        except (UpdateError, UnicodeError, json.JSONDecodeError) as exc:
            raise InstallError(
                f"Bootstrap manifest verification failed: {exc}"
            ) from exc
        if packaged_runtime.stat().st_size != manifest["artifact"]["size"]:
            raise InstallError(
                "Bootstrap Runtime size does not match the signed manifest"
            )
        if (
            hashlib.sha256(packaged_runtime.read_bytes()).hexdigest()
            != manifest["artifact"]["sha256"]
        ):
            raise InstallError(
                "Bootstrap Runtime SHA-256 does not match the signed manifest"
            )
        return packaged_runtime, config, manifest

    runtime = temporary / "runtime.zip"
    try:
        # A source checkout is intentionally installable without a pre-existing
        # site-packages. Keep downloaded build dependencies in the temporary
        # directory; they are copied into the self-contained runtime ZIP and
        # never installed into the user's Python environment.
        dependency_target = temporary / "build-dependencies"
        missing = [
            name
            for name in _RUNTIME_DEPENDENCIES
            if importlib.util.find_spec(name) is None
        ]
        if missing:
            try:
                subprocess.run(
                    [
                        sys.executable,
                        "-m",
                        "pip",
                        "install",
                        "--disable-pip-version-check",
                        "--quiet",
                        "--target",
                        str(dependency_target),
                        *missing,
                    ],
                    check=True,
                    capture_output=True,
                    text=True,
                )
            except (OSError, subprocess.CalledProcessError) as exc:
                details = getattr(exc, "stderr", None) or str(exc)
                raise InstallError(
                    "Development installation needs click/requests dependencies; "
                    f"automatic temporary install failed: {details.strip()}"
                ) from exc
            sys.path.insert(0, str(dependency_target))
            importlib.invalidate_caches()
        build_runtime(source_root, runtime)
    except ReleaseBuildError as exc:
        raise InstallError(str(exc)) from exc
    return (
        runtime,
        {
            "schemaVersion": 1,
            "channel": "development",
            "updateEnabled": False,
            "manifestUrl": None,
            "publicKey": None,
            "requestTimeoutSeconds": 10,
            "lockTimeoutSeconds": 30,
            "doctorTimeoutSeconds": 60,
        },
        None,
    )


def _install_initial_runtime(
    archive: Path,
    paths: LauncherPaths,
    *,
    config: dict[str, Any],
    signed_manifest: dict[str, Any] | None,
) -> dict[str, Any]:
    stage = paths.staging / "bootstrap"
    if stage.exists():
        shutil.rmtree(stage)
    paths.staging.mkdir(parents=True, exist_ok=True)
    try:
        _safe_extract(
            archive,
            stage,
            max_files=int(config.get("maxArchiveFiles", 10_000)),
            max_unpacked_size=int(config.get("maxUnpackedSize", 512 * 1024 * 1024)),
        )
        metadata = _read_json(stage / "runtime.json")
        version = metadata.get("version")
        build_number = metadata.get("buildNumber")
        if (
            metadata.get("schemaVersion") != 1
            or not isinstance(version, str)
            or isinstance(build_number, bool)
            or not isinstance(build_number, int)
            or build_number < 1
            or not (stage / "entry.py").is_file()
            or not (stage / "app" / "pixmax" / "__init__.py").is_file()
        ):
            raise InstallError(
                "Initial runtime metadata or package structure is invalid"
            )
        if signed_manifest is not None and (
            version != signed_manifest["version"]
            or build_number != signed_manifest["buildNumber"]
        ):
            raise InstallError(
                "Initial Runtime metadata does not match the signed manifest"
            )
        _run_doctor(
            stage,
            timeout=float(config.get("doctorTimeoutSeconds", 60)),
            cli_home=paths.home,
        )
        target = paths.versions / f"{build_number}-{version}"
        paths.versions.mkdir(parents=True, exist_ok=True)
        backup_path: Path | None = None
        if target.exists():
            backup = _backup(target, paths.home)
            backup_path = Path(backup) if backup else None
        try:
            os.replace(stage, target)
        except OSError:
            if backup_path is not None and backup_path.exists() and not target.exists():
                os.replace(backup_path, target)
            raise
    except UpdateError as exc:
        raise InstallError(str(exc)) from exc
    except OSError as exc:
        raise InstallError(f"Cannot install initial runtime: {exc}") from exc
    finally:
        with contextlib.suppress(OSError):
            if stage.exists():
                shutil.rmtree(stage)
    current = {
        "schemaVersion": CURRENT_SCHEMA,
        "version": version,
        "buildNumber": build_number,
        "runtimeDir": target.relative_to(paths.home).as_posix(),
        "activatedAt": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }
    _atomic_write_json(paths.current, current)
    return current


def _run_runtime_command(runtime: Path, args: list[str], *, cli_home: Path) -> None:
    environment = os.environ.copy()
    environment["PIXMAX_CLI_HOME"] = str(cli_home)
    result = subprocess.run(
        [sys.executable, str(runtime / "entry.py"), *args],
        env=environment,
        check=False,
    )
    if result.returncode:
        raise InstallError(
            f"Initial runtime command failed with exit code {result.returncode}"
        )


def install(
    source_root: str | Path,
    *,
    environment: str,
    locale: str | None,
    install_root: str | Path,
    bin_dir: str | Path | None = None,
) -> dict[str, Any]:
    source_root = Path(source_root).resolve()
    install_root = Path(install_root).expanduser().resolve()
    if environment not in {"cn", "global"}:
        raise InstallError("environment must be cn or global")
    if locale not in {None, "", "zh-CN", "en"}:
        raise InstallError("locale must be zh-CN or en")
    if install_root == Path(install_root.anchor):
        raise InstallError(
            "Refusing to use a filesystem root as the Pixmax install directory"
        )
    paths = LauncherPaths(install_root)
    with tempfile.TemporaryDirectory(prefix="pixmax-install-") as temporary_name:
        archive, config, signed_manifest = _prepare_runtime_archive(
            source_root,
            Path(temporary_name),
        )
        _copy_launcher(source_root, install_root)
        current = _install_initial_runtime(
            archive,
            paths,
            config=config,
            signed_manifest=signed_manifest,
        )
    config = {
        **config,
        "installedPython": str(Path(sys.executable).resolve()),
        "installedAt": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }
    _atomic_write_json(paths.config, config)
    shim, backups = _write_shim(
        Path(bin_dir).expanduser().resolve() if bin_dir else _default_bin_dir(),
        install_root,
    )
    runtime = (install_root / current["runtimeDir"]).resolve()
    config_args = ["--json", "config", "init", "--environment", environment]
    if locale:
        config_args.extend(["--locale", locale])
    _run_runtime_command(runtime, config_args, cli_home=install_root)
    _run_doctor(
        runtime,
        timeout=float(config.get("doctorTimeoutSeconds", 60)),
        cli_home=install_root,
    )
    return {
        "ok": True,
        "installRoot": str(install_root),
        "command": str(shim),
        "channel": config["channel"],
        "updateEnabled": config["updateEnabled"],
        "version": current["version"],
        "buildNumber": current["buildNumber"],
        "backups": backups,
    }


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-dir", required=True)
    parser.add_argument("--environment", choices=("cn", "global"), required=True)
    parser.add_argument("--locale", choices=("zh-CN", "en"), default=None)
    parser.add_argument("--install-root", required=True)
    parser.add_argument("--bin-dir", default=None)
    return parser


def main(argv: list[str] | None = None) -> None:
    args = _parser().parse_args(argv)
    try:
        result = install(
            args.source_dir,
            environment=args.environment,
            locale=args.locale,
            install_root=args.install_root,
            bin_dir=args.bin_dir,
        )
    except (InstallError, UpdateError, OSError) as exc:
        print(f"[pixmax-cli] Installation failed: {exc}", file=sys.stderr)
        raise SystemExit(1)
    print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
