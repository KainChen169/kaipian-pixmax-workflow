"""Persistent Pixmax CLI session state."""

from __future__ import annotations

import json
import os
from datetime import datetime
from pathlib import Path
from typing import Any


def _acquire_lock(fh) -> str | None:
    """Best-effort exclusive file lock. Returns the lock backend name or None."""
    try:
        import fcntl

        fcntl.flock(fh.fileno(), fcntl.LOCK_EX)
        return "fcntl"
    except ImportError:
        pass
    except OSError:
        return None
    try:
        import msvcrt

        fh.seek(0)
        msvcrt.locking(fh.fileno(), msvcrt.LK_LOCK, 1)
        return "msvcrt"
    except (ImportError, OSError):
        return None


def _release_lock(fh, backend: str | None) -> None:
    if backend == "fcntl":
        import fcntl

        fcntl.flock(fh.fileno(), fcntl.LOCK_UN)
    elif backend == "msvcrt":
        import msvcrt

        fh.seek(0)
        msvcrt.locking(fh.fileno(), msvcrt.LK_UNLCK, 1)


def _locked_save_json(path: str, data: dict[str, Any], **dump_kwargs) -> None:
    try:
        fh = open(path, "r+", encoding="utf-8")
    except FileNotFoundError:
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        fh = open(path, "w", encoding="utf-8")
    # The session file may hold bearer tokens; keep it owner-only where supported.
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass
    with fh:
        backend = _acquire_lock(fh)
        try:
            fh.seek(0)
            fh.truncate()
            json.dump(data, fh, **dump_kwargs)
            fh.flush()
        finally:
            try:
                _release_lock(fh, backend)
            except OSError:
                pass


class PixmaxSession:
    """Stores defaults and command history between one-shot CLI invocations."""

    def __init__(self, session_file: str | None = None, *, environment: str = "cn"):
        cli_home = Path(os.environ.get("PIXMAX_CLI_HOME", Path.home() / ".pixmax-cli"))
        self.session_file = session_file or str(
            cli_home / "session.json"
        )
        self.environment = environment
        self._environment_states: dict[str, dict[str, Any]] = {}
        self.project_uuid: str | None = None
        self.file_uuid: str | None = None
        self.project_name: str | None = None
        self.file_name: str | None = None
        self.group_name: str | None = None
        self.groups: dict[str, list[str]] = {}
        self.workflows: dict[str, dict[str, Any]] = {}
        self.auth_profiles: dict[str, dict[str, Any]] = {}
        self.active_auth_profile: str | None = None
        self.history: list[dict[str, Any]] = []
        self.max_history = 80
        self.modified = False
        self._load()

    def _load(self) -> None:
        if not os.path.exists(self.session_file):
            return
        try:
            with open(self.session_file, "r", encoding="utf-8") as fh:
                data = json.load(fh)
        except (OSError, json.JSONDecodeError):
            return
        environment_states = data.get("environments")
        if isinstance(environment_states, dict):
            self._environment_states = environment_states
            state = environment_states.get(self.environment) or {}
        else:
            # Versions before environment support always targeted the mainland service.
            self._environment_states = {"cn": data}
            state = data if self.environment == "cn" else {}
        self.project_uuid = state.get("project_uuid")
        self.file_uuid = state.get("file_uuid")
        self.project_name = state.get("project_name")
        self.file_name = state.get("file_name")
        self.group_name = state.get("group_name")
        groups = state.get("groups")
        self.groups = groups if isinstance(groups, dict) else {}
        workflows = state.get("workflows")
        self.workflows = workflows if isinstance(workflows, dict) else {}
        profiles = state.get("auth_profiles")
        self.auth_profiles = profiles if isinstance(profiles, dict) else {}
        self.active_auth_profile = state.get("active_auth_profile")
        self.history = state.get("history", [])

    def set_workspace(
        self,
        project_uuid: str | None = None,
        file_uuid: str | None = None,
        project_name: str | None = None,
        file_name: str | None = None,
    ) -> None:
        if project_uuid is not None:
            self.project_uuid = project_uuid
        if file_uuid is not None:
            self.file_uuid = file_uuid
        if project_name is not None:
            self.project_name = project_name
        if file_name is not None:
            self.file_name = file_name
        self.modified = True
        self.save()

    def set_group(self, name: str, node_uuids: list[str]) -> None:
        self.groups[name] = list(dict.fromkeys(node_uuids))
        self.group_name = name
        self.modified = True
        self.save()

    def use_group(self, name: str) -> None:
        if name not in self.groups:
            raise RuntimeError(f"Unknown group: {name}")
        self.group_name = name
        self.modified = True
        self.save()

    def unuse_group(self) -> None:
        self.group_name = None
        self.modified = True
        self.save()

    def delete_group(self, name: str) -> None:
        self.groups.pop(name, None)
        if self.group_name == name:
            self.group_name = None
        self.modified = True
        self.save()

    def set_workflow(self, name: str, definition: dict[str, Any]) -> None:
        self.workflows[name] = definition
        self.modified = True
        self.save()

    def delete_workflow(self, name: str) -> None:
        self.workflows.pop(name, None)
        self.modified = True
        self.save()

    def set_auth_profile(self, name: str, profile: dict[str, Any], *, activate: bool = True) -> None:
        self.auth_profiles[name] = profile
        if activate:
            self.active_auth_profile = name
        self.modified = True
        self.save()

    def use_auth_profile(self, name: str) -> None:
        if name not in self.auth_profiles:
            raise RuntimeError(f"Unknown auth profile: {name}")
        self.active_auth_profile = name
        self.modified = True
        self.save()

    def delete_auth_profile(self, name: str) -> None:
        self.auth_profiles.pop(name, None)
        if self.active_auth_profile == name:
            self.active_auth_profile = None
        self.modified = True
        self.save()

    def clear(self) -> None:
        self.project_uuid = None
        self.file_uuid = None
        self.project_name = None
        self.file_name = None
        self.group_name = None
        self.groups = {}
        self.workflows = {}
        self.auth_profiles = {}
        self.active_auth_profile = None
        self.history = []
        self.modified = True
        self.save()

    def add_history(self, command: str, result: Any = None) -> None:
        self.history.append(
            {
                "command": command,
                "timestamp": datetime.now().isoformat(timespec="seconds"),
                "result": result,
            }
        )
        self.history = self.history[-self.max_history :]
        self.modified = True
        self.save()

    def status(self) -> dict[str, Any]:
        return {
            "environment": self.environment,
            "project_uuid": self.project_uuid,
            "project_name": self.project_name,
            "file_uuid": self.file_uuid,
            "file_name": self.file_name,
            "group_name": self.group_name,
            "groups": self.groups,
            "workflow_count": len(self.workflows),
            "workflows": {
                name: {
                    "type": definition.get("type"),
                    "description": definition.get("description"),
                    "optionKeys": sorted((definition.get("options") or {}).keys()),
                }
                for name, definition in self.workflows.items()
                if isinstance(definition, dict)
            },
            "active_auth_profile": self.active_auth_profile,
            "auth_profile_count": len(self.auth_profiles),
            "auth_profiles": {
                name: {
                    "maskedToken": profile.get("maskedToken"),
                    "hasStoredToken": bool(profile.get("token")),
                    "unionId": profile.get("unionId"),
                    "name": profile.get("name"),
                    "accountType": profile.get("accountType"),
                    "userTier": profile.get("userTier"),
                    "maskedEmail": profile.get("maskedEmail"),
                    "maskedPhone": profile.get("maskedPhone"),
                    "updatedAt": profile.get("updatedAt"),
                    "environment": profile.get("environment"),
                    "apiBaseUrl": profile.get("apiBaseUrl"),
                }
                for name, profile in self.auth_profiles.items()
                if isinstance(profile, dict)
            },
            "history_count": len(self.history),
            "session_file": self.session_file,
            "modified": self.modified,
        }

    def save(self) -> None:
        self._environment_states[self.environment] = {
            "project_uuid": self.project_uuid,
            "project_name": self.project_name,
            "file_uuid": self.file_uuid,
            "file_name": self.file_name,
            "group_name": self.group_name,
            "groups": self.groups,
            "workflows": self.workflows,
            "auth_profiles": self.auth_profiles,
            "active_auth_profile": self.active_auth_profile,
            "history": self.history,
        }
        _locked_save_json(
            self.session_file,
            {
                "version": 2,
                "environments": self._environment_states,
            },
            indent=2,
            ensure_ascii=False,
        )
        self.modified = False
