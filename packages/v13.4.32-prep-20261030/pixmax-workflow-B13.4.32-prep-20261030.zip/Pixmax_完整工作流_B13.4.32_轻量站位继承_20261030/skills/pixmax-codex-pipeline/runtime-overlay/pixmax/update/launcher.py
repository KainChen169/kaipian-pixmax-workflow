"""Stable cross-platform launcher for fail-closed Pixmax CLI updates."""

from __future__ import annotations

import base64
import contextlib
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
import zipfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any, BinaryIO

try:
    from . import LAUNCHER_VERSION
    from .ed25519 import BadSignatureError, verify as verify_ed25519
except ImportError:  # Installed launcher files are executed outside a package.
    LAUNCHER_VERSION = 1
    from ed25519 import BadSignatureError, verify as verify_ed25519

EXIT_MANIFEST_FETCH = 70
EXIT_MANIFEST_SIGNATURE = 71
EXIT_VERSION_STATE = 72
EXIT_RUNTIME_DOWNLOAD = 73
EXIT_ARTIFACT_INVALID = 74
EXIT_INSTALL = 75
EXIT_DOCTOR = 76
EXIT_LOCK_TIMEOUT = 77

CONFIG_SCHEMA = 1
MANIFEST_SCHEMA = 1
STATE_SCHEMA = 1
CURRENT_SCHEMA = 1
RUNTIME_SCHEMA = 1

DEFAULT_TIMEOUT = 10.0
DEFAULT_LOCK_TIMEOUT = 30.0
DEFAULT_MAX_ARTIFACT_SIZE = 256 * 1024 * 1024
DEFAULT_MAX_UNPACKED_SIZE = 512 * 1024 * 1024
DEFAULT_MAX_ARCHIVE_FILES = 10_000

_VERSION_RE = re.compile(
    r"^(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)"
    r"(?:-[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?"
    r"(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$"
)
_WINDOWS_RESERVED_NAMES = {
    "con",
    "prn",
    "aux",
    "nul",
    *(f"com{number}" for number in range(1, 10)),
    *(f"lpt{number}" for number in range(1, 10)),
}


class UpdateError(RuntimeError):
    """A launcher failure with a stable process exit code."""

    def __init__(self, message: str, exit_code: int):
        super().__init__(message)
        self.exit_code = exit_code


@dataclass(frozen=True)
class LauncherPaths:
    home: Path

    @property
    def config(self) -> Path:
        return self.home / "launcher-config.json"

    @property
    def current(self) -> Path:
        return self.home / "runtime" / "current.json"

    @property
    def versions(self) -> Path:
        return self.home / "runtime" / "versions"

    @property
    def state(self) -> Path:
        return self.home / "update" / "update-state.json"

    @property
    def cached_manifest(self) -> Path:
        return self.home / "update" / "manifest.json"

    @property
    def cached_signature(self) -> Path:
        return self.home / "update" / "manifest.sig"

    @property
    def lock(self) -> Path:
        return self.home / "update" / "update.lock"

    @property
    def staging(self) -> Path:
        return self.home / "update" / "staging"

    @property
    def downloads(self) -> Path:
        return self.home / "update" / "downloads"

    @property
    def quarantine(self) -> Path:
        return self.home / "runtime" / "quarantine"


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def default_home() -> Path:
    override = os.environ.get("PIXMAX_CLI_HOME")
    return (
        Path(override).expanduser().resolve()
        if override
        else Path.home() / ".pixmax-cli"
    )


def _read_json(path: Path, *, required: bool = True) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        if not required:
            return {}
        raise UpdateError(f"Required launcher file is missing: {path}", EXIT_INSTALL)
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise UpdateError(
            f"Cannot read launcher JSON {path}: {exc}", EXIT_VERSION_STATE
        ) from exc
    if not isinstance(value, dict):
        raise UpdateError(
            f"Launcher JSON must contain an object: {path}", EXIT_VERSION_STATE
        )
    return value


def _atomic_write(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
    try:
        with temporary.open("wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except OSError as exc:
        with contextlib.suppress(OSError):
            temporary.unlink()
        raise UpdateError(
            f"Cannot atomically write {path}: {exc}", EXIT_INSTALL
        ) from exc


def _atomic_write_json(path: Path, value: dict[str, Any]) -> None:
    payload = (
        json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True).encode("utf-8")
        + b"\n"
    )
    _atomic_write(path, payload)


def _save_state(paths: LauncherPaths, **changes: Any) -> dict[str, Any]:
    state = _read_json(paths.state, required=False)
    state.update({"schemaVersion": STATE_SCHEMA, **changes})
    _atomic_write_json(paths.state, state)
    return state


def _positive_int(value: Any, name: str, *, allow_zero: bool = False) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise UpdateError(
            f"Manifest field {name} must be an integer", EXIT_VERSION_STATE
        )
    minimum = 0 if allow_zero else 1
    if value < minimum:
        raise UpdateError(
            f"Manifest field {name} must be >= {minimum}", EXIT_VERSION_STATE
        )
    return value


def _config_number(
    config: dict[str, Any],
    name: str,
    default: int | float,
    *,
    integer: bool = False,
) -> int | float:
    value = config.get(name, default)
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise UpdateError(f"Launcher config {name} must be numeric", EXIT_VERSION_STATE)
    if value <= 0:
        raise UpdateError(
            f"Launcher config {name} must be positive", EXIT_VERSION_STATE
        )
    if integer and not isinstance(value, int):
        raise UpdateError(
            f"Launcher config {name} must be an integer", EXIT_VERSION_STATE
        )
    return value


def validate_launcher_config(value: dict[str, Any]) -> dict[str, Any]:
    if value.get("schemaVersion") != CONFIG_SCHEMA:
        raise UpdateError(
            "Unsupported launcher-config schemaVersion", EXIT_VERSION_STATE
        )
    if not isinstance(value.get("channel"), str) or not value["channel"]:
        raise UpdateError("Launcher config channel is required", EXIT_VERSION_STATE)
    if not isinstance(value.get("updateEnabled"), bool):
        raise UpdateError(
            "Launcher config updateEnabled must be boolean", EXIT_VERSION_STATE
        )
    if value["updateEnabled"]:
        if not isinstance(value.get("manifestUrl"), str) or not value["manifestUrl"]:
            raise UpdateError(
                "Launcher config manifestUrl is required", EXIT_VERSION_STATE
            )
        if not isinstance(value.get("publicKey"), str) or not value["publicKey"]:
            raise UpdateError(
                "Launcher config publicKey is required", EXIT_VERSION_STATE
            )
    return value


def _parse_python_version(value: Any) -> tuple[int, int]:
    if not isinstance(value, str) or not re.fullmatch(r"\d+\.\d+", value):
        raise UpdateError(
            "Manifest minimumPython must look like 3.10", EXIT_VERSION_STATE
        )
    major, minor = value.split(".")
    return int(major), int(minor)


def validate_manifest(value: Any, *, max_artifact_size: int) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise UpdateError(
            "Update manifest must contain a JSON object", EXIT_VERSION_STATE
        )
    if value.get("schemaVersion") != MANIFEST_SCHEMA:
        raise UpdateError(
            "Unsupported update manifest schemaVersion", EXIT_VERSION_STATE
        )
    version = value.get("version")
    if not isinstance(version, str) or not _VERSION_RE.fullmatch(version):
        raise UpdateError("Manifest version is invalid", EXIT_VERSION_STATE)
    build_number = _positive_int(value.get("buildNumber"), "buildNumber")
    minimum_supported = _positive_int(
        value.get("minimumSupportedBuild", 0), "minimumSupportedBuild", allow_zero=True
    )
    minimum_launcher = _positive_int(
        value.get("minimumLauncherVersion", 1), "minimumLauncherVersion"
    )
    minimum_python = _parse_python_version(value.get("minimumPython"))
    if minimum_supported > build_number:
        raise UpdateError(
            "Manifest minimumSupportedBuild cannot exceed buildNumber",
            EXIT_VERSION_STATE,
        )
    if minimum_launcher > LAUNCHER_VERSION:
        raise UpdateError(
            "This release requires a newer Pixmax launcher; rerun the official installer",
            EXIT_VERSION_STATE,
        )
    if sys.version_info[:2] < minimum_python:
        raise UpdateError(
            f"Pixmax {version} requires Python {minimum_python[0]}.{minimum_python[1]}+",
            EXIT_VERSION_STATE,
        )
    artifact = value.get("artifact")
    if not isinstance(artifact, dict):
        raise UpdateError(
            "Manifest artifact must contain an object", EXIT_VERSION_STATE
        )
    artifact_url = artifact.get("url")
    if not isinstance(artifact_url, str) or not artifact_url.strip():
        raise UpdateError("Manifest artifact.url is required", EXIT_VERSION_STATE)
    digest = artifact.get("sha256")
    if not isinstance(digest, str) or not re.fullmatch(r"[0-9a-f]{64}", digest):
        raise UpdateError("Manifest artifact.sha256 is invalid", EXIT_VERSION_STATE)
    size = _positive_int(artifact.get("size"), "artifact.size")
    if size > max_artifact_size:
        raise UpdateError(
            "Manifest artifact exceeds the configured size limit", EXIT_VERSION_STATE
        )
    return {
        **value,
        "version": version,
        "buildNumber": build_number,
        "minimumSupportedBuild": minimum_supported,
        "minimumLauncherVersion": minimum_launcher,
        "minimumPython": f"{minimum_python[0]}.{minimum_python[1]}",
        "artifact": {**artifact, "url": artifact_url, "sha256": digest, "size": size},
    }


def _decode_base64(value: str | bytes, expected_length: int, label: str) -> bytes:
    try:
        raw = base64.b64decode(value, validate=True)
    except (ValueError, TypeError) as exc:
        raise UpdateError(
            f"{label} is not valid base64", EXIT_MANIFEST_SIGNATURE
        ) from exc
    if len(raw) != expected_length:
        raise UpdateError(
            f"{label} must decode to {expected_length} bytes", EXIT_MANIFEST_SIGNATURE
        )
    return raw


def verify_manifest(
    manifest_bytes: bytes, signature_bytes: bytes, public_key: str
) -> None:
    key = _decode_base64(public_key, 32, "Update public key")
    signature = _decode_base64(signature_bytes.strip(), 64, "Manifest signature")
    try:
        verify_ed25519(key, signature, manifest_bytes)
    except BadSignatureError as exc:
        raise UpdateError(
            "Update manifest signature is invalid", EXIT_MANIFEST_SIGNATURE
        ) from exc


def _allowed_url(url: str, config: dict[str, Any]) -> bool:
    scheme = urllib.parse.urlparse(url).scheme.lower()
    if scheme == "https":
        return True
    return bool(config.get("allowInsecureForDevelopment")) and scheme in {
        "http",
        "file",
    }


def _request_bytes(
    url: str,
    *,
    headers: dict[str, str] | None,
    timeout: float,
    max_bytes: int,
    config: dict[str, Any],
) -> tuple[int, dict[str, str], bytes]:
    if not _allowed_url(url, config):
        raise UpdateError(f"Refusing non-HTTPS update URL: {url}", EXIT_MANIFEST_FETCH)
    request = urllib.request.Request(url, headers=headers or {}, method="GET")
    try:
        response = urllib.request.urlopen(request, timeout=timeout)
    except urllib.error.HTTPError as exc:
        if exc.code == 304:
            return 304, {key.lower(): value for key, value in exc.headers.items()}, b""
        raise UpdateError(
            f"Update request failed with HTTP {exc.code}: {url}", EXIT_MANIFEST_FETCH
        ) from exc
    except (OSError, urllib.error.URLError) as exc:
        raise UpdateError(
            f"Update request failed: {url}: {exc}", EXIT_MANIFEST_FETCH
        ) from exc
    with response:
        final_url = response.geturl()
        if not _allowed_url(final_url, config):
            raise UpdateError(
                f"Update request redirected to a disallowed URL: {final_url}",
                EXIT_MANIFEST_FETCH,
            )
        data = response.read(max_bytes + 1)
        if len(data) > max_bytes:
            raise UpdateError(
                f"Update response is too large: {url}", EXIT_MANIFEST_FETCH
            )
        status = getattr(response, "status", 200) or 200
        response_headers = {
            key.lower(): value for key, value in response.headers.items()
        }
    return status, response_headers, data


def _manifest_from_bytes(payload: bytes, max_artifact_size: int) -> dict[str, Any]:
    try:
        value = json.loads(payload.decode("utf-8"))
    except (UnicodeError, json.JSONDecodeError) as exc:
        raise UpdateError(
            "Update manifest is not valid UTF-8 JSON", EXIT_VERSION_STATE
        ) from exc
    return validate_manifest(value, max_artifact_size=max_artifact_size)


def fetch_manifest(
    paths: LauncherPaths,
    config: dict[str, Any],
    *,
    force: bool = False,
) -> tuple[dict[str, Any], str | None]:
    manifest_url = config.get("manifestUrl")
    public_key = config.get("publicKey")
    if not isinstance(manifest_url, str) or not manifest_url:
        raise UpdateError(
            "launcher-config.json is missing manifestUrl", EXIT_VERSION_STATE
        )
    if not isinstance(public_key, str) or not public_key:
        raise UpdateError(
            "launcher-config.json is missing publicKey", EXIT_VERSION_STATE
        )
    signature_url = config.get("signatureUrl") or urllib.parse.urljoin(
        manifest_url, "manifest.sig"
    )
    if not isinstance(signature_url, str):
        raise UpdateError(
            "launcher-config.json signatureUrl is invalid", EXIT_VERSION_STATE
        )
    timeout = float(_config_number(config, "requestTimeoutSeconds", DEFAULT_TIMEOUT))
    max_artifact_size = int(
        _config_number(
            config,
            "maxArtifactSize",
            DEFAULT_MAX_ARTIFACT_SIZE,
            integer=True,
        )
    )
    state = _read_json(paths.state, required=False)
    headers = {
        "Accept": "application/json",
        "User-Agent": f"pixmax-launcher/{LAUNCHER_VERSION}",
    }
    if not force and isinstance(state.get("etag"), str):
        headers["If-None-Match"] = state["etag"]

    for attempt in range(2):
        status, response_headers, manifest_bytes = _request_bytes(
            manifest_url,
            headers=headers,
            timeout=timeout,
            max_bytes=64 * 1024,
            config=config,
        )
        if status == 304:
            try:
                manifest_bytes = paths.cached_manifest.read_bytes()
                signature_bytes = paths.cached_signature.read_bytes()
                verify_manifest(manifest_bytes, signature_bytes, public_key)
                manifest = _manifest_from_bytes(manifest_bytes, max_artifact_size)
            except (OSError, UpdateError):
                if attempt == 0:
                    headers.pop("If-None-Match", None)
                    continue
                raise UpdateError(
                    "Server returned 304 but the signed manifest cache is invalid",
                    EXIT_MANIFEST_SIGNATURE,
                )
            return manifest, state.get("etag")

        _, _, signature_bytes = _request_bytes(
            signature_url,
            headers={"Accept": "text/plain", "User-Agent": headers["User-Agent"]},
            timeout=timeout,
            max_bytes=1024,
            config=config,
        )
        try:
            verify_manifest(manifest_bytes, signature_bytes, public_key)
        except UpdateError:
            if attempt == 0:
                headers.pop("If-None-Match", None)
                continue
            raise
        manifest = _manifest_from_bytes(manifest_bytes, max_artifact_size)
        _atomic_write(paths.cached_manifest, manifest_bytes)
        _atomic_write(paths.cached_signature, signature_bytes.strip() + b"\n")
        return manifest, response_headers.get("etag")

    raise UpdateError(
        "Unable to obtain a consistent signed manifest", EXIT_MANIFEST_SIGNATURE
    )


def _current_record(paths: LauncherPaths, *, required: bool = True) -> dict[str, Any]:
    current = _read_json(paths.current, required=required)
    if not current and not required:
        return {}
    if current.get("schemaVersion") != CURRENT_SCHEMA:
        raise UpdateError(
            "Unsupported current runtime schemaVersion", EXIT_VERSION_STATE
        )
    _positive_int(current.get("buildNumber"), "current.buildNumber")
    if not isinstance(current.get("version"), str) or not _VERSION_RE.fullmatch(
        current["version"]
    ):
        raise UpdateError("Current runtime version is invalid", EXIT_VERSION_STATE)
    if not isinstance(current.get("runtimeDir"), str):
        raise UpdateError("Current runtimeDir is invalid", EXIT_VERSION_STATE)
    return current


def _runtime_path(paths: LauncherPaths, current: dict[str, Any]) -> Path:
    runtime = (paths.home / current["runtimeDir"]).resolve()
    versions = paths.versions.resolve()
    if versions not in runtime.parents:
        raise UpdateError(
            "Current runtime path escapes the versions directory", EXIT_VERSION_STATE
        )
    if not (runtime / "entry.py").is_file() or not (runtime / "runtime.json").is_file():
        raise UpdateError(f"Current runtime is incomplete: {runtime}", EXIT_INSTALL)
    return runtime


def _validate_runtime_metadata(runtime: Path, manifest: dict[str, Any]) -> None:
    metadata = _read_json(runtime / "runtime.json")
    if metadata.get("schemaVersion") != RUNTIME_SCHEMA:
        raise UpdateError("Runtime schemaVersion is unsupported", EXIT_ARTIFACT_INVALID)
    if metadata.get("version") != manifest["version"]:
        raise UpdateError(
            "Runtime version does not match the signed manifest", EXIT_ARTIFACT_INVALID
        )
    if metadata.get("buildNumber") != manifest["buildNumber"]:
        raise UpdateError(
            "Runtime buildNumber does not match the signed manifest",
            EXIT_ARTIFACT_INVALID,
        )
    if not (runtime / "app" / "pixmax" / "__init__.py").is_file():
        raise UpdateError(
            "Runtime does not contain the Pixmax application", EXIT_ARTIFACT_INVALID
        )


def _download_artifact(
    paths: LauncherPaths,
    config: dict[str, Any],
    manifest: dict[str, Any],
) -> Path:
    artifact = manifest["artifact"]
    artifact_url = urllib.parse.urljoin(config["manifestUrl"], artifact["url"])
    if not _allowed_url(artifact_url, config):
        raise UpdateError(
            f"Refusing non-HTTPS artifact URL: {artifact_url}", EXIT_RUNTIME_DOWNLOAD
        )
    paths.downloads.mkdir(parents=True, exist_ok=True)
    destination = paths.downloads / f"{manifest['buildNumber']}-{uuid.uuid4().hex}.zip"
    request = urllib.request.Request(
        artifact_url,
        headers={"User-Agent": f"pixmax-launcher/{LAUNCHER_VERSION}"},
        method="GET",
    )
    timeout = float(_config_number(config, "requestTimeoutSeconds", DEFAULT_TIMEOUT))
    digest = hashlib.sha256()
    total = 0
    try:
        response = urllib.request.urlopen(request, timeout=timeout)
        with response, destination.open("wb") as stream:
            final_url = response.geturl()
            if not _allowed_url(final_url, config):
                raise UpdateError(
                    f"Runtime download redirected to a disallowed URL: {final_url}",
                    EXIT_RUNTIME_DOWNLOAD,
                )
            content_length = response.headers.get("Content-Length")
            if content_length and int(content_length) != artifact["size"]:
                raise UpdateError(
                    "Runtime Content-Length does not match the manifest",
                    EXIT_RUNTIME_DOWNLOAD,
                )
            while True:
                chunk = response.read(64 * 1024)
                if not chunk:
                    break
                total += len(chunk)
                if total > artifact["size"]:
                    raise UpdateError(
                        "Runtime download exceeds the signed size",
                        EXIT_RUNTIME_DOWNLOAD,
                    )
                digest.update(chunk)
                stream.write(chunk)
            stream.flush()
            os.fsync(stream.fileno())
    except UpdateError:
        with contextlib.suppress(OSError):
            destination.unlink()
        raise
    except (OSError, urllib.error.URLError, ValueError) as exc:
        with contextlib.suppress(OSError):
            destination.unlink()
        raise UpdateError(
            f"Runtime download failed: {exc}", EXIT_RUNTIME_DOWNLOAD
        ) from exc
    if total != artifact["size"]:
        destination.unlink(missing_ok=True)
        raise UpdateError(
            "Runtime download size does not match the manifest", EXIT_ARTIFACT_INVALID
        )
    if digest.hexdigest() != artifact["sha256"]:
        destination.unlink(missing_ok=True)
        raise UpdateError(
            "Runtime SHA-256 does not match the manifest", EXIT_ARTIFACT_INVALID
        )
    return destination


def _safe_extract(
    archive_path: Path,
    destination: Path,
    *,
    max_files: int,
    max_unpacked_size: int,
) -> None:
    try:
        archive = zipfile.ZipFile(archive_path)
    except (OSError, zipfile.BadZipFile) as exc:
        raise UpdateError(
            f"Runtime is not a valid ZIP archive: {exc}", EXIT_ARTIFACT_INVALID
        ) from exc
    with archive:
        infos = archive.infolist()
        if len(infos) > max_files:
            raise UpdateError(
                "Runtime archive contains too many files", EXIT_ARTIFACT_INVALID
            )
        unpacked = sum(info.file_size for info in infos)
        if unpacked > max_unpacked_size:
            raise UpdateError(
                "Runtime archive expands beyond the configured limit",
                EXIT_ARTIFACT_INVALID,
            )
        destination.mkdir(parents=True, exist_ok=False)
        destination_root = destination.resolve()
        seen_members: set[str] = set()
        for info in infos:
            normalized_name = info.filename.replace("\\", "/")
            member = PurePosixPath(normalized_name)
            mode = info.external_attr >> 16
            is_symlink = (mode & 0o170000) == 0o120000
            file_type = mode & 0o170000
            member_key = "/".join(member.parts).casefold()
            invalid_windows_part = any(
                part.rstrip(" .").split(".", 1)[0].casefold() in _WINDOWS_RESERVED_NAMES
                or part.endswith((" ", "."))
                or ":" in part
                or any(ord(character) < 32 for character in part)
                for part in member.parts
            )
            if (
                not normalized_name
                or member.is_absolute()
                or ".." in member.parts
                or is_symlink
                or file_type not in {0, 0o040000, 0o100000}
                or invalid_windows_part
                or any(part in {"", "."} for part in member.parts)
                or member_key in seen_members
            ):
                raise UpdateError(
                    f"Unsafe path in runtime archive: {info.filename}",
                    EXIT_ARTIFACT_INVALID,
                )
            seen_members.add(member_key)
            target = destination.joinpath(*member.parts).resolve()
            if destination_root not in target.parents and target != destination_root:
                raise UpdateError(
                    f"Runtime archive path escapes staging: {info.filename}",
                    EXIT_ARTIFACT_INVALID,
                )
            if info.is_dir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(info, "r") as source, target.open("wb") as output:
                shutil.copyfileobj(source, output, 64 * 1024)


def _run_doctor(
    runtime: Path,
    *,
    timeout: float = 60.0,
    cli_home: Path | None = None,
) -> None:
    environment = os.environ.copy()
    environment["PIXMAX_LAUNCHER_DOCTOR"] = "1"
    if cli_home is not None:
        environment["PIXMAX_CLI_HOME"] = str(cli_home)
    try:
        result = subprocess.run(
            [sys.executable, str(runtime / "entry.py"), "--json", "doctor"],
            text=True,
            capture_output=True,
            timeout=timeout,
            env=environment,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise UpdateError(
            f"New runtime doctor could not run: {exc}", EXIT_DOCTOR
        ) from exc
    if result.returncode:
        details = (result.stderr or result.stdout).strip()
        if len(details) > 1000:
            details = details[:1000] + "..."
        raise UpdateError(f"New runtime doctor failed: {details}", EXIT_DOCTOR)


def _install_runtime(
    paths: LauncherPaths,
    config: dict[str, Any],
    manifest: dict[str, Any],
    *,
    repair: bool,
) -> dict[str, Any]:
    archive = _download_artifact(paths, config, manifest)
    stage = paths.staging / f"{manifest['buildNumber']}-{uuid.uuid4().hex}"
    target_name = f"{manifest['buildNumber']}-{manifest['version']}"
    target = paths.versions / target_name
    try:
        paths.staging.mkdir(parents=True, exist_ok=True)
        _safe_extract(
            archive,
            stage,
            max_files=int(config.get("maxArchiveFiles", DEFAULT_MAX_ARCHIVE_FILES)),
            max_unpacked_size=int(
                config.get("maxUnpackedSize", DEFAULT_MAX_UNPACKED_SIZE)
            ),
        )
        _validate_runtime_metadata(stage, manifest)
        doctor_timeout = float(_config_number(config, "doctorTimeoutSeconds", 60))
        _run_doctor(
            stage,
            timeout=doctor_timeout,
            cli_home=paths.home,
        )
        paths.versions.mkdir(parents=True, exist_ok=True)
        if target.exists():
            if not repair:
                _validate_runtime_metadata(target, manifest)
                _run_doctor(
                    target,
                    timeout=doctor_timeout,
                    cli_home=paths.home,
                )
                shutil.rmtree(stage)
            else:
                paths.quarantine.mkdir(parents=True, exist_ok=True)
                quarantined = paths.quarantine / f"{target.name}-{uuid.uuid4().hex}"
                os.replace(target, quarantined)
                try:
                    os.replace(stage, target)
                except OSError:
                    os.replace(quarantined, target)
                    raise
        else:
            os.replace(stage, target)
    except UpdateError:
        with contextlib.suppress(OSError):
            if stage.exists():
                shutil.rmtree(stage)
        raise
    except OSError as exc:
        with contextlib.suppress(OSError):
            if stage.exists():
                shutil.rmtree(stage)
        raise UpdateError(
            f"Cannot install the new runtime: {exc}", EXIT_INSTALL
        ) from exc
    finally:
        with contextlib.suppress(OSError):
            archive.unlink()

    current = {
        "schemaVersion": CURRENT_SCHEMA,
        "version": manifest["version"],
        "buildNumber": manifest["buildNumber"],
        "runtimeDir": target.relative_to(paths.home).as_posix(),
        "activatedAt": _utc_now(),
    }
    _atomic_write_json(paths.current, current)
    return current


class UpdateLock:
    """Advisory process lock implemented with platform-native stdlib calls."""

    def __init__(self, path: Path, timeout: float):
        self.path = path
        self.timeout = timeout
        self.stream: BinaryIO | None = None

    def __enter__(self) -> "UpdateLock":
        self.path.parent.mkdir(parents=True, exist_ok=True)
        stream = self.path.open("a+b")
        stream.seek(0)
        if stream.read(1) == b"":
            stream.seek(0)
            stream.write(b"0")
            stream.flush()
        deadline = time.monotonic() + self.timeout
        while True:
            try:
                if os.name == "nt":
                    import msvcrt

                    stream.seek(0)
                    msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
                else:
                    import fcntl

                    fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                self.stream = stream
                return self
            except OSError:
                if time.monotonic() >= deadline:
                    stream.close()
                    raise UpdateError(
                        "Timed out waiting for the update lock", EXIT_LOCK_TIMEOUT
                    )
                time.sleep(0.1)

    def __exit__(self, *_exc: Any) -> None:
        if self.stream is None:
            return
        try:
            if os.name == "nt":
                import msvcrt

                self.stream.seek(0)
                msvcrt.locking(self.stream.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl

                fcntl.flock(self.stream.fileno(), fcntl.LOCK_UN)
        finally:
            self.stream.close()
            self.stream = None


def check_for_updates(
    paths: LauncherPaths,
    config: dict[str, Any],
    *,
    force: bool = False,
    repair: bool = False,
) -> dict[str, Any]:
    current = _current_record(paths, required=False)
    if not config.get("updateEnabled", True):
        if not current:
            raise UpdateError(
                "Development launcher has no installed runtime", EXIT_INSTALL
            )
        _runtime_path(paths, current)
        return current

    lock_timeout = float(
        _config_number(config, "lockTimeoutSeconds", DEFAULT_LOCK_TIMEOUT)
    )
    with UpdateLock(paths.lock, lock_timeout):
        _save_state(
            paths, status="checking", lastCheckStartedAt=_utc_now(), lastError=None
        )
        manifest, etag = fetch_manifest(paths, config, force=force)
        state = _read_json(paths.state, required=False)
        highest_value = state.get("highestAcceptedBuild", 0) or 0
        if (
            isinstance(highest_value, bool)
            or not isinstance(highest_value, int)
            or highest_value < 0
        ):
            raise UpdateError("highestAcceptedBuild is invalid", EXIT_VERSION_STATE)
        highest = highest_value
        remote_build = manifest["buildNumber"]
        current_build = int(current.get("buildNumber", 0) or 0)
        if remote_build < highest or remote_build < current_build:
            raise UpdateError(
                f"Signed manifest build {remote_build} is older than the accepted local build",
                EXIT_VERSION_STATE,
            )
        if (
            current_build
            and current_build < manifest["minimumSupportedBuild"]
            and remote_build <= current_build
        ):
            raise UpdateError(
                "Current runtime is below minimumSupportedBuild", EXIT_VERSION_STATE
            )

        updated = repair or not current or remote_build > current_build
        if updated:
            current = _install_runtime(paths, config, manifest, repair=repair)
        else:
            runtime = _runtime_path(paths, current)
            _validate_runtime_metadata(runtime, manifest)

        _save_state(
            paths,
            status="ready",
            etag=etag,
            highestAcceptedBuild=max(highest, remote_build),
            lastCheckedAt=_utc_now(),
            lastSuccessfulBuild=remote_build,
            lastSuccessfulVersion=manifest["version"],
            lastUpdateInstalled=updated,
            lastError=None,
        )
        return current


def local_status(paths: LauncherPaths, config: dict[str, Any]) -> dict[str, Any]:
    current_error = None
    state_error = None
    try:
        current = _current_record(paths, required=False)
    except UpdateError as exc:
        current = {}
        current_error = {"exitCode": exc.exit_code, "message": str(exc)}
    try:
        state = _read_json(paths.state, required=False)
    except UpdateError as exc:
        state = {}
        state_error = {"exitCode": exc.exit_code, "message": str(exc)}
    runtime_ok = False
    if current:
        try:
            _runtime_path(paths, current)
            runtime_ok = True
        except UpdateError:
            runtime_ok = False
    return {
        "ok": runtime_ok,
        "launcherVersion": LAUNCHER_VERSION,
        "channel": config.get("channel", "stable"),
        "updateEnabled": bool(config.get("updateEnabled", True)),
        "manifestUrl": config.get("manifestUrl"),
        "current": current or None,
        "currentError": current_error,
        "state": state or None,
        "stateError": state_error,
        "runtimeHealthy": runtime_ok,
    }


def _emit_status(status: dict[str, Any], *, use_json: bool) -> None:
    if use_json:
        print(json.dumps(status, ensure_ascii=False, indent=2, sort_keys=True))
        return
    current = status.get("current") or {}
    print(f"Launcher: {status['launcherVersion']}")
    print(f"Channel: {status['channel']}")
    print(f"Update enabled: {str(status['updateEnabled']).lower()}")
    print(
        f"Runtime: {current.get('version', 'missing')} (build {current.get('buildNumber', 'n/a')})"
    )
    print(f"Runtime healthy: {str(status['runtimeHealthy']).lower()}")
    state = status.get("state") or {}
    if state.get("lastError"):
        print(f"Last error: {state['lastError']}")


def _record_failure(paths: LauncherPaths, error: UpdateError) -> None:
    with contextlib.suppress(UpdateError, OSError):
        _save_state(
            paths,
            status="failed",
            lastFailedAt=_utc_now(),
            lastError={"exitCode": error.exit_code, "message": str(error)},
        )


def _execute_runtime(
    paths: LauncherPaths, current: dict[str, Any], argv: list[str]
) -> None:
    runtime = _runtime_path(paths, current)
    command = [sys.executable, str(runtime / "entry.py"), *argv]
    try:
        os.execv(sys.executable, command)
    except OSError as exc:
        raise UpdateError(
            f"Cannot execute current Pixmax runtime: {exc}", EXIT_INSTALL
        ) from exc


def _force_utf8_output() -> None:
    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure is not None:
            with contextlib.suppress(OSError, ValueError):
                reconfigure(encoding="utf-8", errors="replace")


def main(argv: list[str] | None = None) -> None:
    _force_utf8_output()
    args = list(sys.argv[1:] if argv is None else argv)
    paths = LauncherPaths(default_home())
    use_json = "--json" in args
    try:
        config = validate_launcher_config(_read_json(paths.config))
        command_args = [arg for arg in args if arg != "--json"]
        if command_args == ["update", "status"]:
            _emit_status(local_status(paths, config), use_json=use_json)
            return
        if command_args == ["--version"]:
            current = _current_record(paths)
            print(
                f"pixmax, version {current['version']} (build {current['buildNumber']})"
            )
            return
        if command_args in (["update", "retry"], ["update", "repair"]):
            repair = command_args[-1] == "repair"
            check_for_updates(paths, config, force=True, repair=repair)
            _emit_status(local_status(paths, config), use_json=use_json)
            return
        current = check_for_updates(paths, config)
        _execute_runtime(paths, current, args)
    except UpdateError as exc:
        _record_failure(paths, exc)
        if use_json:
            print(
                json.dumps(
                    {"ok": False, "error": str(exc), "exitCode": exc.exit_code},
                    ensure_ascii=False,
                    indent=2,
                ),
                file=sys.stderr,
            )
        else:
            print(f"[pixmax-cli] Update blocked command: {exc}", file=sys.stderr)
        raise SystemExit(exc.exit_code)
    except Exception as exc:
        error = UpdateError(f"Unexpected launcher failure: {exc}", EXIT_INSTALL)
        _record_failure(paths, error)
        if use_json:
            print(
                json.dumps(
                    {"ok": False, "error": str(error), "exitCode": error.exit_code},
                    ensure_ascii=False,
                    indent=2,
                ),
                file=sys.stderr,
            )
        else:
            print(f"[pixmax-cli] Update blocked command: {error}", file=sys.stderr)
        raise SystemExit(error.exit_code)


if __name__ == "__main__":
    main()
