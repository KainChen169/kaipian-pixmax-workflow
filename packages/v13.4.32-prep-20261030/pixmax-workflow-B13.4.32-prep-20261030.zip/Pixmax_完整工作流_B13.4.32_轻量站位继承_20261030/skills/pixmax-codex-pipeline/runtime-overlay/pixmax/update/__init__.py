"""Pixmax CLI launcher and static-release update support."""

LAUNCHER_VERSION = 1
