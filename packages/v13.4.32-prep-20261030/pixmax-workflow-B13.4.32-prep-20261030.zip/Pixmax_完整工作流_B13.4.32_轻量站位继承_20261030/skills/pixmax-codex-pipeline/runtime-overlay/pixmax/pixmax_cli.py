#!/usr/bin/env python3
"""Pixmax CLI.

Examples:
    pixmax auth login web
    pixmax project use <project_uuid> --file <file_uuid>
    pixmax canvas summary --json
"""

from __future__ import annotations

import json
import os
import re
import shlex
import sys
import time
import uuid
import webbrowser
from datetime import datetime
from pathlib import Path
from typing import Any

import click

from pixmax import __version__
from pixmax.core.config import (
    ENVIRONMENTS,
    ENV_CONFIG_FILE,
    ENV_ENVIRONMENT,
    ENV_LOCALE,
    PixmaxConfig,
    resolve_environment,
    resolve_locale,
)
from pixmax.core.session import PixmaxSession
from pixmax.core.workspace import canvas_summary, flatten_file_tree
from pixmax.utils.pixmax_backend import (
    DEFAULT_DEVICE_CLIENT_CODE,
    ENV_BASE_URL,
    ENV_TOKEN,
    PixmaxAPIError,
    PixmaxClient,
    device_auth_create_code,
    device_auth_get_token,
    device_auth_page_url,
    get_token,
    guess_content_type,
    write_bytes,
    read_json_file,
)
from pixmax.utils.repl_skin import ReplSkin
from pixmax.utils.skill_packager import build_skill_package

_json_output = False
_repl_mode = False
_LEGACY_NODE_REFERENCE_RE = re.compile(r"\{\{\s*Node\s+(['\"])(.*?)\1\s*\}\}")
_PLATFORM_MENTION_RE = re.compile(
    r"%%@\[(?P<title>[^\]]*)\]\[(?P<kind>text|audio|image|video)\]"
    r"\[(?P<index>\d+)\]\((?P<uuid>[^)]+)\)%%"
)
_V1_GENERATION_NODE_TYPES = {
    "GENERATE_TEXT",
    "GENERATE_IMAGE",
    "GENERATE_AUDIO",
    "GENERATE_VIDEO",
}


def _client(ctx: click.Context) -> PixmaxClient:
    token = ctx.obj.get("token") or _active_profile_token(ctx)
    return PixmaxClient(
        token=token,
        base_url=ctx.obj.get("base_url"),
        timeout=ctx.obj.get("timeout") or 90,
        locale=ctx.obj.get("locale"),
    )


def _session(ctx: click.Context) -> PixmaxSession:
    session = ctx.obj.get("session")
    if session is None:
        session = PixmaxSession(
            ctx.obj.get("session_file"),
            environment=ctx.obj.get("environment") or "cn",
        )
        ctx.obj["session"] = session
    return session


def _mask_token(token: str | None) -> str | None:
    if not token:
        return None
    normalized = token.strip()
    if normalized.lower().startswith("bearer "):
        normalized = normalized[7:].strip()
    if len(normalized) <= 12:
        return "***"
    return f"{normalized[:6]}...{normalized[-6:]}"


def _active_profile(ctx: click.Context) -> dict[str, Any] | None:
    session = _session(ctx)
    name = session.active_auth_profile
    if not name:
        return None
    profile = session.auth_profiles.get(name)
    return profile if isinstance(profile, dict) else None


def _active_profile_token(ctx: click.Context) -> str | None:
    profile = _active_profile(ctx)
    profile_base_url = profile.get("apiBaseUrl") if profile else None
    if profile_base_url and profile_base_url.rstrip("/") != (ctx.obj.get("base_url") or "").rstrip("/"):
        return None
    token = profile.get("token") if profile else None
    return token if isinstance(token, str) and token.strip() else None


def _token_source(ctx: click.Context) -> str | None:
    if ctx.obj.get("token"):
        return "--token"
    if os.environ.get(ENV_TOKEN):
        return "environment"
    if _active_profile_token(ctx):
        return "profile"
    return None


def _auth_profile_public(profile: dict[str, Any]) -> dict[str, Any]:
    return {key: value for key, value in profile.items() if key != "token"}


def _human(ctx: click.Context, *, zh: str, en: str) -> str:
    return zh if ctx.obj.get("locale") == "zh-CN" else en


def _verified_auth_profile(
    token: str,
    result: dict[str, Any],
    *,
    store_token: bool,
    environment: str,
    base_url: str,
) -> dict[str, Any]:
    data = result.get("data") or {}
    profile = {
        "maskedToken": _mask_token(token),
        "storedToken": bool(store_token),
        "unionId": data.get("unionId"),
        "name": data.get("name"),
        "accountType": data.get("accountType"),
        "userTier": data.get("userTier"),
        "maskedEmail": data.get("maskedEmail"),
        "maskedPhone": data.get("maskedPhone"),
        "releaseVersion": result.get("releaseVersion"),
        "updatedAt": datetime.now().isoformat(timespec="seconds"),
        "environment": environment,
        "apiBaseUrl": base_url,
    }
    if store_token:
        profile["token"] = token
    return profile


def _emit(data: Any, message: str = "") -> None:
    if _json_output:
        click.echo(json.dumps(data, ensure_ascii=False, indent=2, default=str))
        return
    if message:
        click.echo(message)
    if isinstance(data, dict):
        _print_dict(data)
    elif isinstance(data, list):
        _print_list(data)
    elif data is not None:
        click.echo(str(data))


def _print_dict(data: dict[str, Any], indent: int = 0) -> None:
    prefix = "  " * indent
    for key, value in data.items():
        if isinstance(value, dict):
            click.echo(f"{prefix}{key}:")
            _print_dict(value, indent + 1)
        elif isinstance(value, list):
            click.echo(f"{prefix}{key}:")
            _print_list(value, indent + 1)
        else:
            click.echo(f"{prefix}{key}: {value}")


def _print_list(items: list[Any], indent: int = 0) -> None:
    prefix = "  " * indent
    for index, item in enumerate(items):
        if isinstance(item, dict):
            click.echo(f"{prefix}[{index}]")
            _print_dict(item, indent + 1)
        else:
            click.echo(f"{prefix}- {item}")


def _handle_errors(func):
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except (RuntimeError, ValueError, PixmaxAPIError) as exc:
            payload = {"error": str(exc), "type": type(exc).__name__}
            if isinstance(exc, PixmaxAPIError) and exc.response:
                payload["response"] = exc.response
            if _json_output:
                click.echo(json.dumps(payload, ensure_ascii=False, indent=2))
            else:
                click.echo(f"Error: {exc}", err=True)
            if not _repl_mode:
                raise click.exceptions.Exit(1)

    wrapper.__name__ = func.__name__
    wrapper.__doc__ = func.__doc__
    return wrapper


def _require_project(ctx: click.Context, value: str | None = None) -> str:
    project = value or _session(ctx).project_uuid
    if not project:
        raise RuntimeError("Missing project UUID. Pass --project or run: project use <uuid>.")
    return project


def _require_file(ctx: click.Context, value: str | None = None) -> str:
    file_uuid = value or _session(ctx).file_uuid
    if not file_uuid:
        raise RuntimeError("Missing file UUID. Pass --file or run: project use <uuid> --file <uuid>.")
    return file_uuid


def _load_payload(data: str | None = None, file: str | None = None) -> dict[str, Any]:
    if data and file:
        raise ValueError("Use either --data or --file, not both.")
    if file:
        payload = read_json_file(file)
    elif data:
        payload = json.loads(data)
    else:
        payload = {}
    if not isinstance(payload, dict):
        raise ValueError("Payload must be a JSON object.")
    return payload


def _load_json_value(data: str | None = None, file: str | None = None) -> Any:
    if data and file:
        raise ValueError("Use either --data or --file, not both.")
    if file:
        return read_json_file(file)
    if data:
        return json.loads(data)
    return None


def _emit_dry_run(endpoint: str, payload: dict[str, Any]) -> None:
    _emit({"dryRun": True, "endpoint": endpoint, "payload": payload}, f"Dry run {endpoint}")


def _payload_with_defaults(
    payload: dict[str, Any],
    *,
    project_uuid: str | None = None,
    file_uuid: str | None = None,
    ctx: click.Context | None = None,
) -> dict[str, Any]:
    result = dict(payload)
    if project_uuid is not None and "projectUuid" not in result:
        result["projectUuid"] = project_uuid
    if file_uuid is not None and "fileUuid" not in result:
        result["fileUuid"] = file_uuid
    if ctx is not None:
        if "projectUuid" not in result and _session(ctx).project_uuid:
            result["projectUuid"] = _session(ctx).project_uuid
        if "fileUuid" not in result and _session(ctx).file_uuid:
            result["fileUuid"] = _session(ctx).file_uuid
    return result


def _load_definition_payload(data: str | None = None, file: str | None = None) -> dict[str, Any]:
    payload = _load_payload(data, file)
    if "type" not in payload and "workflow" in payload:
        payload["type"] = payload["workflow"]
    workflow_type = payload.get("type")
    if not isinstance(workflow_type, str) or not workflow_type:
        raise ValueError("Workflow definition must include type.")
    options = payload.get("options")
    if options is None:
        options = {
            key: value
            for key, value in payload.items()
            if key not in {"type", "workflow", "description"}
        }
    if not isinstance(options, dict):
        raise ValueError("Workflow definition options must be a JSON object.")
    return {
        "type": workflow_type,
        "description": payload.get("description"),
        "options": options,
    }


def _parse_value(value: str) -> Any:
    text = value.strip()
    if text.lower() == "true":
        return True
    if text.lower() == "false":
        return False
    if text.lower() == "null":
        return None
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return value


def _set_nested(payload: dict[str, Any], key: str, value: Any) -> None:
    parts = [part for part in key.split(".") if part]
    if not parts:
        raise ValueError("Empty key in key=value option.")
    cursor = payload
    for part in parts[:-1]:
        next_value = cursor.get(part)
        if not isinstance(next_value, dict):
            next_value = {}
            cursor[part] = next_value
        cursor = next_value
    cursor[parts[-1]] = value


def _apply_key_values(payload: dict[str, Any], pairs: tuple[str, ...], *, prefix: str | None = None) -> dict[str, Any]:
    result = dict(payload)
    for pair in pairs:
        if "=" not in pair:
            raise ValueError(f"Expected key=value, got: {pair}")
        key, raw_value = pair.split("=", 1)
        target_key = f"{prefix}.{key}" if prefix else key
        _set_nested(result, target_key, _parse_value(raw_value))
    return result


def _definition_with_overrides(definition: dict[str, Any], overrides: tuple[str, ...]) -> dict[str, Any]:
    merged = {
        "type": definition.get("type"),
        "description": definition.get("description"),
        "options": dict(definition.get("options") or {}),
    }
    if overrides:
        merged["options"] = _apply_key_values(merged["options"], overrides)
    return merged


def _option_bool(options: dict[str, Any], key: str, default: bool) -> bool:
    value = options.get(key, default)
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.lower() not in {"0", "false", "no", "off", ""}
    return bool(value)


def _option_tuple(options: dict[str, Any], key: str) -> tuple[str, ...]:
    value = options.get(key)
    if value is None:
        return ()
    if isinstance(value, tuple):
        return tuple(str(item) for item in value)
    if isinstance(value, list):
        return tuple(str(item) for item in value)
    return (str(value),)


_WORKFLOW_TYPES = {"image-to-video", "script-to-video", "generate-batch", "quick-task", "template-task"}


def _read_ndjson_stdin() -> list[dict[str, Any]]:
    if sys.stdin is None or sys.stdin.isatty():
        return []
    rows: list[dict[str, Any]] = []
    try:
        for line in sys.stdin:
            line = line.strip()
            if not line:
                continue
            value = json.loads(line)
            if not isinstance(value, dict):
                raise ValueError("stdin JSON lines must be objects.")
            rows.append(value)
    except EOFError:
        return rows
    return rows


def _node_key(row: dict[str, Any]) -> str | None:
    for key in ("nodeKey", "newNodeKey", "uuid", "nodeUuid"):
        value = row.get(key)
        if isinstance(value, str) and value:
            return value
    return None


def _dedupe(items: list[str]) -> list[str]:
    return list(dict.fromkeys([item for item in items if item]))


def _nodes_for_scope(ctx: click.Context, file_uuid: str | None = None, group_name: str | None = None) -> list[dict[str, Any]]:
    file_uuid = _require_file(ctx, file_uuid)
    nodes = canvas_summary(_client(ctx).canvas_get(file_uuid), base_url=ctx.obj.get("base_url"))["nodes"]
    group_name = group_name or _session(ctx).group_name
    if group_name:
        group_nodes = set(_session(ctx).groups.get(group_name) or [])
        nodes = [node for node in nodes if node.get("uuid") in group_nodes]
    return nodes


def _resolve_node(nodes: list[dict[str, Any]], selector: str) -> dict[str, Any]:
    for node in nodes:
        if node.get("uuid") == selector:
            return node
    matches = [node for node in nodes if node.get("label") == selector]
    if len(matches) == 1:
        return matches[0]
    if not matches:
        raise RuntimeError(f"Node not found: {selector}")
    raise RuntimeError(f"Node name is ambiguous: {selector} ({len(matches)} matches). Use UUID.")


def _prompt_reference_occurrences(prompt: str | None) -> list[dict[str, Any]]:
    if not prompt:
        return []
    occurrences: list[dict[str, Any]] = []
    for match in _PLATFORM_MENTION_RE.finditer(prompt):
        occurrences.append(
            {
                "start": match.start(),
                "end": match.end(),
                "style": "platform",
                "selector": match.group("uuid").strip(),
            }
        )
    for match in _LEGACY_NODE_REFERENCE_RE.finditer(prompt):
        occurrences.append(
            {
                "start": match.start(),
                "end": match.end(),
                "style": "legacy",
                "selector": match.group(2).strip(),
            }
        )
    unmatched_platform_text = _PLATFORM_MENTION_RE.sub("", prompt)
    if "%%@" in unmatched_platform_text:
        raise ValueError(
            "Malformed Pixmax @ mention. Expected "
            "%%@[tokenTitle][text|audio|image|video][index](nodeUuid)%%."
        )
    occurrences.sort(key=lambda item: item["start"])
    return occurrences


def _prompt_node_references(prompt: str | None) -> list[str]:
    return [
        occurrence["selector"]
        for occurrence in _prompt_reference_occurrences(prompt)
        if occurrence["selector"]
    ]


def _resolve_prompt_reference_nodes(nodes: list[dict[str, Any]], prompt: str | None) -> list[dict[str, Any]]:
    by_uuid = _nodes_by_uuid(nodes)
    resolved: list[dict[str, Any]] = []
    for occurrence in _prompt_reference_occurrences(prompt):
        selector = occurrence["selector"]
        if not selector:
            raise ValueError("Pixmax @ mention node UUID or legacy node selector cannot be empty.")
        if occurrence["style"] == "platform":
            node = by_uuid.get(selector)
            if node is None:
                raise ValueError(f"Pixmax @ mention references a node outside the current canvas: {selector}")
        else:
            node = _resolve_node(nodes, selector)
        resolved.append(node)
    return resolved


def _resolve_prompt_node_references(nodes: list[dict[str, Any]], prompt: str | None) -> list[str]:
    return [
        node.get("uuid")
        for node in _resolve_prompt_reference_nodes(nodes, prompt)
        if isinstance(node.get("uuid"), str)
    ]


def _validate_unique_upstream_ids(node_uuids: list[str], *, source: str) -> None:
    seen: set[str] = set()
    duplicates: list[str] = []
    for node_uuid in node_uuids:
        if node_uuid in seen and node_uuid not in duplicates:
            duplicates.append(node_uuid)
        seen.add(node_uuid)
    if duplicates:
        raise ValueError(f"Duplicate upstream node UUIDs from {source}: {', '.join(duplicates)}")


def _node_has_mention_content(node: dict[str, Any], kind: str) -> bool:
    data = node.get("data") if isinstance(node.get("data"), dict) else {}
    if kind == "text":
        return bool(node.get("nodeText") or data.get("text"))
    asset = node.get("defaultAsset") if isinstance(node.get("defaultAsset"), dict) else {}
    if asset.get("url") or data.get("url"):
        return True
    node_assets = node.get("nodeAssets") if isinstance(node.get("nodeAssets"), list) else []
    return any(isinstance(item, dict) and item.get("url") for item in node_assets)


def _normalize_prompt_node_references(
    nodes: list[dict[str, Any]],
    prompt: str | None,
    prev_node_uuids: list[str],
    *,
    strict_v1: bool,
) -> str | None:
    if prompt is None:
        return None
    if strict_v1 and ("%%#" in prompt or re.search(r"<#[^>]*#>", prompt)):
        raise ValueError("Pixmax Agent v1 does not support hash-rich, camera, panorama, or pause prompt tokens.")

    occurrences = _prompt_reference_occurrences(prompt)
    if not occurrences:
        return prompt

    by_uuid = _nodes_by_uuid(nodes)
    _validate_unique_upstream_ids(prev_node_uuids, source="the final ordered upstream list")
    missing_upstream = [node_uuid for node_uuid in prev_node_uuids if node_uuid not in by_uuid]
    if missing_upstream:
        raise ValueError(f"Upstream nodes do not exist in the current canvas: {', '.join(missing_upstream)}")

    mention_positions: dict[str, tuple[str, int]] = {}
    next_indexes = {"text": 0, "audio": 0, "image": 0, "video": 0}
    for node_uuid in prev_node_uuids:
        source_node = by_uuid[node_uuid]
        kind = _node_input_kind(source_node)
        if kind in next_indexes:
            mention_positions[node_uuid] = (kind, next_indexes[kind])
            next_indexes[kind] += 1

    resolved_nodes = _resolve_prompt_reference_nodes(nodes, prompt)
    chunks: list[str] = []
    cursor = 0
    for occurrence, source_node in zip(occurrences, resolved_nodes):
        node_uuid = source_node.get("uuid")
        if not isinstance(node_uuid, str) or node_uuid not in mention_positions:
            raise ValueError(
                f"Pixmax @ mention node must also exist in prevNodeUuids: {node_uuid or occurrence['selector']}"
            )
        kind, index = mention_positions[node_uuid]
        if strict_v1 and not _node_has_mention_content(source_node, kind):
            raise ValueError(
                f"Pixmax @ mention source has no usable {kind} content: {_node_label(source_node)} ({node_uuid})"
            )
        token_title = source_node.get("label") if isinstance(source_node.get("label"), str) else ""
        if "]" in token_title:
            raise ValueError(f"Node label cannot be serialized in a Pixmax @ mention: {token_title!r}")
        chunks.append(prompt[cursor : occurrence["start"]])
        chunks.append(f"%%@[{token_title}][{kind}][{index}]({node_uuid})%%")
        cursor = occurrence["end"]
    chunks.append(prompt[cursor:])
    return "".join(chunks)


def _prepare_prompt_node_references(
    nodes: list[dict[str, Any]],
    prompt: str | None,
    base_prev_node_uuids: list[str],
    *,
    strict_v1: bool,
    auto_connect: bool = True,
) -> tuple[str | None, list[str], list[str]]:
    _validate_unique_upstream_ids(base_prev_node_uuids, source="explicit inputs")
    by_uuid = _nodes_by_uuid(nodes)
    missing = [node_uuid for node_uuid in base_prev_node_uuids if node_uuid not in by_uuid]
    if missing:
        raise ValueError(f"Upstream nodes do not exist in the current canvas: {', '.join(missing)}")
    prompt_ref_keys = _resolve_prompt_node_references(nodes, prompt)
    next_prev = list(base_prev_node_uuids)
    if auto_connect:
        next_prev = _dedupe(next_prev + prompt_ref_keys)
    normalized_prompt = _normalize_prompt_node_references(
        nodes,
        prompt,
        next_prev,
        strict_v1=strict_v1,
    )
    return normalized_prompt, next_prev, prompt_ref_keys


def _validate_direct_upstream_graph(
    nodes: list[dict[str, Any]],
    target_uuid: str,
    prev_node_uuids: list[str],
) -> None:
    if target_uuid in prev_node_uuids:
        raise ValueError(f"A node cannot reference itself as an upstream input: {target_uuid}")
    by_uuid = _nodes_by_uuid(nodes)
    missing = [node_uuid for node_uuid in prev_node_uuids if node_uuid not in by_uuid]
    if missing:
        raise ValueError(f"Upstream nodes do not exist in the current canvas: {', '.join(missing)}")

    for source_uuid in prev_node_uuids:
        pending = [source_uuid]
        visited: set[str] = set()
        while pending:
            current_uuid = pending.pop()
            if current_uuid == target_uuid:
                raise ValueError(f"Upstream relationship would create a directed cycle through {source_uuid}")
            if current_uuid in visited:
                continue
            visited.add(current_uuid)
            current = by_uuid.get(current_uuid)
            if not current:
                continue
            pending.extend(
                node_uuid
                for node_uuid in current.get("prevNodeUuids") or []
                if isinstance(node_uuid, str)
            )


def _node_pipe_record(node: dict[str, Any]) -> dict[str, Any]:
    return {
        "nodeKey": node.get("uuid"),
        "uuid": node.get("uuid"),
        "type": node.get("type"),
        "label": node.get("label"),
        "model": node.get("model"),
        "status": node.get("status"),
        "defaultAsset": node.get("defaultAsset"),
    }


def _node_default_asset_uuid(node: dict[str, Any]) -> str | None:
    asset = node.get("defaultAsset") if isinstance(node.get("defaultAsset"), dict) else {}
    value = _asset_uuid(asset)
    if value:
        return value
    for key in ("defaultAssetUuid", "assetUuid", "assetsUuid"):
        raw_value = node.get(key)
        if isinstance(raw_value, str) and raw_value:
            return raw_value
    return None


def _node_input_kind(node: dict[str, Any]) -> str:
    node_type = str(node.get("type") or "").upper()
    asset = node.get("defaultAsset") if isinstance(node.get("defaultAsset"), dict) else {}
    file_type = str(asset.get("fileType") or "").upper()
    if "IMAGE" in node_type or file_type in {"IMG", "IMAGE"}:
        return "image"
    if "VIDEO" in node_type or file_type == "VIDEO":
        return "video"
    if "AUDIO" in node_type or file_type == "AUDIO":
        return "audio"
    if "TEXT" in node_type:
        return "text"
    if "STORYBOARD" in node_type:
        return "image"
    return "unknown"


def _nodes_by_uuid(nodes: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    return {
        node["uuid"]: node
        for node in nodes
        if isinstance(node.get("uuid"), str)
    }


def _normalize_script_row(row: dict[str, Any], index: int) -> dict[str, Any]:
    if not isinstance(row, dict):
        raise ValueError("Script rows must be JSON objects.")
    result = dict(row)
    result.setdefault("shotNumber", index + 1)
    result.setdefault("hiddenUuid", str(uuid.uuid4()))
    return result


def _normalize_script_rows(rows: Any) -> list[dict[str, Any]]:
    if isinstance(rows, dict) and isinstance(rows.get("rows"), list):
        rows = rows["rows"]
    if not isinstance(rows, list):
        raise ValueError("Script rows must be a JSON array or an object with rows[].")
    return [_normalize_script_row(row, index) for index, row in enumerate(rows)]


def _load_script_rows(data_json: str | None, payload_file: str | None) -> list[dict[str, Any]]:
    value = _load_json_value(data_json, payload_file)
    if value is None:
        value = _read_ndjson_stdin()
    return _normalize_script_rows(value)


def _script_node_rows(node: dict[str, Any]) -> list[dict[str, Any]]:
    data = node.get("data") if isinstance(node.get("data"), dict) else {}
    return _normalize_script_rows(data.get("rows") or [])


def _script_row_prompt(row: dict[str, Any]) -> str:
    for key in ("imageGenerationPrompt", "plotDescription", "videoMotionPrompt", "dialogue"):
        value = row.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return f"Storyboard shot {row.get('shotNumber') or ''}".strip()


def _script_row_video_prompt(row: dict[str, Any]) -> str:
    for key in ("videoMotionPrompt", "plotDescription", "dialogue", "imageGenerationPrompt"):
        value = row.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return f"Video shot {row.get('shotNumber') or ''}".strip()


def _emit_pipe_record(record: dict[str, Any], message: str = "") -> None:
    if not _json_output and not sys.stdout.isatty():
        click.echo(json.dumps(record, ensure_ascii=False, separators=(",", ":"), default=str))
        return
    _emit(record, message)


def _flatten_model_config(response: dict[str, Any]) -> list[dict[str, Any]]:
    models: list[dict[str, Any]] = []
    for group in response.get("data") or []:
        node_type = group.get("canvasNodeType") or group.get("nodeType")
        for model in group.get("nodeConfig") or []:
            models.append(
                {
                    "canvasNodeType": node_type,
                    "nodeType": model.get("nodeType"),
                    "modelName": model.get("modelName"),
                    "modelCode": model.get("modelCode"),
                    "sort": model.get("sort"),
                    "restricted": model.get("restricted"),
                    "requiredTierCode": model.get("requiredTierCode"),
                    "restrictionReason": model.get("restrictionReason"),
                    "discountType": model.get("discountType"),
                    "discountRate": model.get("discountRate"),
                    "modelConfig": model.get("modelConfig"),
                }
            )
    return models


def _parse_range(value: Any) -> tuple[int | None, int | None]:
    if isinstance(value, (list, tuple)) and len(value) >= 2:
        return (
            int(value[0]) if isinstance(value[0], (int, float)) else None,
            int(value[1]) if isinstance(value[1], (int, float)) else None,
        )
    if not isinstance(value, str):
        return None, None
    text = value.strip()
    if not (text.startswith("[") and text.endswith("]") and "," in text):
        return None, None
    left, right = text[1:-1].split(",", 1)

    def parse_bound(raw: str) -> int | None:
        raw = raw.strip()
        if not raw:
            return None
        try:
            return int(raw)
        except ValueError:
            return None

    return parse_bound(left), parse_bound(right)


def _parse_number(value: Any) -> float | None:
    if isinstance(value, bool) or value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, str):
        text = value.strip()
        if not text:
            return None
        try:
            return float(text)
        except ValueError:
            return None
    return None


def _schema_value(value: Any) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    if value is None:
        return ""
    return str(value)


def _schema_label(value: Any) -> str:
    if isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)
    return _schema_value(value)


def _param_is_present(params: dict[str, Any], name: str) -> bool:
    if name not in params:
        return False
    value = params.get(name)
    if value is None:
        return False
    if isinstance(value, str) and not value.strip():
        return False
    if isinstance(value, (list, tuple, dict)) and not value:
        return False
    return True


def _condition_matches(params: dict[str, Any], condition: Any) -> bool:
    if not condition:
        return False
    if isinstance(condition, str):
        return _param_is_present(params, condition)
    if isinstance(condition, list):
        return all(_condition_matches(params, item) for item in condition)
    if not isinstance(condition, dict):
        return False
    if "when" in condition:
        return _condition_matches(params, condition.get("when"))
    if "condition" in condition:
        return _condition_matches(params, condition.get("condition"))
    if "all" in condition and isinstance(condition["all"], list):
        return all(_condition_matches(params, item) for item in condition["all"])
    if "any" in condition and isinstance(condition["any"], list):
        return any(_condition_matches(params, item) for item in condition["any"])
    source = condition.get("param") or condition.get("field") or condition.get("name") or condition.get("dependsOn")
    if not isinstance(source, str):
        return False
    if not _param_is_present(params, source):
        return False
    actual = _schema_value(params.get(source))
    if "equals" in condition:
        return actual == _schema_value(condition.get("equals"))
    if "eq" in condition:
        return actual == _schema_value(condition.get("eq"))
    if "notEquals" in condition:
        return actual != _schema_value(condition.get("notEquals"))
    if "notEq" in condition:
        return actual != _schema_value(condition.get("notEq"))
    if "neq" in condition:
        return actual != _schema_value(condition.get("neq"))
    expected = condition.get("value")
    if expected is not None:
        return actual == _schema_value(expected)
    values = condition.get("values") or condition.get("in")
    if isinstance(values, list):
        return actual in {_schema_value(value) for value in values}
    not_values = condition.get("notIn")
    if isinstance(not_values, list):
        return actual not in {_schema_value(value) for value in not_values}
    return True


def _conditional_param_rules(definition: dict[str, Any]) -> list[dict[str, Any]]:
    rules: list[dict[str, Any]] = []
    for key in ("requiredIf", "visibleIf", "enabledIf", "dependsOn"):
        value = definition.get(key)
        if not value:
            continue
        condition = value
        required = key in {"requiredIf", "dependsOn"}
        if isinstance(value, dict) and any(rule_key in value for rule_key in ("when", "condition", "required")):
            condition = value.get("when") or value.get("condition") or value
            required = bool(value.get("required", required))
        rules.append({"kind": key, "condition": condition, "required": required})
    return rules


def _format_conditional_rule(rule: dict[str, Any]) -> dict[str, Any]:
    return {
        "kind": rule.get("kind"),
        "required": bool(rule.get("required")),
        "condition": rule.get("condition"),
        "conditionLabel": _schema_label(rule.get("condition")),
    }


def _model_matches_node_type(model: dict[str, Any], node_type: str | None) -> bool:
    if not node_type:
        return True
    return model.get("canvasNodeType") == node_type or model.get("nodeType") == node_type


def _find_model_schema(api: PixmaxClient, model_code: str, node_type: str | None = None) -> dict[str, Any]:
    rows = [
        row for row in _flatten_model_config(api.canvas_model_config())
        if row.get("modelCode") == model_code or row.get("modelName") == model_code
    ]
    if node_type:
        typed = [row for row in rows if _model_matches_node_type(row, node_type)]
        if typed:
            rows = typed
    if len(rows) == 1:
        return rows[0]
    if not rows:
        suffix = f" for node type {node_type}" if node_type else ""
        raise RuntimeError(f"Model not found{suffix}: {model_code}")
    choices = ", ".join(
        f"{row.get('modelCode')}:{row.get('canvasNodeType') or row.get('nodeType')}"
        for row in rows
    )
    raise RuntimeError(f"Model is ambiguous: {model_code}. Matches: {choices}. Pass --type or use a unique model code.")


def _validate_model_params(model: dict[str, Any], params: dict[str, Any], *, node_type: str | None = None) -> list[str]:
    errors: list[str] = []
    if node_type and not _model_matches_node_type(model, node_type):
        errors.append(
            f"model {model.get('modelCode')} is for {model.get('canvasNodeType') or model.get('nodeType')}, not {node_type}"
        )
    config = model.get("modelConfig") if isinstance(model.get("modelConfig"), dict) else {}
    definitions = {
        item.get("name"): item
        for item in config.get("params") or []
        if isinstance(item, dict) and isinstance(item.get("name"), str)
    }
    for name, definition in definitions.items():
        for rule in _conditional_param_rules(definition):
            if not rule.get("required"):
                continue
            if _condition_matches(params, rule.get("condition")) and not _param_is_present(params, name):
                errors.append(
                    f"{name} is required when {rule.get('kind')} condition is met: "
                    f"{_schema_label(rule.get('condition'))}"
                )
    for name, value in params.items():
        if name == "model":
            continue
        definition = definitions.get(name)
        if not isinstance(definition, dict):
            continue
        options = definition.get("options")
        if isinstance(options, list) and options:
            allowed = {_schema_value(option.get("value")) for option in options if isinstance(option, dict)}
            if allowed and _schema_value(value) not in allowed:
                errors.append(f"{name}={value!r} is not one of: {', '.join(sorted(allowed))}")
        # Match official build100014: the backend enforces prompt length.
        # Keep validation for model options, inputs and other text fields.
        min_len, max_len = _parse_range(definition.get("length"))
        if name.lower() == "prompt":
            continue
        if definition.get("type") == "text" and (min_len is not None or max_len is not None):
            length = len(str(value or ""))
            if min_len is not None and length < min_len:
                errors.append(f"{name} length {length} is below minimum {min_len}")
            if max_len is not None and length > max_len:
                errors.append(f"{name} length {length} exceeds maximum {max_len}")
    return errors


def _value_list(value: Any) -> list[Any]:
    if isinstance(value, list):
        return value
    if isinstance(value, tuple):
        return list(value)
    if isinstance(value, str) and value:
        return [value]
    return []


def _model_input_rules(model: dict[str, Any]) -> list[dict[str, Any]]:
    config = model.get("modelConfig") if isinstance(model.get("modelConfig"), dict) else {}
    raw_rules = None
    for source in (config, model):
        for key in ("allowNodeType", "allowNodeTypes", "allowedNodeTypes", "inputNodeTypes", "inputNodes"):
            value = source.get(key) if isinstance(source, dict) else None
            if isinstance(value, list):
                raw_rules = value
                break
        if raw_rules is not None:
            break
    rules: list[dict[str, Any]] = []
    for raw in raw_rules or []:
        if not isinstance(raw, dict):
            continue
        codes = _value_list(
            raw.get("codes")
            or raw.get("code")
            or raw.get("nodeTypes")
            or raw.get("nodeType")
            or raw.get("types")
            or raw.get("type")
        )
        normalized_codes = [str(code).upper() for code in codes if str(code).strip()]
        min_count, max_count = _parse_range(raw.get("length") or raw.get("range") or raw.get("count"))
        if min_count is None and isinstance(raw.get("min"), int):
            min_count = raw.get("min")
        if max_count is None and isinstance(raw.get("max"), int):
            max_count = raw.get("max")
        if not normalized_codes and min_count is None and max_count is None:
            continue
        rules.append(
            {
                "codes": normalized_codes,
                "min": min_count,
                "max": max_count,
                "label": raw.get("label") or raw.get("name") or raw.get("title"),
                "raw": raw,
            }
        )
    return rules


def _node_matches_input_code(node: dict[str, Any], code: str) -> bool:
    code = code.upper()
    node_type = str(node.get("type") or "").upper()
    kind = _node_input_kind(node)
    if code == node_type:
        return True
    if code in {"IMAGE", "IMG", "BASE_IMAGE", "GENERATE_IMAGE", "GENERATE_STORYBOARD"}:
        return kind == "image" and (code in {"IMAGE", "IMG"} or node_type == code)
    if code in {"VIDEO", "BASE_VIDEO", "GENERATE_VIDEO"}:
        return kind == "video" and (code == "VIDEO" or node_type == code)
    if code in {"AUDIO", "BASE_AUDIO", "GENERATE_AUDIO"}:
        return kind == "audio" and (code == "AUDIO" or node_type == code)
    if code in {"TEXT", "GENERATE_TEXT"}:
        return kind == "text" and (code == "TEXT" or node_type == code)
    return False


def _input_rule_count(rule: dict[str, Any], input_nodes: list[dict[str, Any]]) -> int:
    codes = rule.get("codes") if isinstance(rule.get("codes"), list) else []
    if not codes:
        return 0
    return sum(1 for node in input_nodes if any(_node_matches_input_code(node, code) for code in codes))


# Constraint key variants (min*/max*/*Range) are derived per field in _constraint_range.
_MEDIA_CONSTRAINT_FIELDS = ("width", "height", "duration", "fileSize")


def _constraint_range(raw: dict[str, Any], base_name: str) -> tuple[float | None, float | None]:
    direct = raw.get(base_name)
    min_value: float | None = None
    max_value: float | None = None
    if isinstance(direct, (list, tuple)) and len(direct) >= 2:
        min_value = _parse_number(direct[0])
        max_value = _parse_number(direct[1])
    elif isinstance(direct, str):
        left, right = _parse_range(direct)
        min_value = float(left) if left is not None else None
        max_value = float(right) if right is not None else None
    minimum_keys = (f"min{base_name[0].upper()}{base_name[1:]}", f"{base_name}Min", f"minimum{base_name[0].upper()}{base_name[1:]}")
    maximum_keys = (f"max{base_name[0].upper()}{base_name[1:]}", f"{base_name}Max", f"maximum{base_name[0].upper()}{base_name[1:]}")
    range_keys = (f"{base_name}Range", f"{base_name}Limit", f"{base_name}Limits")
    for key in minimum_keys:
        parsed = _parse_number(raw.get(key))
        if parsed is not None:
            min_value = parsed
            break
    for key in maximum_keys:
        parsed = _parse_number(raw.get(key))
        if parsed is not None:
            max_value = parsed
            break
    for key in range_keys:
        if min_value is not None and max_value is not None:
            break
        left, right = _parse_range(raw.get(key))
        if left is not None:
            min_value = float(left)
        if right is not None:
            max_value = float(right)
    return min_value, max_value


def _media_constraints(raw: dict[str, Any]) -> dict[str, tuple[float | None, float | None]]:
    constraints: dict[str, tuple[float | None, float | None]] = {}
    for name in _MEDIA_CONSTRAINT_FIELDS:
        minimum, maximum = _constraint_range(raw, name)
        if minimum is not None or maximum is not None:
            constraints[name] = (minimum, maximum)
    nested_sources = []
    for key in ("asset", "assets", "media", "image", "video", "audio", "constraints", "assetConstraints", "mediaConstraints"):
        value = raw.get(key)
        if isinstance(value, dict):
            nested_sources.append(value)
    for source in nested_sources:
        for name in _MEDIA_CONSTRAINT_FIELDS:
            minimum, maximum = _constraint_range(source, name)
            if minimum is None and maximum is None:
                continue
            old_min, old_max = constraints.get(name, (None, None))
            constraints[name] = (
                minimum if minimum is not None else old_min,
                maximum if maximum is not None else old_max,
            )
    return constraints


def _node_media_value(node: dict[str, Any], key: str) -> float | None:
    asset = node.get("defaultAsset") if isinstance(node.get("defaultAsset"), dict) else {}
    metadata = node.get("metadata") if isinstance(node.get("metadata"), dict) else {}
    data = node.get("data") if isinstance(node.get("data"), dict) else {}
    candidates = []
    for source in (asset, metadata, data, node):
        if not isinstance(source, dict):
            continue
        candidates.append(source.get(key))
        if key == "fileSize":
            candidates.extend([source.get("size"), source.get("bytes")])
    asset_meta = asset.get("metaData") if isinstance(asset.get("metaData"), dict) else {}
    if asset_meta:
        candidates.append(asset_meta.get(key))
        if key == "fileSize":
            candidates.extend([asset_meta.get("size"), asset_meta.get("bytes")])
    for value in candidates:
        parsed = _parse_number(value)
        if parsed is not None:
            return parsed
    return None


def _node_label(node: dict[str, Any]) -> str:
    return str(node.get("label") or node.get("uuid") or "<unknown>")


def _validate_media_constraints(input_nodes: list[dict[str, Any]], rules: list[dict[str, Any]]) -> list[str]:
    errors: list[str] = []
    for rule in rules:
        constraints = _media_constraints(rule.get("raw", {}) if isinstance(rule.get("raw"), dict) else {})
        if not constraints:
            continue
        matched_nodes = [
            node for node in input_nodes
            if any(_node_matches_input_code(node, code) for code in rule.get("codes") or [])
        ]
        for node in matched_nodes:
            for field, (minimum, maximum) in constraints.items():
                actual = _node_media_value(node, field)
                if actual is None:
                    continue
                if minimum is not None and actual < minimum:
                    errors.append(f"input node {_node_label(node)} {field}={actual:g} is below minimum {minimum:g}")
                if maximum is not None and actual > maximum:
                    errors.append(f"input node {_node_label(node)} {field}={actual:g} exceeds maximum {maximum:g}")
    return errors


def _format_input_rule(rule: dict[str, Any], *, count: int | None = None) -> dict[str, Any]:
    result = {
        "codes": rule.get("codes") or [],
        "min": rule.get("min"),
        "max": rule.get("max"),
    }
    if rule.get("label"):
        result["label"] = rule.get("label")
    constraints = _media_constraints(rule.get("raw", {}) if isinstance(rule.get("raw"), dict) else {})
    if constraints:
        result["mediaConstraints"] = {
            key: {"min": minimum, "max": maximum}
            for key, (minimum, maximum) in constraints.items()
        }
    if count is not None:
        result["count"] = count
    return result


def _validate_input_nodes(model: dict[str, Any], params: dict[str, Any], input_nodes: list[dict[str, Any]]) -> tuple[list[str], list[dict[str, Any]]]:
    errors: list[str] = []
    rules = _model_input_rules(model)
    explained_rules: list[dict[str, Any]] = []
    refer_model = str(params.get("referModel") or "")
    media_nodes = [node for node in input_nodes if _node_input_kind(node) in {"image", "video", "audio"}]
    image_nodes = [node for node in input_nodes if _node_input_kind(node) == "image"]
    video_or_audio_nodes = [node for node in input_nodes if _node_input_kind(node) in {"video", "audio"}]

    if refer_model == "imageToVideo":
        if len(image_nodes) != 1:
            errors.append(f"referModel=imageToVideo requires exactly 1 image reference node, got {len(image_nodes)}")
        if video_or_audio_nodes:
            labels = ", ".join(str(node.get("label") or node.get("uuid")) for node in video_or_audio_nodes)
            errors.append(f"referModel=imageToVideo does not accept video/audio reference nodes: {labels}")
    elif refer_model == "textToVideo" and media_nodes:
        labels = ", ".join(str(node.get("label") or node.get("uuid")) for node in media_nodes)
        errors.append(f"referModel=textToVideo does not accept media reference nodes: {labels}")

    required_rules = [rule for rule in rules if isinstance(rule.get("min"), int) and rule["min"] > 0]
    for rule in rules:
        count = _input_rule_count(rule, input_nodes)
        explained_rules.append(_format_input_rule(rule, count=count))
        max_count = rule.get("max")
        min_count = rule.get("min")
        if isinstance(max_count, int) and count > max_count:
            errors.append(f"input nodes for {', '.join(rule.get('codes') or [])} count {count} exceeds maximum {max_count}")
        enforce_min = isinstance(min_count, int) and min_count > 0 and refer_model != "textToVideo"
        if enforce_min and (len(required_rules) <= 1 or rule.get("raw", {}).get("required") is True) and count < min_count:
            errors.append(f"input nodes for {', '.join(rule.get('codes') or [])} count {count} is below minimum {min_count}")
    errors.extend(_validate_media_constraints(input_nodes, rules))
    return errors, explained_rules


def _model_explanation(model: dict[str, Any]) -> dict[str, Any]:
    config = model.get("modelConfig") if isinstance(model.get("modelConfig"), dict) else {}
    params: list[dict[str, Any]] = []
    for item in config.get("params") or []:
        if not isinstance(item, dict):
            continue
        options = item.get("options")
        option_values = [
            option.get("value")
            for option in options or []
            if isinstance(option, dict) and "value" in option
        ] if isinstance(options, list) else []
        conditional_rules = [
            _format_conditional_rule(rule)
            for rule in _conditional_param_rules(item)
        ]
        param = {
            "name": item.get("name"),
            "type": item.get("type"),
            "label": item.get("label") or item.get("title"),
            "required": item.get("required"),
            "default": item.get("default") or item.get("defaultValue"),
            "length": item.get("length"),
            "options": option_values,
        }
        if conditional_rules:
            param["conditionalRules"] = conditional_rules
        params.append(
            param
        )
    return {
        "modelCode": model.get("modelCode"),
        "modelName": model.get("modelName"),
        "nodeType": model.get("canvasNodeType") or model.get("nodeType"),
        "restricted": model.get("restricted"),
        "requiredTierCode": model.get("requiredTierCode"),
        "restrictionReason": model.get("restrictionReason"),
        "params": params,
        "inputRules": [_format_input_rule(rule) for rule in _model_input_rules(model)],
    }


def _count_items(response: dict[str, Any]) -> int | None:
    data = response.get("data")
    if isinstance(data, list):
        return len(data)
    if isinstance(data, dict):
        for key in ("list", "items", "records", "rows", "data"):
            value = data.get(key)
            if isinstance(value, list):
                return len(value)
        total = data.get("total") or data.get("totalCount")
        if isinstance(total, int):
            return total
    return None


def _response_keys(response: dict[str, Any]) -> list[str]:
    data = response.get("data")
    if isinstance(data, dict):
        return sorted(str(key) for key in data.keys())
    if isinstance(data, list) and data and isinstance(data[0], dict):
        return sorted(str(key) for key in data[0].keys())
    return []


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


def _skill_prompt() -> str:
    return (
        "请帮我安装并初始化 Pixmax CLI。进入 Pixmax CLI 包目录（包含 setup.py 的目录）后，"
        "执行 bash scripts/install.sh。安装后运行 pixmax --json doctor 做本地自检，"
        "再运行 pixmax --help 确认命令可用。需要登录时运行 "
        "pixmax auth login web，我会在浏览器里完成授权；也可以只使用当前 shell 的 "
        "PIXMAX_BEARER_TOKEN 环境变量。不要把我的 Pixmax token 写入源码、文档、脚本或提交记录。"
        "登录后请运行 pixmax --json doctor --online 验证线上鉴权，"
        "再运行 pixmax --json capabilities matrix 查看本地能力矩阵。"
    )


def _skill_file_records(root: Path) -> list[dict[str, Any]]:
    relative_files = [
        "pixmax/skills/SKILL.md",
        "pixmax/skills/references/generation-node-protocol-v1.md",
        "pixmax/README.md",
        "PIXMAX.md",
        "setup.py",
        "scripts/install.sh",
        "scripts/install.ps1",
    ]
    records = []
    for relative in relative_files:
        path = root / relative
        records.append(
            {
                "path": relative,
                "exists": path.exists(),
                "bytes": path.stat().st_size if path.exists() else None,
                "role": (
                    "skill"
                    if relative.endswith("SKILL.md")
                    else "installer"
                    if relative.startswith("scripts/install")
                    else "source"
                    if relative == "setup.py"
                    else "documentation"
                ),
            }
        )
    return records


def _click_leaf_commands(command: click.Command, prefix: str = "") -> list[str]:
    commands = getattr(command, "commands", None)
    if not commands:
        return [prefix.strip()]
    leaves: list[str] = []
    for name, subcommand in commands.items():
        leaves.extend(_click_leaf_commands(subcommand, f"{prefix} {name}".strip()))
    return leaves


def _command_capability_matrix() -> dict[str, Any]:
    categories = [
        {
            "name": "launcherUpdate",
            "commands": ["update status", "update retry", "update repair"],
            "endpoints": [],
            "status": "launcher-static-feed",
        },
        {
            "name": "configuration",
            "commands": ["config show", "config set", "config init"],
            "endpoints": [],
            "status": "local-state",
        },
        {
            "name": "session",
            "commands": ["session status", "session clear"],
            "endpoints": [],
            "status": "local-state",
        },
        {
            "name": "capabilities",
            "commands": ["capabilities matrix", "capabilities probe"],
            "endpoints": [
                "/user/info",
                "/credit/balance",
                "/project/list",
                "/assets/list",
                "/task/list",
                "/quickTask/list",
                "/canvas/template/list",
                "/canvas/template/category/tree",
                "/storyboard/config",
                "/canvas/modelConfig",
                "/project/get",
                "/project/file/tree",
                "/canvas/get",
            ],
            "status": "wrapped",
        },
        {
            "name": "account",
            "commands": [
                "auth whoami",
                "auth credit",
                "auth login token",
                "auth login status",
                "auth login web",
                "auth profile save",
                "auth profile list",
                "auth profile use",
                "auth profile delete",
            ],
            "endpoints": ["/user/info", "/credit/balance", "/auth/code", "/auth/getToken"],
            "status": "wrapped",
        },
        {
            "name": "onboarding",
            "commands": ["doctor", "skill prompt", "skill show", "skill files", "skill package"],
            "endpoints": ["/user/info"],
            "status": "local-and-optional-readonly",
        },
        {
            "name": "project",
            "commands": ["project use", "project list", "project info", "project save", "project delete"],
            "endpoints": ["/project/list", "/project/get", "/project/createOrUpdate", "/project/delete"],
            "status": "wrapped",
        },
        {
            "name": "projectFiles",
            "commands": ["project files", "project file create", "project file rename", "project file move", "project file delete"],
            "endpoints": ["/project/file/tree", "/project/file/create", "/project/file/rename", "/project/file/move", "/project/file/delete"],
            "status": "wrapped",
        },
        {
            "name": "canvas",
            "commands": [
                "canvas get",
                "canvas summary",
                "canvas nodes",
                "canvas export",
                "canvas model-config",
                "canvas node create",
                "canvas node update",
                "canvas node delete",
                "canvas node restore",
                "canvas batch",
            ],
            "endpoints": [
                "/canvas/get",
                "/canvas/modelConfig",
                "/canvas/modelConfigCheck",
                "/canvas/node/create",
                "/canvas/node/update",
                "/canvas/node/delete",
                "/canvas/node/restore",
                "/canvas/node/batch",
            ],
            "status": "wrapped",
        },
        {
            "name": "nodes",
            "commands": ["node get", "node list", "node create", "node update", "node delete"],
            "endpoints": ["/canvas/node/batch", "/canvas/node/delete"],
            "status": "agent-friendly",
        },
        {
            "name": "models",
            "commands": ["model search", "model get", "model explain"],
            "endpoints": ["/canvas/modelConfig"],
            "status": "wrapped",
        },
        {
            "name": "imageWorkflows",
            "commands": ["image generate", "image edit"],
            "endpoints": ["/canvas/node/batch", "/generate/batch", "/generate/progress"],
            "status": "high-level",
        },
        {
            "name": "assets",
            "commands": ["assets list", "assets links", "assets download", "assets upload", "assets check", "assets oss-authorize", "assets oss-check", "assets compliance-check"],
            "endpoints": ["/assets/list", "/assets/getAssetsLink", "/assets/check", "/assets/oss/authorize", "/assets/oss/check", "/assetLibrary/compliance/check"],
            "status": "wrapped",
        },
        {
            "name": "generation",
            "commands": ["tasks list", "tasks history", "tasks detail", "tasks progress", "tasks wait", "tasks cancel", "tasks submit-batch"],
            "endpoints": ["/task/list", "/generate/lists", "/generate/detail", "/generate/progress", "/generate/cancel", "/generate/batch"],
            "status": "wrapped",
        },
        {
            "name": "quickTasks",
            "commands": ["tasks quick-list", "tasks quick-submit", "tasks template-submit"],
            "endpoints": ["/quickTask/list", "/quickTask/submit", "/task/submit/templateTask"],
            "status": "raw-wrapper",
        },
        {
            "name": "templates",
            "commands": ["templates list", "templates get", "templates categories", "templates storyboard-config"],
            "endpoints": ["/canvas/template/list", "/canvas/template/get", "/canvas/template/category/tree", "/storyboard/config"],
            "status": "wrapped",
        },
        {
            "name": "videoWorkflows",
            "commands": ["video image-to-video", "video text-to-video"],
            "endpoints": ["/canvas/node/batch", "/assetLibrary/compliance/check", "/generate/batch", "/generate/progress"],
            "status": "high-level",
        },
        {
            "name": "workflowComposition",
            "commands": ["workflow image-to-video", "workflow script-to-video", "workflow save", "workflow list", "workflow show", "workflow delete", "workflow run"],
            "endpoints": ["/canvas/node/batch", "/generate/batch", "/generate/progress", "/assetLibrary/compliance/check"],
            "status": "high-level-and-saved-payloads",
        },
        {
            "name": "storyboardWorkflows",
            "commands": ["storyboard config", "storyboard create"],
            "endpoints": ["/storyboard/config", "/canvas/node/batch", "/generate/batch"],
            "status": "high-level",
        },
        {
            "name": "scriptWorkflows",
            "commands": ["script create", "script rows", "script set-rows", "script storyboard"],
            "endpoints": ["/canvas/node/batch", "/generate/batch"],
            "status": "compatibility-layer",
        },
        {
            "name": "groups",
            "commands": ["group bind", "group list", "group use", "group unuse", "group delete", "group run"],
            "endpoints": ["/generate/batch"],
            "status": "local-agent-abstraction",
        },
        {
            "name": "escapeHatch",
            "commands": ["raw", "repl"],
            "endpoints": ["any /user/api endpoint"],
            "status": "wrapped",
        },
    ]
    return {
        "categories": categories,
        "commandCount": sum(len(category["commands"]) for category in categories),
        "endpointCount": len({endpoint for category in categories for endpoint in category["endpoints"]}),
    }


def _doctor_check(name: str, status: str, message: str, **details: Any) -> dict[str, Any]:
    check: dict[str, Any] = {
        "name": name,
        "status": status,
        "message": message,
    }
    if details:
        check["details"] = details
    return check


def _summarize_model_capabilities(response: dict[str, Any]) -> dict[str, Any]:
    models = _flatten_model_config(response)
    by_node_type: dict[str, int] = {}
    with_input_rules = 0
    restricted = 0
    for model in models:
        node_type = str(model.get("canvasNodeType") or model.get("nodeType") or "UNKNOWN")
        by_node_type[node_type] = by_node_type.get(node_type, 0) + 1
        if _model_input_rules(model):
            with_input_rules += 1
        if model.get("restricted"):
            restricted += 1
    return {
        "modelCount": len(models),
        "nodeTypes": by_node_type,
        "modelsWithInputRules": with_input_rules,
        "restrictedModelCount": restricted,
        "sampleModels": [
            {
                "modelCode": model.get("modelCode"),
                "modelName": model.get("modelName"),
                "nodeType": model.get("canvasNodeType") or model.get("nodeType"),
            }
            for model in models[:10]
        ],
    }


def _wrapped_model_node_types() -> set[str]:
    return {"GENERATE_TEXT", "GENERATE_IMAGE", "GENERATE_VIDEO", "GENERATE_STORYBOARD"}


def _probe_auth_failed(probe: dict[str, Any]) -> bool:
    error = str(probe.get("error") or "").lower()
    return "401" in error or "no login" in error or "unauthorized" in error


def _capability_discoveries(
    *,
    model_config_response: dict[str, Any] | None,
    probes: list[dict[str, Any]],
) -> dict[str, Any]:
    matrix = _command_capability_matrix()
    matrix_commands = {
        command
        for category in matrix["categories"]
        for command in category.get("commands", [])
    }
    models = _flatten_model_config(model_config_response or {})
    discovered_models = [
        {
            "modelCode": model.get("modelCode"),
            "modelName": model.get("modelName"),
            "nodeType": model.get("canvasNodeType") or model.get("nodeType"),
            "restricted": model.get("restricted"),
            "hasInputRules": bool(_model_input_rules(model)),
        }
        for model in models
    ]
    node_types = sorted({str(model.get("canvasNodeType") or model.get("nodeType")) for model in models if model.get("canvasNodeType") or model.get("nodeType")})
    unwrapped_model_types = [node_type for node_type in node_types if node_type not in _wrapped_model_node_types()]
    failed_probes = [probe for probe in probes if not probe.get("ok")]
    auth_failed_probes = [probe for probe in failed_probes if _probe_auth_failed(probe)]
    probe_by_name = {probe.get("name"): probe for probe in probes}
    action_items: list[dict[str, Any]] = []
    if auth_failed_probes:
        action_items.append(
            {
                "priority": "P0",
                "kind": "auth-failure",
                "name": "pixmax-auth",
                "recommendation": "Refresh the Pixmax bearer token or browser login state before treating probe failures as platform gaps.",
                "failedProbeCount": len(auth_failed_probes),
            }
        )
    for node_type in unwrapped_model_types:
        action_items.append(
            {
                "priority": "P1",
                "kind": "model-node-type",
                "name": node_type,
                "recommendation": f"Add a high-level workflow command for {node_type}.",
            }
        )
    if (
        "templates list" in matrix_commands
        and "tasks quick-list" in matrix_commands
        and (probe_by_name.get("templates") or {}).get("ok")
        and (probe_by_name.get("quickTasks") or {}).get("ok")
    ):
        action_items.append(
            {
                "priority": "P2",
                "kind": "template-automation",
                "name": "template-to-workflow",
                "recommendation": "Convert frequently used template/quick-task payloads into saved workflow definitions after live probing.",
            }
        )
    for probe in failed_probes:
        if auth_failed_probes and len(auth_failed_probes) == len(failed_probes):
            continue
        action_items.append(
            {
                "priority": "P0",
                "kind": "probe-failure",
                "name": probe.get("name"),
                "endpoint": probe.get("endpoint"),
                "recommendation": "Investigate failed read-only probe before relying on this platform surface.",
                "error": probe.get("error"),
            }
        )
    return {
        "discoveredModels": discovered_models,
        "nodeTypes": node_types,
        "unwrappedModelTypes": unwrapped_model_types,
        "failedProbeCount": len(failed_probes),
        "authFailureCount": len(auth_failed_probes),
        "platformProbeReliable": not auth_failed_probes,
        "actionItems": action_items,
    }


def _probe_entry(name: str, endpoint: str, func) -> dict[str, Any]:
    try:
        response = func()
        return {
            "name": name,
            "endpoint": endpoint,
            "ok": True,
            "success": response.get("success"),
            "itemCount": _count_items(response),
            "dataKeys": _response_keys(response),
        }
    except Exception as exc:
        return {
            "name": name,
            "endpoint": endpoint,
            "ok": False,
            "error": str(exc),
            "errorType": type(exc).__name__,
        }


def _probe_readonly_capabilities(api: PixmaxClient, *, project_uuid: str | None = None, file_uuid: str | None = None) -> dict[str, Any]:
    probes = [
        _probe_entry("user", "/user/info", api.user_info),
        _probe_entry("credit", "/credit/balance", api.credit_balance),
        _probe_entry("projects", "/project/list", lambda: api.project_list({"pageIndex": 1, "pageSize": 5})),
        _probe_entry("assets", "/assets/list", api.assets_list),
        _probe_entry("tasks", "/task/list", lambda: api.task_list({"pageIndex": 1, "pageSize": 5, "needTotalCount": True})),
        _probe_entry("quickTasks", "/quickTask/list", lambda: api.quick_task_list({"pageIndex": 1, "pageSize": 5, "needTotalCount": True})),
        _probe_entry("templates", "/canvas/template/list", lambda: api.canvas_template_list({"pageIndex": 1, "pageSize": 5})),
        _probe_entry("templateCategories", "/canvas/template/category/tree", api.canvas_template_category_tree),
        _probe_entry("storyboardConfig", "/storyboard/config", api.storyboard_config),
    ]
    model_summary = None
    model_config_response = None
    try:
        model_config_response = api.canvas_model_config()
        probes.append(
            {
                "name": "modelConfig",
                "endpoint": "/canvas/modelConfig",
                "ok": True,
                "success": model_config_response.get("success"),
                "itemCount": _count_items(model_config_response),
                "dataKeys": _response_keys(model_config_response),
            }
        )
        model_summary = _summarize_model_capabilities(model_config_response)
    except Exception as exc:
        probes.append(
            {
                "name": "modelConfig",
                "endpoint": "/canvas/modelConfig",
                "ok": False,
                "error": str(exc),
                "errorType": type(exc).__name__,
            }
        )
        model_summary = {"error": str(exc), "errorType": type(exc).__name__}
    if project_uuid:
        probes.append(_probe_entry("project", "/project/get", lambda: api.project_get(project_uuid)))
        probes.append(_probe_entry("projectFiles", "/project/file/tree", lambda: api.file_tree(project_uuid)))
    if file_uuid:
        canvas_probe = _probe_entry("canvas", "/canvas/get", lambda: api.canvas_get(file_uuid))
        probes.append(canvas_probe)
    return {
        "mode": "readonly",
        "probedCount": len(probes),
        "okCount": sum(1 for item in probes if item.get("ok")),
        "failedCount": sum(1 for item in probes if not item.get("ok")),
        "probes": probes,
        "modelSummary": model_summary,
        "discoveries": _capability_discoveries(model_config_response=model_config_response, probes=probes),
        "localMatrix": _command_capability_matrix(),
    }


def _validate_node_params(
    api: PixmaxClient,
    node_payload: dict[str, Any],
    *,
    input_nodes: list[dict[str, Any]] | None = None,
) -> dict[str, Any] | None:
    params = node_payload.get("params") if isinstance(node_payload.get("params"), dict) else {}
    model_code = params.get("model")
    if not isinstance(model_code, str) or not model_code:
        return None
    node_type = node_payload.get("type") if isinstance(node_payload.get("type"), str) else None
    model = _find_model_schema(api, model_code, node_type)
    errors = _validate_model_params(model, params, node_type=node_type)
    input_errors, input_rules = _validate_input_nodes(model, params, input_nodes or [])
    errors.extend(input_errors)
    if errors:
        joined = "\n- ".join(errors)
        raise ValueError(f"Model parameter validation failed for {model_code}:\n- {joined}")
    return {
        "modelCode": model.get("modelCode"),
        "nodeType": model.get("canvasNodeType") or model.get("nodeType"),
        "checkedParams": [name for name in params if name != "model"],
        "inputNodeCount": len(input_nodes or []),
        "inputRules": input_rules,
    }


def _synthetic_node_payload(
    *,
    label: str,
    node_type: str,
    file_uuid: str,
    prompt: str | None,
    model: str | None,
    params: dict[str, Any],
    data: dict[str, Any],
    prev_node_uuids: list[str],
    x: float,
    y: float,
) -> dict[str, Any]:
    merged_params = dict(params)
    if prompt is not None:
        merged_params["prompt"] = prompt
    if model is not None:
        merged_params["model"] = model
    if node_type.upper() in _V1_GENERATION_NODE_TYPES:
        merged_params = {
            key: ("true" if value else "false") if isinstance(value, bool)
            else str(value) if isinstance(value, (int, float)) else value
            for key, value in merged_params.items()
        }
    protocol_v1 = node_type.upper() in _V1_GENERATION_NODE_TYPES
    metadata = {
        "data": {"label": label} if protocol_v1 else {"label": label, **data},
        "position": {"x": x, "y": y},
    }
    if protocol_v1:
        metadata.update({
            "GENERATE_TEXT": {"width": 240, "height": 240},
            "GENERATE_IMAGE": {"width": 200, "height": 200},
            "GENERATE_AUDIO": {"width": 280, "height": 120},
            "GENERATE_VIDEO": {"width": 300, "height": 200},
        }[node_type.upper()])
    payload = {
        "uuid": str(uuid.uuid4()),
        "type": node_type,
        "metaData": json.dumps(metadata, ensure_ascii=False, separators=(",", ":")),
        "params": merged_params,
        "prevNodeUuids": prev_node_uuids,
    }
    if protocol_v1:
        payload["nodeText" if node_type.upper() == "GENERATE_TEXT" else "defaultAssetUuid"] = ""
    else:
        payload["fileUuid"] = file_uuid
        payload["isGenerateNode"] = node_type.startswith("GENERATE_")
    return payload


def _find_nested_mapping(data: dict[str, Any], keys: tuple[str, ...]) -> dict[str, Any]:
    for key in keys:
        value = data.get(key)
        if isinstance(value, dict):
            return value
    return {}


def _first_string(data: dict[str, Any], keys: tuple[str, ...]) -> str | None:
    for key in keys:
        value = data.get(key)
        if isinstance(value, str) and value:
            return value
    return None


def _upload_plan(authorize_result: dict[str, Any]) -> dict[str, Any]:
    auth_data = authorize_result.get("data") if isinstance(authorize_result.get("data"), dict) else authorize_result
    upload_data = _find_nested_mapping(auth_data, ("upload", "uploadInfo", "oss", "ossInfo", "credentials")) or auth_data
    method = (_first_string(upload_data, ("method", "uploadMethod")) or "").upper()
    upload_url = _first_string(upload_data, ("uploadUrl", "url", "signedUrl", "putUrl", "host"))
    headers = _find_nested_mapping(upload_data, ("headers", "header"))
    fields = _find_nested_mapping(upload_data, ("fields", "formData", "form"))
    object_key = _first_string(upload_data, ("objectKey", "ossKey", "key", "path", "assetKey"))
    oss_sts = {
        "bucket": _first_string(upload_data, ("bucketName", "bucket")),
        "endpoint": _first_string(upload_data, ("endpoint", "ossEndpoint")),
        "objectKey": object_key,
        "accessKeyId": _first_string(upload_data, ("accessKeyId", "OSSAccessKeyId", "accessid")),
        "accessKeySecret": _first_string(upload_data, ("accessKeySecret", "accessKeySecret")),
        "securityToken": _first_string(upload_data, ("securityToken", "x-oss-security-token")),
        "callbackUrl": _first_string(upload_data, ("callbackUrl",)),
        "callbackBody": _first_string(upload_data, ("callbackBody",)),
        "callbackBodyType": _first_string(upload_data, ("callbackBodyType",)),
    }
    if all(oss_sts[key] for key in ("bucket", "endpoint", "objectKey", "accessKeyId", "accessKeySecret", "securityToken")):
        method = "OSS_STS_PUT"
        upload_url = upload_url or f"https://{oss_sts['bucket']}.{oss_sts['endpoint']}/{object_key}"
    if not fields:
        field_keys = (
            "key",
            "policy",
            "signature",
            "OSSAccessKeyId",
            "accessid",
            "callback",
            "success_action_status",
            "x-oss-security-token",
            "x-oss-credential",
            "x-oss-algorithm",
            "x-oss-date",
            "x-oss-signature",
        )
        fields = {key: upload_data[key] for key in field_keys if key in upload_data and upload_data[key] is not None}
    if not method:
        method = "POST" if fields else "PUT"
    if not upload_url:
        available = sorted(upload_data.keys())
        raise RuntimeError(f"OSS authorization did not include an upload URL. Available keys: {available}")
    if method not in {"PUT", "POST", "OSS_STS_PUT"}:
        raise RuntimeError(f"Unsupported upload method from OSS authorization: {method}")
    file_field = _first_string(upload_data, ("fileField", "fileFieldName")) or "file"
    return {
        "method": method,
        "url": upload_url,
        "headers": headers,
        "fields": fields,
        "fileField": file_field,
        "objectKey": object_key,
        "ossSts": oss_sts,
        "authorization": auth_data,
    }


def _asset_from_check_result(check_result: dict[str, Any]) -> dict[str, Any]:
    data = check_result.get("data") if isinstance(check_result.get("data"), dict) else {}
    asset = data.get("asset") if isinstance(data.get("asset"), dict) else {}
    return asset


def _asset_from_precheck_result(check_result: dict[str, Any]) -> dict[str, Any]:
    data = check_result.get("data")
    if isinstance(data, dict):
        for key in ("asset", "assets", "matchedAsset", "existingAsset"):
            value = data.get(key)
            if isinstance(value, dict):
                return value
            if isinstance(value, list) and value and isinstance(value[0], dict):
                return value[0]
        if data.get("assetsUuid") or data.get("assetUuid") or data.get("uuid"):
            return data
    if isinstance(data, list) and data and isinstance(data[0], dict):
        return data[0]
    return {}


def _asset_uuid(asset: dict[str, Any]) -> str | None:
    for key in ("assetsUuid", "assetUuid", "uuid"):
        value = asset.get(key)
        if isinstance(value, str) and value:
            return value
    return None


def _first_asset_uuid(assets: list[dict[str, Any]]) -> str | None:
    for asset in assets:
        value = _asset_uuid(asset)
        if value:
            return value
    return None


def _generated_input_node(node_payload: dict[str, Any], asset: dict[str, Any] | None = None) -> dict[str, Any]:
    metadata = {}
    raw_metadata = node_payload.get("metaData")
    if isinstance(raw_metadata, str) and raw_metadata:
        try:
            parsed = json.loads(raw_metadata)
            metadata = parsed if isinstance(parsed, dict) else {}
        except json.JSONDecodeError:
            metadata = {}
    data = metadata.get("data") if isinstance(metadata.get("data"), dict) else {}
    return {
        "uuid": node_payload.get("uuid"),
        "type": node_payload.get("type"),
        "isGenerateNode": node_payload.get("isGenerateNode"),
        "label": data.get("label"),
        "model": (node_payload.get("params") or {}).get("model") if isinstance(node_payload.get("params"), dict) else None,
        "status": "COMPLETE" if asset else None,
        "defaultAsset": asset or {},
    }


def _first_result_asset_for_node(wait_result: dict[str, Any], node_uuid: str) -> dict[str, Any] | None:
    nodes = wait_result.get("nodes") if isinstance(wait_result.get("nodes"), list) else []
    for item in nodes:
        if not isinstance(item, dict) or item.get("nodeUuid") != node_uuid:
            continue
        assets = item.get("resultAssets") if isinstance(item.get("resultAssets"), list) else []
        for asset in assets:
            if isinstance(asset, dict) and _asset_uuid(asset):
                return asset
    return None


def _compliance_payload(asset_uuid: str, payload: dict[str, Any]) -> dict[str, Any]:
    result = dict(payload)
    result.setdefault("assetUuid", asset_uuid)
    return result


def _compliance_status(result: dict[str, Any]) -> str | None:
    data = result.get("data") if isinstance(result.get("data"), dict) else {}
    for key in ("complianceStatus", "status", "assetComplianceStatus"):
        value = data.get(key)
        if isinstance(value, str) and value:
            return value.upper()
    return None


def _poll_compliance(
    api: PixmaxClient,
    payload: dict[str, Any],
    *,
    interval: float,
    timeout: float,
) -> dict[str, Any]:
    deadline = time.monotonic() + timeout
    attempts = 0
    terminal_success = {"ACTIVE", "PASS", "PASSED", "SUCCESS", "SUCCEEDED", "COMPLETE", "COMPLETED"}
    terminal_failure = {"FAILED", "FAIL", "REJECTED", "BLOCKED", "ERROR"}
    last_result: dict[str, Any] | None = None

    while True:
        attempts += 1
        last_result = api.asset_library_compliance_check(payload)
        status = _compliance_status(last_result)
        if status in terminal_success or status in terminal_failure:
            return {"attempts": attempts, "status": status, "result": last_result}
        if time.monotonic() >= deadline:
            return {"attempts": attempts, "status": status or "TIMEOUT", "timedOut": True, "result": last_result}
        time.sleep(interval)


_GENERATION_SUCCESS_STATUSES = {"COMPLETE", "COMPLETED", "SUCCESS", "SUCCEEDED"}
_GENERATION_FAILURE_STATUSES = {"FAILED", "FAIL", "ERROR", "CANCEL", "CANCELED", "CANCELLED"}


def _generation_items(result: dict[str, Any]) -> list[dict[str, Any]]:
    data = result.get("data")
    if isinstance(data, list):
        return [item for item in data if isinstance(item, dict)]
    if isinstance(data, dict):
        for key in ("list", "items", "tasks", "records"):
            value = data.get(key)
            if isinstance(value, list):
                return [item for item in value if isinstance(item, dict)]
        return [data]
    return []


def _generation_status(item: dict[str, Any]) -> str | None:
    value = item.get("status")
    return value.upper() if isinstance(value, str) and value else None


def _generation_result_assets(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    assets: list[dict[str, Any]] = []
    for item in items:
        for asset in item.get("resultAssets") or []:
            if isinstance(asset, dict):
                assets.append(asset)
    return assets


def _generation_wait_state(node_uuids: list[str], items: list[dict[str, Any]]) -> dict[str, Any]:
    by_node = {item.get("nodeUuid"): item for item in items if isinstance(item.get("nodeUuid"), str)}
    missing = [node_uuid for node_uuid in node_uuids if node_uuid not in by_node]
    statuses = [_generation_status(by_node[node_uuid]) for node_uuid in node_uuids if node_uuid in by_node]
    if missing or not statuses:
        return {"status": "PENDING", "complete": False, "failed": False, "missingNodeUuids": missing}
    if any(status in _GENERATION_FAILURE_STATUSES for status in statuses):
        return {"status": "FAILED", "complete": True, "failed": True, "missingNodeUuids": []}
    if all(status in _GENERATION_SUCCESS_STATUSES for status in statuses):
        return {"status": "COMPLETE", "complete": True, "failed": False, "missingNodeUuids": []}
    return {"status": "RUNNING", "complete": False, "failed": False, "missingNodeUuids": []}


def _wait_generation(
    api: PixmaxClient,
    node_uuids: list[str],
    *,
    interval: float,
    timeout: float,
) -> dict[str, Any]:
    interval = max(interval, 0)
    deadline = time.monotonic() + max(timeout, 0)
    attempts = 0
    last_result: dict[str, Any] | None = None

    while True:
        attempts += 1
        last_result = api.generate_progress(node_uuids)
        items = _generation_items(last_result)
        state = _generation_wait_state(node_uuids, items)
        if state["complete"]:
            return {
                "attempts": attempts,
                "status": state["status"],
                "ok": not state["failed"],
                "nodeUuids": node_uuids,
                "nodes": items,
                "resultAssets": _generation_result_assets(items),
                "result": last_result,
            }
        if time.monotonic() >= deadline:
            return {
                "attempts": attempts,
                "status": "TIMEOUT",
                "ok": False,
                "timedOut": True,
                "nodeUuids": node_uuids,
                "missingNodeUuids": state.get("missingNodeUuids") or [],
                "nodes": items,
                "resultAssets": _generation_result_assets(items),
                "result": last_result,
            }
        time.sleep(interval)


def _exit_on_failed_wait(wait_result: dict[str, Any], *, allow_failed: bool = False) -> None:
    if not allow_failed and not wait_result.get("ok"):
        raise click.exceptions.Exit(1)


def _canvas_batch_payload(
    api: PixmaxClient,
    file_uuid: str,
    *,
    create: list[dict[str, Any]] | None = None,
    update: list[dict[str, Any]] | None = None,
    delete: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    summary = canvas_summary(api.canvas_get(file_uuid), base_url=getattr(api, "base_url", None))
    revision = summary.get("revision")
    return {
        "fileUuid": file_uuid,
        "baseRevision": revision if isinstance(revision, str) else "",
        "create": create or [],
        "update": update or [],
        "delete": delete or [],
    }


def _batch_mutate_nodes(
    api: PixmaxClient,
    file_uuid: str,
    *,
    create: list[dict[str, Any]] | None = None,
    update: list[dict[str, Any]] | None = None,
    delete: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    return api.canvas_node_batch(
        _canvas_batch_payload(api, file_uuid, create=create, update=update, delete=delete)
    )


def _video_params(
    *,
    model: str,
    prompt: str,
    resolution: str,
    aspect_ratio: str,
    duration: str,
    refer_model: str,
    include_audio: bool,
    count: str,
    extra_params: dict[str, Any],
) -> dict[str, Any]:
    params = dict(extra_params)
    params.update(
        {
            "model": model,
            "prompt": prompt,
            "resolution": resolution,
            "aspectRatio": aspect_ratio,
            "duration": str(duration),
            "referModel": refer_model,
            "includeAudio": "true" if include_audio else "false",
            "count": str(count),
        }
    )
    return params


def _storyboard_params(
    *,
    model: str,
    prompt: str,
    grid_layout: str,
    resolution: str,
    aspect_ratio: str,
    count: str,
    extra_params: dict[str, Any],
) -> dict[str, Any]:
    params = dict(extra_params)
    params.update(
        {
            "model": model,
            "prompt": prompt,
            "gridLayout": grid_layout,
            "resolution": resolution,
            "aspectRatio": aspect_ratio,
            "count": str(count),
        }
    )
    return params


def _batch_create_node(api: PixmaxClient, file_uuid: str, node_payload: dict[str, Any]) -> dict[str, Any]:
    return _batch_mutate_nodes(api, file_uuid, create=[node_payload])


def _image_params(
    *,
    model: str,
    prompt: str,
    resolution: str,
    aspect_ratio: str,
    count: str,
    extra_params: dict[str, Any],
) -> dict[str, Any]:
    params = dict(extra_params)
    params.update(
        {
            "model": model,
            "prompt": prompt,
            "resolution": resolution,
            "aspectRatio": aspect_ratio,
            "count": str(count),
        }
    )
    return params


def _run_generate_node_workflow(
    *,
    api: PixmaxClient,
    file_uuid: str,
    node_payload: dict[str, Any],
    input_nodes: list[dict[str, Any]] | None = None,
    validate_params: bool,
    wait_after_submit: bool,
    interval: float,
    timeout: float,
) -> dict[str, Any]:
    """Validate, create, submit, and optionally wait for one generate node."""
    validation = _validate_node_params(api, node_payload, input_nodes=input_nodes) if validate_params else None
    create_result = _batch_create_node(api, file_uuid, node_payload)
    generate_payload = {
        "fileUuid": file_uuid,
        "nodeUuids": [node_payload["uuid"]],
        "nodes": [node_payload["uuid"]],
    }
    submit_result = api.generate_batch(generate_payload)
    wait_result = None
    if wait_after_submit:
        wait_result = _wait_generation(api, [node_payload["uuid"]], interval=interval, timeout=timeout)
    result: dict[str, Any] = {
        "nodeKey": node_payload["uuid"],
        "uuid": node_payload["uuid"],
        "plans": [
            {"endpoint": "/canvas/node/batch", "payload": {"fileUuid": file_uuid, "create": [node_payload], "update": [], "delete": []}},
            {"endpoint": "/generate/batch", "payload": generate_payload},
        ],
        "create": create_result,
        "submit": submit_result,
    }
    if validation:
        result["validation"] = validation
    if wait_result:
        result["wait"] = wait_result
    return result


@click.group(invoke_without_command=True)
@click.version_option(version=__version__)
@click.option("--json", "use_json", is_flag=True, help="Emit machine-readable JSON.")
@click.option("--token", default=None, help=f"Pixmax bearer token. Prefer {ENV_TOKEN}.")
@click.option("--environment", type=click.Choice(sorted(ENVIRONMENTS)), default=None, help=f"Pixmax service environment. Overrides {ENV_ENVIRONMENT}.")
@click.option("--base-url", default=None, help="Pixmax API base URL.")
@click.option("--locale", "locale_name", type=click.Choice(["en", "zh-CN"], case_sensitive=False), default=None, help=f"Human-readable output locale. Overrides {ENV_LOCALE}.")
@click.option("--timeout", default=90, show_default=True, type=int, help="HTTP timeout seconds.")
@click.option("--session-file", default=None, help="Override session JSON path.")
@click.option("--config-file", default=None, help=f"Override config JSON path. Prefer {ENV_CONFIG_FILE}.")
@click.pass_context
def cli(
    ctx: click.Context,
    use_json: bool,
    token: str | None,
    environment: str | None,
    base_url: str | None,
    locale_name: str | None,
    timeout: int,
    session_file: str | None,
    config_file: str | None,
):
    """Pixmax CLI — operate Pixmax projects, canvases, assets, and tasks."""
    global _json_output
    _json_output = use_json
    ctx.ensure_object(dict)
    settings = PixmaxConfig(config_file)
    selected_environment = resolve_environment(environment, base_url, settings)
    if base_url:
        selected_base_url = base_url
    elif environment:
        selected_base_url = ENVIRONMENTS[selected_environment]["apiBaseUrl"]
    else:
        selected_base_url = os.environ.get(ENV_BASE_URL) or ENVIRONMENTS[selected_environment]["apiBaseUrl"]
    selected_base_url = selected_base_url.rstrip("/")
    ctx.obj.update(
        {
            "token": token,
            "environment": selected_environment,
            "base_url": selected_base_url,
            "locale": resolve_locale(locale_name, settings),
            "timeout": timeout,
            "session_file": session_file,
            "config": settings,
        }
    )
    if ctx.invoked_subcommand is None:
        ctx.invoke(repl)


@cli.group("update")
def update_commands():
    """Inspect, retry, or repair launcher-managed CLI updates."""


def _launcher_command_required() -> None:
    raise click.ClickException(
        "This command must be executed through the installed pixmax launcher."
    )


@update_commands.command("status")
def update_status():
    """Show local launcher and Runtime update status without network access."""
    _launcher_command_required()


@update_commands.command("retry")
def update_retry():
    """Force a fresh signed-manifest check."""
    _launcher_command_required()


@update_commands.command("repair")
def update_repair():
    """Redownload, verify, and reinstall the latest signed Runtime."""
    _launcher_command_required()


@cli.group()
def auth():
    """Authentication and account commands."""


@cli.group("config")
def config_commands():
    """Manage persistent environment and locale defaults."""


@config_commands.command("show")
@click.pass_context
def config_show(ctx: click.Context):
    """Show stored settings and the effective settings for this invocation."""
    stored = ctx.obj["config"].status()
    _emit(
        {
            "stored": stored,
            "effective": {
                "environment": ctx.obj["environment"],
                "locale": ctx.obj["locale"],
                "baseUrl": ctx.obj["base_url"],
            },
        },
        _human(ctx, zh="Pixmax CLI 配置", en="Pixmax CLI configuration"),
    )


@config_commands.command("set")
@click.option("--environment", type=click.Choice(sorted(ENVIRONMENTS)), default=None)
@click.option("--locale", "locale_name", type=click.Choice(["en", "zh-CN"], case_sensitive=False), default=None)
@click.pass_context
@_handle_errors
def config_set(ctx: click.Context, environment: str | None, locale_name: str | None):
    """Persist the default service environment and/or human output locale."""
    if environment is None and locale_name is None:
        raise RuntimeError("Pass --environment and/or --locale.")
    settings = ctx.obj["config"]
    settings.set(environment=environment, locale=locale_name)
    _emit(settings.status(), _human(ctx, zh="Pixmax CLI 配置已保存", en="Pixmax CLI configuration saved"))


@config_commands.command("init")
@click.option("--environment", type=click.Choice(sorted(ENVIRONMENTS)), required=True)
@click.option("--locale", "locale_name", type=click.Choice(["en", "zh-CN"], case_sensitive=False), default=None)
@click.pass_context
def config_init(ctx: click.Context, environment: str, locale_name: str | None):
    """Initialize unset defaults without replacing an existing user choice."""
    settings = ctx.obj["config"]
    changed = settings.initialize(environment=environment, locale=locale_name)
    _emit(
        {**settings.status(), "changed": changed},
        _human(ctx, zh="Pixmax CLI 配置已初始化", en="Pixmax CLI configuration initialized"),
    )


@cli.command("doctor")
@click.option("--online", is_flag=True, help="Also call /user/info to verify the Pixmax token.")
@click.pass_context
def doctor(ctx: click.Context, online: bool):
    """Run local installation and optional online authentication checks."""
    matrix = _command_capability_matrix()
    listed_commands = {
        command
        for category in matrix["categories"]
        for command in category["commands"]
    }
    actual_commands = set(_click_leaf_commands(cli))
    missing_from_matrix = sorted(actual_commands - listed_commands)
    extra_in_matrix = sorted(listed_commands - actual_commands)
    session_obj = _session(ctx)
    token_source = _token_source(ctx)
    token_configured = token_source is not None
    base_url = ctx.obj["base_url"]
    checks = [
        _doctor_check(
            "cli",
            "pass",
            "Pixmax CLI command is importable.",
            version=__version__,
        ),
        _doctor_check(
            "capabilityMatrix",
            "pass" if not missing_from_matrix else "fail",
            "Capability matrix covers the current Click command tree." if not missing_from_matrix else "Capability matrix is missing Click commands.",
            commandCount=matrix["commandCount"],
            endpointCount=matrix["endpointCount"],
            missingFromMatrix=missing_from_matrix,
            extraInMatrix=extra_in_matrix,
        ),
        _doctor_check(
            "session",
            "pass" if session_obj.project_uuid and session_obj.file_uuid else "warn",
            "Default project and file are configured." if session_obj.project_uuid and session_obj.file_uuid else "Default project/file are not fully configured.",
            sessionFile=session_obj.session_file,
            projectUuid=session_obj.project_uuid,
            projectName=session_obj.project_name,
            fileUuid=session_obj.file_uuid,
            fileName=session_obj.file_name,
            groupName=session_obj.group_name,
            workflowCount=len(session_obj.workflows),
        ),
        _doctor_check(
            "token",
            "pass" if token_configured else "warn",
            f"{ENV_TOKEN} is configured." if token_configured else f"{ENV_TOKEN} is not configured; online Pixmax commands will fail until a token is provided.",
            source=token_source,
            activeProfile=session_obj.active_auth_profile,
        ),
    ]
    if online:
        if not token_configured:
            checks.append(
                _doctor_check(
                    "onlineAuth",
                    "fail",
                    f"Cannot verify online auth because {ENV_TOKEN} is missing.",
                    endpoint="/user/info",
                )
            )
        else:
            try:
                result = _client(ctx).user_info()
                data = result.get("data") or {}
                checks.append(
                    _doctor_check(
                        "onlineAuth",
                        "pass",
                        "Pixmax token is accepted by /user/info.",
                        endpoint="/user/info",
                        unionId=data.get("unionId"),
                        userName=data.get("name"),
                        accountType=data.get("accountType"),
                        userTier=data.get("userTier"),
                        maskedEmail=data.get("maskedEmail"),
                        maskedPhone=data.get("maskedPhone"),
                        releaseVersion=result.get("releaseVersion"),
                    )
                )
            except PixmaxAPIError as exc:
                checks.append(
                    _doctor_check(
                        "onlineAuth",
                        "fail",
                        str(exc),
                        endpoint="/user/info",
                        response=exc.response,
                    )
                )
    failed = sum(1 for check in checks if check["status"] == "fail")
    warnings = sum(1 for check in checks if check["status"] == "warn")
    result = {
        "ok": failed == 0,
        "online": online,
        "environment": ctx.obj["environment"],
        "locale": ctx.obj["locale"],
        "baseUrl": base_url,
        "version": __version__,
        "commandCount": matrix["commandCount"],
        "endpointCount": matrix["endpointCount"],
        "failedCount": failed,
        "warningCount": warnings,
        "checks": checks,
        "nextActions": [
            action
            for action in [
                "pixmax auth login web" if not token_configured else None,
                f"export {ENV_TOKEN}=<token>" if not token_configured else None,
                "pixmax project use <project_uuid> --file <file_uuid>" if not (session_obj.project_uuid and session_obj.file_uuid) else None,
                "pixmax --json doctor --online" if token_configured and not online else None,
            ]
            if action
        ],
    }
    _emit(result, "Pixmax CLI doctor")
    if failed:
        raise click.exceptions.Exit(1)


@cli.group()
def skill():
    """Inspect Pixmax CLI Skill prompts, files, and package output."""


@skill.command("prompt")
@click.pass_context
@_handle_errors
def skill_prompt(ctx: click.Context):
    """Show the install prompt that can be sent to an AI agent."""
    _emit(
        {
            "prompt": _skill_prompt(),
            "commands": [
                "bash scripts/install.sh",
                "pixmax --json doctor",
                "pixmax auth login web",
                "pixmax --json doctor --online",
                "pixmax --json capabilities matrix",
            ],
            "tokenPolicy": f"Prefer auth login web; otherwise use {ENV_TOKEN} from the current shell. Never write tokens to files.",
        },
        "Pixmax CLI agent install prompt",
    )


@skill.command("show")
@click.option("--file", "relative_path", default="pixmax/skills/SKILL.md", show_default=True, help="Repository-relative skill/document file to show.")
@click.pass_context
@_handle_errors
def skill_show(ctx: click.Context, relative_path: str):
    """Show the local Pixmax skill markdown."""
    root = _repo_root()
    path = (root / relative_path).resolve()
    if root not in path.parents and path != root:
        raise RuntimeError("Refusing to read files outside the Pixmax CLI repository.")
    if not path.exists() or not path.is_file():
        raise RuntimeError(f"Skill file not found: {relative_path}")
    content = path.read_text(encoding="utf-8")
    if _json_output:
        _emit({"path": str(path.relative_to(root)), "content": content}, "Pixmax CLI skill file")
    else:
        click.echo(content)


@skill.command("files")
@click.pass_context
@_handle_errors
def skill_files(ctx: click.Context):
    """List files used by the local Pixmax CLI skill package."""
    root = _repo_root()
    records = _skill_file_records(root)
    _emit(
        {
            "root": str(root),
            "files": records,
            "missing": [record["path"] for record in records if not record["exists"]],
        },
        "Pixmax CLI skill files",
    )


@skill.command("package")
@click.option("--out", "out_dir", default=None, type=click.Path(file_okay=False), help="Output directory. Defaults to ./dist.")
@click.pass_context
@_handle_errors
def skill_package(ctx: click.Context, out_dir: str | None):
    """Build a local Pixmax CLI skill directory and zip package."""
    root = _repo_root()
    output_dir = Path(out_dir).expanduser().resolve() if out_dir else root / "dist"
    result = build_skill_package(root, output_dir)
    _emit(
        {
            "ok": True,
            "skillDir": result["skillDir"],
            "zipPath": result["zipPath"],
            "files": _skill_file_records(root),
        },
        "Pixmax CLI skill package built",
    )


@cli.group()
def capabilities():
    """Inspect Pixmax CLI coverage and read-only platform capabilities."""


@capabilities.command("matrix")
@click.pass_context
@_handle_errors
def capabilities_matrix(ctx: click.Context):
    """Show the local Pixmax CLI capability matrix."""
    _emit(_command_capability_matrix(), "Pixmax CLI capability matrix")


@capabilities.command("probe")
@click.option("--project", "project_uuid", default=None, help="Optional project UUID for project/file-tree probing.")
@click.option("--file", "file_uuid", default=None, help="Optional file UUID for canvas probing.")
@click.option("--dry-run", is_flag=True, help="Print planned read-only probes without calling Pixmax.")
@click.pass_context
@_handle_errors
def capabilities_probe(ctx: click.Context, project_uuid: str | None, file_uuid: str | None, dry_run: bool):
    """Run read-only probes against Pixmax to discover available platform features."""
    project_uuid = project_uuid or _session(ctx).project_uuid
    file_uuid = file_uuid or _session(ctx).file_uuid
    planned = [
        "/user/info",
        "/credit/balance",
        "/project/list",
        "/assets/list",
        "/task/list",
        "/quickTask/list",
        "/canvas/template/list",
        "/canvas/template/category/tree",
        "/storyboard/config",
        "/canvas/modelConfig",
    ]
    if project_uuid:
        planned.extend(["/project/get", "/project/file/tree"])
    if file_uuid:
        planned.append("/canvas/get")
    if dry_run:
        _emit(
            {
                "dryRun": True,
                "mode": "readonly",
                "projectUuid": project_uuid,
                "fileUuid": file_uuid,
                "plannedEndpoints": planned,
                "plannedOutputs": ["probes", "modelSummary", "discoveries", "localMatrix"],
                "localMatrix": _command_capability_matrix(),
            },
            "Pixmax capability probe dry run",
        )
        return
    _emit(
        _probe_readonly_capabilities(_client(ctx), project_uuid=project_uuid, file_uuid=file_uuid),
        "Pixmax capability probe",
    )


@auth.command("whoami")
@click.pass_context
@_handle_errors
def auth_whoami(ctx: click.Context):
    """Show the authenticated Pixmax user."""
    result = _client(ctx).user_info()
    data = result.get("data") or {}
    _emit(
        {
            "unionId": data.get("unionId"),
            "name": data.get("name"),
            "accountType": data.get("accountType"),
            "userTier": data.get("userTier"),
            "enterpriseVerified": data.get("enterpriseVerified"),
            "maskedEmail": data.get("maskedEmail"),
            "maskedPhone": data.get("maskedPhone"),
            "releaseVersion": result.get("releaseVersion"),
        },
        "Pixmax account",
    )


@auth.command("credit")
@click.pass_context
@_handle_errors
def auth_credit(ctx: click.Context):
    """Show credit balance."""
    _emit(_client(ctx).credit_balance(), "Pixmax credit balance")


@auth.group("login")
def auth_login():
    """Pixmax login helpers: web device-code login, token login, and status."""


@auth_login.command("token")
@click.option("--token", "login_token", default=None, help=f"Bearer token to verify. Defaults to --token or {ENV_TOKEN}.")
@click.option("--profile", "profile_name", default="default", show_default=True, help="Local auth profile name.")
@click.option("--store-token", is_flag=True, help="Store the token in the local session file for future switching.")
@click.option("--no-activate", is_flag=True, help="Save the profile without making it active.")
@click.pass_context
@_handle_errors
def auth_login_token(ctx: click.Context, login_token: str | None, profile_name: str, store_token: bool, no_activate: bool):
    """Verify a Pixmax bearer token and save account metadata as a local profile."""
    token = get_token(login_token or ctx.obj.get("token") or os.environ.get(ENV_TOKEN))
    api = PixmaxClient(
        token=token,
        base_url=ctx.obj.get("base_url"),
        timeout=ctx.obj.get("timeout") or 90,
        locale=ctx.obj.get("locale"),
    )
    result = api.user_info()
    profile = _verified_auth_profile(
        token,
        result,
        store_token=store_token,
        environment=ctx.obj["environment"],
        base_url=ctx.obj["base_url"],
    )
    _session(ctx).set_auth_profile(profile_name, profile, activate=not no_activate)
    _emit(
        {
            "loggedIn": True,
            "method": "bearer-token",
            "profile": profile_name,
            "active": _session(ctx).active_auth_profile == profile_name,
            "storedToken": bool(store_token),
            "account": _auth_profile_public(profile),
            "warning": None if store_token else "Token was verified but not stored. Use --store-token only if local token persistence is acceptable.",
            "nextActions": [
                "pixmax --json doctor --online",
                "pixmax project use <project_uuid> --file <file_uuid>",
            ],
        },
        "Pixmax token login verified",
    )


@auth_login.command("status")
@click.pass_context
@_handle_errors
def auth_login_status(ctx: click.Context):
    """Show current Pixmax CLI authentication source."""
    session = _session(ctx)
    active = _active_profile(ctx) or {}
    token_source = _token_source(ctx)
    _emit(
        {
            "loggedIn": token_source is not None,
            "source": token_source,
            "activeProfile": session.active_auth_profile,
            "hasStoredToken": bool(active.get("token")),
            "maskedToken": _mask_token(ctx.obj.get("token") or os.environ.get(ENV_TOKEN)) or active.get("maskedToken"),
            "account": _auth_profile_public(active) if active else None,
            "nextActions": [
                "pixmax auth login web"
                if token_source is None
                else "pixmax --json doctor --online",
            ],
        },
        "Pixmax auth login status",
    )


@auth_login.command("web")
@click.option("--profile", "profile_name", default="default", show_default=True, help="Local auth profile name.")
@click.option("--client-code", default=DEFAULT_DEVICE_CLIENT_CODE, show_default=True, help="Client name shown on the browser authorization page.")
@click.option("--no-browser", is_flag=True, help="Do not open a browser automatically; only print the authorization URL.")
@click.option("--interval", default=2.0, show_default=True, type=float, help="Token polling interval in seconds.")
@click.option("--timeout", "login_timeout", default=300, show_default=True, type=int, help="Maximum seconds to wait for browser authorization.")
@click.option("--no-store-token", is_flag=True, help="Verify the login but do not persist the token to the local session file.")
@click.option("--no-activate", is_flag=True, help="Save the profile without making it active.")
@click.pass_context
@_handle_errors
def auth_login_web(
    ctx: click.Context,
    profile_name: str,
    client_code: str,
    no_browser: bool,
    interval: float,
    login_timeout: int,
    no_store_token: bool,
    no_activate: bool,
):
    """Sign in through the Pixmax web authorization page (device-code flow)."""
    base_url = ctx.obj.get("base_url")
    http_timeout = ctx.obj.get("timeout") or 90

    started = device_auth_create_code(
        client_code, base_url=base_url, timeout=http_timeout, locale=ctx.obj.get("locale")
    )
    started_data = started.get("data") or {}
    code = str(started_data.get("code") or started.get("code") or "").strip()
    if not code:
        raise RuntimeError("Pixmax did not return a device authorization code.")

    auth_url = device_auth_page_url(code, base_url=base_url)
    click.echo(
        _human(
            ctx,
            zh=f"请在浏览器中打开以下地址并完成授权（5 分钟内有效）：\n  {auth_url}",
            en=f"Open this URL in a browser and authorize within 5 minutes:\n  {auth_url}",
        ),
        err=True,
    )
    browser_opened = False
    if not no_browser:
        try:
            browser_opened = webbrowser.open(auth_url)
        except Exception:
            browser_opened = False
    click.echo(_human(ctx, zh="正在等待浏览器授权...", en="Waiting for browser authorization..."), err=True)

    token = None
    status = str(started_data.get("status") or "PENDING").strip().upper()
    deadline = time.monotonic() + max(login_timeout, 1)
    while time.monotonic() < deadline:
        result = device_auth_get_token(
            code, base_url=base_url, timeout=http_timeout, locale=ctx.obj.get("locale")
        )
        data = result.get("data") or {}
        if result.get("success") is False:
            message = result.get("errMessage") or result.get("errCode") or "Device authorization failed."
            raise RuntimeError(
                _human(
                    ctx,
                    zh=f"网页登录失败：{message}。请重新运行 pixmax auth login web。",
                    en=f"Web login failed: {message}. Run pixmax auth login web again.",
                )
            )
        status = str(data.get("status") or status).strip().upper()
        maybe_token = str(data.get("token") or "").strip()
        if maybe_token:
            token = maybe_token
            break
        time.sleep(max(interval, 0.1))
    if not token:
        raise RuntimeError(
            _human(
                ctx,
                zh="等待浏览器授权超时。请重新运行 pixmax auth login web，并在授权页有效期内完成确认。",
                en="Browser authorization timed out. Run pixmax auth login web again and approve before the page expires.",
            )
        )

    api = PixmaxClient(token=token, base_url=base_url, timeout=http_timeout, locale=ctx.obj.get("locale"))
    result = api.user_info()
    store_token = not no_store_token
    profile = _verified_auth_profile(
        token,
        result,
        store_token=store_token,
        environment=ctx.obj["environment"],
        base_url=ctx.obj["base_url"],
    )
    _session(ctx).set_auth_profile(profile_name, profile, activate=not no_activate)
    _emit(
        {
            "loggedIn": True,
            "method": "web-device-code",
            "clientCode": client_code,
            "authUrl": auth_url,
            "browserOpened": browser_opened,
            "status": status or "APPROVED",
            "profile": profile_name,
            "active": _session(ctx).active_auth_profile == profile_name,
            "storedToken": store_token,
            "account": _auth_profile_public(profile),
            "warning": None
            if store_token
            else f"Token was verified but not stored. Export {ENV_TOKEN} manually or rerun without --no-store-token.",
            "nextActions": [
                "pixmax --json doctor --online",
                "pixmax project use <project_uuid> --file <file_uuid>",
            ],
        },
        "Pixmax web login complete",
    )


@auth.group("profile")
def auth_profile():
    """Manage local Pixmax auth profiles."""


@auth_profile.command("save")
@click.argument("name")
@click.option("--token", "profile_token", default=None, help=f"Token for this profile. Defaults to --token or {ENV_TOKEN}.")
@click.option("--store-token", is_flag=True, help="Store the token in the local session file for future switching.")
@click.option("--no-activate", is_flag=True, help="Save the profile without making it active.")
@click.pass_context
@_handle_errors
def auth_profile_save(ctx: click.Context, name: str, profile_token: str | None, store_token: bool, no_activate: bool):
    """Save account metadata and optionally a local token profile."""
    token = get_token(profile_token or ctx.obj.get("token") or os.environ.get(ENV_TOKEN))
    api = PixmaxClient(
        token=token,
        base_url=ctx.obj.get("base_url"),
        timeout=ctx.obj.get("timeout") or 90,
        locale=ctx.obj.get("locale"),
    )
    result = api.user_info()
    profile = _verified_auth_profile(
        token,
        result,
        store_token=store_token,
        environment=ctx.obj["environment"],
        base_url=ctx.obj["base_url"],
    )
    _session(ctx).set_auth_profile(name, profile, activate=not no_activate)
    _emit(
        {
            "saved": True,
            "name": name,
            "active": _session(ctx).active_auth_profile == name,
            "storedToken": bool(store_token),
            "profile": _auth_profile_public(profile),
            "warning": None if store_token else "Token was verified but not stored. Use --store-token only if local token persistence is acceptable.",
        },
        "Pixmax auth profile saved",
    )


@auth_profile.command("list")
@click.pass_context
@_handle_errors
def auth_profile_list(ctx: click.Context):
    """List local Pixmax auth profiles."""
    session = _session(ctx)
    _emit(
        {
            "active": session.active_auth_profile,
            "profiles": session.status()["auth_profiles"],
        },
        "Pixmax auth profiles",
    )


@auth_profile.command("use")
@click.argument("name")
@click.pass_context
@_handle_errors
def auth_profile_use(ctx: click.Context, name: str):
    """Make a saved auth profile active."""
    session = _session(ctx)
    session.use_auth_profile(name)
    profile = session.auth_profiles.get(name) or {}
    _emit(
        {
            "active": name,
            "hasStoredToken": bool(profile.get("token")),
            "maskedToken": profile.get("maskedToken"),
            "nextActions": [
                "pixmax --json doctor --online"
                if profile.get("token")
                else f"export {ENV_TOKEN}=<token>"
            ],
        },
        "Pixmax auth profile activated",
    )


@auth_profile.command("delete")
@click.argument("name")
@click.option("--yes", is_flag=True, help="Confirm profile deletion.")
@click.pass_context
@_handle_errors
def auth_profile_delete(ctx: click.Context, name: str, yes: bool):
    """Delete a local Pixmax auth profile."""
    if not yes:
        raise RuntimeError("Refusing to delete auth profile without --yes.")
    _session(ctx).delete_auth_profile(name)
    _emit({"deleted": True, "name": name}, "Pixmax auth profile deleted")


@cli.group()
def session():
    """Persistent CLI defaults."""


@session.command("status")
@click.pass_context
def session_status(ctx: click.Context):
    """Show stored workspace defaults."""
    _emit(_session(ctx).status(), "Pixmax CLI session")


@session.command("clear")
@click.pass_context
def session_clear(ctx: click.Context):
    """Clear stored workspace defaults."""
    _session(ctx).clear()
    _emit({"cleared": True}, "Session cleared")


@cli.group()
def project():
    """Project and file tree commands."""


@project.command("use")
@click.argument("project_uuid")
@click.option("--file", "file_uuid", default=None, help="Default canvas file UUID.")
@click.pass_context
@_handle_errors
def project_use(ctx: click.Context, project_uuid: str, file_uuid: str | None):
    """Store a default Pixmax project and optional file for later commands."""
    api = _client(ctx)
    project_result = api.project_get(project_uuid)
    project_data = project_result.get("data") or {}
    file_name = None
    if file_uuid:
        for row in flatten_file_tree(api.file_tree(project_uuid).get("data") or []):
            if row.get("uuid") == file_uuid:
                file_name = row.get("name")
                break
    _session(ctx).set_workspace(
        project_uuid=project_uuid,
        file_uuid=file_uuid,
        project_name=project_data.get("name"),
        file_name=file_name,
    )
    _emit(_session(ctx).status(), "Workspace defaults saved")


@project.command("info")
@click.option("--project", "project_uuid", default=None, help="Project UUID.")
@click.pass_context
@_handle_errors
def project_info(ctx: click.Context, project_uuid: str | None):
    """Fetch project metadata."""
    project_uuid = _require_project(ctx, project_uuid)
    _emit(_client(ctx).project_get(project_uuid), "Pixmax project")


@project.command("list")
@click.option("--page", "page_index", default=1, show_default=True, type=int)
@click.option("--page-size", default=20, show_default=True, type=int)
@click.option("--mode", "project_set_mode", default="UNGROUPED", show_default=True)
@click.pass_context
@_handle_errors
def project_list(ctx: click.Context, page_index: int, page_size: int, project_set_mode: str):
    """List projects visible to the authenticated account."""
    payload = {"pageIndex": page_index, "pageSize": page_size, "projectSetMode": project_set_mode}
    _emit(_client(ctx).project_list(payload), "Pixmax projects")


@project.command("save")
@click.option("--name", required=True, help="Project name.")
@click.option("--project", "project_uuid", default=None, help="Existing project UUID for update.")
@click.option("--description", default=None, help="Project description.")
@click.option("--type", "project_type", default="PERSONAL", show_default=True, help="Pixmax project type.")
@click.option("--data", "data_json", default=None, help="Extra JSON fields merged into payload.")
@click.option("--file", "payload_file", default=None, type=click.Path(exists=True), help="Extra JSON payload file.")
@click.option("--dry-run", is_flag=True, help="Print payload without creating/updating.")
@click.pass_context
@_handle_errors
def project_save(
    ctx: click.Context,
    name: str,
    project_uuid: str | None,
    description: str | None,
    project_type: str,
    data_json: str | None,
    payload_file: str | None,
    dry_run: bool,
):
    """Create or update a Pixmax project."""
    payload = _load_payload(data_json, payload_file)
    payload.update({"name": name, "projectType": project_type})
    if project_uuid:
        payload["uuid"] = project_uuid
    if description:
        payload["description"] = description
    if dry_run:
        _emit_dry_run("/project/createOrUpdate", payload)
        return
    _emit(_client(ctx).project_create_or_update(payload), "Project saved")


@project.command("delete")
@click.argument("project_uuid", required=False)
@click.option("--yes", is_flag=True, help="Confirm deletion.")
@click.option("--dry-run", is_flag=True, help="Print payload without deleting.")
@click.pass_context
@_handle_errors
def project_delete(ctx: click.Context, project_uuid: str | None, yes: bool, dry_run: bool):
    """Delete a Pixmax project."""
    project_uuid = _require_project(ctx, project_uuid)
    payload = {"uuid": project_uuid}
    if dry_run:
        _emit_dry_run("/project/delete", payload)
        return
    if not yes:
        raise RuntimeError("Refusing to delete without --yes.")
    _emit(_client(ctx).project_delete(project_uuid), "Project deleted")


@project.command("files")
@click.option("--project", "project_uuid", default=None, help="Project UUID.")
@click.option("--flat/--tree", default=True, show_default=True, help="Flatten the file tree.")
@click.pass_context
@_handle_errors
def project_files(ctx: click.Context, project_uuid: str | None, flat: bool):
    """Fetch the project file tree."""
    project_uuid = _require_project(ctx, project_uuid)
    result = _client(ctx).file_tree(project_uuid)
    if flat:
        result = {**result, "data": flatten_file_tree(result.get("data") or [])}
    _emit(result, "Pixmax file tree")


@project.group("file")
def project_file():
    """Create, rename, move, and delete project files/folders."""


@project_file.command("create")
@click.option("--project", "project_uuid", default=None, help="Project UUID.")
@click.option("--name", required=True, help="File or folder name.")
@click.option("--type", "file_type", default="FILE", show_default=True, help="FILE or DIR.")
@click.option("--parent", "parent_uuid", default=None, help="Parent folder UUID.")
@click.option("--data", "data_json", default=None, help="Extra JSON fields merged into payload.")
@click.option("--file", "payload_file", default=None, type=click.Path(exists=True), help="Extra JSON payload file.")
@click.option("--dry-run", is_flag=True, help="Print payload without creating.")
@click.pass_context
@_handle_errors
def project_file_create(
    ctx: click.Context,
    project_uuid: str | None,
    name: str,
    file_type: str,
    parent_uuid: str | None,
    data_json: str | None,
    payload_file: str | None,
    dry_run: bool,
):
    """Create a project canvas file or folder."""
    project_uuid = _require_project(ctx, project_uuid)
    payload = _load_payload(data_json, payload_file)
    payload.update({"projectUuid": project_uuid, "name": name, "type": file_type})
    if parent_uuid:
        payload["parentUuid"] = parent_uuid
    if dry_run:
        _emit_dry_run("/project/file/create", payload)
        return
    _emit(_client(ctx).project_file_create(payload), "Project file created")


@project_file.command("rename")
@click.argument("file_uuid")
@click.option("--name", required=True, help="New name.")
@click.option("--dry-run", is_flag=True, help="Print payload without renaming.")
@click.pass_context
@_handle_errors
def project_file_rename(ctx: click.Context, file_uuid: str, name: str, dry_run: bool):
    """Rename a project file or folder."""
    payload = {"uuid": file_uuid, "name": name}
    if dry_run:
        _emit_dry_run("/project/file/rename", payload)
        return
    _emit(_client(ctx).project_file_rename(file_uuid, name), "Project file renamed")


@project_file.command("move")
@click.argument("file_uuid")
@click.option("--parent", "parent_uuid", default=None, help="Destination parent folder UUID.")
@click.option("--sort-order", type=int, default=None, help="Destination sort order.")
@click.option("--data", "data_json", default=None, help="Extra JSON fields merged into payload.")
@click.option("--file", "payload_file", default=None, type=click.Path(exists=True), help="Extra JSON payload file.")
@click.option("--dry-run", is_flag=True, help="Print payload without moving.")
@click.pass_context
@_handle_errors
def project_file_move(
    ctx: click.Context,
    file_uuid: str,
    parent_uuid: str | None,
    sort_order: int | None,
    data_json: str | None,
    payload_file: str | None,
    dry_run: bool,
):
    """Move a project file or folder."""
    payload = _load_payload(data_json, payload_file)
    payload["uuid"] = file_uuid
    if parent_uuid is not None:
        payload["parentUuid"] = parent_uuid
    if sort_order is not None:
        payload["sortOrder"] = sort_order
    if dry_run:
        _emit_dry_run("/project/file/move", payload)
        return
    _emit(_client(ctx).project_file_move(payload), "Project file moved")


@project_file.command("delete")
@click.argument("file_uuid")
@click.option("--yes", is_flag=True, help="Confirm deletion.")
@click.option("--dry-run", is_flag=True, help="Print payload without deleting.")
@click.pass_context
@_handle_errors
def project_file_delete(ctx: click.Context, file_uuid: str, yes: bool, dry_run: bool):
    """Delete a project file or folder."""
    payload = {"uuid": file_uuid}
    if dry_run:
        _emit_dry_run("/project/file/delete", payload)
        return
    if not yes:
        raise RuntimeError("Refusing to delete without --yes.")
    _emit(_client(ctx).project_file_delete(file_uuid), "Project file deleted")


@cli.group()
def canvas():
    """Canvas inspection and raw mutation commands."""


@canvas.command("get")
@click.option("--file", "file_uuid", default=None, help="Canvas file UUID.")
@click.pass_context
@_handle_errors
def canvas_get(ctx: click.Context, file_uuid: str | None):
    """Fetch the raw canvas payload for a Pixmax file."""
    file_uuid = _require_file(ctx, file_uuid)
    _emit(_client(ctx).canvas_get(file_uuid), "Pixmax canvas")


@canvas.command("summary")
@click.option("--file", "file_uuid", default=None, help="Canvas file UUID.")
@click.option("--include-prompts/--no-prompts", default=True, show_default=True)
@click.pass_context
@_handle_errors
def canvas_summary_cmd(ctx: click.Context, file_uuid: str | None, include_prompts: bool):
    """Summarize a canvas into agent-friendly node records."""
    file_uuid = _require_file(ctx, file_uuid)
    summary = canvas_summary(_client(ctx).canvas_get(file_uuid), base_url=ctx.obj.get("base_url"))
    if not include_prompts:
        for node in summary["nodes"]:
            node.pop("prompt", None)
    _emit(summary, "Pixmax canvas summary")


@canvas.command("nodes")
@click.option("--file", "file_uuid", default=None, help="Canvas file UUID.")
@click.option("--type", "node_type", default=None, help="Filter by Pixmax node type.")
@click.option("--generated/--all", "generated_only", default=False, help="Only generated nodes.")
@click.pass_context
@_handle_errors
def canvas_nodes(ctx: click.Context, file_uuid: str | None, node_type: str | None, generated_only: bool):
    """List canvas nodes with resolved asset URLs."""
    file_uuid = _require_file(ctx, file_uuid)
    nodes = canvas_summary(_client(ctx).canvas_get(file_uuid), base_url=ctx.obj.get("base_url"))["nodes"]
    if node_type:
        nodes = [node for node in nodes if node.get("type") == node_type]
    if generated_only:
        nodes = [node for node in nodes if node.get("isGenerateNode")]
    _emit(nodes, "Pixmax canvas nodes")


@canvas.command("model-config")
@click.option("--check", is_flag=True, help="Call modelConfigCheck instead of modelConfig.")
@click.pass_context
@_handle_errors
def canvas_model_config(ctx: click.Context, check: bool):
    """Fetch Pixmax canvas model configuration."""
    api = _client(ctx)
    _emit(api.canvas_model_config_check() if check else api.canvas_model_config(), "Pixmax canvas model config")


@canvas.group("node")
def canvas_node():
    """Raw canvas node create, update, delete, and restore commands."""


@canvas_node.command("create")
@click.option("--data", "data_json", default=None, help="JSON object payload.")
@click.option("--file", "payload_file", default=None, type=click.Path(exists=True), help="JSON payload file.")
@click.option("--dry-run", is_flag=True, help="Print payload without creating.")
@click.pass_context
@_handle_errors
def canvas_node_create(ctx: click.Context, data_json: str | None, payload_file: str | None, dry_run: bool):
    """Submit a raw /canvas/node/create payload."""
    payload = _payload_with_defaults(_load_payload(data_json, payload_file), ctx=ctx)
    if dry_run:
        _emit_dry_run("/canvas/node/create", payload)
        return
    _emit(_client(ctx).canvas_node_create(payload), "Canvas node created")


@canvas_node.command("update")
@click.option("--data", "data_json", default=None, help="JSON object payload.")
@click.option("--file", "payload_file", default=None, type=click.Path(exists=True), help="JSON payload file.")
@click.option("--dry-run", is_flag=True, help="Print payload without updating.")
@click.pass_context
@_handle_errors
def canvas_node_update(ctx: click.Context, data_json: str | None, payload_file: str | None, dry_run: bool):
    """Submit a raw /canvas/node/update payload."""
    payload = _payload_with_defaults(_load_payload(data_json, payload_file), ctx=ctx)
    if dry_run:
        _emit_dry_run("/canvas/node/update", payload)
        return
    _emit(_client(ctx).canvas_node_update(payload), "Canvas node updated")


@canvas_node.command("delete")
@click.option("--data", "data_json", default=None, help="JSON object payload.")
@click.option("--file", "payload_file", default=None, type=click.Path(exists=True), help="JSON payload file.")
@click.option("--yes", is_flag=True, help="Confirm deletion.")
@click.option("--dry-run", is_flag=True, help="Print payload without deleting.")
@click.pass_context
@_handle_errors
def canvas_node_delete(ctx: click.Context, data_json: str | None, payload_file: str | None, yes: bool, dry_run: bool):
    """Submit a raw /canvas/node/delete payload."""
    payload = _payload_with_defaults(_load_payload(data_json, payload_file), ctx=ctx)
    if dry_run:
        _emit_dry_run("/canvas/node/delete", payload)
        return
    if not yes:
        raise RuntimeError("Refusing to delete without --yes.")
    _emit(_client(ctx).canvas_node_delete(payload), "Canvas node deleted")


@canvas_node.command("restore")
@click.option("--data", "data_json", default=None, help="JSON object payload.")
@click.option("--file", "payload_file", default=None, type=click.Path(exists=True), help="JSON payload file.")
@click.option("--dry-run", is_flag=True, help="Print payload without restoring.")
@click.pass_context
@_handle_errors
def canvas_node_restore(ctx: click.Context, data_json: str | None, payload_file: str | None, dry_run: bool):
    """Submit a raw /canvas/node/restore payload."""
    payload = _payload_with_defaults(_load_payload(data_json, payload_file), ctx=ctx)
    if dry_run:
        _emit_dry_run("/canvas/node/restore", payload)
        return
    _emit(_client(ctx).canvas_node_restore(payload), "Canvas node restored")


@canvas.command("export")
@click.option("--file", "file_uuid", default=None, help="Canvas file UUID.")
@click.option("--output", "-o", required=True, type=click.Path(dir_okay=False), help="Output JSON file.")
@click.option("--summary/--raw", "summary_mode", default=True, show_default=True)
@click.pass_context
@_handle_errors
def canvas_export(ctx: click.Context, file_uuid: str | None, output: str, summary_mode: bool):
    """Export canvas raw JSON or summarized JSON to disk."""
    file_uuid = _require_file(ctx, file_uuid)
    raw = _client(ctx).canvas_get(file_uuid)
    data = canvas_summary(raw, base_url=ctx.obj.get("base_url")) if summary_mode else raw
    out = Path(output)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(data, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    _emit({"output": str(out), "bytes": out.stat().st_size, "summary": summary_mode}, "Canvas exported")


@canvas.command("batch")
@click.option("--data", "data_json", default=None, help="JSON object payload.")
@click.option("--file", "payload_file", default=None, type=click.Path(exists=True), help="JSON payload file.")
@click.option("--dry-run", is_flag=True, help="Validate payload locally without submitting.")
@click.pass_context
@_handle_errors
def canvas_batch(ctx: click.Context, data_json: str | None, payload_file: str | None, dry_run: bool):
    """Submit a raw /canvas/node/batch payload. Use carefully."""
    payload = _load_payload(data_json, payload_file)
    if dry_run:
        _emit({"dryRun": True, "payload": payload}, "Canvas batch dry run")
        return
    _emit(_client(ctx).canvas_node_batch(payload), "Canvas batch submitted")


@cli.group()
def model():
    """Search Pixmax models and fetch model schemas."""


@model.command("get")
@click.argument("name", nargs=-1, required=True)
@click.pass_context
@_handle_errors
def model_get(ctx: click.Context, name: tuple[str, ...]):
    """Fetch one Pixmax model schema by model code or name."""
    query = " ".join(name).strip()
    models = _flatten_model_config(_client(ctx).canvas_model_config())
    exact = [
        row for row in models
        if row.get("modelCode") == query or str(row.get("modelName") or "").lower() == query.lower()
    ]
    if len(exact) != 1:
        raise RuntimeError(f"Expected exactly one model match for {query}, got {len(exact)}. Try: model search {query}")
    _emit(exact[0], "Pixmax model")


@model.command("explain")
@click.argument("name", nargs=-1, required=True)
@click.option("--type", "node_type", default=None, help="Disambiguate by Pixmax node type, e.g. GENERATE_VIDEO.")
@click.pass_context
@_handle_errors
def model_explain(ctx: click.Context, name: tuple[str, ...], node_type: str | None):
    """Explain model params and input-node constraints in an agent-friendly shape."""
    query = " ".join(name).strip()
    model = _find_model_schema(_client(ctx), query, node_type)
    _emit(_model_explanation(model), "Pixmax model capabilities")


@model.command("search")
@click.argument("query", nargs=-1, required=False)
@click.option("--type", "node_type", default=None, help="Filter by Pixmax node type, e.g. GENERATE_IMAGE.")
@click.option("--restricted/--all", "restricted_only", default=False, help="Only restricted models.")
@click.pass_context
@_handle_errors
def model_search(ctx: click.Context, query: tuple[str, ...], node_type: str | None, restricted_only: bool):
    """Search Pixmax model configuration."""
    needle = " ".join(query).strip().lower()
    rows = _flatten_model_config(_client(ctx).canvas_model_config())
    if node_type:
        rows = [row for row in rows if row.get("canvasNodeType") == node_type or row.get("nodeType") == node_type]
    if restricted_only:
        rows = [row for row in rows if row.get("restricted")]
    if needle:
        rows = [
            row for row in rows
            if needle in str(row.get("modelCode") or "").lower()
            or needle in str(row.get("modelName") or "").lower()
        ]
    _emit({"query": needle, "count": len(rows), "models": rows}, "Pixmax models")


@cli.group()
def node():
    """Friendly Pixmax canvas node commands."""


@node.command("get")
@click.argument("selector")
@click.option("--file", "file_uuid", default=None, help="Canvas file UUID.")
@click.option("--group", "group_name", default=None, help="Use a named local node group.")
@click.pass_context
@_handle_errors
def node_get(ctx: click.Context, selector: str, file_uuid: str | None, group_name: str | None):
    """Query a Pixmax node by UUID or exact label."""
    target = _resolve_node(_nodes_for_scope(ctx, file_uuid, group_name), selector)
    _emit_pipe_record(_node_pipe_record(target), "Pixmax node")


@node.command("update")
@click.argument("selector")
@click.option("--file", "file_uuid", default=None, help="Canvas file UUID.")
@click.option("--group", "group_name", default=None, help="Use a named local node group.")
@click.option("--name", "new_name", default=None, help="Rename the node.")
@click.option("--prompt", default=None, help="Set params.prompt.")
@click.option("--model", "model_code", default=None, help="Set params.model.")
@click.option("-s", "--set", "set_values", multiple=True, help="Set params key=value, supports dotted keys.")
@click.option("-u", "--update", "update_values", multiple=True, help="Set metadata data key=value, supports dotted keys.")
@click.option("--left", "left_nodes", multiple=True, help="Ensure an upstream node by UUID or exact label.")
@click.option("--left-add", "left_add_nodes", multiple=True, help="Append an upstream node.")
@click.option("--left-set", "left_set_nodes", multiple=True, help="Replace all upstream nodes in the supplied order.")
@click.option("--left-clear", is_flag=True, help="Remove all upstream nodes; fails while the prompt still mentions one.")
@click.option("--left-rm", "left_rm_nodes", multiple=True, help="Remove an upstream node.")
@click.option("--run", "run_after", is_flag=True, help="Submit a generate batch after mutation and wait for the final state.")
@click.option("--validate/--no-validate", "validate_params", default=True, show_default=True, help="Validate model params before running generation.")
@click.option("--wait/--no-wait", "wait_after_run", default=True, show_default=True, help="When --run is set, wait for generation to finish.")
@click.option("--interval", default=5.0, show_default=True, type=float, help="Generation polling interval seconds.")
@click.option("--timeout", default=1800.0, show_default=True, type=float, help="Generation polling timeout seconds.")
@click.option("--allow-failed", is_flag=True, help="Return JSON instead of non-zero exit when waited generation fails.")
@click.option("--dry-run", is_flag=True, help="Print planned payloads without mutating or generating.")
@click.pass_context
@_handle_errors
def node_update(
    ctx: click.Context,
    selector: str,
    file_uuid: str | None,
    group_name: str | None,
    new_name: str | None,
    prompt: str | None,
    model_code: str | None,
    set_values: tuple[str, ...],
    update_values: tuple[str, ...],
    left_nodes: tuple[str, ...],
    left_add_nodes: tuple[str, ...],
    left_set_nodes: tuple[str, ...],
    left_clear: bool,
    left_rm_nodes: tuple[str, ...],
    run_after: bool,
    validate_params: bool,
    wait_after_run: bool,
    interval: float,
    timeout: float,
    allow_failed: bool,
    dry_run: bool,
):
    """Update a Pixmax node, connect upstream nodes, or run it."""
    file_uuid = _require_file(ctx, file_uuid)
    nodes = _nodes_for_scope(ctx, file_uuid, group_name)
    target = _resolve_node(nodes, selector)
    if left_clear and (left_nodes or left_add_nodes or left_set_nodes or left_rm_nodes):
        raise ValueError("--left-clear cannot be combined with --left, --left-add, --left-set, or --left-rm.")
    if left_set_nodes and (left_nodes or left_add_nodes or left_rm_nodes):
        raise ValueError("--left-set cannot be combined with --left, --left-add, or --left-rm.")
    stdin_keys = [_node_key(row) for row in _read_ndjson_stdin()]
    if (left_clear or left_set_nodes) and stdin_keys:
        raise ValueError("Piped upstream nodes cannot be combined with --left-set or --left-clear.")
    add_keys = [_resolve_node(nodes, item).get("uuid") for item in left_nodes + left_add_nodes]
    set_keys = [_resolve_node(nodes, item).get("uuid") for item in left_set_nodes]
    rm_keys = {_resolve_node(nodes, item).get("uuid") for item in left_rm_nodes}
    current_prev = [key for key in target.get("prevNodeUuids") or [] if isinstance(key, str)]
    relation_requested = bool(
        left_nodes
        or left_add_nodes
        or left_set_nodes
        or left_clear
        or left_rm_nodes
        or stdin_keys
    )
    if left_clear:
        requested_prev: list[str] = []
    elif left_set_nodes:
        requested_prev = [key for key in set_keys if isinstance(key, str)]
        _validate_unique_upstream_ids(requested_prev, source="--left-set")
    else:
        requested_prev = _dedupe(
            current_prev
            + [key for key in stdin_keys if key]
            + [key for key in add_keys if isinstance(key, str)]
        )
        requested_prev = [key for key in requested_prev if key not in rm_keys]

    source_prompt = prompt if prompt is not None else target.get("prompt")
    normalized_prompt = source_prompt
    next_prev = requested_prev
    if prompt is not None or relation_requested:
        normalized_prompt, next_prev, _ = _prepare_prompt_node_references(
            nodes,
            source_prompt,
            requested_prev,
            strict_v1=str(target.get("type") or "").upper() in _V1_GENERATION_NODE_TYPES,
            auto_connect=not (left_clear or bool(left_set_nodes) or bool(left_rm_nodes)),
        )
    target_uuid = str(target.get("uuid") or "")
    if prompt is not None or relation_requested:
        _validate_direct_upstream_graph(nodes, target_uuid, next_prev)
    relation_changed = next_prev != current_prev

    metadata_data: dict[str, Any] = {}
    if new_name is not None:
        metadata_data["label"] = new_name
    metadata_data = _apply_key_values(metadata_data, update_values)
    params = _apply_key_values({}, set_values)
    if prompt is not None:
        params["prompt"] = normalized_prompt
    elif relation_requested and normalized_prompt is not None and normalized_prompt != target.get("prompt"):
        params["prompt"] = normalized_prompt
    if model_code is not None:
        params["model"] = model_code
    if str(target.get("type") or "").upper() in _V1_GENERATION_NODE_TYPES and params:
        params = {
            key: ("true" if value else "false") if isinstance(value, bool)
            else str(value) if isinstance(value, (int, float)) else value
            for key, value in params.items()
        }

    update_payload = {
        "uuid": target.get("uuid"),
    }
    if relation_changed:
        update_payload["prevNodeUuids"] = next_prev
    if params:
        update_payload["params"] = params
    if metadata_data:
        # Agent v1 persists complete metaData, retaining all unrelated metadata.
        current_metadata = target.get("metadata")
        if not isinstance(current_metadata, dict) or not isinstance(current_metadata.get("data"), dict):
            raise click.ClickException("Cannot preserve existing node metadata; reread the canvas.")
        next_metadata = json.loads(json.dumps(current_metadata, ensure_ascii=False))
        next_metadata["data"].update(metadata_data)
        update_payload["metaData"] = json.dumps(next_metadata, ensure_ascii=False, separators=(",", ":"))

    mutation_requested = bool(params or metadata_data or relation_changed)
    generate_payload = {
        "fileUuid": file_uuid,
        "nodeUuids": [target.get("uuid")],
        "nodes": [target.get("uuid")],
    }
    plans: list[dict[str, Any]] = []
    if mutation_requested:
        plans.append(
            {
                "endpoint": "/canvas/node/batch",
                "payload": _canvas_batch_payload(_client(ctx), file_uuid, update=[update_payload]),
            }
        )
    if run_after:
        plans.append({"endpoint": "/generate/batch", "payload": generate_payload})

    if dry_run:
        _emit({"dryRun": True, "target": _node_pipe_record(target), "plans": plans}, "Node dry run")
        return
    if not plans:
        _emit_pipe_record(_node_pipe_record(target), "Pixmax node")
        return
    api = _client(ctx)
    results = []
    if mutation_requested:
        results.append(_batch_mutate_nodes(api, file_uuid, update=[update_payload]))
    if run_after:
        validation = None
        if validate_params:
            validation_params = {}
            if target.get("prompt") is not None:
                validation_params["prompt"] = target.get("prompt")
            if target.get("model") is not None:
                validation_params["model"] = target.get("model")
            validation_params.update(params)
            validation_payload = {
                "uuid": target.get("uuid"),
                "type": target.get("type"),
                "params": validation_params,
            }
            node_lookup = _nodes_by_uuid(nodes)
            input_nodes = [node_lookup[key] for key in next_prev if key in node_lookup]
            validation = _validate_node_params(api, validation_payload, input_nodes=input_nodes)
        results.append(api.generate_batch(generate_payload))
    wait_result = None
    if run_after and wait_after_run:
        wait_result = _wait_generation(api, [target.get("uuid")], interval=interval, timeout=timeout)
    output = {"target": _node_pipe_record(target), "results": results}
    if run_after and validation:
        output["validation"] = validation
    if wait_result:
        output["wait"] = wait_result
    _emit(output, "Pixmax node updated")
    if wait_result:
        _exit_on_failed_wait(wait_result, allow_failed=allow_failed)


@node.command("list")
@click.option("--file", "file_uuid", default=None, help="Canvas file UUID.")
@click.option("--group", "group_name", default=None, help="Use a named local node group.")
@click.option("--type", "node_type", default=None, help="Filter by Pixmax node type.")
@click.option("--generated/--all", "generated_only", default=False, help="Only generated nodes.")
@click.pass_context
@_handle_errors
def node_list(ctx: click.Context, file_uuid: str | None, group_name: str | None, node_type: str | None, generated_only: bool):
    """List Pixmax canvas nodes in an agent-friendly shape."""
    nodes = _nodes_for_scope(ctx, file_uuid, group_name)
    if node_type:
        nodes = [row for row in nodes if row.get("type") == node_type]
    if generated_only:
        nodes = [row for row in nodes if row.get("isGenerateNode")]
    _emit({"count": len(nodes), "nodes": [_node_pipe_record(row) for row in nodes]}, "Pixmax nodes")


@node.command("create")
@click.argument("label")
@click.option("--file", "file_uuid", default=None, help="Canvas file UUID.")
@click.option("-t", "--type", "node_type", required=True, help="Pixmax node type, e.g. GENERATE_IMAGE.")
@click.option("--prompt", default=None, help="Set params.prompt.")
@click.option("--model", "model_code", default=None, help="Set params.model.")
@click.option("-s", "--set", "set_values", multiple=True, help="Set params key=value, supports dotted keys.")
@click.option("-u", "--update", "update_values", multiple=True, help="Set metadata data key=value, supports dotted keys.")
@click.option("--left", "left_nodes", multiple=True, help="Upstream node UUID or exact label.")
@click.option("--x", type=float, default=0, show_default=True, help="Canvas X position.")
@click.option("--y", type=float, default=0, show_default=True, help="Canvas Y position.")
@click.option("--run", "run_after", is_flag=True, help="Submit a generate batch after create and wait for the final state.")
@click.option("--validate/--no-validate", "validate_params", default=True, show_default=True, help="Validate model params before running generation.")
@click.option("--wait/--no-wait", "wait_after_run", default=True, show_default=True, help="When --run is set, wait for generation to finish.")
@click.option("--interval", default=5.0, show_default=True, type=float, help="Generation polling interval seconds.")
@click.option("--timeout", default=1800.0, show_default=True, type=float, help="Generation polling timeout seconds.")
@click.option("--allow-failed", is_flag=True, help="Return JSON instead of non-zero exit when waited generation fails.")
@click.option("--dry-run", is_flag=True, help="Print planned payloads without mutating or generating.")
@click.pass_context
@_handle_errors
def node_create(
    ctx: click.Context,
    label: str,
    file_uuid: str | None,
    node_type: str,
    prompt: str | None,
    model_code: str | None,
    set_values: tuple[str, ...],
    update_values: tuple[str, ...],
    left_nodes: tuple[str, ...],
    x: float,
    y: float,
    run_after: bool,
    validate_params: bool,
    wait_after_run: bool,
    interval: float,
    timeout: float,
    allow_failed: bool,
    dry_run: bool,
):
    """Create a Pixmax node from friendly CLI flags."""
    file_uuid = _require_file(ctx, file_uuid)
    stdin_keys = [_node_key(row) for row in _read_ndjson_stdin()]
    prompt_refs = _prompt_node_references(prompt)
    nodes = _nodes_for_scope(ctx, file_uuid, None) if left_nodes or prompt_refs or stdin_keys else []
    left_keys = [_resolve_node(nodes, item).get("uuid") for item in left_nodes]
    explicit_prev = [key for key in stdin_keys if key] + [key for key in left_keys if isinstance(key, str)]
    normalized_prompt, prev_node_uuids, _ = _prepare_prompt_node_references(
        nodes,
        prompt,
        explicit_prev,
        strict_v1=node_type.upper() in _V1_GENERATION_NODE_TYPES,
    )
    params = _apply_key_values({}, set_values)
    data = _apply_key_values({}, update_values)
    payload = _synthetic_node_payload(
        label=label,
        node_type=node_type,
        file_uuid=file_uuid,
        prompt=normalized_prompt,
        model=model_code,
        params=params,
        data=data,
        prev_node_uuids=prev_node_uuids,
        x=x,
        y=y,
    )
    api = _client(ctx)
    plans = [
        {
            "endpoint": "/canvas/node/batch",
            "payload": _canvas_batch_payload(api, file_uuid, create=[payload]),
        }
    ]
    if run_after:
        plans.append({"endpoint": "/generate/batch", "payload": {"fileUuid": file_uuid, "nodeUuids": [payload["uuid"]], "nodes": [payload["uuid"]]}})
    if dry_run:
        _emit({"dryRun": True, "nodeKey": payload["uuid"], "plans": plans}, "Node create dry run")
        return
    node_lookup = _nodes_by_uuid(nodes) if nodes else {}
    input_nodes = [node_lookup[key] for key in payload.get("prevNodeUuids") or [] if key in node_lookup]
    validation = _validate_node_params(api, payload, input_nodes=input_nodes) if run_after and validate_params else None
    create_result = _batch_mutate_nodes(api, file_uuid, create=[payload])
    results = [create_result]
    if run_after:
        results.append(api.generate_batch(plans[1]["payload"]))
    wait_result = None
    if run_after and wait_after_run:
        wait_result = _wait_generation(api, [payload["uuid"]], interval=interval, timeout=timeout)
    output = {"nodeKey": payload["uuid"], "uuid": payload["uuid"], "results": results}
    if validation:
        output["validation"] = validation
    if wait_result:
        output["wait"] = wait_result
    _emit_pipe_record(output, "Pixmax node created")
    if wait_result:
        _exit_on_failed_wait(wait_result, allow_failed=allow_failed)


@node.command("delete")
@click.argument("selector")
@click.option("--file", "file_uuid", default=None, help="Canvas file UUID.")
@click.option("--group", "group_name", default=None, help="Use a named local node group.")
@click.option("--yes", is_flag=True, help="Confirm deletion.")
@click.option("--dry-run", is_flag=True, help="Print payload without deleting.")
@click.pass_context
@_handle_errors
def node_delete(ctx: click.Context, selector: str, file_uuid: str | None, group_name: str | None, yes: bool, dry_run: bool):
    """Delete a Pixmax node by UUID or exact label."""
    file_uuid = _require_file(ctx, file_uuid)
    target = _resolve_node(_nodes_for_scope(ctx, file_uuid, group_name), selector)
    payload = {"fileUuid": file_uuid, "nodeUuids": [target.get("uuid")], "uuid": target.get("uuid")}
    if dry_run:
        _emit_dry_run("/canvas/node/delete", payload)
        return
    if not yes:
        raise RuntimeError("Refusing to delete without --yes.")
    _emit(_client(ctx).canvas_node_delete(payload), "Pixmax node deleted")


@cli.group()
def image():
    """High-level image generation and reference-image workflows."""


@image.command("generate")
@click.argument("label")
@click.option("--file", "file_uuid", default=None, help="Canvas file UUID.")
@click.option("--prompt", required=True, help="Image generation prompt.")
@click.option("--model", "model_code", default="GPT_IMAGE_2", show_default=True, help="Pixmax image model code.")
@click.option("--resolution", default="2K", show_default=True, help="Image resolution.")
@click.option("--aspect-ratio", default="", show_default=True, help="Image aspect ratio; empty means model auto/default.")
@click.option("--count", default="1", show_default=True, help="Number of generations.")
@click.option("-s", "--set", "set_values", multiple=True, help="Extra model param key=value, supports dotted keys.")
@click.option("--x", type=float, default=640, show_default=True, help="Canvas X position.")
@click.option("--y", type=float, default=0, show_default=True, help="Canvas Y position.")
@click.option("--run", "run_after", is_flag=True, help="Submit a generate batch after create and wait for the final state.")
@click.option("--validate/--no-validate", "validate_params", default=True, show_default=True, help="Validate model params before submission.")
@click.option("--wait/--no-wait", "wait_after_submit", default=True, show_default=True, help="When --run is set, wait for generation to finish.")
@click.option("--interval", default=5.0, show_default=True, type=float, help="Generation polling interval seconds.")
@click.option("--timeout", default=1800.0, show_default=True, type=float, help="Generation polling timeout seconds.")
@click.option("--allow-failed", is_flag=True, help="Return JSON instead of non-zero exit when waited generation fails.")
@click.option("--dry-run", is_flag=True, help="Print planned payloads without mutating or generating.")
@click.pass_context
@_handle_errors
def image_generate(
    ctx: click.Context,
    label: str,
    file_uuid: str | None,
    prompt: str,
    model_code: str,
    resolution: str,
    aspect_ratio: str,
    count: str,
    set_values: tuple[str, ...],
    x: float,
    y: float,
    run_after: bool,
    validate_params: bool,
    wait_after_submit: bool,
    interval: float,
    timeout: float,
    allow_failed: bool,
    dry_run: bool,
):
    """Create an image generation node from friendly CLI flags."""
    file_uuid = _require_file(ctx, file_uuid)
    prompt_refs = _prompt_node_references(prompt)
    nodes = _nodes_for_scope(ctx, file_uuid, None) if prompt_refs else []
    normalized_prompt, prev_node_uuids, _ = _prepare_prompt_node_references(
        nodes,
        prompt,
        [],
        strict_v1=True,
    )
    params = _image_params(
        model=model_code,
        prompt=normalized_prompt or "",
        resolution=resolution,
        aspect_ratio=aspect_ratio,
        count=count,
        extra_params=_apply_key_values({}, set_values),
    )
    node_payload = _synthetic_node_payload(
        label=label,
        node_type="GENERATE_IMAGE",
        file_uuid=file_uuid,
        prompt=None,
        model=None,
        params=params,
        data={"label": label, "workflow": "image-generate"},
        prev_node_uuids=prev_node_uuids,
        x=x,
        y=y,
    )
    generate_payload = {"fileUuid": file_uuid, "nodeUuids": [node_payload["uuid"]], "nodes": [node_payload["uuid"]]}
    plans: list[dict[str, Any]] = [
        {"endpoint": "/canvas/node/batch", "payload": {"fileUuid": file_uuid, "create": [node_payload], "update": [], "delete": []}},
    ]
    if run_after:
        plans.append({"endpoint": "/generate/batch", "payload": generate_payload})
        if wait_after_submit:
            plans.append({"endpoint": "/generate/progress", "payload": {"nodeUuids": [node_payload["uuid"]]}})
    if dry_run:
        _emit({"dryRun": True, "nodeKey": node_payload["uuid"], "plans": plans}, "Image generate dry run")
        return

    api = _client(ctx)
    if not run_after:
        create_result = _batch_create_node(api, file_uuid, node_payload)
        _emit({"nodeKey": node_payload["uuid"], "uuid": node_payload["uuid"], "plans": plans, "create": create_result}, "Image node created")
        return
    node_lookup = _nodes_by_uuid(nodes) if nodes else {}
    input_nodes = [node_lookup[key] for key in node_payload.get("prevNodeUuids") or [] if key in node_lookup]
    result = _run_generate_node_workflow(
        api=api,
        file_uuid=file_uuid,
        node_payload=node_payload,
        input_nodes=input_nodes,
        validate_params=validate_params,
        wait_after_submit=wait_after_submit,
        interval=interval,
        timeout=timeout,
    )
    _emit(result, "Image generation submitted")
    wait_result = result.get("wait")
    if isinstance(wait_result, dict):
        _exit_on_failed_wait(wait_result, allow_failed=allow_failed)


@image.command("edit")
@click.argument("label")
@click.option("--file", "file_uuid", default=None, help="Canvas file UUID.")
@click.option("--image-node", "image_selector", required=True, help="Reference image node UUID or exact label.")
@click.option("--prompt", required=True, help="Image edit prompt.")
@click.option("--model", "model_code", default="GPT_IMAGE_2", show_default=True, help="Pixmax image model code.")
@click.option("--resolution", default="2K", show_default=True, help="Image resolution.")
@click.option("--aspect-ratio", default="", show_default=True, help="Image aspect ratio; empty means model auto/default.")
@click.option("--count", default="1", show_default=True, help="Number of generations.")
@click.option("-s", "--set", "set_values", multiple=True, help="Extra model param key=value, supports dotted keys.")
@click.option("--x", type=float, default=640, show_default=True, help="Canvas X position.")
@click.option("--y", type=float, default=240, show_default=True, help="Canvas Y position.")
@click.option("--run", "run_after", is_flag=True, help="Submit a generate batch after create and wait for the final state.")
@click.option("--validate/--no-validate", "validate_params", default=True, show_default=True, help="Validate model params before submission.")
@click.option("--wait/--no-wait", "wait_after_submit", default=True, show_default=True, help="When --run is set, wait for generation to finish.")
@click.option("--interval", default=5.0, show_default=True, type=float, help="Generation polling interval seconds.")
@click.option("--timeout", default=1800.0, show_default=True, type=float, help="Generation polling timeout seconds.")
@click.option("--allow-failed", is_flag=True, help="Return JSON instead of non-zero exit when waited generation fails.")
@click.option("--dry-run", is_flag=True, help="Print planned payloads without mutating or generating.")
@click.pass_context
@_handle_errors
def image_edit(
    ctx: click.Context,
    label: str,
    file_uuid: str | None,
    image_selector: str,
    prompt: str,
    model_code: str,
    resolution: str,
    aspect_ratio: str,
    count: str,
    set_values: tuple[str, ...],
    x: float,
    y: float,
    run_after: bool,
    validate_params: bool,
    wait_after_submit: bool,
    interval: float,
    timeout: float,
    allow_failed: bool,
    dry_run: bool,
):
    """Create an image generation node that edits from a reference image node."""
    file_uuid = _require_file(ctx, file_uuid)
    nodes = _nodes_for_scope(ctx, file_uuid, None)
    image_node = _resolve_node(nodes, image_selector)
    if _node_input_kind(image_node) != "image":
        raise ValueError(f"--image-node must resolve to an image node, got {image_node.get('type')}: {image_selector}")
    normalized_prompt, prev_node_uuids, _ = _prepare_prompt_node_references(
        nodes,
        prompt,
        [str(image_node.get("uuid") or "")],
        strict_v1=True,
    )
    params = _image_params(
        model=model_code,
        prompt=normalized_prompt or "",
        resolution=resolution,
        aspect_ratio=aspect_ratio,
        count=count,
        extra_params=_apply_key_values({}, set_values),
    )
    node_payload = _synthetic_node_payload(
        label=label,
        node_type="GENERATE_IMAGE",
        file_uuid=file_uuid,
        prompt=None,
        model=None,
        params=params,
        data={"label": label, "workflow": "image-edit", "referenceNodeUuid": image_node.get("uuid")},
        prev_node_uuids=prev_node_uuids,
        x=x,
        y=y,
    )
    generate_payload = {"fileUuid": file_uuid, "nodeUuids": [node_payload["uuid"]], "nodes": [node_payload["uuid"]]}
    plans: list[dict[str, Any]] = [
        {"endpoint": "/canvas/node/batch", "payload": {"fileUuid": file_uuid, "create": [node_payload], "update": [], "delete": []}},
    ]
    if run_after:
        plans.append({"endpoint": "/generate/batch", "payload": generate_payload})
        if wait_after_submit:
            plans.append({"endpoint": "/generate/progress", "payload": {"nodeUuids": [node_payload["uuid"]]}})
    if dry_run:
        _emit(
            {
                "dryRun": True,
                "nodeKey": node_payload["uuid"],
                "reference": _node_pipe_record(image_node),
                "plans": plans,
            },
            "Image edit dry run",
        )
        return

    api = _client(ctx)
    if not run_after:
        create_result = _batch_create_node(api, file_uuid, node_payload)
        _emit(
            {"nodeKey": node_payload["uuid"], "uuid": node_payload["uuid"], "reference": _node_pipe_record(image_node), "plans": plans, "create": create_result},
            "Image edit node created",
        )
        return
    node_lookup = _nodes_by_uuid(nodes)
    input_nodes = [node_lookup[key] for key in node_payload.get("prevNodeUuids") or [] if key in node_lookup]
    result = _run_generate_node_workflow(
        api=api,
        file_uuid=file_uuid,
        node_payload=node_payload,
        input_nodes=input_nodes,
        validate_params=validate_params,
        wait_after_submit=wait_after_submit,
        interval=interval,
        timeout=timeout,
    )
    result["reference"] = _node_pipe_record(image_node)
    _emit(result, "Image edit submitted")
    wait_result = result.get("wait")
    if isinstance(wait_result, dict):
        _exit_on_failed_wait(wait_result, allow_failed=allow_failed)


@cli.group()
def video():
    """High-level video generation workflows."""


@video.command("image-to-video")
@click.argument("label")
@click.option("--file", "file_uuid", default=None, help="Canvas file UUID.")
@click.option("--image-node", "image_selector", required=True, help="Reference image node UUID or exact label.")
@click.option("--prompt", required=True, help="Video generation prompt.")
@click.option("--model", "model_code", default="PIXDANCE_2", show_default=True, help="Pixmax video model code.")
@click.option("--resolution", default="480P", show_default=True, help="Video resolution.")
@click.option("--aspect-ratio", default="3:4", show_default=True, help="Video aspect ratio.")
@click.option("--duration", default="7", show_default=True, help="Duration seconds.")
@click.option("--include-audio/--no-audio", default=False, show_default=True, help="Enable generated audio.")
@click.option("--count", default="1", show_default=True, help="Number of generations.")
@click.option("-s", "--set", "set_values", multiple=True, help="Extra model param key=value, supports dotted keys.")
@click.option("--human-reference/--no-human-reference", default=True, show_default=True, help="Run asset compliance before Seedance 2.0 submission.")
@click.option("--compliance-interval", default=2.0, show_default=True, type=float, help="Compliance polling interval seconds.")
@click.option("--compliance-timeout", default=180.0, show_default=True, type=float, help="Compliance polling timeout seconds.")
@click.option("--x", type=float, default=640, show_default=True, help="Canvas X position.")
@click.option("--y", type=float, default=0, show_default=True, help="Canvas Y position.")
@click.option("--validate/--no-validate", "validate_params", default=True, show_default=True, help="Validate model params before submission.")
@click.option("--wait/--no-wait", "wait_after_submit", default=True, show_default=True, help="Wait for generation to finish.")
@click.option("--interval", default=5.0, show_default=True, type=float, help="Generation polling interval seconds.")
@click.option("--timeout", default=1800.0, show_default=True, type=float, help="Generation polling timeout seconds.")
@click.option("--allow-failed", is_flag=True, help="Return JSON instead of non-zero exit when waited generation fails.")
@click.option("--dry-run", is_flag=True, help="Print planned payloads without mutating or generating.")
@click.pass_context
@_handle_errors
def video_image_to_video(
    ctx: click.Context,
    label: str,
    file_uuid: str | None,
    image_selector: str,
    prompt: str,
    model_code: str,
    resolution: str,
    aspect_ratio: str,
    duration: str,
    include_audio: bool,
    count: str,
    set_values: tuple[str, ...],
    human_reference: bool,
    compliance_interval: float,
    compliance_timeout: float,
    x: float,
    y: float,
    validate_params: bool,
    wait_after_submit: bool,
    interval: float,
    timeout: float,
    allow_failed: bool,
    dry_run: bool,
):
    """Create, submit, and optionally wait for an image-to-video generation."""
    file_uuid = _require_file(ctx, file_uuid)
    nodes = _nodes_for_scope(ctx, file_uuid, None)
    image_node = _resolve_node(nodes, image_selector)
    if _node_input_kind(image_node) != "image":
        raise ValueError(f"--image-node must resolve to an image node, got {image_node.get('type')}: {image_selector}")
    normalized_prompt, prev_node_uuids, prompt_ref_keys = _prepare_prompt_node_references(
        nodes,
        prompt,
        [str(image_node.get("uuid") or "")],
        strict_v1=True,
    )
    asset_uuid = _node_default_asset_uuid(image_node)
    if human_reference and not asset_uuid:
        raise RuntimeError(f"Reference image node has no default asset UUID: {image_selector}")
    params = _video_params(
        model=model_code,
        prompt=normalized_prompt or "",
        resolution=resolution,
        aspect_ratio=aspect_ratio,
        duration=duration,
        refer_model="imageToVideo",
        include_audio=include_audio,
        count=count,
        extra_params=_apply_key_values({}, set_values),
    )
    node_payload = _synthetic_node_payload(
        label=label,
        node_type="GENERATE_VIDEO",
        file_uuid=file_uuid,
        prompt=None,
        model=None,
        params=params,
        data={"label": label, "workflow": "image-to-video", "referenceNodeUuid": image_node.get("uuid")},
        prev_node_uuids=prev_node_uuids,
        x=x,
        y=y,
    )
    generate_payload = {"fileUuid": file_uuid, "nodeUuids": [node_payload["uuid"]], "nodes": [node_payload["uuid"]]}
    plans: list[dict[str, Any]] = []
    if human_reference and asset_uuid:
        plans.append({"endpoint": "/assetLibrary/compliance/check", "payload": _compliance_payload(asset_uuid, {})})
    plans.append({"endpoint": "/canvas/node/batch", "payload": {"fileUuid": file_uuid, "create": [node_payload], "update": [], "delete": []}})
    plans.append({"endpoint": "/generate/batch", "payload": generate_payload})
    if wait_after_submit:
        plans.append({"endpoint": "/generate/progress", "payload": {"nodeUuids": [node_payload["uuid"]]}})
    if dry_run:
        _emit(
            {
                "dryRun": True,
                "nodeKey": node_payload["uuid"],
                "reference": _node_pipe_record(image_node),
                "assetUuid": asset_uuid,
                "plans": plans,
            },
            "Video image-to-video dry run",
        )
        return

    api = _client(ctx)
    compliance_result = None
    if human_reference and asset_uuid:
        compliance_result = _poll_compliance(
            api,
            _compliance_payload(asset_uuid, {}),
            interval=compliance_interval,
            timeout=compliance_timeout,
        )
        if compliance_result.get("status") not in {"ACTIVE", "PASS", "PASSED", "SUCCESS", "SUCCEEDED", "COMPLETE", "COMPLETED"}:
            _emit(
                {
                    "nodeKey": node_payload["uuid"],
                    "reference": _node_pipe_record(image_node),
                    "assetUuid": asset_uuid,
                    "compliance": compliance_result,
                },
                "Video image-to-video compliance failed",
            )
            raise click.exceptions.Exit(1)

    result = _run_generate_node_workflow(
        api=api,
        file_uuid=file_uuid,
        node_payload=node_payload,
        input_nodes=[image_node] + [
            node for node in (_nodes_by_uuid(nodes).get(key) for key in prompt_ref_keys)
            if isinstance(node, dict)
        ],
        validate_params=validate_params,
        wait_after_submit=wait_after_submit,
        interval=interval,
        timeout=timeout,
    )
    result["reference"] = _node_pipe_record(image_node)
    result["assetUuid"] = asset_uuid
    if compliance_result:
        result["compliance"] = compliance_result
    _emit(result, "Video image-to-video submitted")
    wait_result = result.get("wait")
    if isinstance(wait_result, dict):
        _exit_on_failed_wait(wait_result, allow_failed=allow_failed)


@video.command("text-to-video")
@click.argument("label")
@click.option("--file", "file_uuid", default=None, help="Canvas file UUID.")
@click.option("--prompt", required=True, help="Video generation prompt.")
@click.option("--model", "model_code", default="PIXDANCE_2", show_default=True, help="Pixmax video model code.")
@click.option("--resolution", default="480P", show_default=True, help="Video resolution.")
@click.option("--aspect-ratio", default="3:4", show_default=True, help="Video aspect ratio.")
@click.option("--duration", default="7", show_default=True, help="Duration seconds.")
@click.option("--include-audio/--no-audio", default=False, show_default=True, help="Enable generated audio.")
@click.option("--count", default="1", show_default=True, help="Number of generations.")
@click.option("-s", "--set", "set_values", multiple=True, help="Extra model param key=value, supports dotted keys.")
@click.option("--x", type=float, default=640, show_default=True, help="Canvas X position.")
@click.option("--y", type=float, default=240, show_default=True, help="Canvas Y position.")
@click.option("--validate/--no-validate", "validate_params", default=True, show_default=True, help="Validate model params before submission.")
@click.option("--wait/--no-wait", "wait_after_submit", default=True, show_default=True, help="Wait for generation to finish.")
@click.option("--interval", default=5.0, show_default=True, type=float, help="Generation polling interval seconds.")
@click.option("--timeout", default=1800.0, show_default=True, type=float, help="Generation polling timeout seconds.")
@click.option("--allow-failed", is_flag=True, help="Return JSON instead of non-zero exit when waited generation fails.")
@click.option("--dry-run", is_flag=True, help="Print planned payloads without mutating or generating.")
@click.pass_context
@_handle_errors
def video_text_to_video(
    ctx: click.Context,
    label: str,
    file_uuid: str | None,
    prompt: str,
    model_code: str,
    resolution: str,
    aspect_ratio: str,
    duration: str,
    include_audio: bool,
    count: str,
    set_values: tuple[str, ...],
    x: float,
    y: float,
    validate_params: bool,
    wait_after_submit: bool,
    interval: float,
    timeout: float,
    allow_failed: bool,
    dry_run: bool,
):
    """Create, submit, and optionally wait for a text-to-video generation."""
    file_uuid = _require_file(ctx, file_uuid)
    prompt_refs = _prompt_node_references(prompt)
    nodes = _nodes_for_scope(ctx, file_uuid, None) if prompt_refs else []
    normalized_prompt, prev_node_uuids, prompt_ref_keys = _prepare_prompt_node_references(
        nodes,
        prompt,
        [],
        strict_v1=True,
    )
    params = _video_params(
        model=model_code,
        prompt=normalized_prompt or "",
        resolution=resolution,
        aspect_ratio=aspect_ratio,
        duration=duration,
        refer_model="textToVideo",
        include_audio=include_audio,
        count=count,
        extra_params=_apply_key_values({}, set_values),
    )
    node_payload = _synthetic_node_payload(
        label=label,
        node_type="GENERATE_VIDEO",
        file_uuid=file_uuid,
        prompt=None,
        model=None,
        params=params,
        data={"label": label, "workflow": "text-to-video"},
        prev_node_uuids=prev_node_uuids,
        x=x,
        y=y,
    )
    generate_payload = {"fileUuid": file_uuid, "nodeUuids": [node_payload["uuid"]], "nodes": [node_payload["uuid"]]}
    plans: list[dict[str, Any]] = [
        {"endpoint": "/canvas/node/batch", "payload": {"fileUuid": file_uuid, "create": [node_payload], "update": [], "delete": []}},
        {"endpoint": "/generate/batch", "payload": generate_payload},
    ]
    if wait_after_submit:
        plans.append({"endpoint": "/generate/progress", "payload": {"nodeUuids": [node_payload["uuid"]]}})
    if dry_run:
        _emit(
            {
                "dryRun": True,
                "nodeKey": node_payload["uuid"],
                "plans": plans,
            },
            "Video text-to-video dry run",
        )
        return

    result = _run_generate_node_workflow(
        api=_client(ctx),
        file_uuid=file_uuid,
        node_payload=node_payload,
        input_nodes=[
            node for node in (_nodes_by_uuid(nodes).get(key) for key in prompt_ref_keys)
            if isinstance(node, dict)
        ],
        validate_params=validate_params,
        wait_after_submit=wait_after_submit,
        interval=interval,
        timeout=timeout,
    )
    _emit(result, "Video text-to-video submitted")
    wait_result = result.get("wait")
    if isinstance(wait_result, dict):
        _exit_on_failed_wait(wait_result, allow_failed=allow_failed)


@cli.group()
def workflow():
    """Compose multi-step Pixmax generation workflows."""


@workflow.command("save")
@click.argument("name")
@click.option("--type", "workflow_type", default=None, help="Workflow type, such as image-to-video or script-to-video.")
@click.option("--description", default=None, help="Short description for humans and agents.")
@click.option("--data", "data_json", default=None, help="JSON workflow definition with type/options.")
@click.option("--file", "payload_file", default=None, type=click.Path(exists=True), help="JSON workflow definition file.")
@click.option("-s", "--set", "set_values", multiple=True, help="Workflow option key=value, supports dotted keys.")
@click.pass_context
@_handle_errors
def workflow_save(
    ctx: click.Context,
    name: str,
    workflow_type: str | None,
    description: str | None,
    data_json: str | None,
    payload_file: str | None,
    set_values: tuple[str, ...],
):
    """Save a reusable local workflow definition in the CLI session."""
    if data_json or payload_file:
        definition = _load_definition_payload(data_json, payload_file)
    else:
        if not workflow_type:
            raise ValueError("Pass --type or a JSON definition via --data/--file.")
        definition = {"type": workflow_type, "description": description, "options": {}}
    if workflow_type:
        definition["type"] = workflow_type
    if description:
        definition["description"] = description
    definition = _definition_with_overrides(definition, set_values)
    workflow_type = str(definition.get("type") or "")
    if workflow_type not in _WORKFLOW_TYPES:
        raise ValueError(f"Unsupported workflow type: {workflow_type}")
    _session(ctx).set_workflow(name, definition)
    _emit({"name": name, **definition}, "Workflow saved")


@workflow.command("list")
@click.pass_context
def workflow_list(ctx: click.Context):
    """List saved local workflow definitions."""
    workflows = _session(ctx).workflows
    _emit(
        {
            "count": len(workflows),
            "workflows": [
                {
                    "name": name,
                    "type": definition.get("type"),
                    "description": definition.get("description"),
                    "optionKeys": sorted((definition.get("options") or {}).keys()),
                }
                for name, definition in workflows.items()
                if isinstance(definition, dict)
            ],
        },
        "Saved workflows",
    )


@workflow.command("show")
@click.argument("name")
@click.pass_context
@_handle_errors
def workflow_show(ctx: click.Context, name: str):
    """Show one saved workflow definition."""
    definition = _session(ctx).workflows.get(name)
    if not isinstance(definition, dict):
        raise RuntimeError(f"Unknown workflow: {name}")
    _emit({"name": name, **definition}, "Saved workflow")


@workflow.command("delete")
@click.argument("name")
@click.pass_context
def workflow_delete(ctx: click.Context, name: str):
    """Delete a saved local workflow definition."""
    _session(ctx).delete_workflow(name)
    _emit({"deleted": name}, "Workflow deleted")


def _saved_payload_workflow(
    *,
    ctx: click.Context,
    workflow_type: str,
    name: str,
    options: dict[str, Any],
    run_workflow: bool,
) -> dict[str, Any]:
    payload = options.get("payload")
    if not isinstance(payload, dict):
        payload = {
            key: value
            for key, value in options.items()
            if key not in {"payload", "wait", "interval", "timeout", "allow_failed"}
        }
    endpoint_by_type = {
        "generate-batch": "/generate/batch",
        "quick-task": "/quickTask/submit",
        "template-task": "/task/submit/templateTask",
    }
    endpoint = endpoint_by_type[workflow_type]
    output: dict[str, Any] = {
        "workflow": workflow_type,
        "name": name,
        "dryRun": not run_workflow,
        "plans": [{"endpoint": endpoint, "payload": payload}],
    }
    if workflow_type == "generate-batch" and _option_bool(options, "wait", False):
        node_uuids = [item for item in payload.get("nodeUuids") or payload.get("nodes") or [] if isinstance(item, str)]
        output["plans"].append({"endpoint": "/generate/progress", "payload": {"nodeUuids": node_uuids}})
    if not run_workflow:
        return output
    api = _client(ctx)
    if workflow_type == "generate-batch":
        submit_result = api.generate_batch(payload)
        output["submit"] = submit_result
        if _option_bool(options, "wait", False):
            node_uuids = [item for item in payload.get("nodeUuids") or payload.get("nodes") or [] if isinstance(item, str)]
            if not node_uuids:
                raise RuntimeError("Cannot wait for generate-batch workflow without nodeUuids or nodes in payload.")
            wait_result = _wait_generation(
                api,
                node_uuids,
                interval=float(options.get("interval") or 5.0),
                timeout=float(options.get("timeout") or 1800.0),
            )
            output["wait"] = wait_result
            _exit_on_failed_wait(wait_result, allow_failed=_option_bool(options, "allow_failed", False))
        return output
    if workflow_type == "quick-task":
        output["submit"] = api.quick_task_submit(payload)
        return output
    output["submit"] = api.template_task_submit(payload)
    return output


@workflow.command("run")
@click.argument("name")
@click.option("-s", "--set", "set_values", multiple=True, help="Override saved option key=value for this run.")
@click.option("--run/--dry-run", "run_workflow", default=False, show_default=True, help="Submit the workflow; default is dry-run planning.")
@click.pass_context
@_handle_errors
def workflow_run(ctx: click.Context, name: str, set_values: tuple[str, ...], run_workflow: bool):
    """Run a saved workflow definition, defaulting to dry-run planning."""
    definition = _session(ctx).workflows.get(name)
    if not isinstance(definition, dict):
        raise RuntimeError(f"Unknown workflow: {name}")
    definition = _definition_with_overrides(definition, set_values)
    options = definition.get("options") if isinstance(definition.get("options"), dict) else {}
    workflow_type = definition.get("type")
    if workflow_type == "image-to-video":
        return ctx.invoke(
            workflow_image_to_video,
            label=str(options.get("label") or name),
            file_uuid=options.get("file"),
            image_prompt=str(options.get("image_prompt") or options.get("imagePrompt") or ""),
            video_prompt=str(options.get("video_prompt") or options.get("videoPrompt") or ""),
            image_label=options.get("image_label") or options.get("imageLabel"),
            video_label=options.get("video_label") or options.get("videoLabel"),
            image_model=str(options.get("image_model") or options.get("imageModel") or "GPT_IMAGE_2"),
            video_model=str(options.get("video_model") or options.get("videoModel") or "PIXDANCE_2"),
            image_resolution=str(options.get("image_resolution") or options.get("imageResolution") or "2K"),
            image_aspect_ratio=str(options.get("image_aspect_ratio") or options.get("imageAspectRatio") or ""),
            image_count=str(options.get("image_count") or options.get("imageCount") or "1"),
            video_resolution=str(options.get("video_resolution") or options.get("videoResolution") or "480P"),
            video_aspect_ratio=str(options.get("video_aspect_ratio") or options.get("videoAspectRatio") or "3:4"),
            duration=str(options.get("duration") or "7"),
            include_audio=_option_bool(options, "include_audio", _option_bool(options, "includeAudio", False)),
            video_count=str(options.get("video_count") or options.get("videoCount") or "1"),
            image_set_values=_option_tuple(options, "image_set") + _option_tuple(options, "imageSet"),
            video_set_values=_option_tuple(options, "video_set") + _option_tuple(options, "videoSet"),
            human_reference=_option_bool(options, "human_reference", _option_bool(options, "humanReference", True)),
            compliance_interval=float(options.get("compliance_interval") or options.get("complianceInterval") or 2.0),
            compliance_timeout=float(options.get("compliance_timeout") or options.get("complianceTimeout") or 180.0),
            image_x=float(options.get("image_x") or options.get("imageX") or 640),
            image_y=float(options.get("image_y") or options.get("imageY") or 0),
            video_x=float(options.get("video_x") or options.get("videoX") or 1280),
            video_y=float(options.get("video_y") or options.get("videoY") or 0),
            run_workflow=run_workflow,
            validate_params=_option_bool(options, "validate", _option_bool(options, "validate_params", True)),
            wait_after_submit=_option_bool(options, "wait", _option_bool(options, "wait_after_submit", True)),
            interval=float(options.get("interval") or 5.0),
            timeout=float(options.get("timeout") or 1800.0),
            allow_failed=_option_bool(options, "allow_failed", False),
        )
    if workflow_type == "script-to-video":
        max_rows = options.get("max_rows", options.get("maxRows"))
        return ctx.invoke(
            workflow_script_to_video,
            selector=str(options.get("selector") or name),
            file_uuid=options.get("file"),
            storyboard_model=str(options.get("storyboard_model") or options.get("storyboardModel") or "BANANA_2"),
            video_model=str(options.get("video_model") or options.get("videoModel") or "PIXDANCE_2"),
            storyboard_resolution=str(options.get("storyboard_resolution") or options.get("storyboardResolution") or "2K"),
            storyboard_aspect_ratio=str(options.get("storyboard_aspect_ratio") or options.get("storyboardAspectRatio") or ""),
            storyboard_count=str(options.get("storyboard_count") or options.get("storyboardCount") or "1"),
            video_resolution=str(options.get("video_resolution") or options.get("videoResolution") or "480P"),
            video_aspect_ratio=str(options.get("video_aspect_ratio") or options.get("videoAspectRatio") or "3:4"),
            duration=str(options.get("duration") or "7"),
            include_audio=_option_bool(options, "include_audio", _option_bool(options, "includeAudio", False)),
            video_count=str(options.get("video_count") or options.get("videoCount") or "1"),
            storyboard_set_values=_option_tuple(options, "storyboard_set") + _option_tuple(options, "storyboardSet"),
            video_set_values=_option_tuple(options, "video_set") + _option_tuple(options, "videoSet"),
            human_reference=_option_bool(options, "human_reference", _option_bool(options, "humanReference", True)),
            compliance_interval=float(options.get("compliance_interval") or options.get("complianceInterval") or 2.0),
            compliance_timeout=float(options.get("compliance_timeout") or options.get("complianceTimeout") or 180.0),
            x=float(options.get("x") or 960),
            y=float(options.get("y") or 720),
            video_x=float(options.get("video_x") or options.get("videoX") or 1280),
            video_y=float(options.get("video_y") or options.get("videoY") or 720),
            gap=float(options.get("gap") or 240),
            max_rows=int(max_rows) if max_rows is not None else None,
            run_workflow=run_workflow,
            validate_params=_option_bool(options, "validate", _option_bool(options, "validate_params", True)),
            wait_after_submit=_option_bool(options, "wait", _option_bool(options, "wait_after_submit", True)),
            interval=float(options.get("interval") or 5.0),
            timeout=float(options.get("timeout") or 1800.0),
            allow_failed=_option_bool(options, "allow_failed", False),
        )
    if workflow_type in {"generate-batch", "quick-task", "template-task"}:
        result = _saved_payload_workflow(
            ctx=ctx,
            workflow_type=str(workflow_type),
            name=name,
            options=options,
            run_workflow=run_workflow,
        )
        _emit(result, "Saved payload workflow")
        return
    raise ValueError(f"Unsupported workflow type: {workflow_type}")


@workflow.command("image-to-video")
@click.argument("label")
@click.option("--file", "file_uuid", default=None, help="Canvas file UUID.")
@click.option("--image-prompt", required=True, help="Prompt for the generated reference image.")
@click.option("--video-prompt", required=True, help="Prompt for the Seedance image-to-video step.")
@click.option("--image-label", default=None, help="Canvas label for the intermediate image node.")
@click.option("--video-label", default=None, help="Canvas label for the final video node.")
@click.option("--image-model", default="GPT_IMAGE_2", show_default=True, help="Pixmax image model code.")
@click.option("--video-model", default="PIXDANCE_2", show_default=True, help="Pixmax video model code.")
@click.option("--image-resolution", default="2K", show_default=True, help="Image resolution.")
@click.option("--image-aspect-ratio", default="", show_default=True, help="Image aspect ratio; empty means model auto/default.")
@click.option("--image-count", default="1", show_default=True, help="Number of generated reference images.")
@click.option("--video-resolution", default="480P", show_default=True, help="Video resolution.")
@click.option("--video-aspect-ratio", default="3:4", show_default=True, help="Video aspect ratio.")
@click.option("--duration", default="7", show_default=True, help="Video duration seconds.")
@click.option("--include-audio/--no-audio", default=False, show_default=True, help="Enable generated audio.")
@click.option("--video-count", default="1", show_default=True, help="Number of generated videos.")
@click.option("--image-set", "image_set_values", multiple=True, help="Extra image model param key=value, supports dotted keys.")
@click.option("--video-set", "video_set_values", multiple=True, help="Extra video model param key=value, supports dotted keys.")
@click.option("--human-reference/--no-human-reference", default=True, show_default=True, help="Run asset compliance before Seedance 2.0 submission.")
@click.option("--compliance-interval", default=2.0, show_default=True, type=float, help="Compliance polling interval seconds.")
@click.option("--compliance-timeout", default=180.0, show_default=True, type=float, help="Compliance polling timeout seconds.")
@click.option("--image-x", type=float, default=640, show_default=True, help="Canvas X position for the image node.")
@click.option("--image-y", type=float, default=0, show_default=True, help="Canvas Y position for the image node.")
@click.option("--video-x", type=float, default=1280, show_default=True, help="Canvas X position for the video node.")
@click.option("--video-y", type=float, default=0, show_default=True, help="Canvas Y position for the video node.")
@click.option("--run/--dry-run", "run_workflow", default=False, show_default=True, help="Submit the full workflow; default is dry-run planning.")
@click.option("--validate/--no-validate", "validate_params", default=True, show_default=True, help="Validate model params before submission.")
@click.option("--wait/--no-wait", "wait_after_submit", default=True, show_default=True, help="Wait for final video generation after submission.")
@click.option("--interval", default=5.0, show_default=True, type=float, help="Generation polling interval seconds.")
@click.option("--timeout", default=1800.0, show_default=True, type=float, help="Generation polling timeout seconds.")
@click.option("--allow-failed", is_flag=True, help="Return JSON instead of non-zero exit when a waited step fails.")
@click.pass_context
@_handle_errors
def workflow_image_to_video(
    ctx: click.Context,
    label: str,
    file_uuid: str | None,
    image_prompt: str,
    video_prompt: str,
    image_label: str | None,
    video_label: str | None,
    image_model: str,
    video_model: str,
    image_resolution: str,
    image_aspect_ratio: str,
    image_count: str,
    video_resolution: str,
    video_aspect_ratio: str,
    duration: str,
    include_audio: bool,
    video_count: str,
    image_set_values: tuple[str, ...],
    video_set_values: tuple[str, ...],
    human_reference: bool,
    compliance_interval: float,
    compliance_timeout: float,
    image_x: float,
    image_y: float,
    video_x: float,
    video_y: float,
    run_workflow: bool,
    validate_params: bool,
    wait_after_submit: bool,
    interval: float,
    timeout: float,
    allow_failed: bool,
):
    """Generate a reference image, then use it for Seedance image-to-video."""
    file_uuid = _require_file(ctx, file_uuid)
    image_label = image_label or f"{label} Image"
    video_label = video_label or f"{label} Video"
    image_refs = _prompt_node_references(image_prompt)
    video_refs = _prompt_node_references(video_prompt)
    nodes = _nodes_for_scope(ctx, file_uuid, None) if image_refs or video_refs else []
    node_lookup = _nodes_by_uuid(nodes) if nodes else {}
    normalized_image_prompt, image_prev_node_uuids, image_ref_keys = _prepare_prompt_node_references(
        nodes,
        image_prompt,
        [],
        strict_v1=False,
    )

    image_params = _image_params(
        model=image_model,
        prompt=normalized_image_prompt or "",
        resolution=image_resolution,
        aspect_ratio=image_aspect_ratio,
        count=image_count,
        extra_params=_apply_key_values({}, image_set_values),
    )
    image_node = _synthetic_node_payload(
        label=image_label,
        node_type="GENERATE_IMAGE",
        file_uuid=file_uuid,
        prompt=None,
        model=None,
        params=image_params,
        data={"label": image_label, "workflow": "workflow-image-to-video", "workflowLabel": label, "step": "image"},
        prev_node_uuids=image_prev_node_uuids,
        x=image_x,
        y=image_y,
    )
    mention_nodes = nodes + [
        {
            "uuid": image_node["uuid"],
            "type": "GENERATE_IMAGE",
            "label": image_label,
            "prevNodeUuids": image_prev_node_uuids,
        }
    ]
    normalized_video_prompt, video_prev_node_uuids, video_ref_keys = _prepare_prompt_node_references(
        mention_nodes,
        video_prompt,
        [image_node["uuid"]],
        strict_v1=False,
    )
    video_params = _video_params(
        model=video_model,
        prompt=normalized_video_prompt or "",
        resolution=video_resolution,
        aspect_ratio=video_aspect_ratio,
        duration=duration,
        refer_model="imageToVideo",
        include_audio=include_audio,
        count=video_count,
        extra_params=_apply_key_values({}, video_set_values),
    )
    video_node = _synthetic_node_payload(
        label=video_label,
        node_type="GENERATE_VIDEO",
        file_uuid=file_uuid,
        prompt=None,
        model=None,
        params=video_params,
        data={
            "label": video_label,
            "workflow": "workflow-image-to-video",
            "workflowLabel": label,
            "step": "video",
            "referenceNodeUuid": image_node["uuid"],
        },
        prev_node_uuids=video_prev_node_uuids,
        x=video_x,
        y=video_y,
    )

    image_generate_payload = {"fileUuid": file_uuid, "nodeUuids": [image_node["uuid"]], "nodes": [image_node["uuid"]]}
    video_generate_payload = {"fileUuid": file_uuid, "nodeUuids": [video_node["uuid"]], "nodes": [video_node["uuid"]]}
    plans: list[dict[str, Any]] = [
        {"step": "create-image-node", "endpoint": "/canvas/node/batch", "payload": {"fileUuid": file_uuid, "create": [image_node], "update": [], "delete": []}},
        {"step": "generate-image", "endpoint": "/generate/batch", "payload": image_generate_payload},
        {"step": "wait-image", "endpoint": "/generate/progress", "payload": {"nodeUuids": [image_node["uuid"]]}},
    ]
    if human_reference:
        plans.append(
            {
                "step": "check-generated-image-compliance",
                "endpoint": "/assetLibrary/compliance/check",
                "payload": {"assetUuid": "${image.resultAssets[0].assetsUuid}"},
            }
        )
    plans.extend(
        [
            {"step": "create-video-node", "endpoint": "/canvas/node/batch", "payload": {"fileUuid": file_uuid, "create": [video_node], "update": [], "delete": []}},
            {"step": "generate-video", "endpoint": "/generate/batch", "payload": video_generate_payload},
        ]
    )
    if wait_after_submit:
        plans.append({"step": "wait-video", "endpoint": "/generate/progress", "payload": {"nodeUuids": [video_node["uuid"]]}})

    if not run_workflow:
        _emit(
            {
                "dryRun": True,
                "workflow": "image-to-video",
                "label": label,
                "imageNodeKey": image_node["uuid"],
                "videoNodeKey": video_node["uuid"],
                "requiresRun": True,
                "plans": plans,
            },
            "Workflow image-to-video dry run",
        )
        return

    api = _client(ctx)
    image_input_nodes = [node_lookup[key] for key in image_node.get("prevNodeUuids") or [] if key in node_lookup]
    image_result = _run_generate_node_workflow(
        api=api,
        file_uuid=file_uuid,
        node_payload=image_node,
        input_nodes=image_input_nodes,
        validate_params=validate_params,
        wait_after_submit=True,
        interval=interval,
        timeout=timeout,
    )
    workflow_result: dict[str, Any] = {
        "workflow": "image-to-video",
        "label": label,
        "imageNodeKey": image_node["uuid"],
        "videoNodeKey": video_node["uuid"],
        "plans": plans,
        "image": image_result,
    }
    image_wait = image_result.get("wait") if isinstance(image_result.get("wait"), dict) else {}
    if not image_wait.get("ok"):
        _emit(workflow_result, "Workflow image-to-video image step failed")
        _exit_on_failed_wait(image_wait, allow_failed=allow_failed)
        return

    image_assets = image_wait.get("resultAssets") if isinstance(image_wait.get("resultAssets"), list) else []
    image_asset_uuid = _first_asset_uuid(image_assets)
    if not image_asset_uuid:
        workflow_result["error"] = "Generated image step completed without a result asset UUID."
        _emit(workflow_result, "Workflow image-to-video missing generated asset")
        raise click.exceptions.Exit(1)
    workflow_result["imageAssetUuid"] = image_asset_uuid

    compliance_result = None
    if human_reference:
        compliance_result = _poll_compliance(
            api,
            _compliance_payload(image_asset_uuid, {}),
            interval=compliance_interval,
            timeout=compliance_timeout,
        )
        workflow_result["compliance"] = compliance_result
        if compliance_result.get("status") not in {"ACTIVE", "PASS", "PASSED", "SUCCESS", "SUCCEEDED", "COMPLETE", "COMPLETED"}:
            _emit(workflow_result, "Workflow image-to-video compliance failed")
            if allow_failed:
                return
            raise click.exceptions.Exit(1)

    generated_image_node = _generated_input_node(image_node, image_assets[0] if image_assets else None)
    video_input_nodes = [generated_image_node] + [
        node for node in (node_lookup.get(key) for key in video_ref_keys)
        if isinstance(node, dict)
    ]
    video_result = _run_generate_node_workflow(
        api=api,
        file_uuid=file_uuid,
        node_payload=video_node,
        input_nodes=video_input_nodes,
        validate_params=validate_params,
        wait_after_submit=wait_after_submit,
        interval=interval,
        timeout=timeout,
    )
    workflow_result["generatedReference"] = _node_pipe_record(generated_image_node)
    workflow_result["video"] = video_result
    _emit(workflow_result, "Workflow image-to-video submitted")
    video_wait = video_result.get("wait")
    if isinstance(video_wait, dict):
        _exit_on_failed_wait(video_wait, allow_failed=allow_failed)


@workflow.command("script-to-video")
@click.argument("selector")
@click.option("--file", "file_uuid", default=None, help="Canvas file UUID.")
@click.option("--storyboard-model", default="BANANA_2", show_default=True, help="Model for per-row storyboard image nodes.")
@click.option("--video-model", default="PIXDANCE_2", show_default=True, help="Pixmax video model code.")
@click.option("--storyboard-resolution", default="2K", show_default=True, help="Storyboard image resolution.")
@click.option("--storyboard-aspect-ratio", default="", show_default=True, help="Storyboard image aspect ratio; empty means model auto/default.")
@click.option("--storyboard-count", default="1", show_default=True, help="Number of storyboard generations per row.")
@click.option("--video-resolution", default="480P", show_default=True, help="Video resolution.")
@click.option("--video-aspect-ratio", default="3:4", show_default=True, help="Video aspect ratio.")
@click.option("--duration", default="7", show_default=True, help="Video duration seconds.")
@click.option("--include-audio/--no-audio", default=False, show_default=True, help="Enable generated audio.")
@click.option("--video-count", default="1", show_default=True, help="Number of videos per row.")
@click.option("--storyboard-set", "storyboard_set_values", multiple=True, help="Extra storyboard model param key=value, supports dotted keys.")
@click.option("--video-set", "video_set_values", multiple=True, help="Extra video model param key=value, supports dotted keys.")
@click.option("--human-reference/--no-human-reference", default=True, show_default=True, help="Run asset compliance before Seedance 2.0 submission.")
@click.option("--compliance-interval", default=2.0, show_default=True, type=float, help="Compliance polling interval seconds.")
@click.option("--compliance-timeout", default=180.0, show_default=True, type=float, help="Compliance polling timeout seconds.")
@click.option("--x", type=float, default=960, show_default=True, help="First storyboard node X position.")
@click.option("--y", type=float, default=720, show_default=True, help="First storyboard node Y position.")
@click.option("--video-x", type=float, default=1280, show_default=True, help="First video node X position.")
@click.option("--video-y", type=float, default=720, show_default=True, help="First video node Y position.")
@click.option("--gap", type=float, default=240, show_default=True, help="Vertical gap between row nodes.")
@click.option("--max-rows", type=int, default=None, help="Limit rows from the script node.")
@click.option("--run/--dry-run", "run_workflow", default=False, show_default=True, help="Submit the full workflow; default is dry-run planning.")
@click.option("--validate/--no-validate", "validate_params", default=True, show_default=True, help="Validate model params before submission.")
@click.option("--wait/--no-wait", "wait_after_submit", default=True, show_default=True, help="Wait for final video generation after submission.")
@click.option("--interval", default=5.0, show_default=True, type=float, help="Generation polling interval seconds.")
@click.option("--timeout", default=1800.0, show_default=True, type=float, help="Generation polling timeout seconds.")
@click.option("--allow-failed", is_flag=True, help="Return JSON instead of non-zero exit when a waited step fails.")
@click.pass_context
@_handle_errors
def workflow_script_to_video(
    ctx: click.Context,
    selector: str,
    file_uuid: str | None,
    storyboard_model: str,
    video_model: str,
    storyboard_resolution: str,
    storyboard_aspect_ratio: str,
    storyboard_count: str,
    video_resolution: str,
    video_aspect_ratio: str,
    duration: str,
    include_audio: bool,
    video_count: str,
    storyboard_set_values: tuple[str, ...],
    video_set_values: tuple[str, ...],
    human_reference: bool,
    compliance_interval: float,
    compliance_timeout: float,
    x: float,
    y: float,
    video_x: float,
    video_y: float,
    gap: float,
    max_rows: int | None,
    run_workflow: bool,
    validate_params: bool,
    wait_after_submit: bool,
    interval: float,
    timeout: float,
    allow_failed: bool,
):
    """Create storyboard images from script rows, then create Seedance videos."""
    file_uuid = _require_file(ctx, file_uuid)
    nodes = _nodes_for_scope(ctx, file_uuid, None)
    node_lookup = _nodes_by_uuid(nodes)
    script_node = _resolve_node(nodes, selector)
    rows = _script_node_rows(script_node)
    if max_rows is not None:
        if max_rows <= 0:
            raise ValueError("--max-rows must be greater than 0.")
        rows = rows[:max_rows]
    if not rows:
        raise ValueError("Script node has no stored rows. Use script set-rows first.")

    storyboard_extra = _apply_key_values({}, storyboard_set_values)
    video_extra = _apply_key_values({}, video_set_values)
    storyboard_nodes: list[dict[str, Any]] = []
    video_nodes: list[dict[str, Any]] = []
    for index, row in enumerate(rows):
        shot_label = f"{script_node.get('label') or 'Script'} Shot {row.get('shotNumber') or index + 1}"
        storyboard_prompt, storyboard_prev_node_uuids, _ = _prepare_prompt_node_references(
            nodes,
            _script_row_prompt(row),
            [str(script_node.get("uuid") or "")],
            strict_v1=False,
        )
        storyboard_params = _storyboard_params(
            model=storyboard_model,
            prompt=storyboard_prompt or "",
            grid_layout="1x1",
            resolution=storyboard_resolution,
            aspect_ratio=storyboard_aspect_ratio,
            count=storyboard_count,
            extra_params=storyboard_extra,
        )
        storyboard_node = _synthetic_node_payload(
            label=f"{shot_label} Storyboard",
            node_type="GENERATE_STORYBOARD",
            file_uuid=file_uuid,
            prompt=None,
            model=None,
            params=storyboard_params,
            data={
                "workflow": "workflow-script-to-video",
                "step": "storyboard",
                "scriptNodeUuid": script_node.get("uuid"),
                "scriptRowHiddenUuid": row.get("hiddenUuid"),
                "row": row,
            },
            prev_node_uuids=storyboard_prev_node_uuids,
            x=x,
            y=y + index * gap,
        )
        # The storyboard is not on the server yet, but it is the direct input
        # for the paired video node. Include it while normalizing any other
        # row-level mentions so their UUIDs and media indexes stay consistent.
        mention_nodes = nodes + [
            {
                "uuid": storyboard_node["uuid"],
                "type": "GENERATE_STORYBOARD",
                "label": f"{shot_label} Storyboard",
                "prevNodeUuids": storyboard_prev_node_uuids,
            }
        ]
        video_prompt, video_prev_node_uuids, _ = _prepare_prompt_node_references(
            mention_nodes,
            _script_row_video_prompt(row),
            [storyboard_node["uuid"]],
            strict_v1=False,
        )
        video_params = _video_params(
            model=video_model,
            prompt=video_prompt or "",
            resolution=video_resolution,
            aspect_ratio=video_aspect_ratio,
            duration=duration,
            refer_model="imageToVideo",
            include_audio=include_audio,
            count=video_count,
            extra_params=video_extra,
        )
        video_node = _synthetic_node_payload(
            label=f"{shot_label} Video",
            node_type="GENERATE_VIDEO",
            file_uuid=file_uuid,
            prompt=None,
            model=None,
            params=video_params,
            data={
                "workflow": "workflow-script-to-video",
                "step": "video",
                "scriptNodeUuid": script_node.get("uuid"),
                "scriptRowHiddenUuid": row.get("hiddenUuid"),
                "storyboardNodeUuid": storyboard_node["uuid"],
                "row": row,
            },
            prev_node_uuids=video_prev_node_uuids,
            x=video_x,
            y=video_y + index * gap,
        )
        storyboard_nodes.append(storyboard_node)
        video_nodes.append(video_node)

    storyboard_uuids = [node["uuid"] for node in storyboard_nodes]
    video_uuids = [node["uuid"] for node in video_nodes]
    storyboard_generate_payload = {"fileUuid": file_uuid, "nodeUuids": storyboard_uuids, "nodes": storyboard_uuids}
    video_generate_payload = {"fileUuid": file_uuid, "nodeUuids": video_uuids, "nodes": video_uuids}
    plans: list[dict[str, Any]] = [
        {"step": "create-storyboard-nodes", "endpoint": "/canvas/node/batch", "payload": {"fileUuid": file_uuid, "create": storyboard_nodes, "update": [], "delete": []}},
        {"step": "generate-storyboards", "endpoint": "/generate/batch", "payload": storyboard_generate_payload},
        {"step": "wait-storyboards", "endpoint": "/generate/progress", "payload": {"nodeUuids": storyboard_uuids}},
    ]
    if human_reference:
        plans.append(
            {
                "step": "check-storyboard-compliance",
                "endpoint": "/assetLibrary/compliance/check",
                "payload": {"assetUuid": "${storyboard.resultAssetsByNode[*].assetsUuid}"},
            }
        )
    plans.extend(
        [
            {"step": "create-video-nodes", "endpoint": "/canvas/node/batch", "payload": {"fileUuid": file_uuid, "create": video_nodes, "update": [], "delete": []}},
            {"step": "generate-videos", "endpoint": "/generate/batch", "payload": video_generate_payload},
        ]
    )
    if wait_after_submit:
        plans.append({"step": "wait-videos", "endpoint": "/generate/progress", "payload": {"nodeUuids": video_uuids}})

    if not run_workflow:
        _emit(
            {
                "dryRun": True,
                "workflow": "script-to-video",
                "scriptNode": _node_pipe_record(script_node),
                "rowCount": len(rows),
                "storyboardNodeKeys": storyboard_uuids,
                "videoNodeKeys": video_uuids,
                "requiresRun": True,
                "plans": plans,
            },
            "Workflow script-to-video dry run",
        )
        return

    api = _client(ctx)
    validations = []
    if validate_params:
        validations.extend(
            _validate_node_params(
                api,
                payload,
                input_nodes=[
                    node_lookup.get(key, script_node)
                    for key in payload.get("prevNodeUuids") or []
                    if key in node_lookup or key == script_node.get("uuid")
                ],
            )
            for payload in storyboard_nodes
        )
    storyboard_create = _batch_mutate_nodes(api, file_uuid, create=storyboard_nodes)
    storyboard_submit = api.generate_batch(storyboard_generate_payload)
    storyboard_wait = _wait_generation(api, storyboard_uuids, interval=interval, timeout=timeout)
    result: dict[str, Any] = {
        "workflow": "script-to-video",
        "scriptNode": _node_pipe_record(script_node),
        "rowCount": len(rows),
        "storyboardNodeKeys": storyboard_uuids,
        "videoNodeKeys": video_uuids,
        "plans": plans,
        "storyboard": {
            "create": storyboard_create,
            "submit": storyboard_submit,
            "wait": storyboard_wait,
        },
    }
    if validations:
        result["validations"] = validations
    if not storyboard_wait.get("ok"):
        _emit(result, "Workflow script-to-video storyboard step failed")
        _exit_on_failed_wait(storyboard_wait, allow_failed=allow_failed)
        return

    storyboard_assets_by_node: dict[str, dict[str, Any]] = {}
    compliance_results = []
    for node in storyboard_nodes:
        asset = _first_result_asset_for_node(storyboard_wait, node["uuid"])
        if not asset:
            result["error"] = f"Storyboard node completed without a result asset UUID: {node['uuid']}"
            _emit(result, "Workflow script-to-video missing storyboard asset")
            raise click.exceptions.Exit(1)
        storyboard_assets_by_node[node["uuid"]] = asset
        if human_reference:
            compliance = _poll_compliance(
                api,
                _compliance_payload(_asset_uuid(asset) or "", {}),
                interval=compliance_interval,
                timeout=compliance_timeout,
            )
            compliance_results.append({"nodeUuid": node["uuid"], "assetUuid": _asset_uuid(asset), "compliance": compliance})
            if compliance.get("status") not in {"ACTIVE", "PASS", "PASSED", "SUCCESS", "SUCCEEDED", "COMPLETE", "COMPLETED"}:
                result["compliance"] = compliance_results
                _emit(result, "Workflow script-to-video compliance failed")
                if allow_failed:
                    return
                raise click.exceptions.Exit(1)

    result["storyboard"]["resultAssetsByNode"] = {
        node_uuid: _asset_uuid(asset)
        for node_uuid, asset in storyboard_assets_by_node.items()
    }
    if compliance_results:
        result["compliance"] = compliance_results

    generated_storyboard_nodes = [
        _generated_input_node(node, storyboard_assets_by_node[node["uuid"]])
        for node in storyboard_nodes
    ]
    generated_storyboard_by_uuid = {
        node["uuid"]: node for node in generated_storyboard_nodes
    }
    if validate_params:
        validations.extend(
            _validate_node_params(
                api,
                payload,
                input_nodes=[
                    generated_storyboard_by_uuid.get(key, node_lookup.get(key))
                    for key in payload.get("prevNodeUuids") or []
                    if key in generated_storyboard_by_uuid or key in node_lookup
                ],
            )
            for index, payload in enumerate(video_nodes)
        )
        result["validations"] = validations
    video_create = _batch_mutate_nodes(api, file_uuid, create=video_nodes)
    video_submit = api.generate_batch(video_generate_payload)
    video_wait = _wait_generation(api, video_uuids, interval=interval, timeout=timeout) if wait_after_submit else None
    result["generatedStoryboards"] = [_node_pipe_record(node) for node in generated_storyboard_nodes]
    result["video"] = {"create": video_create, "submit": video_submit}
    if video_wait:
        result["video"]["wait"] = video_wait
    _emit(result, "Workflow script-to-video submitted")
    if video_wait:
        _exit_on_failed_wait(video_wait, allow_failed=allow_failed)


@cli.group()
def script():
    """Script row workflows backed by Pixmax text and storyboard/image nodes."""


@script.command("create")
@click.argument("label")
@click.option("--file", "file_uuid", default=None, help="Canvas file UUID.")
@click.option("--prompt", required=True, help="Script generation prompt.")
@click.option("--model", "model_code", default="GEMINI_31_PRO", show_default=True, help="Pixmax text model code.")
@click.option("--rows-data", default=None, help="JSON array or object with rows[] to store on the script node.")
@click.option("--rows-file", default=None, type=click.Path(exists=True), help="JSON file containing rows[] to store on the script node.")
@click.option("-s", "--set", "set_values", multiple=True, help="Extra model param key=value, supports dotted keys.")
@click.option("--left", "left_nodes", multiple=True, help="Reference node UUID or exact label.")
@click.option("--x", type=float, default=640, show_default=True, help="Canvas X position.")
@click.option("--y", type=float, default=720, show_default=True, help="Canvas Y position.")
@click.option("--run", "run_after", is_flag=True, help="Submit a generate batch after create and wait for the final state.")
@click.option("--validate/--no-validate", "validate_params", default=True, show_default=True, help="Validate model params before running generation.")
@click.option("--wait/--no-wait", "wait_after_run", default=True, show_default=True, help="When --run is set, wait for generation to finish.")
@click.option("--interval", default=5.0, show_default=True, type=float, help="Generation polling interval seconds.")
@click.option("--timeout", default=1800.0, show_default=True, type=float, help="Generation polling timeout seconds.")
@click.option("--allow-failed", is_flag=True, help="Return JSON instead of non-zero exit when waited generation fails.")
@click.option("--dry-run", is_flag=True, help="Print planned payloads without mutating or generating.")
@click.pass_context
@_handle_errors
def script_create(
    ctx: click.Context,
    label: str,
    file_uuid: str | None,
    prompt: str,
    model_code: str,
    rows_data: str | None,
    rows_file: str | None,
    set_values: tuple[str, ...],
    left_nodes: tuple[str, ...],
    x: float,
    y: float,
    run_after: bool,
    validate_params: bool,
    wait_after_run: bool,
    interval: float,
    timeout: float,
    allow_failed: bool,
    dry_run: bool,
):
    """Create a GENERATE_TEXT node that carries script/storyboard rows."""
    file_uuid = _require_file(ctx, file_uuid)
    rows = _load_script_rows(rows_data, rows_file) if rows_data or rows_file else []
    prompt_refs = _prompt_node_references(prompt)
    nodes = _nodes_for_scope(ctx, file_uuid, None) if left_nodes or prompt_refs else []
    left_keys = [_resolve_node(nodes, item).get("uuid") for item in left_nodes]
    normalized_prompt, prev_node_uuids, _ = _prepare_prompt_node_references(
        nodes,
        prompt,
        [key for key in left_keys if isinstance(key, str)],
        strict_v1=False,
    )
    params = _apply_key_values({}, set_values)
    payload = _synthetic_node_payload(
        label=label,
        node_type="GENERATE_TEXT",
        file_uuid=file_uuid,
        prompt=normalized_prompt,
        model=model_code,
        params=params,
        data={"label": label, "workflow": "script", "rows": rows},
        prev_node_uuids=prev_node_uuids,
        x=x,
        y=y,
    )
    generate_payload = {"fileUuid": file_uuid, "nodeUuids": [payload["uuid"]], "nodes": [payload["uuid"]]}
    plans = [{"endpoint": "/canvas/node/batch", "payload": {"fileUuid": file_uuid, "create": [payload], "update": [], "delete": []}}]
    if run_after:
        plans.append({"endpoint": "/generate/batch", "payload": generate_payload})
        if wait_after_run:
            plans.append({"endpoint": "/generate/progress", "payload": {"nodeUuids": [payload["uuid"]]}})
    if dry_run:
        _emit({"dryRun": True, "nodeKey": payload["uuid"], "rowCount": len(rows), "plans": plans}, "Script create dry run")
        return
    api = _client(ctx)
    node_lookup = _nodes_by_uuid(nodes) if nodes else {}
    input_nodes = [node_lookup[key] for key in payload.get("prevNodeUuids") or [] if key in node_lookup]
    validation = _validate_node_params(api, payload, input_nodes=input_nodes) if run_after and validate_params else None
    create_result = _batch_mutate_nodes(api, file_uuid, create=[payload])
    submit_result = None
    wait_result = None
    if run_after:
        submit_result = api.generate_batch(generate_payload)
        if wait_after_run:
            wait_result = _wait_generation(api, [payload["uuid"]], interval=interval, timeout=timeout)
    result: dict[str, Any] = {"nodeKey": payload["uuid"], "uuid": payload["uuid"], "rowCount": len(rows), "plans": plans, "create": create_result}
    if validation:
        result["validation"] = validation
    if submit_result:
        result["submit"] = submit_result
    if wait_result:
        result["wait"] = wait_result
    _emit(result, "Script node created")
    if wait_result:
        _exit_on_failed_wait(wait_result, allow_failed=allow_failed)


@script.command("rows")
@click.argument("selector")
@click.option("--file", "file_uuid", default=None, help="Canvas file UUID.")
@click.pass_context
@_handle_errors
def script_rows(ctx: click.Context, selector: str, file_uuid: str | None):
    """Show stored script/storyboard rows from a node."""
    target = _resolve_node(_nodes_for_scope(ctx, file_uuid, None), selector)
    rows = _script_node_rows(target)
    _emit({"node": _node_pipe_record(target), "rowCount": len(rows), "rows": rows}, "Script rows")


@script.command("set-rows")
@click.argument("selector")
@click.option("--file", "file_uuid", default=None, help="Canvas file UUID.")
@click.option("--data", "data_json", default=None, help="JSON array or object with rows[]. Defaults to NDJSON stdin.")
@click.option("--rows-file", "payload_file", default=None, type=click.Path(exists=True), help="JSON rows file.")
@click.option("--dry-run", is_flag=True, help="Print planned payload without mutating.")
@click.pass_context
@_handle_errors
def script_set_rows(ctx: click.Context, selector: str, file_uuid: str | None, data_json: str | None, payload_file: str | None, dry_run: bool):
    """Replace stored script/storyboard rows on a node."""
    file_uuid = _require_file(ctx, file_uuid)
    target = _resolve_node(_nodes_for_scope(ctx, file_uuid, None), selector)
    rows = _load_script_rows(data_json, payload_file)
    update_payload = {
        "uuid": target.get("uuid"),
        "fileUuid": file_uuid,
        "metaDataPatch": {"data": {"rows": rows, "workflow": "script"}},
    }
    plan = {"endpoint": "/canvas/node/batch", "payload": {"fileUuid": file_uuid, "create": [], "update": [update_payload], "delete": []}}
    if dry_run:
        _emit({"dryRun": True, "target": _node_pipe_record(target), "rowCount": len(rows), "plans": [plan]}, "Script rows dry run")
        return
    result = _batch_mutate_nodes(_client(ctx), file_uuid, update=[update_payload])
    _emit({"target": _node_pipe_record(target), "rowCount": len(rows), "plans": [plan], "update": result}, "Script rows updated")


@script.command("storyboard")
@click.argument("selector")
@click.option("--file", "file_uuid", default=None, help="Canvas file UUID.")
@click.option("--model", "model_code", default="BANANA_2", show_default=True, help="Image model for per-row storyboard nodes.")
@click.option("--resolution", default="2K", show_default=True, help="Storyboard image resolution.")
@click.option("--aspect-ratio", default="", show_default=True, help="Storyboard image aspect ratio; empty means model auto/default.")
@click.option("--count", default="1", show_default=True, help="Number of generations per row.")
@click.option("-s", "--set", "set_values", multiple=True, help="Extra model param key=value, supports dotted keys.")
@click.option("--x", type=float, default=960, show_default=True, help="First node X position.")
@click.option("--y", type=float, default=720, show_default=True, help="First node Y position.")
@click.option("--gap", type=float, default=240, show_default=True, help="Vertical gap between row nodes.")
@click.option("--run", "run_after", is_flag=True, help="Submit generated row nodes and wait for terminal state.")
@click.option("--validate/--no-validate", "validate_params", default=True, show_default=True, help="Validate model params before running generation.")
@click.option("--wait/--no-wait", "wait_after_run", default=True, show_default=True, help="When --run is set, wait for generation to finish.")
@click.option("--interval", default=5.0, show_default=True, type=float, help="Generation polling interval seconds.")
@click.option("--timeout", default=1800.0, show_default=True, type=float, help="Generation polling timeout seconds.")
@click.option("--allow-failed", is_flag=True, help="Return JSON instead of non-zero exit when waited generation fails.")
@click.option("--dry-run", is_flag=True, help="Print planned payloads without mutating or generating.")
@click.pass_context
@_handle_errors
def script_storyboard(
    ctx: click.Context,
    selector: str,
    file_uuid: str | None,
    model_code: str,
    resolution: str,
    aspect_ratio: str,
    count: str,
    set_values: tuple[str, ...],
    x: float,
    y: float,
    gap: float,
    run_after: bool,
    validate_params: bool,
    wait_after_run: bool,
    interval: float,
    timeout: float,
    allow_failed: bool,
    dry_run: bool,
):
    """Create one storyboard image node per stored script row."""
    file_uuid = _require_file(ctx, file_uuid)
    target = _resolve_node(_nodes_for_scope(ctx, file_uuid, None), selector)
    rows = _script_node_rows(target)
    if not rows:
        raise ValueError("Script node has no stored rows. Use script set-rows first.")
    extra_params = _apply_key_values({}, set_values)
    create_payloads = []
    for index, row in enumerate(rows):
        params = _storyboard_params(
            model=model_code,
            prompt=_script_row_prompt(row),
            grid_layout="1x1",
            resolution=resolution,
            aspect_ratio=aspect_ratio,
            count=count,
            extra_params=extra_params,
        )
        create_payloads.append(
            _synthetic_node_payload(
                label=f"{target.get('label') or 'Script'} Shot {row.get('shotNumber') or index + 1}",
                node_type="GENERATE_STORYBOARD",
                file_uuid=file_uuid,
                prompt=None,
                model=None,
                params=params,
                data={
                    "workflow": "script-storyboard",
                    "scriptNodeUuid": target.get("uuid"),
                    "scriptRowHiddenUuid": row.get("hiddenUuid"),
                    "row": row,
                },
                prev_node_uuids=[target.get("uuid")],
                x=x,
                y=y + index * gap,
            )
        )
    node_uuids = [node["uuid"] for node in create_payloads]
    generate_payload = {"fileUuid": file_uuid, "nodeUuids": node_uuids, "nodes": node_uuids}
    plans = [{"endpoint": "/canvas/node/batch", "payload": {"fileUuid": file_uuid, "create": create_payloads, "update": [], "delete": []}}]
    if run_after:
        plans.append({"endpoint": "/generate/batch", "payload": generate_payload})
        if wait_after_run:
            plans.append({"endpoint": "/generate/progress", "payload": {"nodeUuids": node_uuids}})
    if dry_run:
        _emit({"dryRun": True, "scriptNode": _node_pipe_record(target), "rowCount": len(rows), "imageNodeKeys": node_uuids, "plans": plans}, "Script storyboard dry run")
        return
    api = _client(ctx)
    validations = [
        _validate_node_params(api, payload, input_nodes=[target])
        for payload in create_payloads
    ] if run_after and validate_params else []
    create_result = _batch_mutate_nodes(api, file_uuid, create=create_payloads)
    submit_result = None
    wait_result = None
    if run_after:
        submit_result = api.generate_batch(generate_payload)
        if wait_after_run:
            wait_result = _wait_generation(api, node_uuids, interval=interval, timeout=timeout)
    result: dict[str, Any] = {"scriptNode": _node_pipe_record(target), "rowCount": len(rows), "imageNodeKeys": node_uuids, "plans": plans, "create": create_result}
    if validations:
        result["validations"] = validations
    if submit_result:
        result["submit"] = submit_result
    if wait_result:
        result["wait"] = wait_result
    _emit(result, "Script storyboard nodes created")
    if wait_result:
        _exit_on_failed_wait(wait_result, allow_failed=allow_failed)


@cli.group()
def storyboard():
    """High-level storyboard generation workflows."""


@storyboard.command("config")
@click.pass_context
@_handle_errors
def storyboard_config(ctx: click.Context):
    """Fetch Pixmax storyboard defaults and supported models."""
    _emit(_client(ctx).storyboard_config(), "Pixmax storyboard config")


@storyboard.command("create")
@click.argument("label")
@click.option("--file", "file_uuid", default=None, help="Canvas file UUID.")
@click.option("--prompt", required=True, help="Storyboard generation prompt.")
@click.option("--model", "model_code", default=None, help="Pixmax storyboard image model code. Defaults to storyboard config.")
@click.option("--grid", "grid_layout", default="2x2", show_default=True, help="Storyboard grid layout, e.g. 2x2, 3x3.")
@click.option("--resolution", default="2K", show_default=True, help="Storyboard image resolution.")
@click.option("--aspect-ratio", default="", show_default=True, help="Storyboard image aspect ratio; empty means model auto/default.")
@click.option("--count", default="1", show_default=True, help="Number of generations.")
@click.option("-s", "--set", "set_values", multiple=True, help="Extra model param key=value, supports dotted keys.")
@click.option("--left", "left_nodes", multiple=True, help="Reference image node UUID or exact label.")
@click.option("--x", type=float, default=640, show_default=True, help="Canvas X position.")
@click.option("--y", type=float, default=480, show_default=True, help="Canvas Y position.")
@click.option("--run", "run_after", is_flag=True, help="Submit a generate batch after create and wait for the final state.")
@click.option("--validate/--no-validate", "validate_params", default=True, show_default=True, help="Validate model params before running generation.")
@click.option("--wait/--no-wait", "wait_after_run", default=True, show_default=True, help="When --run is set, wait for generation to finish.")
@click.option("--interval", default=5.0, show_default=True, type=float, help="Generation polling interval seconds.")
@click.option("--timeout", default=1800.0, show_default=True, type=float, help="Generation polling timeout seconds.")
@click.option("--allow-failed", is_flag=True, help="Return JSON instead of non-zero exit when waited generation fails.")
@click.option("--dry-run", is_flag=True, help="Print planned payloads without mutating or generating.")
@click.pass_context
@_handle_errors
def storyboard_create(
    ctx: click.Context,
    label: str,
    file_uuid: str | None,
    prompt: str,
    model_code: str | None,
    grid_layout: str,
    resolution: str,
    aspect_ratio: str,
    count: str,
    set_values: tuple[str, ...],
    left_nodes: tuple[str, ...],
    x: float,
    y: float,
    run_after: bool,
    validate_params: bool,
    wait_after_run: bool,
    interval: float,
    timeout: float,
    allow_failed: bool,
    dry_run: bool,
):
    """Create a GENERATE_STORYBOARD node from friendly CLI flags."""
    file_uuid = _require_file(ctx, file_uuid)
    api = None if dry_run and not left_nodes and model_code else _client(ctx)
    config = api.storyboard_config() if api and not model_code else {}
    config_data = config.get("data") if isinstance(config.get("data"), dict) else {}
    supported_models = [item for item in config_data.get("supportedModelCodes") or [] if isinstance(item, str)]
    model_code = model_code or (supported_models[0] if supported_models else "BANANA_2")
    grid_values = [item.get("gridLayout") for item in config_data.get("grids") or [] if isinstance(item, dict)]
    if grid_values and grid_layout not in grid_values:
        raise ValueError(f"Unsupported storyboard grid {grid_layout!r}. Options: {', '.join(grid_values)}")
    prompt_refs = _prompt_node_references(prompt)
    nodes = _nodes_for_scope(ctx, file_uuid, None) if left_nodes or prompt_refs else []
    left_keys = [_resolve_node(nodes, item).get("uuid") for item in left_nodes]
    normalized_prompt, prev_node_uuids, _ = _prepare_prompt_node_references(
        nodes,
        prompt,
        [key for key in left_keys if isinstance(key, str)],
        strict_v1=False,
    )
    params = _storyboard_params(
        model=model_code,
        prompt=normalized_prompt or "",
        grid_layout=grid_layout,
        resolution=resolution,
        aspect_ratio=aspect_ratio,
        count=count,
        extra_params=_apply_key_values({}, set_values),
    )
    node_payload = _synthetic_node_payload(
        label=label,
        node_type="GENERATE_STORYBOARD",
        file_uuid=file_uuid,
        prompt=None,
        model=None,
        params=params,
        data={"label": label, "workflow": "storyboard", "gridLayout": grid_layout},
        prev_node_uuids=prev_node_uuids,
        x=x,
        y=y,
    )
    generate_payload = {"fileUuid": file_uuid, "nodeUuids": [node_payload["uuid"]], "nodes": [node_payload["uuid"]]}
    plans: list[dict[str, Any]] = [
        {"endpoint": "/canvas/node/batch", "payload": {"fileUuid": file_uuid, "create": [node_payload], "update": [], "delete": []}},
    ]
    if run_after:
        plans.append({"endpoint": "/generate/batch", "payload": generate_payload})
        if wait_after_run:
            plans.append({"endpoint": "/generate/progress", "payload": {"nodeUuids": [node_payload["uuid"]]}})
    if dry_run:
        _emit(
            {
                "dryRun": True,
                "nodeKey": node_payload["uuid"],
                "supportedModels": supported_models,
                "supportedGrids": grid_values,
                "plans": plans,
            },
            "Storyboard create dry run",
        )
        return

    api = api or _client(ctx)
    node_lookup = _nodes_by_uuid(nodes) if nodes else {}
    input_nodes = [node_lookup[key] for key in node_payload.get("prevNodeUuids") or [] if key in node_lookup]
    validation = _validate_node_params(api, node_payload, input_nodes=input_nodes) if run_after and validate_params else None
    create_result = _batch_mutate_nodes(api, file_uuid, create=[node_payload])
    submit_result = None
    wait_result = None
    if run_after:
        submit_result = api.generate_batch(generate_payload)
        if wait_after_run:
            wait_result = _wait_generation(api, [node_payload["uuid"]], interval=interval, timeout=timeout)
    result: dict[str, Any] = {
        "nodeKey": node_payload["uuid"],
        "uuid": node_payload["uuid"],
        "plans": plans,
        "create": create_result,
        "supportedModels": supported_models,
        "supportedGrids": grid_values,
    }
    if validation:
        result["validation"] = validation
    if submit_result:
        result["submit"] = submit_result
    if wait_result:
        result["wait"] = wait_result
    _emit(result, "Storyboard node created")
    if wait_result:
        _exit_on_failed_wait(wait_result, allow_failed=allow_failed)


@cli.group()
def group():
    """Manage local Pixmax node groups for agent workflows."""


@group.command("bind")
@click.argument("name")
@click.option("--node", "node_selectors", multiple=True, help="Node UUID or exact label to bind into this group.")
@click.option("--file", "file_uuid", default=None, help="Canvas file UUID for resolving labels.")
@click.pass_context
@_handle_errors
def group_bind(ctx: click.Context, name: str, node_selectors: tuple[str, ...], file_uuid: str | None):
    """Bind nodes into a local Pixmax group."""
    nodes = _nodes_for_scope(ctx, file_uuid, None)
    stdin_keys = [_node_key(row) for row in _read_ndjson_stdin()]
    selected = [_resolve_node(nodes, item).get("uuid") for item in node_selectors]
    current = _session(ctx).groups.get(name) or []
    node_uuids = _dedupe(current + [key for key in stdin_keys if key] + [key for key in selected if key])
    _session(ctx).set_group(name, node_uuids)
    _emit({"action": "bind", "group": name, "nodeUuids": node_uuids}, "Pixmax group saved")


@group.command("list")
@click.pass_context
def group_list(ctx: click.Context):
    """List local Pixmax node groups."""
    _emit({"active": _session(ctx).group_name, "groups": _session(ctx).groups}, "Pixmax groups")


@group.command("use")
@click.argument("name")
@click.pass_context
@_handle_errors
def group_use(ctx: click.Context, name: str):
    """Use a local node group as the default node scope."""
    _session(ctx).use_group(name)
    _emit({"active": name, "nodeUuids": _session(ctx).groups.get(name) or []}, "Pixmax group active")


@group.command("unuse")
@click.pass_context
def group_unuse(ctx: click.Context):
    """Clear the default local node group."""
    _session(ctx).unuse_group()
    _emit({"groupUnbound": True}, "Pixmax group unbound")


@group.command("delete")
@click.argument("name")
@click.pass_context
def group_delete(ctx: click.Context, name: str):
    """Delete a local node group binding."""
    _session(ctx).delete_group(name)
    _emit({"deleted": name}, "Pixmax group deleted")


@group.command("run")
@click.argument("name", required=False)
@click.option("--file", "file_uuid", default=None, help="Canvas file UUID.")
@click.option("--dry-run", is_flag=True, help="Print generate payload without submitting.")
@click.pass_context
@_handle_errors
def group_run(ctx: click.Context, name: str | None, file_uuid: str | None, dry_run: bool):
    """Submit generation for every node in a local group."""
    file_uuid = _require_file(ctx, file_uuid)
    name = name or _session(ctx).group_name
    if not name:
        raise RuntimeError("Pass a group name or run: group use <name>.")
    node_uuids = _session(ctx).groups.get(name) or []
    payload = {"fileUuid": file_uuid, "nodeUuids": node_uuids, "nodes": node_uuids}
    if dry_run:
        _emit_dry_run("/generate/batch", payload)
        return
    _emit(_client(ctx).generate_batch(payload), "Pixmax group generation submitted")


@cli.group()
def assets():
    """Asset library commands."""


@assets.command("list")
@click.pass_context
@_handle_errors
def assets_list(ctx: click.Context):
    """List account assets."""
    _emit(_client(ctx).assets_list(), "Pixmax assets")


@assets.command("links")
@click.argument("asset_uuids", nargs=-1, required=True)
@click.pass_context
@_handle_errors
def assets_links(ctx: click.Context, asset_uuids: tuple[str, ...]):
    """Resolve asset UUIDs to downloadable URLs."""
    _emit(_client(ctx).get_assets_link(list(asset_uuids)), "Pixmax asset links")


@assets.command("download")
@click.argument("asset_uuid")
@click.option("--output", "-o", required=True, type=click.Path(dir_okay=False), help="Output file.")
@click.option("--kind", type=click.Choice(["web", "preview", "thumbnail"]), default="web", show_default=True)
@click.pass_context
@_handle_errors
def assets_download(ctx: click.Context, asset_uuid: str, output: str, kind: str):
    """Resolve and download an asset."""
    api = _client(ctx)
    result = api.get_assets_link([asset_uuid])
    assets_data = result.get("data") or []
    if not assets_data:
        raise RuntimeError(f"Asset link not found: {asset_uuid}")
    asset = assets_data[0]
    key = {"web": "webUrl", "preview": "previewWebUrl", "thumbnail": "thumbnailWebUrl"}[kind]
    from pixmax.utils.pixmax_backend import absolutize_asset_url

    url = absolutize_asset_url(asset, key, base_url=getattr(api, "base_url", None))
    if not url:
        raise RuntimeError(f"Asset URL not available for kind {kind}: {asset_uuid}")
    written = write_bytes(output, api.download(url))
    _emit({**written, "assetUuid": asset_uuid, "url": url, "kind": kind}, "Asset downloaded")


@assets.command("upload")
@click.argument("path", type=click.Path(exists=True, dir_okay=False))
@click.option("--project", "project_uuid", default=None, help="Project UUID.")
@click.option("--file-uuid", default=None, help="Canvas file UUID.")
@click.option("--node", "node_uuid", default=None, help="Canvas node UUID.")
@click.option("--asset-type", default="IMG", show_default=True, help="Pixmax asset fileType, such as IMG/VIDEO/AUDIO.")
@click.option("--content-type", default=None, help="Override MIME type.")
@click.option("--as-node", "as_node", default=None, help="Create a BASE_* node with this display label after upload.")
@click.option("--x", type=float, default=0, show_default=True, help="Canvas X position for --as-node.")
@click.option("--y", type=float, default=0, show_default=True, help="Canvas Y position for --as-node.")
@click.option("--data", "data_json", default=None, help="Extra JSON fields merged into authorize/check payloads.")
@click.option("--file", "payload_file", default=None, type=click.Path(exists=True), help="Extra JSON payload file.")
@click.option("--dry-run", is_flag=True, help="Print authorize/check payloads without uploading.")
@click.pass_context
@_handle_errors
def assets_upload(
    ctx: click.Context,
    path: str,
    project_uuid: str | None,
    file_uuid: str | None,
    node_uuid: str | None,
    asset_type: str,
    content_type: str | None,
    as_node: str | None,
    x: float,
    y: float,
    data_json: str | None,
    payload_file: str | None,
    dry_run: bool,
):
    """Authorize, upload a local file to OSS, then check it with Pixmax."""
    source = Path(path)
    content_type = content_type or guess_content_type(source)
    base_payload = _payload_with_defaults(_load_payload(data_json, payload_file), project_uuid=project_uuid, file_uuid=file_uuid, ctx=ctx)
    base_payload.update(
        {
            "fileName": source.name,
            "fileSize": source.stat().st_size,
            "fileType": asset_type,
            "contentType": content_type,
        }
    )
    if node_uuid:
        base_payload["nodeUuid"] = node_uuid
    if dry_run:
        plans = [{"endpoint": "/assets/oss/authorize", "payload": base_payload}]
        if as_node:
            node_type = {"IMG": "BASE_IMAGE", "IMAGE": "BASE_IMAGE", "VIDEO": "BASE_VIDEO", "AUDIO": "BASE_AUDIO"}.get(asset_type.upper(), "BASE_IMAGE")
            node_payload = _synthetic_node_payload(
                label=as_node,
                node_type=node_type,
                file_uuid=base_payload.get("fileUuid") or _require_file(ctx, None),
                prompt=None,
                model=None,
                params={},
                data={"pendingAssetFileName": source.name},
                prev_node_uuids=[],
                x=x,
                y=y,
            )
            plans.append(
                {
                    "endpoint": "/canvas/node/batch",
                    "payload": {
                        "fileUuid": base_payload.get("fileUuid") or _require_file(ctx, None),
                        "create": [node_payload],
                        "update": [],
                        "delete": [],
                    },
                }
            )
        _emit({"dryRun": True, "plans": plans}, "Asset upload dry run")
        return

    api = _client(ctx)
    content = source.read_bytes()
    try:
        precheck_result = api.assets_check(base_payload)
    except PixmaxAPIError as exc:
        if exc.response.get("errCode") != "Common.NotFound":
            raise
        precheck_result = {
            "success": False,
            "errCode": exc.response.get("errCode"),
            "errMessage": exc.response.get("errMessage"),
            "data": None,
        }
    asset = _asset_from_precheck_result(precheck_result)
    authorize_result = None
    upload_result: dict[str, Any] | None = {"skipped": True, "reason": "assets/check matched existing asset"} if asset else None
    check_result: dict[str, Any] = precheck_result
    if not asset:
        authorize_result = api.assets_oss_authorize(base_payload)
        plan = _upload_plan(authorize_result)
        if plan["method"] == "OSS_STS_PUT":
            sts = plan["ossSts"]
            upload_result = api.upload_oss_sts_put(
                bucket=sts["bucket"],
                endpoint=sts["endpoint"],
                object_key=sts["objectKey"],
                access_key_id=sts["accessKeyId"],
                access_key_secret=sts["accessKeySecret"],
                security_token=sts["securityToken"],
                content=content,
                content_type=content_type,
                callback_url=sts.get("callbackUrl"),
                callback_body=sts.get("callbackBody"),
                callback_body_type=sts.get("callbackBodyType"),
            )
        elif plan["method"] == "POST":
            upload_result = api.upload_post(
                plan["url"],
                plan["fields"],
                plan["fileField"],
                source.name,
                content,
                content_type,
            )
        else:
            headers = dict(plan["headers"])
            headers.setdefault("Content-Type", content_type)
            upload_result = api.upload_put(plan["url"], content, headers)

        check_payload = dict(base_payload)
        if plan.get("objectKey") and "key" not in check_payload:
            check_payload["key"] = plan["objectKey"]
        for key in (
            "assetsUuid",
            "assetUuid",
            "uuid",
            "sessionId",
            "bucket",
            "bucketName",
            "ossDomain",
            "endpoint",
            "relativePath",
            "webUrl",
        ):
            value = plan["authorization"].get(key)
            if value is not None and key not in check_payload:
                check_payload[key] = value
        check_result = api.assets_oss_check(check_payload)
        for _ in range(30):
            asset = _asset_from_check_result(check_result)
            if asset:
                break
            check_data = check_result.get("data") if isinstance(check_result.get("data"), dict) else {}
            status = check_data.get("status")
            if status in {"FAILED", "ERROR"}:
                break
            if status not in {"QUEUED", "RUNNING", "PROCESSING", "PENDING"}:
                break
            time.sleep(1)
            check_result = api.assets_oss_check(check_payload)
    node_result = None
    node_key = None
    asset_uuid = _asset_uuid(asset) if asset else None
    if as_node:
        asset_data = asset or (check_result.get("data") if isinstance(check_result.get("data"), dict) else check_payload)
        asset_uuid = (
            _asset_uuid(asset_data)
            or base_payload.get("assetsUuid")
            or base_payload.get("assetUuid")
        )
        if not asset_uuid:
            raise RuntimeError("Pixmax asset check completed without an asset UUID; cannot create --as-node.")
        node_type = {"IMG": "BASE_IMAGE", "IMAGE": "BASE_IMAGE", "VIDEO": "BASE_VIDEO", "AUDIO": "BASE_AUDIO"}.get(asset_type.upper(), "BASE_IMAGE")
        node_payload = _synthetic_node_payload(
            label=as_node,
            node_type=node_type,
            file_uuid=base_payload.get("fileUuid") or _require_file(ctx, None),
            prompt=None,
            model=None,
            params={},
            data={"assetUuid": asset_uuid, "label": as_node},
            prev_node_uuids=[],
            x=x,
            y=y,
        )
        node_key = node_payload["uuid"]
        node_payload["defaultAssetUuid"] = asset_uuid
        if asset:
            node_payload["defaultAsset"] = asset
        node_result = _batch_mutate_nodes(
            api,
            base_payload.get("fileUuid") or _require_file(ctx, None),
            create=[node_payload],
        )
    _emit(
        {
            "file": str(source),
            "bytes": len(content),
            "contentType": content_type,
            "precheck": precheck_result,
            "authorize": authorize_result,
            "upload": upload_result,
            "check": check_result,
            "assetUuid": asset_uuid,
            "nodeKey": node_key,
            "uuid": node_key,
            "node": node_result,
        },
        "Asset uploaded",
    )


@assets.command("check")
@click.option("--data", "data_json", default=None, help="JSON object payload.")
@click.option("--file", "payload_file", default=None, type=click.Path(exists=True), help="JSON payload file.")
@click.pass_context
@_handle_errors
def assets_check(ctx: click.Context, data_json: str | None, payload_file: str | None):
    """Call /assets/check for uploaded asset validation."""
    _emit(_client(ctx).assets_check(_load_payload(data_json, payload_file)), "Pixmax asset check")


@assets.command("oss-authorize")
@click.option("--data", "data_json", default=None, help="JSON object payload.")
@click.option("--file", "payload_file", default=None, type=click.Path(exists=True), help="JSON payload file.")
@click.pass_context
@_handle_errors
def assets_oss_authorize(ctx: click.Context, data_json: str | None, payload_file: str | None):
    """Call /assets/oss/authorize for upload credentials."""
    _emit(_client(ctx).assets_oss_authorize(_load_payload(data_json, payload_file)), "Pixmax OSS authorization")


@assets.command("oss-check")
@click.option("--data", "data_json", default=None, help="JSON object payload.")
@click.option("--file", "payload_file", default=None, type=click.Path(exists=True), help="JSON payload file.")
@click.pass_context
@_handle_errors
def assets_oss_check(ctx: click.Context, data_json: str | None, payload_file: str | None):
    """Call /assets/oss/check after an OSS upload."""
    _emit(_client(ctx).assets_oss_check(_load_payload(data_json, payload_file)), "Pixmax OSS check")


@assets.command("compliance-check")
@click.argument("asset_uuid")
@click.option("--data", "data_json", default=None, help="Extra JSON fields merged into payload.")
@click.option("--file", "payload_file", default=None, type=click.Path(exists=True), help="Extra JSON payload file.")
@click.option("--poll/--no-poll", default=True, show_default=True, help="Poll until a terminal compliance status.")
@click.option("--interval", default=2.0, show_default=True, type=float, help="Polling interval seconds.")
@click.option("--timeout", default=180.0, show_default=True, type=float, help="Polling timeout seconds.")
@click.option("--dry-run", is_flag=True, help="Print payload without submitting.")
@click.pass_context
@_handle_errors
def assets_compliance_check(
    ctx: click.Context,
    asset_uuid: str,
    data_json: str | None,
    payload_file: str | None,
    poll: bool,
    interval: float,
    timeout: float,
    dry_run: bool,
):
    """Submit and poll asset compliance for Seedance 2.0 reference media."""
    payload = _compliance_payload(asset_uuid, _load_payload(data_json, payload_file))
    if dry_run:
        _emit_dry_run("/assetLibrary/compliance/check", payload)
        return
    api = _client(ctx)
    if poll:
        _emit(_poll_compliance(api, payload, interval=interval, timeout=timeout), "Pixmax asset compliance")
        return
    result = api.asset_library_compliance_check(payload)
    _emit({"status": _compliance_status(result), "result": result}, "Pixmax asset compliance")


@cli.group()
def tasks():
    """Generation and task commands."""


@tasks.command("list")
@click.option("--page", "page_index", default=1, show_default=True, type=int)
@click.option("--page-size", default=20, show_default=True, type=int)
@click.option("--task-type", default=None, help="Optional Pixmax task type.")
@click.pass_context
@_handle_errors
def tasks_list(ctx: click.Context, page_index: int, page_size: int, task_type: str | None):
    """List Pixmax tasks."""
    payload: dict[str, Any] = {"pageIndex": page_index, "pageSize": page_size, "needTotalCount": True}
    if task_type:
        payload["taskType"] = task_type
    _emit(_client(ctx).task_list(payload), "Pixmax tasks")


@tasks.command("progress")
@click.argument("node_uuids", nargs=-1, required=True)
@click.pass_context
@_handle_errors
def tasks_progress(ctx: click.Context, node_uuids: tuple[str, ...]):
    """Poll generation progress for one or more node UUIDs."""
    _emit(_client(ctx).generate_progress(list(node_uuids)), "Pixmax generation progress")


@tasks.command("wait")
@click.argument("node_uuids", nargs=-1, required=True)
@click.option("--interval", default=5.0, show_default=True, type=float, help="Generation polling interval seconds.")
@click.option("--timeout", default=1800.0, show_default=True, type=float, help="Generation polling timeout seconds.")
@click.option("--allow-failed", is_flag=True, help="Return JSON instead of non-zero exit when generation fails or times out.")
@click.pass_context
@_handle_errors
def tasks_wait(ctx: click.Context, node_uuids: tuple[str, ...], interval: float, timeout: float, allow_failed: bool):
    """Wait until generation reaches a terminal state for one or more node UUIDs."""
    result = _wait_generation(_client(ctx), list(node_uuids), interval=interval, timeout=timeout)
    _emit(result, "Pixmax generation wait")
    _exit_on_failed_wait(result, allow_failed=allow_failed)


@tasks.command("detail")
@click.option("--data", "data_json", default=None, help="JSON object payload.")
@click.option("--file", "payload_file", default=None, type=click.Path(exists=True), help="JSON payload file.")
@click.pass_context
@_handle_errors
def tasks_detail(ctx: click.Context, data_json: str | None, payload_file: str | None):
    """Call /generate/detail with a raw payload."""
    _emit(_client(ctx).generate_detail(_load_payload(data_json, payload_file)), "Pixmax generation detail")


@tasks.command("history")
@click.option("--page", "page_index", default=1, show_default=True, type=int)
@click.option("--page-size", default=20, show_default=True, type=int)
@click.option("--data", "data_json", default=None, help="Extra JSON fields merged into payload.")
@click.option("--file", "payload_file", default=None, type=click.Path(exists=True), help="Extra JSON payload file.")
@click.pass_context
@_handle_errors
def tasks_history(ctx: click.Context, page_index: int, page_size: int, data_json: str | None, payload_file: str | None):
    """Call /generate/lists for generation history."""
    payload = _load_payload(data_json, payload_file)
    payload.update({"pageIndex": page_index, "pageSize": page_size})
    _emit(_client(ctx).generate_lists(payload), "Pixmax generation history")


@tasks.command("cancel")
@click.option("--data", "data_json", default=None, help="JSON object payload.")
@click.option("--file", "payload_file", default=None, type=click.Path(exists=True), help="JSON payload file.")
@click.option("--yes", is_flag=True, help="Confirm cancellation.")
@click.option("--dry-run", is_flag=True, help="Print payload without cancelling.")
@click.pass_context
@_handle_errors
def tasks_cancel(ctx: click.Context, data_json: str | None, payload_file: str | None, yes: bool, dry_run: bool):
    """Cancel a generation task with a raw /generate/cancel payload."""
    payload = _load_payload(data_json, payload_file)
    if dry_run:
        _emit_dry_run("/generate/cancel", payload)
        return
    if not yes:
        raise RuntimeError("Refusing to cancel without --yes.")
    _emit(_client(ctx).generate_cancel(payload), "Pixmax generation cancelled")


@tasks.command("submit-batch")
@click.option("--data", "data_json", default=None, help="JSON object payload.")
@click.option("--file", "payload_file", default=None, type=click.Path(exists=True), help="JSON payload file.")
@click.option("--wait", "wait_after_submit", is_flag=True, help="Wait for submitted node UUIDs to finish.")
@click.option("--interval", default=5.0, show_default=True, type=float, help="Generation polling interval seconds.")
@click.option("--timeout", default=1800.0, show_default=True, type=float, help="Generation polling timeout seconds.")
@click.option("--allow-failed", is_flag=True, help="Return JSON instead of non-zero exit when waited generation fails.")
@click.option("--dry-run", is_flag=True, help="Validate payload locally without submitting.")
@click.pass_context
@_handle_errors
def tasks_submit_batch(
    ctx: click.Context,
    data_json: str | None,
    payload_file: str | None,
    wait_after_submit: bool,
    interval: float,
    timeout: float,
    allow_failed: bool,
    dry_run: bool,
):
    """Submit a raw /generate/batch payload."""
    payload = _load_payload(data_json, payload_file)
    if dry_run:
        _emit({"dryRun": True, "endpoint": "/generate/batch", "payload": payload}, "Generate batch dry run")
        return
    api = _client(ctx)
    submit_result = api.generate_batch(payload)
    node_uuids = [item for item in payload.get("nodeUuids") or payload.get("nodes") or [] if isinstance(item, str)]
    wait_result = None
    if wait_after_submit:
        if not node_uuids:
            raise RuntimeError("Cannot --wait without nodeUuids or nodes in the submit payload.")
        wait_result = _wait_generation(api, node_uuids, interval=interval, timeout=timeout)
    output = {"submit": submit_result}
    if wait_result:
        output["wait"] = wait_result
    _emit(output, "Generate batch submitted")
    if wait_result:
        _exit_on_failed_wait(wait_result, allow_failed=allow_failed)


@tasks.command("quick-list")
@click.option("--page", "page_index", default=1, show_default=True, type=int)
@click.option("--page-size", default=20, show_default=True, type=int)
@click.option("--data", "data_json", default=None, help="Extra JSON fields merged into payload.")
@click.option("--file", "payload_file", default=None, type=click.Path(exists=True), help="Extra JSON payload file.")
@click.pass_context
@_handle_errors
def tasks_quick_list(ctx: click.Context, page_index: int, page_size: int, data_json: str | None, payload_file: str | None):
    """List Pixmax quick tasks."""
    payload = _load_payload(data_json, payload_file)
    payload.update({"pageIndex": page_index, "pageSize": page_size, "needTotalCount": True})
    _emit(_client(ctx).quick_task_list(payload), "Pixmax quick tasks")


@tasks.command("quick-submit")
@click.option("--data", "data_json", default=None, help="JSON object payload.")
@click.option("--file", "payload_file", default=None, type=click.Path(exists=True), help="JSON payload file.")
@click.option("--dry-run", is_flag=True, help="Print payload without submitting.")
@click.pass_context
@_handle_errors
def tasks_quick_submit(ctx: click.Context, data_json: str | None, payload_file: str | None, dry_run: bool):
    """Submit a raw /quickTask/submit payload."""
    payload = _load_payload(data_json, payload_file)
    if dry_run:
        _emit_dry_run("/quickTask/submit", payload)
        return
    _emit(_client(ctx).quick_task_submit(payload), "Pixmax quick task submitted")


@tasks.command("template-submit")
@click.option("--data", "data_json", default=None, help="JSON object payload.")
@click.option("--file", "payload_file", default=None, type=click.Path(exists=True), help="JSON payload file.")
@click.option("--dry-run", is_flag=True, help="Print payload without submitting.")
@click.pass_context
@_handle_errors
def tasks_template_submit(ctx: click.Context, data_json: str | None, payload_file: str | None, dry_run: bool):
    """Submit a raw /task/submit/templateTask payload."""
    payload = _load_payload(data_json, payload_file)
    if dry_run:
        _emit_dry_run("/task/submit/templateTask", payload)
        return
    _emit(_client(ctx).template_task_submit(payload), "Pixmax template task submitted")


@cli.group()
def templates():
    """Canvas template and storyboard configuration commands."""


@templates.command("list")
@click.option("--data", "data_json", default=None, help="JSON object payload.")
@click.option("--file", "payload_file", default=None, type=click.Path(exists=True), help="JSON payload file.")
@click.pass_context
@_handle_errors
def templates_list(ctx: click.Context, data_json: str | None, payload_file: str | None):
    """List Pixmax canvas templates."""
    _emit(_client(ctx).canvas_template_list(_load_payload(data_json, payload_file)), "Pixmax templates")


@templates.command("get")
@click.option("--data", "data_json", default=None, help="JSON object payload.")
@click.option("--file", "payload_file", default=None, type=click.Path(exists=True), help="JSON payload file.")
@click.pass_context
@_handle_errors
def templates_get(ctx: click.Context, data_json: str | None, payload_file: str | None):
    """Fetch a Pixmax canvas template."""
    _emit(_client(ctx).canvas_template_get(_load_payload(data_json, payload_file)), "Pixmax template")


@templates.command("categories")
@click.pass_context
@_handle_errors
def templates_categories(ctx: click.Context):
    """Fetch Pixmax template category tree."""
    _emit(_client(ctx).canvas_template_category_tree(), "Pixmax template categories")


@templates.command("storyboard-config")
@click.pass_context
@_handle_errors
def templates_storyboard_config(ctx: click.Context):
    """Fetch Pixmax storyboard configuration."""
    _emit(_client(ctx).storyboard_config(), "Pixmax storyboard config")


@cli.command("raw")
@click.argument("method", type=click.Choice(["GET", "POST", "PUT", "PATCH", "DELETE"], case_sensitive=False))
@click.argument("endpoint")
@click.option("--data", "data_json", default=None, help="JSON object payload.")
@click.option("--file", "payload_file", default=None, type=click.Path(exists=True), help="JSON payload file.")
@click.pass_context
@_handle_errors
def raw(ctx: click.Context, method: str, endpoint: str, data_json: str | None, payload_file: str | None):
    """Call a Pixmax /user/api endpoint not covered by a dedicated command."""
    payload = _load_payload(data_json, payload_file)
    _emit(_client(ctx).request(method, endpoint, payload), f"Pixmax raw {method.upper()} {endpoint}")


@cli.command()
@click.pass_context
def repl(ctx: click.Context):
    """Start an interactive Pixmax command shell."""
    global _repl_mode
    _repl_mode = True
    skin = ReplSkin("pixmax", version=__version__)
    skin.print_banner()
    pt_session = skin.create_prompt_session()
    commands = {
        "auth whoami": "show authenticated account",
        "project use <uuid> --file <uuid>": "store workspace defaults",
        "project files --json": "list files in the current project",
        "canvas summary --json": "summarize the current canvas",
        "tasks list --json": "list recent Pixmax tasks",
        "raw POST /endpoint --data '{}'": "call an uncovered endpoint",
    }
    session_obj = _session(ctx)
    while True:
        try:
            line = skin.get_input(pt_session, project_name=session_obj.project_name)
        except (EOFError, KeyboardInterrupt):
            click.echo()
            break
        line = line.strip()
        if not line:
            continue
        if line in {"exit", "quit", ":q"}:
            break
        if line in {"help", "?"}:
            skin.help(commands)
            continue
        try:
            args = shlex.split(line)
        except ValueError as exc:
            skin.error(str(exc))
            continue
        try:
            cli.main(args=args, obj=ctx.obj, standalone_mode=False)
            session_obj.add_history(line, {"ok": True})
        except SystemExit:
            pass
        except Exception as exc:
            skin.error(str(exc))
            session_obj.add_history(line, {"ok": False, "error": str(exc)})
    skin.print_goodbye()


def _force_utf8_output() -> None:
    """Keep Chinese output readable on legacy Windows consoles (GBK code page)."""
    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure is not None:
            try:
                reconfigure(encoding="utf-8", errors="replace")
            except (OSError, ValueError):
                pass


def main(argv: list[str] | None = None) -> None:
    _force_utf8_output()
    # Click's Windows argument expansion collapses literal %% mention delimiters.
    cli.main(args=argv, prog_name="pixmax", windows_expand_args=False)


if __name__ == "__main__":
    main(sys.argv[1:])
