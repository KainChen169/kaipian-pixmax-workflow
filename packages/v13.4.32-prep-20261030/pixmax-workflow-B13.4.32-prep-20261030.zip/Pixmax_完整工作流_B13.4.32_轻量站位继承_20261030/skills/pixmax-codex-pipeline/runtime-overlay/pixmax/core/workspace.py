"""Helpers for summarizing Pixmax project and canvas payloads."""

from __future__ import annotations

import json
from typing import Any

from pixmax.utils.pixmax_backend import absolutize_asset_url


def flatten_file_tree(items: list[dict[str, Any]], parent: str | None = None) -> list[dict[str, Any]]:
    flat: list[dict[str, Any]] = []
    for item in items or []:
        row = {
            "uuid": item.get("uuid"),
            "name": item.get("name"),
            "type": item.get("type"),
            "parentUuid": item.get("parentUuid") or parent,
            "sortOrder": item.get("sortOrder"),
            "updateTime": item.get("updateTime"),
        }
        flat.append(row)
        flat.extend(flatten_file_tree(item.get("children") or [], item.get("uuid")))
    return flat


def parse_node_metadata(node: dict[str, Any]) -> dict[str, Any]:
    raw = node.get("metaData")
    if isinstance(raw, dict):
        return raw
    if not isinstance(raw, str) or not raw.strip():
        return {}
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return {"raw": raw}


def summarize_asset(asset: dict[str, Any] | None, *, base_url: str | None = None) -> dict[str, Any] | None:
    if not asset:
        return None
    meta = asset.get("metaData") or {}
    return {
        "assetsUuid": asset.get("assetsUuid"),
        "fileType": asset.get("fileType"),
        "extension": meta.get("fileExtension") if isinstance(meta, dict) else None,
        "width": asset.get("width") or (meta.get("width") if isinstance(meta, dict) else None),
        "height": asset.get("height") or (meta.get("height") if isinstance(meta, dict) else None),
        "duration": meta.get("duration") if isinstance(meta, dict) else None,
        "fileSize": (
            asset.get("fileSize")
            or asset.get("size")
            or asset.get("bytes")
            or (meta.get("fileSize") if isinstance(meta, dict) else None)
            or (meta.get("size") if isinstance(meta, dict) else None)
            or (meta.get("bytes") if isinstance(meta, dict) else None)
        ),
        "url": absolutize_asset_url(asset, "webUrl", base_url=base_url),
        "previewUrl": absolutize_asset_url(asset, "previewWebUrl", base_url=base_url),
        "thumbnailUrl": absolutize_asset_url(asset, "thumbnailWebUrl", base_url=base_url),
    }


def summarize_nodes(canvas_data: dict[str, Any], *, base_url: str | None = None) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for node in canvas_data.get("nodes") or []:
        metadata = parse_node_metadata(node)
        data = metadata.get("data") if isinstance(metadata.get("data"), dict) else {}
        position = metadata.get("position") if isinstance(metadata.get("position"), dict) else {}
        params = node.get("params") if isinstance(node.get("params"), dict) else {}
        task = node.get("generationTask") if isinstance(node.get("generationTask"), dict) else {}
        raw_node_assets = node.get("nodeAssets") or task.get("resultAssets") or []
        node_assets = [
            summarized
            for summarized in (
                summarize_asset(asset, base_url=base_url)
                for asset in raw_node_assets
                if isinstance(asset, dict)
            )
            if summarized
        ]
        rows.append(
            {
                "uuid": node.get("uuid"),
                "type": node.get("type"),
                "label": data.get("label"),
                "isGenerateNode": node.get("isGenerateNode"),
                "position": position or None,
                "model": params.get("model") or task.get("modelCode"),
                "status": (task.get("status") or data.get("status")),
                "progress": task.get("progress") or data.get("progress"),
                "prompt": params.get("prompt"),
                "params": params,
                "nodeText": node.get("nodeText") or task.get("resultText"),
                "data": data,
                "metadata": metadata,
                "defaultAsset": summarize_asset(node.get("defaultAsset"), base_url=base_url),
                "nodeAssets": node_assets,
                "assetCount": len(raw_node_assets),
                "prevNodeUuids": node.get("prevNodeUuids") or [],
                "taskUuid": task.get("taskUuid"),
            }
        )
    return rows


def canvas_summary(canvas_response: dict[str, Any], *, base_url: str | None = None) -> dict[str, Any]:
    data = canvas_response.get("data") or {}
    nodes = summarize_nodes(data, base_url=base_url)
    by_type: dict[str, int] = {}
    for node in nodes:
        node_type = str(node.get("type") or "UNKNOWN")
        by_type[node_type] = by_type.get(node_type, 0) + 1
    return {
        "uuid": data.get("uuid"),
        "fileUuid": data.get("fileUuid"),
        "revision": data.get("revision"),
        "nodeCount": len(nodes),
        "nodeTypes": by_type,
        "nodes": nodes,
    }
