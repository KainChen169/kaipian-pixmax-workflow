"""Pixmax web API client used by the CLI harness."""

from __future__ import annotations

import json
import os
import warnings
import mimetypes
import base64
import email.utils
import hashlib
import hmac
from pathlib import Path
from typing import Any
from urllib.parse import quote, urljoin, urlparse

warnings.filterwarnings(
    "ignore",
    message=r"urllib3 v2 only supports OpenSSL 1\.1\.1\+",
    category=Warning,
)
import requests

DEFAULT_BASE_URL = "https://app.pixmax.cn/user/api"
DEFAULT_APP_URL = "https://app.pixmax.cn"
ENV_TOKEN = "PIXMAX_BEARER_TOKEN"
ENV_BASE_URL = "PIXMAX_API_BASE_URL"
DEFAULT_DEVICE_CLIENT_CODE = "Pixmax CLI"
DEVICE_AUTH_PAGE_PATH = "/bridge/passport/cli/"


class PixmaxAPIError(RuntimeError):
    """Raised when Pixmax returns an unsuccessful API payload."""

    def __init__(self, message: str, response: dict[str, Any] | None = None):
        super().__init__(message)
        self.response = response or {}


def get_token(explicit: str | None = None) -> str:
    token = (explicit or os.environ.get(ENV_TOKEN) or "").strip()
    if token.lower().startswith("bearer "):
        token = token[7:].strip()
    if not token:
        raise RuntimeError(
            f"Missing Pixmax bearer token. Set {ENV_TOKEN} or pass --token."
        )
    return token


def resolve_base_url(base_url: str | None = None) -> str:
    return (base_url or os.environ.get(ENV_BASE_URL) or DEFAULT_BASE_URL).rstrip("/")


def app_origin(base_url: str | None = None) -> str:
    """Derive the Pixmax web app origin from an API base URL."""
    base = resolve_base_url(base_url)
    if base.endswith("/user/api"):
        base = base[: -len("/user/api")]
    parsed = urlparse(base)
    if parsed.scheme and parsed.netloc:
        return f"{parsed.scheme}://{parsed.netloc}"
    return DEFAULT_APP_URL


def _anonymous_post(
    endpoint: str,
    payload: dict[str, Any] | None = None,
    *,
    base_url: str | None = None,
    timeout: int = 30,
    locale: str | None = None,
) -> dict[str, Any]:
    """POST to a Pixmax endpoint that does not require authentication."""
    url = f"{resolve_base_url(base_url)}/{endpoint.lstrip('/')}"
    try:
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": "pixmax-cli/1.2",
        }
        if locale:
            headers["Accept-Language"] = locale
        response = requests.post(
            url,
            json=payload or {},
            headers=headers,
            timeout=timeout,
        )
    except requests.RequestException as exc:
        raise PixmaxAPIError(f"Request failed: {exc}") from exc
    try:
        data = response.json()
    except ValueError as exc:
        raise PixmaxAPIError(
            f"Non-JSON response from Pixmax ({response.status_code})"
        ) from exc
    if response.status_code >= 400:
        message = data.get("errMessage") or data.get("message") or response.text
        raise PixmaxAPIError(f"HTTP {response.status_code}: {message}", data)
    return data


def device_auth_create_code(
    client_code: str,
    *,
    base_url: str | None = None,
    timeout: int = 30,
    locale: str | None = None,
) -> dict[str, Any]:
    """Request a short-lived device authorization code (POST /auth/code)."""
    data = _anonymous_post(
        "/auth/code", {"clientCode": client_code}, base_url=base_url, timeout=timeout, locale=locale
    )
    if data.get("success") is False:
        message = data.get("errMessage") or data.get("errCode") or "Device code request failed"
        raise PixmaxAPIError(str(message), data)
    return data


def device_auth_get_token(
    code: str,
    *,
    base_url: str | None = None,
    timeout: int = 30,
    locale: str | None = None,
) -> dict[str, Any]:
    """Poll the device authorization token endpoint (POST /auth/getToken)."""
    return _anonymous_post(
        "/auth/getToken", {"code": code}, base_url=base_url, timeout=timeout, locale=locale
    )


def device_auth_page_url(code: str, *, base_url: str | None = None) -> str:
    """Build the browser authorization page URL for a device code."""
    return f"{app_origin(base_url)}{DEVICE_AUTH_PAGE_PATH}?code={quote(code, safe='')}"


def read_json_file(path: str | Path) -> Any:
    with open(path, "r", encoding="utf-8") as fh:
        return json.load(fh)


def write_bytes(path: str | Path, content: bytes) -> dict[str, Any]:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(content)
    return {"output": str(target), "bytes": target.stat().st_size}


def guess_content_type(path: str | Path) -> str:
    return mimetypes.guess_type(str(path))[0] or "application/octet-stream"


def absolutize_asset_url(
    asset: dict[str, Any],
    key: str = "webUrl",
    *,
    base_url: str | None = None,
) -> str | None:
    value = asset.get(key)
    if not isinstance(value, str) or not value:
        return None
    if value.startswith("http://") or value.startswith("https://"):
        return value
    domain = asset.get("ossDomain")
    if isinstance(domain, str) and domain:
        return urljoin(domain.rstrip("/") + "/", value.lstrip("/"))
    return urljoin(app_origin(base_url), value)


class PixmaxClient:
    """Small typed wrapper around Pixmax's browser-facing REST API."""

    def __init__(
        self,
        token: str | None = None,
        base_url: str | None = None,
        timeout: int = 90,
        session: requests.Session | None = None,
        locale: str | None = None,
    ):
        self.token = get_token(token)
        self.base_url = (base_url or os.environ.get(ENV_BASE_URL) or DEFAULT_BASE_URL).rstrip("/")
        self.timeout = timeout
        self.session = session or requests.Session()
        self.locale = locale

    @property
    def headers(self) -> dict[str, str]:
        origin = app_origin(self.base_url)
        headers = {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Origin": origin,
            "Referer": origin + "/",
            "User-Agent": "pixmax-cli/1.2",
        }
        if self.locale:
            headers["Accept-Language"] = self.locale
        return headers

    def url(self, endpoint: str) -> str:
        if endpoint.startswith("http://") or endpoint.startswith("https://"):
            return endpoint
        return f"{self.base_url}/{endpoint.lstrip('/')}"

    def request(
        self,
        method: str,
        endpoint: str,
        payload: dict[str, Any] | None = None,
        *,
        params: dict[str, Any] | None = None,
        raise_for_api_error: bool = True,
    ) -> dict[str, Any]:
        try:
            response = self.session.request(
                method.upper(),
                self.url(endpoint),
                headers=self.headers,
                params=params,
                json=payload if payload is not None else ({} if method.upper() != "GET" else None),
                timeout=self.timeout,
            )
        except requests.RequestException as exc:
            raise PixmaxAPIError(f"Request failed: {exc}") from exc
        try:
            data = response.json()
        except ValueError as exc:
            raise PixmaxAPIError(
                f"Non-JSON response from Pixmax ({response.status_code})"
            ) from exc
        if response.status_code >= 400:
            message = data.get("errMessage") or data.get("message") or response.text
            raise PixmaxAPIError(f"HTTP {response.status_code}: {message}", data)
        if raise_for_api_error and data.get("success") is False:
            message = data.get("errMessage") or data.get("errCode") or "Pixmax API error"
            raise PixmaxAPIError(str(message), data)
        return data

    def download(self, url: str) -> bytes:
        try:
            response = self.session.get(url, timeout=self.timeout)
            response.raise_for_status()
            return response.content
        except requests.RequestException as exc:
            raise PixmaxAPIError(f"Download failed: {exc}") from exc

    def upload_put(self, url: str, content: bytes, headers: dict[str, str] | None = None) -> dict[str, Any]:
        try:
            response = self.session.put(url, data=content, headers=headers or {}, timeout=self.timeout)
            response.raise_for_status()
            return {"statusCode": response.status_code, "bytes": len(content)}
        except requests.RequestException as exc:
            raise PixmaxAPIError(f"Upload failed: {exc}") from exc

    def upload_oss_sts_put(
        self,
        *,
        bucket: str,
        endpoint: str,
        object_key: str,
        access_key_id: str,
        access_key_secret: str,
        security_token: str,
        content: bytes,
        content_type: str,
        callback_url: str | None = None,
        callback_body: str | None = None,
        callback_body_type: str | None = None,
    ) -> dict[str, Any]:
        parsed_endpoint = urlparse(endpoint if "://" in endpoint else f"https://{endpoint}")
        host = parsed_endpoint.netloc or parsed_endpoint.path
        path = quote(object_key, safe="/~")
        url = f"https://{bucket}.{host}/{path}"
        date = email.utils.formatdate(usegmt=True)
        headers = {
            "Content-Type": content_type,
            "Date": date,
            "x-oss-security-token": security_token,
        }
        if callback_url and callback_body:
            callback = {
                "callbackUrl": callback_url,
                "callbackBody": callback_body,
            }
            if callback_body_type:
                callback["callbackBodyType"] = callback_body_type
            headers["x-oss-callback"] = base64.b64encode(
                json.dumps(callback, separators=(",", ":")).encode("utf-8")
            ).decode("ascii")

        canonical_headers = "".join(
            f"{key.lower()}:{headers[key]}\n"
            for key in sorted(headers)
            if key.lower().startswith("x-oss-")
        )
        canonical_resource = f"/{bucket}/{object_key}"
        string_to_sign = "\n".join(
            [
                "PUT",
                "",
                content_type,
                date,
                f"{canonical_headers}{canonical_resource}",
            ]
        )
        signature = base64.b64encode(
            hmac.new(access_key_secret.encode("utf-8"), string_to_sign.encode("utf-8"), hashlib.sha1).digest()
        ).decode("ascii")
        headers["Authorization"] = f"OSS {access_key_id}:{signature}"
        try:
            response = self.session.put(url, data=content, headers=headers, timeout=self.timeout)
            response.raise_for_status()
        except requests.RequestException as exc:
            raise PixmaxAPIError(f"OSS STS upload failed: {exc}") from exc

        result: dict[str, Any] = {"statusCode": response.status_code, "bytes": len(content), "url": url, "objectKey": object_key}
        if response.content:
            try:
                result["response"] = response.json()
            except ValueError:
                result["responseText"] = response.text
        return result

    def upload_post(
        self,
        url: str,
        fields: dict[str, Any],
        file_field: str,
        filename: str,
        content: bytes,
        content_type: str,
    ) -> dict[str, Any]:
        try:
            files = {file_field: (filename, content, content_type)}
            response = self.session.post(url, data=fields, files=files, timeout=self.timeout)
            response.raise_for_status()
            return {"statusCode": response.status_code, "bytes": len(content)}
        except requests.RequestException as exc:
            raise PixmaxAPIError(f"Upload failed: {exc}") from exc

    def get(self, endpoint: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
        return self.request("GET", endpoint, params=params)

    def post(self, endpoint: str, payload: dict[str, Any] | None = None) -> dict[str, Any]:
        return self.request("POST", endpoint, payload)

    def user_info(self) -> dict[str, Any]:
        return self.post("/user/info")

    def credit_balance(self) -> dict[str, Any]:
        return self.get("/credit/balance")

    def project_get(self, project_uuid: str) -> dict[str, Any]:
        return self.post("/project/get", {"uuid": project_uuid})

    def project_create_or_update(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self.post("/project/createOrUpdate", payload)

    def project_delete(self, project_uuid: str) -> dict[str, Any]:
        return self.post("/project/delete", {"uuid": project_uuid})

    def project_list(self, payload: dict[str, Any] | None = None) -> dict[str, Any]:
        body = {"pageIndex": 1, "pageSize": 20, "orderColumn": "UPDATE_TIME", "orderType": "DESC"}
        if payload:
            body.update(payload)
        return self.post("/project/list", body)

    def file_tree(self, project_uuid: str) -> dict[str, Any]:
        return self.post("/project/file/tree", {"projectUuid": project_uuid})

    def project_file_create(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self.post("/project/file/create", payload)

    def project_file_rename(self, file_uuid: str, name: str) -> dict[str, Any]:
        return self.post("/project/file/rename", {"uuid": file_uuid, "name": name})

    def project_file_move(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self.post("/project/file/move", payload)

    def project_file_delete(self, file_uuid: str) -> dict[str, Any]:
        return self.post("/project/file/delete", {"uuid": file_uuid})

    def canvas_get(self, file_uuid: str) -> dict[str, Any]:
        return self.post("/canvas/get", {"fileUuid": file_uuid})

    def canvas_model_config(self) -> dict[str, Any]:
        return self.post("/canvas/modelConfig")

    def canvas_model_config_check(self) -> dict[str, Any]:
        return self.post("/canvas/modelConfigCheck")

    def canvas_node_create(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self.post("/canvas/node/create", payload)

    def canvas_node_update(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self.post("/canvas/node/update", payload)

    def canvas_node_delete(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self.post("/canvas/node/delete", payload)

    def canvas_node_restore(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self.post("/canvas/node/restore", payload)

    def canvas_node_batch(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self.post("/canvas/node/batch", payload)

    def assets_list(self) -> dict[str, Any]:
        return self.post("/assets/list")

    def assets_check(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self.post("/assets/check", payload)

    def assets_oss_authorize(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self.post("/assets/oss/authorize", payload)

    def assets_oss_check(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self.post("/assets/oss/check", payload)

    def asset_library_compliance_check(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self.post("/assetLibrary/compliance/check", payload)

    def get_assets_link(self, asset_uuids: list[str]) -> dict[str, Any]:
        return self.post("/assets/getAssetsLink", {"assetUuids": asset_uuids})

    def task_list(self, payload: dict[str, Any] | None = None) -> dict[str, Any]:
        body = {"pageIndex": 1, "pageSize": 20, "needTotalCount": True}
        if payload:
            body.update(payload)
        return self.post("/task/list", body)

    def generate_progress(self, node_uuids: list[str]) -> dict[str, Any]:
        return self.post("/generate/progress", {"nodeUuids": node_uuids})

    def generate_detail(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self.post("/generate/detail", payload)

    def generate_lists(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self.post("/generate/lists", payload)

    def generate_batch(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self.post("/generate/batch", payload)

    def generate_cancel(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self.post("/generate/cancel", payload)

    def quick_task_list(self, payload: dict[str, Any] | None = None) -> dict[str, Any]:
        body = {"pageIndex": 1, "pageSize": 20, "needTotalCount": True}
        if payload:
            body.update(payload)
        return self.post("/quickTask/list", body)

    def quick_task_submit(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self.post("/quickTask/submit", payload)

    def template_task_submit(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self.post("/task/submit/templateTask", payload)

    def canvas_template_list(self, payload: dict[str, Any] | None = None) -> dict[str, Any]:
        return self.post("/canvas/template/list", payload or {})

    def canvas_template_get(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self.post("/canvas/template/get", payload)

    def canvas_template_category_tree(self) -> dict[str, Any]:
        return self.post("/canvas/template/category/tree")

    def storyboard_config(self) -> dict[str, Any]:
        return self.post("/storyboard/config")
