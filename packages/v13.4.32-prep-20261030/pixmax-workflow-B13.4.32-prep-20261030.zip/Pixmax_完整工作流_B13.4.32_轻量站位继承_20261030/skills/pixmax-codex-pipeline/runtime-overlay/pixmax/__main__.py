"""Module entry point for pixmax."""

from .pixmax_cli import main
from .prompt_file import expand_prompt_file
import sys


if __name__ == "__main__":
    main(expand_prompt_file(sys.argv[1:]))
