"""Pixmax CLI utilities: API client, REPL skin, and skill packaging."""
