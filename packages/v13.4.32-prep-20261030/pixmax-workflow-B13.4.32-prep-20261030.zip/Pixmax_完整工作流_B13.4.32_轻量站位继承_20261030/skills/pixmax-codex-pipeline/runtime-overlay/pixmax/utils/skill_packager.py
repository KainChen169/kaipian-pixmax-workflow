"""Build the distributable Pixmax CLI skill package (cross-platform, no bash required)."""

from __future__ import annotations

import shutil
import stat
import sys
from pathlib import Path
from typing import Any
from zipfile import ZIP_DEFLATED, ZipFile

SKILL_DIR_NAME = "pixmax-cli-skill"

# (repo-relative source, package-relative destination)
COPY_FILES = [
    ("README.md", "OVERVIEW.md"),
    ("pixmax/skills/SKILL.md", "SKILL.md"),
    ("pixmax/skills/references/generation-node-protocol-v1.md", "references/generation-node-protocol-v1.md"),
    ("pixmax/README.md", "README.md"),
    ("PIXMAX.md", "PIXMAX.md"),
    ("setup.py", "setup.py"),
    ("scripts/install.sh", "scripts/install.sh"),
    ("scripts/install.ps1", "scripts/install.ps1"),
]

EXCLUDED_NAMES = {
    "__pycache__",
    ".DS_Store",
    "tests",
    ".pytest_cache",
    "CLI-HOT-UPDATE-DESIGN.md",
    "ASSET-MENTION-CHANGE-PLAN.md",
}

INSTALL_MD = """# Pixmax CLI 安装说明

## 快速安装

进入这个包目录后执行：

- macOS / Linux：

```bash
bash scripts/install.sh
```

- Windows（PowerShell）：

```powershell
powershell -ExecutionPolicy Bypass -File scripts/install.ps1
```

安装脚本会检查 Python 环境（需要 3.10+）、安装稳定启动器和自包含 Runtime，并自动运行安装自检。源码 development 安装若缺少 `click`/`requests`，会把依赖下载到临时目录后封装进 Runtime，不污染用户环境。生产安装后每次执行 `pixmax` 都会先校验静态更新源；更新失败时业务命令不会执行。

本地包默认初始化中国大陆环境；海外环境安装时使用：

```bash
bash scripts/install.sh --environment global
```

PowerShell 使用 `scripts\\install.ps1 -Environment global`。安装不会覆盖已有环境选择。可用 `pixmax config show` 查看环境和 locale，用 `pixmax config set --environment cn|global` 或 `pixmax config set --locale zh-CN|en` 修改。

## 登录

安装完成后登录 Pixmax（会打开浏览器完成授权）：

```bash
pixmax auth login web
```

验证登录状态：

```bash
pixmax --json doctor --online
```

也可以不走网页登录，直接使用当前 shell 的 `PIXMAX_BEARER_TOKEN` 环境变量
（PowerShell 语法：`$env:PIXMAX_BEARER_TOKEN = "<token>"`）。
不要把 Pixmax token 写入源码、文档、脚本或提交记录。

## 包内文档

- `OVERVIEW.md`：面向用户和智能体的中文总览。
- `README.md`：详细命令说明。
- `PIXMAX.md`：工程封装说明。
- `SKILL.md`：智能体 Skill 使用说明。
"""


def _ignore_names(_dir: str, names: list[str]) -> set[str]:
    return {name for name in names if name in EXCLUDED_NAMES or name.endswith(".pyc")}


def build_skill_package(repo_root: str | Path, out_dir: str | Path) -> dict[str, Any]:
    """Assemble the skill directory and zip under ``out_dir``."""
    repo_root = Path(repo_root).resolve()
    out_dir = Path(out_dir).resolve()
    skill_root = out_dir / SKILL_DIR_NAME
    zip_path = out_dir / f"{SKILL_DIR_NAME}.zip"
    installers_root = out_dir / "installers"

    if skill_root.exists():
        shutil.rmtree(skill_root)
    if installers_root.exists():
        shutil.rmtree(installers_root)
    (skill_root / "scripts").mkdir(parents=True, exist_ok=True)

    for source_rel, dest_rel in COPY_FILES:
        source = repo_root / source_rel
        if not source.is_file():
            raise FileNotFoundError(f"Missing skill package input: {source_rel}")
        destination = skill_root / dest_rel
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)

    shutil.copytree(repo_root / "pixmax", skill_root / "pixmax", ignore=_ignore_names)

    for script in (skill_root / "scripts").glob("*.sh"):
        script.chmod(script.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)

    (skill_root / "INSTALL.md").write_text(INSTALL_MD, encoding="utf-8")

    if zip_path.exists():
        zip_path.unlink()
    with ZipFile(zip_path, "w", ZIP_DEFLATED) as archive:
        for path in sorted(skill_root.rglob("*")):
            if path.is_file():
                archive.write(path, path.relative_to(out_dir).as_posix())

    # Hosted entrypoints differ only in their initial environment. Both download
    # the same zip generated above, so the installed CLI artifact stays identical.
    shell_source = (repo_root / "scripts" / "install.sh").read_text(encoding="utf-8")
    powershell_source = (repo_root / "scripts" / "install.ps1").read_text(encoding="utf-8-sig")
    for environment in ("cn", "global"):
        target = installers_root / environment
        target.mkdir(parents=True, exist_ok=True)
        shell = shell_source.replace(
            'HOSTED_DEFAULT_ENV="cn" # PIXMAX_HOSTED_DEFAULT',
            f'HOSTED_DEFAULT_ENV="{environment}" # PIXMAX_HOSTED_DEFAULT',
        )
        powershell = powershell_source.replace(
            "else { 'cn' }), # PIXMAX_HOSTED_DEFAULT",
            f"else {{ '{environment}' }}), # PIXMAX_HOSTED_DEFAULT",
        )
        shell_path = target / "install.sh"
        shell_path.write_text(shell, encoding="utf-8")
        shell_path.chmod(shell_path.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
        (target / "install.ps1").write_text(powershell, encoding="utf-8-sig")

    return {
        "skillDir": str(skill_root),
        "zipPath": str(zip_path),
        "installersDir": str(installers_root),
    }


def main(argv: list[str] | None = None) -> None:
    args = sys.argv[1:] if argv is None else argv
    repo_root = Path(__file__).resolve().parents[2]
    out_dir = Path(args[0]).expanduser() if args else repo_root / "dist"
    result = build_skill_package(repo_root, out_dir)
    print(f"Skill directory: {result['skillDir']}")
    print(f"Skill zip: {result['zipPath']}")
    print(f"Hosted installers: {result['installersDir']}")


if __name__ == "__main__":
    main()
