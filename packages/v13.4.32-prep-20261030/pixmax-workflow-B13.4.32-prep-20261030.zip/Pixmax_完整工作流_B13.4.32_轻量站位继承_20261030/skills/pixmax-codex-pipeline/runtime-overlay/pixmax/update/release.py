"""Build signed, static-hostable Pixmax CLI release artifacts."""

from __future__ import annotations

import argparse
import base64
import hashlib
import importlib.metadata
import importlib.util
import json
import os
import re
import shutil
import stat
import sys
import tempfile
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from pixmax import __build__, __version__
from pixmax.update import LAUNCHER_VERSION

RUNTIME_DEPENDENCIES = (
    "click",
    "requests",
    "urllib3",
    "certifi",
    "idna",
    "charset_normalizer",
)
RUNTIME_SCRIPTS = ("install.sh", "install.ps1")
EXCLUDED_NAMES = {
    "__pycache__",
    ".pytest_cache",
    ".DS_Store",
    "tests",
    "CLI-HOT-UPDATE-DESIGN.md",
    "ASSET-MENTION-CHANGE-PLAN.md",
}
EXCLUDED_SUFFIXES = {".pyc", ".pyo", ".so", ".dylib", ".pyd"}

RUNTIME_ENTRY = '''#!/usr/bin/env python3
"""Versioned Pixmax CLI runtime entry point."""

from __future__ import annotations

import os
import sys
from pathlib import Path

RUNTIME_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(RUNTIME_ROOT / "vendor"))
sys.path.insert(0, str(RUNTIME_ROOT / "app"))
os.environ["PIXMAX_RUNTIME_ROOT"] = str(RUNTIME_ROOT)

from pixmax.pixmax_cli import main

if __name__ == "__main__":
    main(sys.argv[1:])
'''


class ReleaseBuildError(RuntimeError):
    """Raised when a release artifact cannot be built safely."""


def _ignore_runtime_names(_directory: str, names: list[str]) -> set[str]:
    return {
        name
        for name in names
        if name in EXCLUDED_NAMES or Path(name).suffix.lower() in EXCLUDED_SUFFIXES
    }


def _copy_dependency(name: str, vendor_root: Path) -> dict[str, str]:
    spec = importlib.util.find_spec(name)
    if spec is None or not spec.submodule_search_locations:
        raise ReleaseBuildError(
            f"Runtime dependency {name!r} is not installed in the build environment"
        )
    source = Path(next(iter(spec.submodule_search_locations))).resolve()
    destination = vendor_root / name
    shutil.copytree(source, destination, ignore=_ignore_runtime_names)
    try:
        version = importlib.metadata.version(name.replace("_", "-"))
    except importlib.metadata.PackageNotFoundError:
        version = "unknown"
    return {"name": name, "version": version}


def _write_deterministic_zip(source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_name(f".{destination.name}.tmp")
    with zipfile.ZipFile(
        temporary, "w", zipfile.ZIP_DEFLATED, compresslevel=9
    ) as archive:
        for path in sorted(source.rglob("*")):
            if not path.is_file():
                continue
            relative = path.relative_to(source).as_posix()
            info = zipfile.ZipInfo(relative, date_time=(2020, 1, 1, 0, 0, 0))
            mode = 0o755 if relative == "entry.py" else 0o644
            info.external_attr = (stat.S_IFREG | mode) << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, path.read_bytes())
    os.replace(temporary, destination)


def build_runtime(
    repo_root: str | Path,
    output_path: str | Path,
    *,
    version: str = __version__,
    build_number: int = __build__,
) -> dict[str, Any]:
    """Build a self-contained, architecture-neutral Python runtime ZIP."""
    repo_root = Path(repo_root).resolve()
    output_path = Path(output_path).resolve()
    if not re.fullmatch(
        r"(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)"
        r"(?:-[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?"
        r"(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?",
        version,
    ):
        raise ReleaseBuildError(f"Invalid runtime version: {version}")
    if (
        isinstance(build_number, bool)
        or not isinstance(build_number, int)
        or build_number < 1
    ):
        raise ReleaseBuildError("build_number must be a positive integer")
    required = [
        repo_root / "pixmax" / "__init__.py",
        repo_root / "pixmax" / "pixmax_cli.py",
        repo_root / "setup.py",
        *(repo_root / "scripts" / name for name in RUNTIME_SCRIPTS),
    ]
    missing = [str(path) for path in required if not path.is_file()]
    if missing:
        raise ReleaseBuildError(f"Runtime source is incomplete: {', '.join(missing)}")

    with tempfile.TemporaryDirectory(prefix="pixmax-runtime-") as temporary:
        runtime_root = Path(temporary)
        app_root = runtime_root / "app"
        vendor_root = runtime_root / "vendor"
        app_root.mkdir()
        vendor_root.mkdir()
        shutil.copytree(
            repo_root / "pixmax", app_root / "pixmax", ignore=_ignore_runtime_names
        )
        for relative in ("README.md", "PIXMAX.md", "setup.py"):
            source = repo_root / relative
            if source.is_file():
                shutil.copy2(source, app_root / relative)
        scripts_root = app_root / "scripts"
        scripts_root.mkdir()
        for name in RUNTIME_SCRIPTS:
            shutil.copy2(repo_root / "scripts" / name, scripts_root / name)
        dependencies = [
            _copy_dependency(name, vendor_root) for name in RUNTIME_DEPENDENCIES
        ]
        metadata = {
            "schemaVersion": 1,
            "version": version,
            "buildNumber": build_number,
            "minimumPython": "3.10",
            "entryPoint": "entry.py",
            "dependencies": dependencies,
        }
        (runtime_root / "runtime.json").write_text(
            json.dumps(metadata, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
        (runtime_root / "entry.py").write_text(RUNTIME_ENTRY, encoding="utf-8")
        _write_deterministic_zip(runtime_root, output_path)

    digest = hashlib.sha256(output_path.read_bytes()).hexdigest()
    return {
        "path": str(output_path),
        "version": version,
        "buildNumber": build_number,
        "sha256": digest,
        "size": output_path.stat().st_size,
        "dependencies": dependencies,
    }


def _load_private_key(path: Path):
    try:
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    except ImportError as exc:
        raise ReleaseBuildError(
            "Release signing requires the build-only cryptography package"
        ) from exc
    try:
        payload = path.read_bytes().strip()
    except OSError as exc:
        raise ReleaseBuildError(f"Cannot read signing key {path}: {exc}") from exc
    if payload.startswith(b"-----BEGIN"):
        try:
            key = serialization.load_pem_private_key(payload, password=None)
        except (TypeError, ValueError) as exc:
            raise ReleaseBuildError(
                "Signing key is not a valid unencrypted PEM key"
            ) from exc
        if not isinstance(key, Ed25519PrivateKey):
            raise ReleaseBuildError("Signing key must be an Ed25519 private key")
        return key
    try:
        raw = base64.b64decode(payload, validate=True)
    except ValueError as exc:
        raise ReleaseBuildError(
            "Signing key must be PEM or base64-encoded raw bytes"
        ) from exc
    if len(raw) != 32:
        raise ReleaseBuildError("Raw Ed25519 private key must contain exactly 32 bytes")
    return Ed25519PrivateKey.from_private_bytes(raw)


def _public_key_base64(private_key: Any) -> str:
    from cryptography.hazmat.primitives import serialization

    raw = private_key.public_key().public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    return base64.b64encode(raw).decode("ascii")


def generate_private_key(output_path: str | Path) -> dict[str, str]:
    """Create a new owner-only Ed25519 PEM key without overwriting a file."""
    try:
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    except ImportError as exc:
        raise ReleaseBuildError(
            "Release key generation requires the build-only cryptography package"
        ) from exc
    output_path = Path(output_path).expanduser().resolve()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    payload = Ed25519PrivateKey.generate().private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    try:
        descriptor = os.open(output_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
    except FileExistsError as exc:
        raise ReleaseBuildError(
            f"Refusing to overwrite existing key: {output_path}"
        ) from exc
    except OSError as exc:
        raise ReleaseBuildError(
            f"Cannot write release key {output_path}: {exc}"
        ) from exc
    private_key = _load_private_key(output_path)
    return {
        "privateKey": str(output_path),
        "publicKey": _public_key_base64(private_key),
    }


def _rewrite_skill_zip(skill_root: Path, zip_path: Path) -> None:
    temporary = zip_path.with_name(f".{zip_path.name}.tmp")
    with zipfile.ZipFile(
        temporary, "w", zipfile.ZIP_DEFLATED, compresslevel=9
    ) as archive:
        for path in sorted(skill_root.rglob("*")):
            if path.is_file():
                archive.write(path, path.relative_to(skill_root.parent).as_posix())
    os.replace(temporary, zip_path)


def build_hosted_release(
    repo_root: str | Path,
    output_root: str | Path,
    *,
    environment: str,
    manifest_url: str,
    private_key_path: str | Path,
    version: str = __version__,
    build_number: int = __build__,
    minimum_supported_build: int | None = None,
) -> dict[str, Any]:
    """Build one static host root, including the signed feed and installer package."""
    if environment not in {"cn", "global"}:
        raise ReleaseBuildError("environment must be cn or global")
    if not manifest_url.startswith("https://"):
        raise ReleaseBuildError("Production manifest_url must use HTTPS")
    repo_root = Path(repo_root).resolve()
    output_root = Path(output_root).resolve()
    private_key = _load_private_key(Path(private_key_path).expanduser().resolve())
    public_key = _public_key_base64(private_key)
    # Keep every build immutable even when maintainers publish multiple CI
    # builds for the same semantic version. The launcher still compares the
    # numeric build number, while the public version remains human-managed.
    release_dir_name = f"{build_number}-{version}"
    runtime_name = f"pixmax-cli-runtime-{release_dir_name}.zip"
    runtime_path = output_root / "releases" / release_dir_name / runtime_name
    runtime = build_runtime(
        repo_root,
        runtime_path,
        version=version,
        build_number=build_number,
    )
    manifest = {
        "schemaVersion": 1,
        "version": version,
        "buildNumber": build_number,
        "minimumSupportedBuild": (
            minimum_supported_build
            if minimum_supported_build is not None
            else build_number
        ),
        "minimumLauncherVersion": LAUNCHER_VERSION,
        "minimumPython": "3.10",
        "publishedAt": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "artifact": {
            "url": f"../releases/{release_dir_name}/{runtime_name}",
            "sha256": runtime["sha256"],
            "size": runtime["size"],
        },
    }
    manifest_bytes = (
        json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True).encode(
            "utf-8"
        )
        + b"\n"
    )
    signature = private_key.sign(manifest_bytes)
    stable = output_root / "stable"
    stable.mkdir(parents=True, exist_ok=True)
    (stable / "manifest.json").write_bytes(manifest_bytes)
    (stable / "manifest.sig").write_text(
        base64.b64encode(signature).decode("ascii") + "\n", encoding="ascii"
    )

    from pixmax.utils.skill_packager import build_skill_package

    package_work = output_root / ".package-work"
    package_result = build_skill_package(repo_root, package_work)
    skill_root = Path(package_result["skillDir"])
    release_dir = skill_root / "release"
    release_dir.mkdir(parents=True, exist_ok=True)
    shutil.copy2(runtime_path, release_dir / "runtime.zip")
    shutil.copy2(stable / "manifest.json", release_dir / "manifest.json")
    shutil.copy2(stable / "manifest.sig", release_dir / "manifest.sig")
    launcher_config = {
        "schemaVersion": 1,
        "channel": "stable",
        "updateEnabled": True,
        "manifestUrl": manifest_url,
        "publicKey": public_key,
        "requestTimeoutSeconds": 10,
        "lockTimeoutSeconds": 30,
        "doctorTimeoutSeconds": 60,
        "maxArtifactSize": 256 * 1024 * 1024,
        "maxUnpackedSize": 512 * 1024 * 1024,
        "maxArchiveFiles": 10_000,
    }
    (release_dir / "launcher-config.json").write_text(
        json.dumps(launcher_config, ensure_ascii=False, indent=2, sort_keys=True)
        + "\n",
        encoding="utf-8",
    )
    package_zip = output_root / "pixmax-cli-skill.zip"
    _rewrite_skill_zip(skill_root, package_zip)
    hosted_installers = Path(package_result["installersDir"]) / environment
    shutil.copy2(hosted_installers / "install.sh", output_root / "install.sh")
    shutil.copy2(hosted_installers / "install.ps1", output_root / "install.ps1")
    shutil.rmtree(package_work)
    return {
        "root": str(output_root),
        "environment": environment,
        "manifest": str(stable / "manifest.json"),
        "signature": str(stable / "manifest.sig"),
        "runtime": runtime,
        "installerPackage": str(package_zip),
        "installSh": str(output_root / "install.sh"),
        "installPs1": str(output_root / "install.ps1"),
        "publicKey": public_key,
    }


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="command", required=True)
    keygen = subparsers.add_parser(
        "keygen", help="Generate an owner-only Ed25519 PEM key"
    )
    keygen.add_argument("--out", required=True)
    runtime = subparsers.add_parser(
        "runtime", help="Build an unsigned local runtime ZIP"
    )
    runtime.add_argument(
        "--repo-root", default=str(Path(__file__).resolve().parents[2])
    )
    runtime.add_argument("--out", required=True)
    runtime.add_argument("--version", default=__version__)
    runtime.add_argument("--build-number", type=int, default=__build__)
    hosted = subparsers.add_parser(
        "hosted", help="Build a signed static-host release tree"
    )
    hosted.add_argument("--repo-root", default=str(Path(__file__).resolve().parents[2]))
    hosted.add_argument("--out", required=True)
    hosted.add_argument("--environment", choices=("cn", "global"), required=True)
    hosted.add_argument("--manifest-url", required=True)
    hosted.add_argument("--private-key-file", required=True)
    hosted.add_argument("--version", default=__version__)
    hosted.add_argument("--build-number", type=int, default=__build__)
    hosted.add_argument("--minimum-supported-build", type=int, default=None)
    return parser


def main(argv: list[str] | None = None) -> None:
    args = _parser().parse_args(argv)
    try:
        if args.command == "keygen":
            result = generate_private_key(args.out)
        elif args.command == "runtime":
            result = build_runtime(
                args.repo_root,
                args.out,
                version=args.version,
                build_number=args.build_number,
            )
        else:
            result = build_hosted_release(
                args.repo_root,
                args.out,
                environment=args.environment,
                manifest_url=args.manifest_url,
                private_key_path=args.private_key_file,
                version=args.version,
                build_number=args.build_number,
                minimum_supported_build=args.minimum_supported_build,
            )
    except ReleaseBuildError as exc:
        print(f"Release build failed: {exc}", file=sys.stderr)
        raise SystemExit(2)
    print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
