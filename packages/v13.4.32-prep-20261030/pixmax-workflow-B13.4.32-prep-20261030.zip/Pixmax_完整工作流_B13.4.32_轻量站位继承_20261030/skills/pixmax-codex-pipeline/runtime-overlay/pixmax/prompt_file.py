"""Load --prompt-file inside the CLI process, avoiding shell argument limits."""
from pathlib import Path


def expand_prompt_file(args):
    args = list(args)
    positions = [i for i, value in enumerate(args)
                 if value == '--prompt-file' or value.startswith('--prompt-file=')]
    if not positions:
        return args
    if len(positions) != 1:
        raise ValueError('Pass exactly one --prompt-file')
    if any(value == '--prompt' or value.startswith('--prompt=') for value in args):
        raise ValueError('--prompt and --prompt-file cannot be combined')
    for i, value in enumerate(args):
        if ((value in ('--set', '-s') and i+1 < len(args) and args[i+1].startswith('prompt='))
                or value.startswith(('--set=prompt=', '-sprompt='))):
            raise ValueError('--prompt-file cannot be combined with a prompt parameter override')
    index = positions[0]
    flag = args[index]
    if '=' in flag:
        path = flag.split('=', 1)[1]
        consumed = 1
    else:
        if index+1 >= len(args) or args[index+1].startswith('--'):
            raise ValueError('--prompt-file requires a UTF-8 file path')
        path = args[index+1]
        consumed = 2
    if not path:
        raise ValueError('--prompt-file requires a UTF-8 file path')
    # read_bytes preserves CRLF and trailing whitespace. Never strip or truncate.
    text = Path(path).read_bytes().decode('utf-8')
    if text.startswith('\ufeff'):
        raise ValueError('Prompt file must be UTF-8 without BOM; normalize the execution copy explicitly')
    if not text.strip() or '\x00' in text:
        raise ValueError('Prompt must be nonempty and contain no NUL characters')
    return args[:index] + ['--prompt', text] + args[index+consumed:]
