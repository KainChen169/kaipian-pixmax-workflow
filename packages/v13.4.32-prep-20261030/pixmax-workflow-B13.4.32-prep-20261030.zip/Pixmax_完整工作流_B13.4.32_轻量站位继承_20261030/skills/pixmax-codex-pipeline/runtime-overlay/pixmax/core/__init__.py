"""Pixmax CLI core state: session and workspace helpers."""
