#!/usr/bin/env python3
"""Read-only animation prompt checks. No network, generation, or file mutation."""
import argparse
import json
import math
import re
from pathlib import Path

SECTIONS = ['人物指定', '场景指定', '道具指定', '人物开场站位', '时间线', '声音', '输出要求']
KINDS = {'现场对白', '画外对白', '内心旁白', '旁白', '回忆声', '通话'}
SEGMENT = re.compile(r'^##[ \t]+第\s*(\d+)\s*段[^\n]*$', re.M)
SECTION = re.compile(r'^###[ \t]+([^\n]+?)\s*$', re.M)
SHOT = re.compile(r'^####[ \t]+镜头\s*(\d+)\s*[｜|]\s*(\d+(?:\.\d+)?)\s*[-–—~～]\s*(\d+(?:\.\d+)?)秒\s*[｜|]\s*景别[:：]([^｜|\n]+)[｜|]([^｜|\n]+)[｜|]\s*运镜[:：]([^\n]+)$', re.M)
SPOKEN = re.compile(r'^原话[（(]([^／→（）\n]+)／([^→（）\n]+)→([^（）\n]+)[）)](?:〔声线：([\w.-]+)/([\w.-]+)〕)?[:：]「([^\n]*)」\s*$', re.M)
VOICE = re.compile(r'声音身份[:：](.+?)；声线版本[:：]([\w.-]+)/([\w.-]+)(?=[；。\n]|$)')
HAN = re.compile(r'[\u3400-\u9fff]')
SIZE = re.compile(r'(?:大特写|特写|近景|中景|中近景|中全景|全景|远景)')
BODY_FIELD = re.compile(r'^(构图|画面内容|画面|表演|动作与表演|动作)[:：]([^\n]*)$', re.M)
GUIDANCE = re.compile(r'^导演指导[:：]([^\n]*)$', re.M)


def voice_rows(block, errors, label):
    rows = {}
    for line in block.splitlines():
        if '声音身份' not in line and '声线版本' not in line:
            continue
        m = VOICE.search(line)
        prefix = line.split('：', 1)[0].replace('**', '').strip()
        prefix = re.sub(r'^(纯声源|补充声线)\s+', '', prefix)
        if not m or not prefix:
            errors.append(label + '：声音身份／版本行不可解析')
            continue
        key = (prefix, m[2])
        if key in rows:
            errors.append(label + '：同角色同阶段声线重复')
        rows[key] = {'identity': m[1], 'version': m[3], 'line': line}
    return rows


def cast_records(data, errors):
    if data is None:
        return {}, False
    if not isinstance(data, dict) or data.get('schema_version') != '1.0' or not isinstance(data.get('voices'), list):
        errors.append('声音档案须为schema_version=1.0及voices列表')
        return {}, False
    records, valid = {}, True
    for n, item in enumerate(data['voices'], 1):
        required = ('speaker', 'stage', 'version', 'identity', 'language', 'accent', 'basis')
        if not isinstance(item, dict) or any(not isinstance(item.get(k), str) or not item[k].strip() for k in required):
            errors.append('声音档案第%d项缺少非空身份／阶段／版本／语言／口音／依据' % n)
            valid = False
            continue
        key = (item['speaker'], item['stage'])
        if key in records:
            errors.append('声音档案同人同阶段存在多个当前版本')
            valid = False
        if item['language'] != 'English':
            errors.append('本英文执行契约不接受非English声线，须明确改用对应语言契约')
            valid = False
        ref = item.get('reference', {})
        if not isinstance(ref, dict) or ref.get('mode') not in ('text_only', 'existing_unverified', 'verified_binding'):
            errors.append('声音档案须区分text_only／existing_unverified／verified_binding')
            valid = False
        elif ref['mode'] == 'verified_binding' and any(not isinstance(ref.get(k), str) or not ref[k].strip() for k in ('asset_or_voice_id', 'entry', 'readback_evidence')):
            errors.append('verified_binding缺真实标识／入口／回读证据字段，不得仅凭文本声称绑定')
            valid = False
        records[key] = item
    return records, valid


def source_records(data, errors):
    if data is None:
        return [], False
    if not isinstance(data, dict) or data.get('schema_version') != '1.0' or data.get('language') != 'English' or not isinstance(data.get('utterances'), list) or not isinstance(data.get('source_version'), str) or not data['source_version'].strip():
        errors.append('英文源须含schema_version=1.0、language=English、source_version、utterances列表')
        return [], False
    result, valid = [], True
    for n, item in enumerate(data['utterances'], 1):
        if not isinstance(item, dict) or any(not isinstance(item.get(k), str) or not item[k].strip() for k in ('speaker', 'text', 'source_location')) or not isinstance(item.get('kind'), str) or item['kind'] not in KINDS or not isinstance(item.get('voice_stage', 'default'), str):
            errors.append('英文源第%d项缺speaker／kind／text／source_location或阶段无效' % n)
            valid = False
            continue
        if HAN.search(item['text']):
            errors.append('独立英文源包含中文发声，先在写稿阶段完成忠实翻译')
            valid = False
        result.append(item)
    return result, valid


def check(text, source=None, voice_cast=None, max_duration=30.0, format_mode='auto'):
    errors, review = [], []
    records, cast_valid = cast_records(voice_cast, errors)
    expected, source_valid = source_records(source, errors)
    if format_mode not in ('auto', 'natural', 'legacy'):
        errors.append('格式模式须为auto／natural／legacy')
    segments = list(SEGMENT.finditer(text))
    if not segments:
        errors.append('无可解析片段：使用 ## 第01段')
    if not math.isfinite(max_duration) or max_duration <= 0:
        errors.append('规划上限必须为有限正数')
    if re.search(r'/Users/|file://|[A-Za-z]:[\\/]|%%@\[|\b[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}\b', text):
        errors.append('干净源稿含本机路径、UUID或机器引用；执行副本另由主流程核验')
    if re.search(r'\bTODO\b|\[(?:待填|角色描述|原话|组装好的完整提示词)\]', text):
        errors.append('存在未展开占位符')
    if re.search(r'(?m)^\s*(?:中文[:：]|CN:)', text):
        errors.append('生成稿包含中文阅读对照')

    actual, total_shots, voice_ok = [], 0, True
    for idx, seg in enumerate(segments):
        label = '第%02d段' % int(seg[1])
        if int(seg[1]) != idx + 1:
            errors.append(label + '：段号缺失、重复或乱序')
        block = text[seg.end():segments[idx + 1].start() if idx + 1 < len(segments) else len(text)]
        headers = list(SECTION.finditer(block))
        if [m[1] for m in headers] != SECTIONS:
            errors.append(label + '：七板块缺项、重复或顺序错误')
        parts = {m[1]: block[m.end():headers[j+1].start() if j+1 < len(headers) else len(block)] for j, m in enumerate(headers)}
        d = re.search(r'(?m)^\s*-?\s*时长[:：]\s*(\d+(?:\.\d+)?)秒\s*$', block)
        duration = float(d[1]) if d else None
        if duration is None or not 0 < duration <= max_duration:
            errors.append(label + '：时长缺失、非正或超规划上限')
        if not re.search(r'(?m)^\s*-?\s*画幅[:：]\s*\d+:\d+\s*$', block):
            errors.append(label + '：缺少明确画幅')
        if not re.search(r'(?m)^\s*-?\s*模型[:：]\s*Seedance2\.5\s*$', block):
            errors.append(label + '：缺少Seedance2.5模型声明')
        timeline = parts.get('时间线', '')
        if re.search(r'(?m)^\s*-\s*(?:构图|画面内容|画面|表演|动作与表演|动作)[:：]', timeline):
            errors.append(label + '：镜头字段须为无列表符号的段首字段，供Pixmax锚点解析')
        shots = list(SHOT.finditer(timeline))
        if not shots or len(shots) != len(re.findall(r'(?m)^####\s+镜头[^\n]*$', timeline)):
            errors.append(label + '：镜头标题不可解析或无镜头')
        natural = format_mode == 'natural' or (format_mode == 'auto' and (
            GUIDANCE.search(timeline) or any(m[1] in ('画面', '表演', '动作', '动作与表演') for m in BODY_FIELD.finditer(timeline))))
        if natural:
            guide = list(GUIDANCE.finditer(timeline))
            if len(guide) != 1 or not guide[0][1].strip() or (shots and guide[0].start() > shots[0].start()):
                errors.append(label + '：新格式须在首镜前有一段非空导演指导')
            preamble = block[:headers[0].start()] if headers else block
            style = list(re.finditer(r'^统一风格总纲[:：]([^\n]*)$', preamble, re.M))
            if len(style) != 1 or not style[0][1].strip():
                errors.append(label + '：新稿须保留一段非空统一风格总纲')
        end = 0.0
        pre = voice_rows(parts.get('人物指定', ''), errors, label + '人物区')
        sound = voice_rows(parts.get('声音', ''), errors, label + '声音区')
        segment_spoken = []
        for j, shot in enumerate(shots):
            tag = label + '镜头%02d' % int(shot[1])
            if int(shot[1]) != j + 1:
                errors.append(tag + '：镜号不连续')
            start, stop = float(shot[2]), float(shot[3])
            if abs(start - end) > .011 or stop <= start or (duration is not None and stop > duration + .011):
                errors.append(tag + '：时码缺口／重叠／非正或超时')
            end = stop
            if any(not SIZE.search(s) for s in re.split(r'→|->', shot[4])):
                errors.append(tag + '：实际景别无效，过肩／主观等不能代替景别')
            body = timeline[shot.end():shots[j+1].start() if j+1 < len(shots) else len(timeline)]
            fields = list(BODY_FIELD.finditer(body))
            names = [m[1] for m in fields]
            valid_fields = (len(names) == 2 and names[0] == '画面' and names[1] in ('表演', '动作', '动作与表演')) if natural else names == ['构图', '画面内容']
            if not valid_fields or any(not m[2].strip() for m in fields):
                errors.append(tag + ('：须为唯一非空画面＋表演／动作，不能混用旧字段' if natural else '：须为唯一非空构图＋画面内容'))
            spoken = list(SPOKEN.finditer(body))
            if len(spoken) != len(re.findall(r'(?m)^原话[（(]', body)):
                errors.append(tag + '：原话行须含姓名／类型→对象及完整引号')
            residue = SPOKEN.sub('', body)
            residue = re.sub(r'实体文字[:：]「[^\n]*」', '', residue)
            if re.search(r'[“「\"][^”」\"\n]*[A-Za-z][^”」\"\n]*[”」\"]', residue) or re.search(r'(?:说|问|回答|喊|念|旁白)\s*[:：]', residue):
                errors.append(tag + '：疑似未标记台词／引语；发声用原话行，物件证据用实体文字标记')
            for m in spoken:
                who, kind, target, stage, version, words = m.groups()
                who, kind = who.strip(), kind.strip()
                if kind not in KINDS or not words.strip():
                    errors.append(tag + '：声部或原话为空／无效')
                if HAN.search(words):
                    errors.append(tag + '：原话含中文')
                available = [(k, row) for k, row in pre.items() if k[0] == who]
                if stage is None:
                    if len(available) == 1:
                        (unused, stage), row = available[0]
                        version = row['version']
                    else:
                        errors.append(tag + '：声音身份缺失或多阶段未显式指定')
                        stage, version = 'default', None
                        voice_ok = False
                key = (who, stage)
                entry = records.get(key)
                if not entry or key not in pre or key not in sound:
                    errors.append(tag + '：缺少该说话者阶段的档案／前置／声音身份')
                    voice_ok = False
                else:
                    for place, rows in [('人物区', pre), ('声音区', sound)]:
                        if rows[key]['identity'] != entry['identity'] or rows[key]['version'] != entry['version']:
                            errors.append(tag + '：' + place + '声线文字／版本与档案不符')
                            voice_ok = False
                    if version != entry['version']:
                        errors.append(tag + '：镜内声线版本不符')
                        voice_ok = False
                    line = sound[key]['line']
                    if '语言：' + entry['language'] not in line or '口音：' + entry['accent'] not in line:
                        errors.append(tag + '：语言／口音与档案不符')
                        voice_ok = False
                    kline = re.search(r'声部[:：]([^。\n]+)', line)
                    kinds = set(re.split(r'[、,，]', kline[1])) if kline else set()
                    if kind not in kinds:
                        errors.append(tag + '：声音区遗漏实际声部')
                        voice_ok = False
                segment_spoken.append((who, kind, words, stage))
            total_shots += 1
        if duration is not None and shots and abs(end - duration) > .011:
            errors.append(label + '：末镜未覆盖片段时长')
        actual.extend(segment_spoken)
        # Content checks are deliberately conservative and do not claim aesthetic proof.
        visual = SPOKEN.sub('', block)
        for clause in re.split(r'[。；\n]', visual):
            m = re.search(r'真人(?:电影)?实拍|真实人类(?:皮肤|毛孔)|ARRI(?:摄影|机身|风格)', clause)
            if m and not re.search(r'不|禁止|避免|非', clause[:m.start()]):
                errors.append(label + '：出现正向真人实拍／皮肤／机身指令')
        if not re.search(r'动画|animated|animation', parts.get('输出要求', ''), re.I):
            errors.append(label + '：输出未明确动画媒介')

    if len(re.findall(r'(?m)^原话[（(]', text)) != len(actual):
        errors.append('有原话行未落入可解析镜头窗口，或标记格式无效')
    dialogue_ok = source_valid
    if actual and source is None:
        errors.append('有发声但未提供独立英文源，不能声称原话核验完成')
        dialogue_ok = False
    if actual and voice_cast is None:
        errors.append('有发声但未提供项目声音档案')
        voice_ok = False
    if source_valid:
        cursor, joined = 0, ''
        for who, kind, words, stage in actual:
            if cursor >= len(expected):
                errors.append('出现源外额外原话')
                dialogue_ok = False
                break
            item = expected[cursor]
            if (who, kind, stage) != (item['speaker'], item['kind'], item.get('voice_stage', 'default')):
                errors.append('第%d项原话的说话者／声部／阶段与独立源不同' % (cursor + 1))
                dialogue_ok = False
                break
            joined += words
            if not item['text'].startswith(joined):
                errors.append('第%d项原话逐字不符、重复或顺序错误' % (cursor + 1))
                dialogue_ok = False
                break
            if joined == item['text']:
                cursor += 1
                joined = ''
        if cursor != len(expected) or joined:
            errors.append('独立源原话未完整准确覆盖')
            dialogue_ok = False
    review.append('逐镜语义核对未标记／未加引号的潜在发声、画外／内心口型、动作／时长、机位背景及声线设计的听觉辨识度；程序无法穷尽自由文本。')
    return {'passed': not errors, 'segments': len(segments), 'shots': total_shots,
            'source_dialogue_checked': bool(source_valid and dialogue_ok),
            'voice_identity_checked': bool(actual and cast_valid and voice_ok),
            'actual_voiceprint_verified': False, 'errors': errors, 'review': review,
            'limits': '只校验可解析文本及附件一致；不证明来源提取独立性、空间、口型、实际声纹或视频效果。'}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('prompt', type=Path)
    p.add_argument('--source-dialogue', type=Path)
    p.add_argument('--voice-cast', type=Path)
    p.add_argument('--max-duration', type=float, default=30.0)
    p.add_argument('--format', choices=('auto', 'natural', 'legacy'), default='auto', help='新写用natural；auto兼容旧确定稿，不改源文')
    a = p.parse_args()
    try:
        source = json.loads(a.source_dialogue.read_text()) if a.source_dialogue else None
        cast = json.loads(a.voice_cast.read_text()) if a.voice_cast else None
        result = check(a.prompt.read_text(), source, cast, a.max_duration, a.format)
    except (OSError, ValueError) as exc:
        result = {'passed': False, 'errors': [str(exc)], 'actual_voiceprint_verified': False}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
