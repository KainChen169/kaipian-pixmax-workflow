#!/usr/bin/env python3
"""Offline regression of observable source/voice/timing invariants; no media."""
import copy
import json
import re
import unittest
from pathlib import Path
from validate_animation_prompt import check

ROOT = Path(__file__).resolve().parents[1]
EX = ROOT / 'assets' / 'examples'
PROMPT = (EX / 'voice_scene.prompt.md').read_text()
SOURCE = json.loads((EX / 'voice_scene.dialogue.json').read_text())
CAST = json.loads((EX / 'voice_scene.voices.json').read_text())
LEGACY = (EX / 'legacy_voice_scene.prompt.md').read_text()


class AnimationContract(unittest.TestCase):
    def verify(self, text=PROMPT, source=SOURCE, cast=CAST, passes=True, contains=None):
        result = check(text, source, cast)
        self.assertEqual(result['passed'], passes, result)
        self.assertFalse(result['actual_voiceprint_verified'])
        if contains:
            self.assertTrue(any(contains in x for x in result['errors']), result)
        return result

    def test_valid_animal_inner_and_offscreen(self):
        r = self.verify()
        self.assertTrue(r['source_dialogue_checked'])
        self.assertTrue(r['voice_identity_checked'])
        self.assertEqual(r['shots'], 3)

    def test_voice_identity_drift_in_both_sections(self):
        self.verify(PROMPT.replace(CAST['voices'][0]['identity'], '幼年尖细嗓音，甜腻拖腔'), passes=False, contains='档案不符')

    def test_only_sound_identity_drift(self):
        a, b = PROMPT.split('### 声音', 1)
        self.verify(a + '### 声音' + b.replace(CAST['voices'][0]['identity'], '成年低沉嗓音'), passes=False, contains='档案不符')

    def test_version_drift(self):
        self.verify(PROMPT.replace('default/v1', 'default/v2'), passes=False, contains='版本')

    def test_accent_drift(self):
        self.verify(PROMPT.replace('口音：Neutral English pronunciation', '口音：New strong regional accent'), passes=False, contains='口音')

    def test_language_drift(self):
        self.verify(PROMPT.replace('语言：English', '语言：Chinese'), passes=False, contains='语言')

    def test_missing_cast(self):
        self.verify(cast=None, passes=False, contains='声音档案')

    def test_missing_source(self):
        self.verify(source=None, passes=False, contains='独立英文源')

    def test_source_word_change(self):
        self.verify(PROMPT.replace("I'm ready.", "I'm not ready."), passes=False, contains='逐字')

    def test_missing_utterance(self):
        self.verify(PROMPT.replace('原话（Ren／画外对白→Mira）：「Then come in.」', ''), passes=False, contains='未完整')

    def test_speaker_swap(self):
        self.verify(PROMPT.replace('原话（Ren／画外对白', '原话（Mira／画外对白'), passes=False, contains='说话者')

    def test_inner_voice_mislabeled(self):
        self.verify(PROMPT.replace('原话（Mira／内心旁白', '原话（Mira／现场对白'), passes=False, contains='声部')

    def test_duplicate_marked_utterance(self):
        line = '原话（Ren／画外对白→Mira）：「Then come in.」'
        self.verify(PROMPT.replace(line, line + '\n' + line), passes=False, contains='额外原话')

    def test_extra_unmarked_dialogue(self):
        self.verify(PROMPT.replace('### 声音', 'Mira说：“I will leave now.”\n\n### 声音'), passes=False, contains='未标记')

    def test_speech_outside_timeline(self):
        self.verify(PROMPT + '\n原话（Mira／现场对白→自己）：「Extra words.」\n', passes=False, contains='镜头窗口')

    def test_chinese_reading_translation(self):
        self.verify(PROMPT.replace('### 声音', '中文：我准备好了。\n\n### 声音'), passes=False, contains='中文阅读')

    def test_chinese_spoken(self):
        self.verify(PROMPT.replace('Stay calm.', '冷静。'), passes=False, contains='原话含中文')

    def test_invalid_angle_as_shot_size(self):
        self.verify(PROMPT.replace('景别：中全景', '景别：过肩'), passes=False, contains='景别无效')

    def test_liveaction_contamination(self):
        self.verify(PROMPT + '\n真人实拍，ARRI摄影，真实人类毛孔。\n', passes=False, contains='真人实拍')

    def test_no_false_positive_on_negative_liveaction_or_eye_material(self):
        self.verify(PROMPT + '\n不转真人实拍；保持动画自然眼部高光。\n')

    def test_missing_model_or_aspect(self):
        for field in ('模型：Seedance2.5\n', '画幅：9:16\n'):
            with self.subTest(field=field):
                self.verify(PROMPT.replace(field, ''), passes=False)

    def test_time_gap(self):
        self.verify(PROMPT.replace('2.0–6.0秒', '2.2–6.0秒'), passes=False, contains='时码')

    def test_time_overlap(self):
        self.verify(PROMPT.replace('6.0–10.0秒', '5.8–10.0秒'), passes=False, contains='时码')

    def test_overlong_segment(self):
        self.verify(PROMPT.replace('时长：10秒', '时长：31秒'), passes=False, contains='超规划')

    def test_missing_section(self):
        self.verify(PROMPT.replace('### 道具指定\n', ''), passes=False, contains='七板块')

    def test_missing_pixmax_body_anchor_field(self):
        self.verify(PROMPT.replace('画面：', '- 画面：'), passes=False, contains='Pixmax锚点')

    def test_legacy_kept_readable_without_rewriting(self):
        self.verify(LEGACY)
        self.assertFalse(check(LEGACY, SOURCE, CAST, format_mode='natural')['passed'])

    def test_new_guidance_required_and_before_first_shot(self):
        guide = re.search(r'^导演指导：[^\n]*\n', PROMPT, re.M)[0]
        self.verify(PROMPT.replace(guide, ''), passes=False, contains='导演指导')
        self.verify(PROMPT.replace(guide, '').replace('### 声音', guide + '### 声音'), passes=False, contains='导演指导')
        self.verify(PROMPT.replace(guide, '导演指导：\n'), passes=False, contains='导演指导')

    def test_style_outline_preserved_in_new_format(self):
        text = re.sub(r'^统一风格总纲：[^\n]*\n', '', PROMPT, flags=re.M)
        self.verify(text, passes=False, contains='统一风格总纲')

    def test_short_clear_field_has_no_length_threshold(self):
        self.verify(re.sub(r'^画面：[^\n]*', '画面：固定近景看Mira。', PROMPT, flags=re.M))

    def test_action_alternatives(self):
        for field in ('动作', '动作与表演'):
            self.verify(PROMPT.replace('表演：', field + '：'))

    def test_missing_empty_duplicate_or_mixed_fields_fail(self):
        for old, new in [('画面：', '构图：'), ('表演：', '画面内容：'),
                         ('表演：', '动作：同窗动作。\n表演：'), ('画面：', '画面：\n构图：')]:
            with self.subTest(new=new):
                self.verify(PROMPT.replace(old, new, 1), passes=False, contains='字段')
        text = re.sub(r'^表演：[^\n]*', '表演：', PROMPT, count=1, flags=re.M)
        self.verify(text, passes=False, contains='非空')

    def test_new_fields_cannot_hide_added_speech(self):
        for field in ('画面', '表演', '动作', '动作与表演'):
            text = PROMPT.replace('表演：', '动作：') if field in ('动作', '动作与表演') else PROMPT
            if field == '动作与表演': text = text.replace('动作：', '动作与表演：')
            text = text.replace(field + '：', field + '：Mira说：“Extra words.” ', 1)
            self.verify(text, passes=False, contains='未标记')

    def test_repeat_current_stage_is_invalid(self):
        cast = copy.deepcopy(CAST)
        cast['voices'].append(copy.deepcopy(cast['voices'][0]))
        self.verify(cast=cast, passes=False, contains='多个当前版本')

    def test_false_bound_voice_status(self):
        cast = copy.deepcopy(CAST)
        cast['voices'][0]['reference'] = {'mode': 'verified_binding'}
        self.verify(cast=cast, passes=False, contains='证据字段')

    def test_malformed_source_kind_does_not_crash(self):
        source = copy.deepcopy(SOURCE)
        source['utterances'][0]['kind'] = []
        self.verify(source=source, passes=False)

    def test_same_utterance_across_cut_once(self):
        # Continuation is byte-faithful, including the source space.
        text = PROMPT.replace('「Stay calm.」', '「Stay 」').replace('原话（Mira／现场对白→门口）', '原话（Mira／内心旁白→自己）：「calm.」\n原话（Mira／现场对白→门口）')
        self.verify(text)

    def test_source_sign_text_is_not_extra_speech(self):
        self.verify(PROMPT.replace('### 声音', '实体文字：「PRIVATE」\n\n### 声音'))

    def test_multi_segment_stable_and_drifting_voices(self):
        second = PROMPT.split('## 第01段', 1)[1]
        text = PROMPT + '\n## 第02段' + second
        source = copy.deepcopy(SOURCE)
        source['utterances'] *= 2
        self.verify(text, source=source)
        bad = PROMPT + '\n## 第02段' + second.replace(CAST['voices'][0]['identity'], '另一人的幼态高音')
        self.verify(bad, source=source, passes=False, contains='档案不符')

    def test_authorized_explicit_voice_stage(self):
        cast = copy.deepcopy(CAST)
        older = copy.deepcopy(cast['voices'][0])
        older.update(stage='older', identity='老年女性声线，温厚略沙的中音；表达从容清楚，不刻意衰弱')
        cast['voices'].append(older)
        text = PROMPT.replace('### 场景指定', '补充声线 Mira：声音身份：' + older['identity'] + '；声线版本：older/v1。\n\n### 场景指定')
        text = text.replace('原话（Mira／内心旁白→自己）：', '原话（Mira／内心旁白→自己）〔声线：older/v1〕：')
        text = text.replace('原话（Mira／现场对白→门口）：', '原话（Mira／现场对白→门口）〔声线：default/v1〕：')
        text = text.replace('### 输出要求', 'Mira：声音身份：' + older['identity'] + '；声线版本：older/v1；语言：English；口音：Neutral English pronunciation；声部：内心旁白。\n\n### 输出要求')
        source = copy.deepcopy(SOURCE)
        source['utterances'][0]['voice_stage'] = 'older'
        self.verify(text, source=source, cast=cast)


if __name__ == '__main__':
    unittest.main(verbosity=2)
