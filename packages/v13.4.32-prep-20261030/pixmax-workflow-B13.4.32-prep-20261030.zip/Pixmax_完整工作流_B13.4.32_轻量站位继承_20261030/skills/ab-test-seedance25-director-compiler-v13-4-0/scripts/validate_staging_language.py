"""Check readable staging and prompt language, without interpreting scene geometry."""
import argparse
import json
import re
from pathlib import Path
from inline_dialogue import VOICE

ROLES=re.compile(r'女主(?:角)?|男主(?:角)?|女反(?:派)?|男反(?:派)?|男[一二三四]|女[一二三四]|女配|男配|反派|主角|'
                 r'前者|后者|(?:人物|角色)[甲乙丙丁一二三四五六七八九十0-9]+|'
                 r'\b(?:female lead|male lead|heroine|villainess|villain|antagonist|protagonist)\b',re.I)
LETTERS=re.compile(r'(?<![A-Za-z0-9_])[A-Z](?![A-Za-z0-9_])|'
                   r'(?:走到|位于|站在|坐在|抵达|到达|仍在|仍|从|经|至|在|到|坐|过|向|自|扶)\s*[A-Z]\d+(?![A-Za-z0-9_])|'
                   r'(?:point|actor|character|zone)\s+[A-Z]\d*(?![A-Za-z0-9_])|'
                   r'[甲乙丙丁](?=的|身|从|站|坐|向|与|和|、|点|区)|'
                   r'[a-z](?=点|处|区|号位)|(?:门|窗|椅子|椅|桌子|桌|柜|地点)[a-z](?![A-Za-z0-9_])|'
                   r'(?:POINT|POS|ANCHOR|ZONE|CHAR|ROLE|PERSON|ACTOR)_[A-Za-z0-9_]+|'
                   r'(?:点位|位置点|区域|站位点|锚点)[一二三四五六七八九十甲乙丙丁0-9]+')
COORDS=re.compile(r'[（(]\s*[+-]?\d+(?:\.\d+)?\s*[,，]\s*[+-]?\d+(?:\.\d+)?'
                  r'(?:\s*[,，]\s*[+-]?\d+(?:\.\d+)?)?\s*[）)]|'
                  r'(?<![A-Za-z0-9_])[xyzXYZ]\s*(?:[=＝]|轴|坐标|[+-]?\d)|'
                  r'以[^。；;\n]{0,24}为原点|坐标系|坐标为|坐标范围|横纵轴|[XYZxyz]正方向')
TECH={'id','policy','episode_id','scene','expected_segment_ids','shot_numbers','time','actual_duration',
      'prepared_before_prompt','source_sha256','status','blocking_plan_file','blocking_plan_sha256',
      'blocking_text_file','blocking_text_sha256'}

# A letter inside a concrete shape/material term is not an anonymous point.
# Exempt only that one character; aliases elsewhere in the same sentence still fail.
LEXICAL_LETTERS = (
    re.compile(r'(?<![A-Za-z0-9_])(?P<letter>[LUTSHZ])\s*形(?:沙发|走廊|通道|楼梯|餐桌|工作桌|桌|吧台|柜台|建筑|扶手|管道)'),
    re.compile(r'(?<![A-Za-z0-9_])(?P<letter>[LUTSHZ])[- ]shaped\s+(?:sofa|couch|corridor|hallway|table|counter|staircase|building|pipe)\b', re.I),
    re.compile(r'(?:维生素\s*|\bvitamin\s+)(?P<letter>[ABCDEK])(?![A-Za-z0-9_]|点|区|号位)', re.I),
)

def validate_text(text,protect_dialogue=True):
    scan=list(text)
    if protect_dialogue:
        for speech in VOICE.finditer(text):
            start,end=speech.span('text');scan[start:end]=' '*(end-start)
    scan=''.join(scan)
    lexical_spans = {match.span('letter') for pattern in LEXICAL_LETTERS for match in pattern.finditer(scan)}
    rows=[]
    for pattern,code,message in [
        (ROLES,'CHARACTER_ALIAS','人物主体及对象用来源姓名，不使用剧情标签或匿名人物代称。'),
        (LETTERS,'SPATIAL_ALIAS','人物和位置直接用姓名及完整实景地标，不使用字母／匿名点位。'),
        (COORDS,'NUMERIC_COORDINATES','以门口、桌边等具体地标描述空间，不建立坐标或数值点位。')]:
        for match in pattern.finditer(scan):
            if pattern is LETTERS and match.span() in lexical_spans:
                continue
            rows.append(dict(level='ERROR',code=code,message=message,line=text.count('\n',0,match.start())+1,
                             excerpt=text[max(0,match.start()-12):min(len(text),match.end()+20)]))
    return rows

def validate_plan(plan):
    rows=[]
    def walk(value,path='',field=''):
        if isinstance(value,str):
            for row in validate_text(value,protect_dialogue=False):
                rows.append({**row,'path':path})
        elif isinstance(value,list):
            if field in ('position','coordinates','location','start','end','位置','坐标') and len(value) in (2,3) and all(isinstance(x,(float,int)) for x in value):
                rows.append(dict(level='ERROR',code='NUMERIC_COORDINATES',message='位置数组应改为中文实景地标关系。',path=path,line=1))
            else:
                for i,item in enumerate(value): walk(item,f'{path}[{i}]',field)
        elif isinstance(value,dict):
            for key,item in value.items():
                if key in TECH or key.endswith(('_file','_sha256')): continue
                if field in ('opening_state','exit_state'):
                    for row in validate_text(key,protect_dialogue=False): rows.append({**row,'path':path+'.'+key})
                if key in ('x','y','z','coords','xyz','坐标','原点'):
                    rows.append(dict(level='ERROR',code='NUMERIC_COORDINATES',message='状态不可建立坐标字段。',path=path+'.'+key,line=1))
                walk(item,path+'.'+key,key)
    # Review status/IDs and paths are metadata; all human observations remain checked.
    walk(plan)
    return rows

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('file',type=Path)
    parser.add_argument('--json',action='store_true',dest='json_mode')
    args=parser.parse_args()
    try:
        text=args.file.read_text(encoding='utf-8-sig')
        rows=validate_plan(json.loads(text)) if args.json_mode else validate_text(text)
    except (OSError,UnicodeError,ValueError) as error:
        print(json.dumps({'status':'ERROR','error':str(error)},ensure_ascii=False));return 2
    print(json.dumps({'status':'FAIL' if rows else 'PASS','findings':rows,
                      'scope':'name/landmark language only; source mapping and geometry require semantic review'},ensure_ascii=False,indent=2))
    return 1 if rows else 0

if __name__=='__main__':raise SystemExit(main())
