"""Offline text checks for generation prompts; never proves rendered video quality."""
from __future__ import annotations
import argparse
import json
import re
from pathlib import Path
from inline_dialogue import VOICE

QUOTES = re.compile(r'“([^”\n]*)”|"([^"\n]*)"|‘([^’\n]*)’')
CJK = re.compile(r'[\u3400-\u4dbf\u4e00-\u9fff]')
EYES = r'(?:眼睛|双眼|眼眸|瞳孔|瞳仁|眼球|眼底|眼中|眼里|眼神|目光|眸子|眼部)'
BRIDGE = r'(?:(?:里|中|内|的|开始|突然|微微|逐渐|随之|持续|实际|真的|正|泛起|透出|闪过|闪着|泛着|含着|带着|绽放|发出|射出|放出|充满|有|一|束|道|丝|点|了|着|明亮|耀眼|蓝色|红色|金色|银色|蓝|红|金|银|希望的|喜悦的|异样的|细小的|微|能量)){0,6}'
REFLECT = re.compile(EYES + BRIDGE + r'(?:反光|反射|倒映|映出|映着|高光|光点|光斑)|'
    r'\b(?:eyes?|pupils?|irises?)\s+(?:\w+\s+){0,2}(?:reflect\w*|mirror\w*|catchlights?)\b|'
    r'\bcatchlights?\b|\b(?:reflections?|highlights?|glints?)\s+(?:in|on)\s+(?:her|his|their|the)\s+eyes?\b', re.I)
GLOW = re.compile(EYES + BRIDGE + r'(?:发光|光芒|亮光|光辉|光彩|光泽|光|亮起|一亮|明亮|闪亮|闪烁|闪耀|发亮|光效)|泪光|'
    r'\b(?:eyes?|pupils?|irises?)\s+(?:(?:begin|begins|start|starts|to|are|is|brightly|suddenly|with|a|hopeful|of)\s+){0,5}(?:glow\w*|shin\w*|sparkl\w*|(?:light|lit)\s+up|brighten\w*|light|emit\s+\w*\s*light)\b|'
    r'\b(?:glowing|shining|sparkling|luminous)\s+(?:eyes?|pupils?|irises?)\b',re.I)
LITERAL = re.compile(r'(?:眼睛|双眼|眼眸|瞳孔|瞳仁)(?:(?:开始|突然|逐渐|持续|实际|真的|同时|的)){0,3}'
    r'(?:发光|发出.{0,4}光|射出.{0,4}光)|\beyes?\s+(?:(?:begin|begins|start|starts|to|are|is|suddenly)\s+){0,4}glow\w*\b',re.I)
STYLE = re.compile(r'二维|二次元|黑白简笔画|简笔画|线稿|白底线条|纸片化|分层头像|平面示意图|信息图|图解画面|插画|动漫|漫画|卡通|'
    r'\b2[- ]?d\b|\b(?:anime|cartoon|illustration|line[- ]art|sketch|cel[- ]shad\w*|flat\s+avatars?)\b',re.I)
TEXT = re.compile(r'字幕|标题卡|字幕卡|时间卡|地点卡|身份标签|悬浮文字|悬浮标签|英文单词|英文标签|叠加文字|头顶文字|'
    r'字样(?=.{0,16}(?:头顶|悬浮|画面上方))|'
    r'\b(?:subtitles?|captions?|intertitles?|title\s+cards?|floating\s+(?:text|labels?)|on[- ]screen\s+titles?)\b',re.I)
DEVICE = re.compile(r'(?:手机|电脑|笔记本|显示器).{0,14}(?:屏幕|显示屏)|(?:屏幕|显示屏).{0,14}(?:手机|电脑|笔记本)|'
    r'\b(?:phone|computer|laptop|monitor)\s+(?:physical\s+)?(?:screen|display)\b',re.I)
TRANSLATION = re.compile(r'中文原文|中文对照|中文译文|中文翻译|中文释义|仅阅读不口播|Chinese\s+(?:translation|gloss|original)',re.I)

def negated(clause, start):
    prefix=clause[:start]
    # Only a nearby, preceding negation applies; a later ban cannot hide a positive instruction.
    return bool(re.search(r'(?:禁止|严禁|不要|不得|不能|避免|无需|不生成|不出现|没有|不|无|勿|\bno\b|\bnot\b|\bwithout\b|\bnever\b)'
                          r'[^，,；;。.!?！？\n]{0,12}$',prefix,re.I))

def eye_evidence_ok(text, start, end, source, evidence):
    for row in evidence:
        if not isinstance(row,dict): continue
        character=row.get('character',''); sq=row.get('source_quote',''); pq=row.get('prompt_quote','')
        if not all(isinstance(x,str) and x.strip() for x in (character,sq,pq)): continue
        if len(sq)>300 or len(pq)>200 or sq not in source: continue
        sm=LITERAL.search(sq); pm=GLOW.search(pq)
        if not sm or not pm or negated(sq,sm.start()) or negated(pq,pm.start()): continue
        # Evidence identifies the glowing subject before its eye event, never a later bystander.
        if character not in sq[:sm.start()] or character not in pq[:pm.start()]: continue
        for occurrence in re.finditer(re.escape(pq),text):
            if occurrence.start()<=start and end<=occurrence.end(): return True
    return False

def validate_content(text, source='', evidence=None):
    evidence=evidence or []
    if not isinstance(evidence,list): raise ValueError('Eye evidence must be a JSON array')
    findings=[]
    def add(code,message,start):
        findings.append(dict(level='ERROR',code=code,message=message,line=text.count('\n',0,start)+1))
    # Mask actual speech / physical screen content, never arbitrary quoted style instructions.
    speech=list(VOICE.finditer(text))
    masked=list(text)
    for quote in QUOTES.finditer(text):
        if CJK.search(quote[0]): add('CHINESE_QUOTED_CONTENT','生成稿引号内不得有中文台词／可读文字；用英文，不附双语。',quote.start())
        prefix=re.split(r'[。；;\n，,]',text[max(0,quote.start()-160):quote.start()])[-1]
        spoken=any(v.start()<=quote.start() and quote.end()<=v.end() for v in speech)
        spoken=spoken or bool(re.search(r'\b(?:says?|said|asks?|whispers?|shouts?)\b[^“”"\n]{0,40}$',prefix,re.I))
        if spoken or DEVICE.search(prefix):
            masked[quote.start():quote.end()]=' '*(quote.end()-quote.start())
    scan=''.join(masked)
    for clause in re.finditer(r'[^。；;\n，,]+',scan):
        body=clause[0];offset=clause.start()
        for pattern,code,msg in [
            (REFLECT,'EYE_REFLECTION','删除眼部反射、倒映、高光等描写；用目光与面部表演。'),
            (STYLE,'NON_LIVE_ACTION_STYLE','抽象空间仍须真人电影实拍；删除线稿、二维／图解等媒介切换。'),
            (TEXT,'GENERATED_OVERLAY_TEXT','不生成字幕／身份／时间标签；仅剧情必要手机或电脑实体屏幕内英文信息例外。'),
            (TRANSLATION,'CHINESE_DIALOGUE_GLOSS','删除中文原文／对照／仅阅读不口播等辅助行。')]:
            for match in pattern.finditer(body):
                if negated(body,match.start()): continue
                if code=='GENERATED_OVERLAY_TEXT' and DEVICE.search(body): continue
                add(code,msg,offset+match.start())
        for match in GLOW.finditer(body):
            if negated(body,match.start()): continue
            start=offset+match.start();end=offset+match.end()
            if not eye_evidence_ok(text,start,end,source,evidence):
                add('UNSOURCED_EYE_GLOW','眼部亮光／修辞不进入生成描述；明确剧情发光需同一人物的源原句与局部证据。',start)
    return findings

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('prompt',type=Path)
    parser.add_argument('--source-script',type=Path)
    parser.add_argument('--eye-glow-evidence',type=Path)
    args=parser.parse_args()
    try:
        text=args.prompt.read_text(encoding='utf-8-sig')
        source=args.source_script.read_text(encoding='utf-8-sig') if args.source_script else ''
        evidence=json.loads(args.eye_glow_evidence.read_text(encoding='utf-8-sig')) if args.eye_glow_evidence else []
        findings=validate_content(text,source,evidence)
    except (OSError,UnicodeError,ValueError) as error:
        print(json.dumps({'status':'ERROR','error':str(error)},ensure_ascii=False));return 2
    print(json.dumps({'status':'FAIL' if findings else 'PASS','findings':findings,
        'scope':'text risk checks only; source meaning, timing and rendered live-action quality require semantic review'},ensure_ascii=False,indent=2))
    return 1 if findings else 0

if __name__=='__main__': raise SystemExit(main())
