#!/usr/bin/env python3
"""Check staging handoff identities, hashes and timing, not image geometry."""
import argparse
import hashlib
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from validate_director_prompt import parse_shots, infer_duration, validate_shots
from validate_staging_language import validate_text, validate_plan


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def check(plan_file, review_file):
    plan_file, review_file = Path(plan_file), Path(review_file)
    plan = json.loads(plan_file.read_text(encoding='utf-8-sig'))
    review = json.loads(review_file.read_text(encoding='utf-8-sig'))
    errors = []
    def require(ok, message):
        if not ok: errors.append(message)
    for label,record in [('plan',plan),('review',review)]:
        errors.extend(f'{label}: {row["code"]} {row.get("path", "")}' for row in validate_plan(record))
    readable=plan.get('blocking_text_file')
    require(isinstance(readable,str) and bool(readable.strip()), 'Missing actual readable staging MD')
    if isinstance(readable,str) and readable.strip():
        readable_path=Path(readable)
        if not readable_path.is_absolute(): readable_path=plan_file.parent/readable_path
        require(readable_path.is_file() and readable_path.suffix.lower()=='.md', 'Readable staging MD missing or invalid')
        if readable_path.is_file():
            require(plan.get('blocking_text_sha256')==sha(readable_path),'Readable staging MD changed or unverified')
            errors.extend('staging MD: '+row['code'] for row in validate_text(readable_path.read_text(encoding='utf-8-sig')))
    require(plan.get('policy') == 'seedance25_episode_blocking_plan_v1', 'Unsupported plan policy')
    require(review.get('policy') == 'seedance25_blocking_prompt_match_v1', 'Unsupported review policy')
    require(review.get('status') == 'PASS', 'Review is not PASS')
    require(review.get('blocking_plan_sha256') == sha(plan_file), 'Plan version changed')
    require(Path(review.get('blocking_plan_file', '')).resolve() == plan_file.resolve(), 'Plan path mismatch')
    require(bool(plan.get('prepared_before_prompt')), 'Missing pre-writing staging declaration (requires human evidence)')
    script = Path(plan['script_file'])
    require(plan.get('script_sha256') == sha(script), 'Script version changed')
    expected = plan.get('expected_segment_ids', [])
    segments = plan.get('segments', [])
    require(bool(expected) and len(expected) == len(set(expected)), 'Missing or duplicate expected segments')
    require([s.get('id') for s in segments] == expected, 'Plan coverage/order mismatch')
    reviews = review.get('segments', [])
    require([s.get('id') for s in reviews] == expected, 'Review coverage/order mismatch')
    lookup = {s.get('id'): s for s in reviews}
    for segment in segments:
        sid = segment['id']
        report = lookup.get(sid, {})
        prompt = Path(segment['source_prompt_file'])
        text = prompt.read_text(encoding='utf-8-sig')
        errors.extend(f'{sid}: {row["code"]}' for row in validate_text(text))
        require(report.get('source_sha256') == sha(prompt), f'{sid}: prompt version changed')
        require(report.get('status') == 'PASS', f'{sid}: incomplete review')
        target = segment.get('actual_duration')
        require(isinstance(target, (int, float)) and target > 0, f'{sid}: invalid duration')
        require(target == infer_duration(text), f'{sid}: header/plan duration mismatch')
        shots = parse_shots(text)
        errors.extend(f'{sid}: {f.code}' for f in validate_shots(shots, target) if f.level == 'ERROR')
        actors = set(segment.get('opening_state', {})) | set(segment.get('exit_state', {}))
        checks = report.get('character_checks', [])
        require({c.get('name') for c in checks} == actors and len(checks) == len(actors), f'{sid}: actor review coverage mismatch')
        for c in checks:
            for key in ('opening_match', 'movement_match', 'exit_match'):
                observation = c.get(key, {})
                require(observation.get('status') == 'PASS' and bool(str(observation.get('observation', '')).strip()), f'{sid}/{c.get("name")}: missing {key} observation')
        movements = segment.get('movements', [])
        event_checks = report.get('movement_checks', [])
        require([c.get('id') for c in event_checks] == [m.get('id') for m in movements], f'{sid}: movement review coverage mismatch')
        shot_map = {s.number: s for s in shots}
        for movement, assessment in zip(movements, event_checks):
            mid = movement.get('id')
            window = movement.get('time', [])
            require(movement.get('actor') in actors, f'{sid}/{mid}: unknown actor')
            require(all(str(movement.get(k, '')).strip() for k in ('trigger', 'start', 'route', 'turn', 'end')), f'{sid}/{mid}: incomplete movement chain')
            valid_window = len(window) == 2 and isinstance(target, (int, float)) and 0 <= window[0] < window[1] <= target
            require(valid_window, f'{sid}/{mid}: invalid movement window')
            numbers = movement.get('shot_numbers', [])
            linked = [shot_map[n] for n in numbers if n in shot_map]
            require(bool(numbers) and len(linked) == len(numbers) and len(numbers) == len(set(numbers)), f'{sid}/{mid}: invalid supporting shot IDs')
            if valid_window and linked:
                require(all(s.start < window[1] and s.end > window[0] for s in linked), f'{sid}/{mid}: supporting shot outside movement window')
                require(min(s.start for s in linked) <= window[0] and max(s.end for s in linked) >= window[1], f'{sid}/{mid}: incomplete temporal coverage')
            require(assessment.get('status') == 'PASS' and bool(str(assessment.get('observation', '')).strip()), f'{sid}/{mid}: missing movement observation')
    return errors


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', required=True, type=Path)
    parser.add_argument('--review', required=True, type=Path)
    args = parser.parse_args()
    try:
        errors = check(args.plan, args.review)
    except (OSError, ValueError, KeyError, TypeError) as exc:
        errors = [f'Invalid or inaccessible record: {exc}']
    print(json.dumps({'status': 'FAIL' if errors else 'PASS', 'errors': errors,
                      'scope': 'file identity, versions, timing and supplied observations; no automatic semantic/image proof'}, ensure_ascii=False, indent=2))
    return 1 if errors else 0


if __name__ == '__main__':
    raise SystemExit(main())
