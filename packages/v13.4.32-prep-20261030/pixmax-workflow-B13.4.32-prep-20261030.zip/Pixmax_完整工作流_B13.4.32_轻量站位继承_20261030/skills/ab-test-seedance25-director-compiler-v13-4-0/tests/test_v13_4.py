import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
import validate_director_prompt as v
import validate_blocking_handoff as h


def prompt(seconds=30, shots=12, filler=0):
    rows = [f'# 测试\n总时长：{seconds}秒｜画幅：9:16｜构图模式\n',
            '## 1. 人物指定\n**Seren：** 站在树旁，胸口朝Alaric。\n',
            '## 2. 场景指定\n**禁林：** 日间树根与林路。\n',
            '## 3. 道具指定\n本段无剧情道具。\n',
            '## 4. 时间线镜头设计\n**整段剧情概述：** Seren与Alaric对峙。\n']
    for i in range(shots):
        a, b = i * seconds / shots, (i + 1) * seconds / shots
        rows.append(f'### 镜头{i+1:02d}｜{a:g}–{b:g}秒｜Seren近景｜固定\n**构图：** Seren正面，摄影机在右手边。\n**画面内容：** Seren保持视线。\n')
    # Synthetic units for numeric-budget tests, not a narrative example.
    rows.append('## 5. 声音安排\n林间环境声。\n## 6. 输出要求\n无字幕。\n' + '测' * filler)
    return ''.join(rows)


class TimingAndBudget(unittest.TestCase):
    def test_positive_short_shots_are_allowed(self):
        for length in (0.3, 0.8, 1.49, 1.5, 1.51):
            with self.subTest(length=length):
                found = v.validate_shots(v.parse_shots(prompt(length, 1)), length)
                self.assertFalse(found)

    def test_non_positive_shot_and_gap_still_fail(self):
        text = prompt(30, 2)
        zero = text.replace('0–15秒', '0–0秒')
        gap = text.replace('15–30秒', '16–30秒')
        self.assertIn('TIME_RANGE', {f.code for f in v.validate_shots(v.parse_shots(zero), 30)})
        self.assertIn('TIMELINE_GAP', {f.code for f in v.validate_shots(v.parse_shots(gap), 30)})

    def test_sixteen_shots_fit_thirty_seconds(self):
        self.assertFalse(v.validate_shots(v.parse_shots(prompt(30, 16)), 30))

    def test_short_package_is_not_forced_to_twelve_shots(self):
        text = prompt(15, 8)
        found = v.validate_v11(text, v.parse_shots(text), 15)
        self.assertNotIn('SHOT_COUNT_GUIDE', {f.code for f in found})

    def test_default_length_does_not_limit_detailed_shot_prose(self):
        for seconds in (12, 15, 20, 27, 30):
            for profile, base in (('normal', 5500), ('enhanced', 7000)):
                with self.subTest(seconds=seconds, profile=profile):
                    text = prompt(seconds, max(1, round(seconds / 2.5)))
                    target = round(base * seconds / 30)
                    text += '测' * (target - v.length_metrics(text)['total'])
                    found = v.validate_v11(text, v.parse_shots(text), seconds, profile=profile)
                    self.assertNotIn('LENGTH_BUDGET', {f.code for f in found})
                    shortened = text[:-int(target * .1)]
                    self.assertNotIn('LENGTH_BUDGET', {f.code for f in v.validate_v11(shortened, v.parse_shots(shortened), seconds, profile=profile)})
                    expanded = text + '测' * target * 3
                    self.assertNotIn('LENGTH_BUDGET', {f.code for f in v.validate_v11(expanded, v.parse_shots(expanded), seconds, profile=profile)})

    def test_explicit_budget_and_shot_limit_override(self):
        text = prompt(30, 12)
        total = v.length_metrics(text)['total']
        found = v.validate_v11(text, v.parse_shots(text), 30, length_target=total, max_shots=11)
        self.assertIn('SHOT_LIMIT', {f.code for f in found})
        self.assertNotIn('LENGTH_BUDGET', {f.code for f in found})

    def test_duration_mismatch_remains_error(self):
        self.assertIn('TOTAL_DURATION', {f.code for f in v.validate_shots(v.parse_shots(prompt(27)), 30)})


class SourcePreservation(unittest.TestCase):
    def setUp(self):
        root = Path(__file__).resolve().parents[1] / 'assets/examples'
        self.text = (root/'e01_hand_to_face.prompt.md').read_text(encoding='utf-8')
        self.source = json.loads((root/'e01_dialogue.json').read_text(encoding='utf-8'))

    def test_original_dialogue_keeps_matching(self):
        self.assertNotIn('DIALOGUE_SOURCE_MISMATCH', {f.code for f in v.validate(self.text, source_dialogue=self.source)})

    def test_changed_words_are_rejected(self):
        changed = self.text.replace('：“就走。”', '：“走。”')
        self.assertNotEqual(self.text, changed)
        self.assertIn('DIALOGUE_SOURCE_MISMATCH', {f.code for f in v.validate(changed, source_dialogue=self.source)})

    def test_changed_speaker_is_rejected(self):
        changed = self.text.replace('周远（画外对白）', '林夕（画外对白）')
        self.assertNotEqual(self.text, changed)
        self.assertIn('DIALOGUE_SOURCE_MISMATCH', {f.code for f in v.validate(changed, source_dialogue=self.source)})

    def test_no_section_ratio_gate_is_restored(self):
        text = self.text.replace('**整段剧情概述：**', '**整段剧情概述：** ' + '概述' * 1000)
        self.assertFalse({'TIMELINE_DENSITY','OVERVIEW_TOO_LONG'} & {f.code for f in v.validate(text)})


class HandoffVersions(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.script = self.root/'script.md'
        self.script.write_text('Seren在树旁向Alaric转身。', encoding='utf-8')
        self.readable = self.root/'站位走位.md'
        self.readable.write_text('Seren站在树旁，身体朝向Alaric，双脚保持原地，随后转头看向Alaric。',encoding='utf-8')
        self.prompt = self.root/'prompt.md'
        self.prompt.write_text(prompt(30), encoding='utf-8')
        self.plan_file, self.review_file = self.root/'plan.json', self.root/'review.json'
        self.plan = {'policy':'seedance25_episode_blocking_plan_v1','prepared_before_prompt':True,
                     'blocking_text_file':str(self.readable),'blocking_text_sha256':h.sha(self.readable),
                     'script_file':str(self.script),'script_sha256':h.sha(self.script),
                     'expected_segment_ids':['B01'],'segments':[{'id':'B01','actual_duration':30,
                     'source_prompt_file':str(self.prompt), 'opening_state':{'Seren':'树旁朝Alaric'},
                     'exit_state':{'Seren':'树旁朝Alaric'},'movements':[{'id':'M01','actor':'Seren',
                     'time':[2.5,5],'trigger':'Alaric说话','start':'树旁','route':'原位转头',
                     'turn':'胸口保持、脸转向Alaric','end':'树旁看Alaric','shot_numbers':[2]}]}]}
        self.review = {'policy':'seedance25_blocking_prompt_match_v1','status':'PASS',
                       'blocking_plan_file':str(self.plan_file),'segments':[{'id':'B01','status':'PASS',
                       'source_sha256':h.sha(self.prompt),'character_checks':[{'name':'Seren',
                       **{k:{'status':'PASS','observation':'人工核对树旁位置与原位转头过程一致。'}
                          for k in ('opening_match','movement_match','exit_match')}}],
                       'movement_checks':[{'id':'M01','status':'PASS','observation':'第2镜承接转头时间窗口。'}]}]}
        self.save()

    def save(self):
        self.plan_file.write_text(json.dumps(self.plan,ensure_ascii=False),encoding='utf-8')
        self.review['blocking_plan_sha256']=h.sha(self.plan_file)
        self.review_file.write_text(json.dumps(self.review,ensure_ascii=False),encoding='utf-8')

    def tearDown(self): self.temp.cleanup()

    def test_current_versions_pass(self): self.assertEqual([],h.check(self.plan_file,self.review_file))

    def test_modified_prompt_invalidates_review(self):
        self.prompt.write_text(prompt(27),encoding='utf-8')
        errors=h.check(self.plan_file,self.review_file)
        self.assertTrue(any('prompt version changed' in e for e in errors))
        self.assertTrue(any('duration mismatch' in e for e in errors))

    def test_modified_plan_invalidates_review(self):
        self.plan['segments'][0]['opening_state']['Seren']='改到Alaric身后'
        self.plan_file.write_text(json.dumps(self.plan,ensure_ascii=False),encoding='utf-8')
        self.assertTrue(any('Plan version changed' in e for e in h.check(self.plan_file,self.review_file)))

    def test_missing_actor_review_is_blocked(self):
        self.review['segments'][0]['character_checks']=[]
        self.save()
        self.assertTrue(any('actor review coverage' in e for e in h.check(self.plan_file,self.review_file)))

    def test_orphan_movement_is_blocked(self):
        self.plan['segments'][0]['movements'][0]['shot_numbers']=[99]
        self.save()
        self.assertTrue(any('supporting shot IDs' in e for e in h.check(self.plan_file,self.review_file)))

    def test_unreviewed_observation_is_blocked(self):
        self.review['segments'][0]['character_checks'][0]['movement_match']['status']='UNCERTAIN'
        self.save()
        self.assertTrue(any('movement_match' in e for e in h.check(self.plan_file,self.review_file)))


if __name__ == '__main__': unittest.main()
