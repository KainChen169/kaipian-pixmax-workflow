"""New prose fields must retain old source/time/space checks without label quotas."""
import json
from pathlib import Path
import unittest
import validate_director_prompt as v

ROOT = Path(__file__).resolve().parents[1]
TEXT = (ROOT/'assets/examples/natural_performance.prompt.md').read_text()
SOURCE = json.loads((ROOT/'assets/examples/live_action_opening.dialogue.json').read_text())

class NaturalPerformance(unittest.TestCase):
    def errors(self, text=TEXT):
        return [f for f in v.validate(text, source_dialogue=SOURCE) if f.level in ('ERROR', 'WARNING')]

    def test_new_example_passes_without_composition_or_background_label(self):
        self.assertNotIn('**构图：**', TEXT)
        self.assertNotIn('背景：', TEXT)
        self.assertFalse(self.errors(), [f.render() for f in self.errors()])

    def test_missing_guidance_or_empty_fields_fail(self):
        for before, after in [('**导演指导：**', '**指导备注：**'),
                              ('**画面：**', '**其他说明：**'),
                              ('**表演：**', '**其他说明：**')]:
            self.assertTrue(self.errors(TEXT.replace(before, after, 1)))

    def test_action_variants_and_multiline_prose_work(self):
        for label in ('动作', '动作与表演'):
            changed=TEXT.replace('**表演：**', f'**{label}：**\n')
            self.assertFalse(self.errors(changed))

    def test_duplicate_and_mixed_fields_fail(self):
        for extra in ('**画面：** 重复。\n', '**表演：** 重复。\n',
                      '**动作：** 重复。\n', '**构图：** 重复。\n'):
            self.assertTrue(self.errors(TEXT.replace('### 镜头02', extra+'### 镜头02')))

    def test_missing_added_speaker_reordered_and_timing_dialogue_fail(self):
        for before,after in [('I leave tomorrow.', ''),
                             ('I leave tomorrow.', 'I leave tomorrow. Come with me.'),
                             ('周远（现场对白）','陈宁（现场对白）'),
                             ('I leave tomorrow.','Look at me.'),
                             ('[0–3秒，镜内]', '[0–4秒，镜内]')]:
            self.assertTrue(self.errors(TEXT.replace(before,after,1)))

    def test_dialogue_in_visual_field_is_not_invisible_to_source_check(self):
        extra='[0–1秒，镜内] 周远（现场对白）对林夕说：“Come here.”'
        changed=TEXT.replace('**画面：**', '**画面：** '+extra, 1)
        self.assertTrue(v.validate_inline_dialogue(changed, SOURCE))

    def test_staging_scale_timeline_still_checked(self):
        start=TEXT.index('## 4. 人物开场站位'); end=TEXT.index('## 5. 时间线镜头设计')
        for changed in [TEXT[:start]+'## 4. 人物开场站位\n'+TEXT[end:],
                        TEXT.replace('景别：上半身近景','景别：过肩',1),
                        TEXT.replace('镜头02｜3–4秒','镜头02｜3.5–4秒')]:
            self.assertTrue(self.errors(changed))

    def test_metrics_exclude_guidance_and_dialogue(self):
        original=v.shot_detail_metrics(TEXT)
        enlarged=TEXT.replace('**导演指导：**', '**导演指导：**'+'指导文字'*300, 1)
        self.assertNotEqual(TEXT, enlarged)
        self.assertEqual(original,v.shot_detail_metrics(enlarged))
        self.assertEqual([3,4,8],[s.end for s in v.parse_shots(TEXT)])

    def test_old_format_unchanged_and_still_valid(self):
        legacy=(ROOT/'assets/examples/live_action_opening.prompt.md').read_text()
        self.assertFalse(self.errors(legacy))

    def test_medium_and_wide_dialogue_are_valid_without_closeup_exception(self):
        # The same source speech and timeline can use a relational or environmental view.
        start=TEXT.index('**画面：**')
        end=TEXT.index('**表演：**', start)
        for scale, picture in [
            ('中景', '从入口侧平视双人腰部以上，林夕在左、周远在右，身体相对。两人的距离与各自肩背姿态同时可读，台阶在周远身后；陈宁保持廊柱旁的画外位置。'),
            ('全景', '从入口侧拍大厅中的三人全身，林夕在左前景、周远在右中景，陈宁留在右后方廊柱旁。两人之间的空地与高处台阶形成纵深，周远面向林夕说话，画面呈现平静对话中的疏离。'),
        ]:
            changed=(TEXT[:start]+'**画面：** '+picture+'\n'+TEXT[end:]).replace('景别：上半身近景', '景别：'+scale, 1)
            self.assertFalse(self.errors(changed))
            self.assertEqual([3,4,8],[s.end for s in v.parse_shots(changed)])

    def test_story_rejection_is_not_banned_negative_language(self):
        changed=TEXT.replace('离开的时间突然变得具体，林夕原本等待解释的神情僵了一下，目光仍追着周远，像是还想把话谈下去。',
                             '林夕没有回应他的决定，仍望着周远，等他解释。')
        self.assertNotEqual(TEXT, changed)
        self.assertFalse(self.errors(changed))

    def test_negative_source_dialogue_keeps_exact_words(self):
        changed=TEXT.replace('I leave tomorrow.', "I won't leave.")
        source=json.loads(json.dumps(SOURCE))
        # Change the independent source too; literal negative speech remains valid.
        def replace_value(item):
            if isinstance(item, dict): return {k: replace_value(value) for k,value in item.items()}
            if isinstance(item, list): return [replace_value(value) for value in item]
            return "I won't leave." if item=='I leave tomorrow.' else item
        findings=v.validate(changed, source_dialogue=replace_value(source))
        self.assertFalse([f for f in findings if f.level in ('ERROR','WARNING')])

if __name__=='__main__':
    unittest.main()
