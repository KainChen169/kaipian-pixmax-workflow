import unittest
from pathlib import Path
from validate_staging_language import validate_text,validate_plan
import validate_director_prompt as director
import validate_blocking_handoff as handoff
import test_v13_4 as original_tests

def codes(text):return {r['code'] for r in validate_text(text)}

class StagingLanguage(unittest.TestCase):
    def test_real_shape_and_vitamin_terms_pass(self):
        for text in ('Lucian坐在L形沙发靠窗的一端。', 'Mara沿T形走廊走向诊室。',
                     'Mara右手握着维生素C药瓶。', 'Mara坐在U形沙发旁。',
                     'Mara经过S形通道。', 'Mara holds vitamin C by the L-shaped sofa.'):
            with self.subTest(text=text):self.assertFalse(validate_text(text))

    def test_lexical_exception_does_not_hide_another_alias(self):
        for text in ('Mara从A走到L形沙发。', '维生素C药瓶放在C点。',
                     'Lucian从T形走廊走到T点。', 'Mara在L形区域停下。',
                     'Mara走到维生素C点。', 'L形沙发旁的女主停在B。'):
            with self.subTest(text=text):self.assertIn('SPATIAL_ALIAS',codes(text))

    def test_json_lexical_terms_pass_but_route_alias_still_fails(self):
        self.assertFalse(validate_plan({'opening_state':{'Lucian':'坐在L形沙发上'},
                                       'props':[{'description':'维生素C药瓶'}]}))
        self.assertTrue(validate_plan({'movements':[{'route':'从A走向T形走廊'}]}))

    def test_main_api_preserves_normal_letter_words(self):
        self.assertNotIn('SPATIAL_ALIAS',{f.code for f in director.validate('Lucian坐在L形沙发旁，Mara拿起维生素C药瓶。')})

    def test_real_source_names_and_landmarks_pass(self):
        text='Mara已经穿过起居间通往工作间的门，Lucian仍坐在处理伤口的椅子上。Mara绕过门边矮柜，在工作桌靠窗的一端停下，身体面向Lucian。'
        self.assertFalse(validate_text(text))

    def test_roles_fail_in_all_prompt_sections(self):
        for section in ('人物指定','人物开场站位','整段剧情概述','镜头主体','构图','画面内容','背景','声音安排'):
            for label in ('女主','女反','男主','男二','女配'):
                with self.subTest(section=section,label=label):
                    self.assertIn('CHARACTER_ALIAS',codes(section+'：'+label+'停在门口。'))

    def test_letter_references_from_reported_failure_fail(self):
        for text in ('Lucian坐C穿上衣。','Mara已过A，Lucian仍C。','Lucian自A跟进，刺客从R翻出。','H短抱。','前门D，工作桌T，矮柜K。'):
            with self.subTest(text=text):self.assertIn('SPATIAL_ALIAS',codes(text))

    def test_lowercase_and_anonymous_chinese_points_fail(self):
        for text in ('林夕走到a点。','甲站在乙身后。','停在点位一。','周远站在ANCHOR_ENTRY。'):
            with self.subTest(text=text):self.assertIn('SPATIAL_ALIAS',codes(text))

    def test_coordinates_and_systems_fail(self):
        for text in ('前门D=(1.2,0)。','工作间x6—10、y1—5。','Mara仰倒(7.5,2.8)。','以门口为原点建立坐标系。','所有坐标为设计假设。'):
            with self.subTest(text=text):self.assertIn('NUMERIC_COORDINATES',codes(text))

    def test_steps_timing_dimensions_and_names_are_preserved(self):
        self.assertFalse(codes('Lucian在门内约两步处停下，左手保持原位。镜头01｜0–3秒，9:16竖屏，1920×1080，30fps。'))

    def test_unnamed_source_characters_are_not_given_false_names(self):
        self.assertFalse(codes('刺客右手持刀，门口守卫面向工作桌，医生站在病床旁。'))

    def test_only_actual_spoken_text_is_protected(self):
        self.assertFalse(codes('Alice（现场对白）轻声说：“I am the heroine in plan A.” Alice仍站在门边。'))
        self.assertIn('CHARACTER_ALIAS',codes('“女主”站在门边。'))
        self.assertIn('CHARACTER_ALIAS',codes('女主（现场对白）轻声说：“Stay.”'))

    def test_english_name_initials_are_not_split_into_aliases(self):
        self.assertFalse(codes('Avery看向Camille，Julian站在门框旁。'))

    def test_main_prompt_api_also_rejects_aliases(self):
        self.assertIn('CHARACTER_ALIAS',{f.code for f in director.validate('女反走到门口。')})
        self.assertIn('SPATIAL_ALIAS',{f.code for f in director.validate('Mara已过A。')})

    def test_json_tracking_metadata_is_not_staging_text(self):
        value={'expected_segment_ids':['B01'],'segments':[{'id':'B01','scene':'SC01','actual_duration':3,
            'source_prompt_file':'C:/work/A/prompt.md','opening_state':{'Mara':'站在门口'},
            'exit_state':{'Mara':'站在工作桌旁'},'movements':[{'id':'M01','actor':'Mara','time':[0,3],
                'start':'门口','route':'沿桌边经过','end':'工作桌旁','shot_numbers':[1]}]}]}
        self.assertFalse(validate_plan(value))

    def test_json_actor_keys_locations_routes_and_review_observations_checked(self):
        for value in ({'opening_state':{'A':'门口'}},{'exit_state':{'女主':'桌边'}},
                      {'opening_state':{'Mara':'已过A'}},{'movements':[{'route':'从C到A'}]},
                      {'character_checks':[{'name':'女反','opening_match':{'observation':'她在A点'}}]}):
            with self.subTest(value=value):self.assertTrue(validate_plan(value))

    def test_json_numeric_spatial_fields_rejected(self):
        for state in ({'position':[1.2,0]},{'x':1,'y':2}):
            self.assertTrue(validate_plan({'opening_state':{'Mara':state}}))

class HandoffStagingText(unittest.TestCase):
    def fixture(self):
        case=original_tests.HandoffVersions(methodName='test_current_versions_pass');case.setUp()
        self.addCleanup(case.tearDown)
        return case

    def test_missing_readable_md_blocks_handoff(self):
        case=self.fixture();del case.plan['blocking_text_file'];case.save()
        self.assertTrue(any('readable staging MD' in e for e in handoff.check(case.plan_file,case.review_file)))

    def test_readable_md_alias_blocked_even_with_correct_hash(self):
        case=self.fixture();case.readable.write_text('Seren从A点走到B点。',encoding='utf-8')
        case.plan['blocking_text_sha256']=handoff.sha(case.readable);case.save()
        self.assertTrue(any('staging MD: SPATIAL_ALIAS' in e for e in handoff.check(case.plan_file,case.review_file)))

    def test_readable_md_version_is_checked(self):
        case=self.fixture();case.readable.write_text('Seren站在门口。',encoding='utf-8')
        self.assertTrue(any('MD changed' in e for e in handoff.check(case.plan_file,case.review_file)))

    def test_json_semantic_alias_blocks_handoff(self):
        case=self.fixture();case.plan['segments'][0]['opening_state']['Seren']='站在C点';case.save()
        self.assertTrue(any('SPATIAL_ALIAS' in e for e in handoff.check(case.plan_file,case.review_file)))

if __name__=='__main__':unittest.main()
