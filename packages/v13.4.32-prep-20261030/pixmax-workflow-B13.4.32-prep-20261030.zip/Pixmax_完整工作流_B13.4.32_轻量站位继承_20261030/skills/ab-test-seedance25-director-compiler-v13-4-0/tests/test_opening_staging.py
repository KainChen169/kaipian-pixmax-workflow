import sys
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import validate_director_prompt as v

PROMPT = """# 多人大厅空间测试
总时长：8秒｜画幅：9:16竖屏｜构图模式
## 1. 人物指定
**林夕：** 清醒，紧张而克制。
**周远：** 态度坚决。
**陈宁：** 安静观察。
## 2. 场景指定
**大厅｜日｜内：** 侧窗冷光照入，入口保留柔和暗部。
## 3. 道具指定
本段无剧情道具。
## 4. 人物开场站位
摄影机从入口朝台阶拍摄。林夕在前景左侧，距门槛一步；周远在她前方约三步的中景右侧，距台阶两步，二人身体相对、目光看向对方。陈宁在后景右侧廊柱旁，距周远右后方约两步，身体朝向二人，错开周远不遮挡。三人原位持续。
## 5. 时间线镜头设计
**整段剧情概述：** 周远告知离开决定，林夕克制回应。
### 镜头01｜0–1秒｜景别：全景｜周远作出决定｜固定
**构图：** 入口朝台阶的平视全景，全程三人全身可见。前景左侧林夕、中景右侧周远、后景右侧陈宁相互错开。背景：台阶与廊柱，陈宁在柱旁观察。
**画面内容：** 周远留在原位，林夕目光落稳，陈宁原位观察；两人闭口。\n### 镜头02｜1–2秒｜景别：面部特写｜林夕承接压力｜固定\n**构图：** 林夕面部为主体，背景：入口的虚化色块。\n**画面内容：** 林夕保持目光，呼吸稍停后自然继续，闭口。\n### 镜头03｜2–5秒｜景别：上半身近景｜周远说出决定｜固定\n**构图：** 周远胸口以上可见，背景：台阶侧的虚化廊柱。\n**画面内容：** [0–3秒，镜内] 周远（现场对白）平静对林夕说：“我明天就走。”
### 镜头04｜5–8秒｜景别：上半身近景｜林夕回应｜固定
**构图：** 摄影机在周远右肩后反打林夕，林夕胸部以上可见。背景：林夕后方为入口与门侧墙面，周远的窄肩缘为前景，陈宁位于该镜取景之外。
**画面内容：** [0–3秒，镜内] 林夕（现场对白）克制地对周远说：“看着我。”林夕保持目光，身体没有移动。
## 6. 声音安排
室内轻微环境声。
## 7. 输出要求
无字幕、无水印，保留对白与环境声。
"""
SOURCE = [{"speaker": "周远", "text": "我明天就走。"}, {"speaker": "林夕", "text": "看着我。"}]

def findings(text):
    return v.validate(text, source_dialogue=SOURCE, length_target=v.length_metrics(text)["total"])

def codes(text): return {f.code for f in findings(text)}

class OpeningStaging(unittest.TestCase):
    def test_complete_prompt_preserves_timing_and_source(self):
        self.assertFalse([f.render() for f in findings(PROMPT) if f.level in ("ERROR", "WARNING")])
        self.assertEqual([1, 2, 3, 4], [s.number for s in v.parse_shots(PROMPT)])
        self.assertIn("室内轻微环境声", v.role_section(PROMPT, "audio"))
        self.assertIn("距门槛一步", v.role_section(PROMPT, "state"))

    def test_nonwide_and_changing_opening_not_mechanically_rejected(self):
        for scale in ("上半身近景", "中景", "全景→面部特写", "全景到近景", "远景"):
            with self.subTest(scale=scale):
                self.assertNotIn("OPENING_WIDE", codes(PROMPT.replace("景别：全景", "景别："+scale)))

    def test_readable_large_wide_allowed(self):
        self.assertNotIn("OPENING_WIDE", codes(PROMPT.replace("景别：全景", "景别：大全景")))

    def test_later_closeup_allowed(self):
        self.assertNotIn("OPENING_WIDE", codes(PROMPT.replace("景别：上半身近景", "景别：面部特写")))

    def test_each_shot_background_required(self):
        for old in ("背景：台阶与廊柱，陈宁在柱旁观察。", "背景：林夕后方为入口与门侧墙面，周远的窄肩缘为前景，陈宁位于该镜取景之外。"):
            with self.subTest(background=old):
                found = [f for f in findings(PROMPT.replace(old, "")) if f.code == "SHOT_BACKGROUND_MISSING"]
                self.assertEqual(1, len(found))

    def test_empty_background_rejected(self):
        self.assertIn("SHOT_BACKGROUND_MISSING", codes(PROMPT.replace("背景：台阶与廊柱，陈宁在柱旁观察。", "背景：")))

    def test_quoted_background_does_not_satisfy_field(self):
        self.assertIn("SHOT_BACKGROUND_MISSING", codes(PROMPT.replace("背景：台阶与廊柱，陈宁在柱旁观察。", "引用对白：“背景：台阶。”")))

    def test_empty_staging_rejected(self):
        a, rest = PROMPT.split("## 4. 人物开场站位")
        rest = rest[rest.index("## 5."):]
        self.assertIn("OPENING_STAGING_EMPTY", codes(a+"## 4. 人物开场站位\n"+rest))

    def test_wrong_section_order_rejected_without_losing_dialogue(self):
        changed = PROMPT.replace("## 4. 人物开场站位", "## 5. 人物开场站位").replace("## 5. 时间线镜头设计", "## 4. 时间线镜头设计")
        self.assertIn("HEADING_NUMBER", codes(changed))
        self.assertNotIn("DIALOGUE_SOURCE_MISMATCH", codes(changed))

    def test_legacy_parse_is_preserved_but_not_new_style_pass(self):
        a, rest = PROMPT.split("## 4. 人物开场站位")
        rest = rest[rest.index("## 5."):]
        for before, after in ((5,4),(6,5),(7,6)):
            rest=rest.replace(f"## {before}.", f"## {after}.")
        legacy=a+rest
        self.assertEqual(4, len(v.parse_shots(legacy)))
        self.assertIn("LEGACY_ASSET_LAYOUT", codes(legacy))
        self.assertNotIn("DIALOGUE_SOURCE_MISMATCH", codes(legacy))

    def test_source_change_still_rejected_in_seven_sections(self):
        self.assertIn("DIALOGUE_SOURCE_MISMATCH", codes(PROMPT.replace("我明天就走。", "我现在就走。")))
        self.assertIn("DIALOGUE_SOURCE_MISMATCH", codes(PROMPT.replace("周远（现场对白）", "陈宁（现场对白）")))

    def test_staging_leak_requires_review(self):
        changed = PROMPT.replace("**周远：** 态度坚决。", "**周远：** 站在台阶前两步，身体朝向林夕。")
        self.assertIn("STAGING_IN_DESIGNATION", codes(changed))

    def test_merged_mode_keeps_background_and_dialogue(self):
        changed=PROMPT.replace("｜构图模式", "｜无独立构图栏模式")
        import re
        changed=re.sub(r"\*\*构图：\*\* (.*?)\n\*\*画面内容：\*\* ", r"**画面内容：** \1\n", changed)
        self.assertFalse([f.render() for f in findings(changed) if f.level in ("ERROR", "WARNING")])

if __name__ == "__main__": unittest.main()
