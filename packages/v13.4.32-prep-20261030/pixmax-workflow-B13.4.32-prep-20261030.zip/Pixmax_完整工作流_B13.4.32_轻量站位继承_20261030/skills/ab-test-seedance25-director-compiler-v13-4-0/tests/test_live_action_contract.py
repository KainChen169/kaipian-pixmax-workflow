import unittest
import subprocess
import sys
import tempfile
from pathlib import Path
from validate_live_action_prompt import validate_content

def codes(text,source='',evidence=None):
    return {f['code'] for f in validate_content(text,source,evidence)}

class LiveActionContent(unittest.TestCase):
    def test_chinese_instructions_with_english_speech_are_allowed(self):
        self.assertFalse(codes('真人面部保持自然皮肤纹理。Camille（现场对白）低声说：“The food is here.”'))

    def test_all_spoken_channels_reject_chinese(self):
        for channel in ('现场对白','画外对白','内心旁白','旁白'):
            with self.subTest(channel=channel):
                self.assertIn('CHINESE_QUOTED_CONTENT',codes(f'Camille（{channel}）说：“吃的到了。”'))

    def test_chinese_gloss_is_not_a_silent_exemption(self):
        self.assertIn('CHINESE_DIALOGUE_GLOSS',codes('“The food is here.” 中文原文对照，仅阅读不口播：（吃的到了。）'))

    def test_chinese_without_gloss_label_still_fails(self):
        self.assertIn('CHINESE_QUOTED_CONTENT',codes('“The food is here.”（“吃的到了。”）'))

    def test_eye_metaphors_fail(self):
        for text in ('她眼里有光。','Camille眼神一亮。','眼底闪过希望的光。','Her eyes sparkle.'):
            with self.subTest(text=text): self.assertIn('UNSOURCED_EYE_GLOW',codes(text))

    def test_eye_reflection_and_catchlight_fail(self):
        for text in ('她眼中反射火焰。','眼睛的微反光稳定。','眼底能量反射。','Her eyes reflect fire.','Add a catchlight.'):
            with self.subTest(text=text): self.assertIn('EYE_REFLECTION',codes(text))

    def test_gaze_toward_a_luminous_prop_is_not_eye_emission(self):
        self.assertFalse(codes('她的眼睛看向发光的剑。剑火映在近处石面。'))

    def test_actual_eye_glow_needs_source_and_local_evidence(self):
        prompt='Alice眼睛发出蓝光。Bob保持注视。'
        source='Alice眼睛发出蓝光。'
        evidence=[dict(character='Alice',source_quote=source,prompt_quote=source)]
        self.assertIn('UNSOURCED_EYE_GLOW',codes(prompt,source))
        self.assertFalse(codes(prompt,source,evidence))

    def test_metaphor_or_negation_is_not_source_authorization(self):
        for source in ('Alice眼里有光。','Alice眼睛不发光。'):
            evidence=[dict(character='Alice',source_quote=source,prompt_quote='Alice眼睛发光。')]
            self.assertIn('UNSOURCED_EYE_GLOW',codes('Alice眼睛发光。',source,evidence))

    def test_source_for_one_character_does_not_authorize_another(self):
        source='Alice眼睛发光。';prompt='Bob眼睛发光。'
        evidence=[dict(character='Bob',source_quote=source,prompt_quote=prompt)]
        self.assertIn('UNSOURCED_EYE_GLOW',codes(prompt,source,evidence))

    def test_allowed_glow_does_not_waive_unrelated_reflections(self):
        source='Alice眼睛发光。';prompt=source+'Bob眼中反射金光。'
        ev=[dict(character='Alice',source_quote=source,prompt_quote=source)]
        self.assertIn('EYE_REFLECTION',codes(prompt,source,ev))

    def test_screenshot_style_is_rejected(self):
        prompt='进入白底线稿意识空间。两个二维分层头像并列。英文GODDESS字样固定在头顶。'
        found=codes(prompt)
        self.assertIn('NON_LIVE_ACTION_STYLE',found)
        self.assertIn('GENERATED_OVERLAY_TEXT',found)

    def test_photoreal_abstract_space_keeps_fantasy(self):
        self.assertFalse(codes('真人演员站在有体积与接触阴影的白色意识空间。狼形幻象保留毛发、遮挡与透视，摄影机绕移产生真实视差。'))

    def test_intertitles_are_rejected_even_when_english(self):
        for text in ('字幕显示“Three days later”。','画面叠加文字“GODDESS”。','Add a title card: "Three days later".'):
            with self.subTest(text=text): self.assertIn('GENERATED_OVERLAY_TEXT',codes(text))

    def test_actual_phone_and_computer_screen_english_exception(self):
        self.assertFalse(codes('手机屏幕显示英文字幕“The food is here”。'))
        self.assertFalse(codes('The computer screen shows captions: "Message received".'))

    def test_phone_in_scene_does_not_waive_overlay(self):
        self.assertIn('GENERATED_OVERLAY_TEXT',codes('她握住手机，空中出现字幕“GODDESS”。'))

    def test_chinese_screen_text_is_never_allowed(self):
        self.assertIn('CHINESE_QUOTED_CONTENT',codes('手机屏幕显示英文字幕“吃的到了”。'))

    def test_negative_requirements_do_not_create_positive_effects(self):
        self.assertFalse(codes('禁止眼睛发光。不要二维线稿。无字幕。Do not add catchlight.'))

    def test_later_negation_does_not_hide_positive_instruction(self):
        self.assertIn('NON_LIVE_ACTION_STYLE',codes('画面转二维线稿，其他地方不要二维。'))

    def test_spoken_english_metaphor_does_not_become_visual_effect(self):
        self.assertFalse(codes('Alice（现场对白）轻声说：“Your eyes sparkle.” 她维持目光接触。'))

    def test_quoted_english_style_is_not_mistaken_for_dialogue(self):
        self.assertIn('NON_LIVE_ACTION_STYLE',codes('Render the space as "2D line-art".'))

    def test_unrelated_english_prop_text_is_not_automatically_a_subtitle(self):
        self.assertFalse(codes('信封上是英文名字字样“Camille”。'))

    def test_main_cli_enforces_content_checks(self):
        root=Path(__file__).resolve().parents[1]
        example=(root/'assets/examples/live_action_opening.prompt.md').read_text(encoding='utf-8')
        with tempfile.TemporaryDirectory() as temp:
            prompt=Path(temp)/'prompt.md'
            prompt.write_text(example+'\n画面转为二维线稿。\n',encoding='utf-8')
            run=subprocess.run([sys.executable,'-B',str(root/'scripts/validate_director_prompt.py'),str(prompt),'--strict'],
                               capture_output=True,text=True,encoding='utf-8')
            self.assertEqual(1,run.returncode)
            self.assertIn('NON_LIVE_ACTION_STYLE',run.stdout)

if __name__=='__main__': unittest.main()
