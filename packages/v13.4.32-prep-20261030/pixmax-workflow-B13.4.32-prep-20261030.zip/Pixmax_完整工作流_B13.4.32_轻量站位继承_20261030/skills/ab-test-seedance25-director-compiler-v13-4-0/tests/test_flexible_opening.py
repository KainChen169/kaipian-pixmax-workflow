"""Opening freedom must not disable source, timing, staging or content checks."""
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

import validate_director_prompt as v

ROOT = Path(__file__).resolve().parents[1]
TEXT = (ROOT / 'assets/examples/live_action_opening.prompt.md').read_text(encoding='utf-8')
SOURCE = json.loads((ROOT / 'assets/examples/live_action_opening.dialogue.json').read_text(encoding='utf-8'))


class FlexibleOpening(unittest.TestCase):
    def findings(self, text):
        return v.validate(text, source_dialogue=SOURCE)

    def test_close_opening_with_first_shot_dialogue_passes(self):
        self.assertFalse([f.render() for f in self.findings(TEXT)
                          if f.level in ('ERROR', 'WARNING')])
        self.assertEqual(3, len(v.parse_shots(TEXT)))

    def test_two_shot_continuous_exchange_is_allowed(self):
        # No obligatory silent reaction or establishing shot is inserted.
        first, rest = TEXT.split('### 镜头02｜3–4秒', 1)
        last = rest[rest.index('### 镜头03｜4–8秒'):]
        text = first + last.replace('镜头03｜4–8秒', '镜头02｜3–8秒', 1)
        self.assertFalse([f.render() for f in self.findings(text)
                          if f.level in ('ERROR', 'WARNING')])

    def test_first_shot_offscreen_dialogue_keeps_source_channel(self):
        text = TEXT.replace('周远（现场对白）', '周远（画外对白）')
        source = [dict(row) for row in SOURCE]
        source[0]['kind'] = '画外对白'
        self.assertFalse([f for f in v.validate(text, source_dialogue=source)
                          if f.level == 'ERROR'])
        # Existing source comparison groups on/off-screen as dialogue; it must
        # still distinguish dialogue from an internal/narration voice channel.
        source[0]['kind'] = '内心旁白'
        self.assertTrue(v.validate_inline_dialogue(text, source))

    def test_second_shot_wide_is_not_a_mechanical_failure(self):
        text = TEXT.replace('景别：面部特写', '景别：全景', 1)
        self.assertFalse([f for f in self.findings(text)
                          if f.code.startswith('OPENING_')])
        # Actual scale/crop and narrative usefulness still need semantic review.

    def test_source_omission_addition_and_speaker_change_still_fail(self):
        for text in (TEXT.replace('I leave tomorrow.', ''),
                     TEXT.replace('I leave tomorrow.', 'I leave tomorrow. Come with me.'),
                     TEXT.replace('周远（现场对白）', '陈宁（现场对白）')):
            with self.subTest(text=text):
                self.assertTrue(v.validate_inline_dialogue(text, SOURCE))

    def test_empty_staging_background_scale_and_timing_still_fail(self):
        start = TEXT.index('## 4. 人物开场站位')
        end = TEXT.index('## 5. 时间线镜头设计')
        empty = TEXT[:start] + '## 4. 人物开场站位\n' + TEXT[end:]
        self.assertIn('OPENING_STAGING_EMPTY', {f.code for f in self.findings(empty)})
        text = TEXT.replace('背景：入口的虚化色块。', '背景：')
        self.assertIn('SHOT_BACKGROUND_MISSING', {f.code for f in self.findings(text)})
        text = TEXT.replace('景别：上半身近景｜', '景别：｜', 1)
        self.assertTrue([f for f in self.findings(text) if f.level == 'ERROR'])
        text = TEXT.replace('镜头02｜3–4秒', '镜头02｜3.5–4秒')
        self.assertTrue([f for f in self.findings(text) if f.level == 'ERROR'])

    def test_main_cli_with_source_passes_without_opening_waiver(self):
        with tempfile.TemporaryDirectory() as temporary:
            prompt = Path(temporary) / 'prompt.md'
            prompt.write_text(TEXT, encoding='utf-8')
            result = subprocess.run([sys.executable, '-B', str(ROOT / 'scripts/validate_director_prompt.py'),
                                     str(prompt), '--strict', '--source-dialogue',
                                     str(ROOT / 'assets/examples/live_action_opening.dialogue.json')],
                                    capture_output=True, text=True)
            self.assertEqual(0, result.returncode, result.stdout + result.stderr)


if __name__ == '__main__':
    unittest.main()
