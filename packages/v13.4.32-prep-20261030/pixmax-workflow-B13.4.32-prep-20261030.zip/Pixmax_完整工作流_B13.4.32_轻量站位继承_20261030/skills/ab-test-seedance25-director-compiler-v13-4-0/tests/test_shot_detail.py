"""Text-volume behavior only; ratios do not prove expressive/visual quality."""
import importlib.util
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'scripts'))
import validate_director_prompt as v


def document(bodies, intro='', dialogue='我明天就走。', merged=False):
    rows = ['# 测试\n总时长：6秒｜画幅：9:16｜'+('无独立构图栏模式' if merged else '构图模式')+'\n',
            '## 1. 人物指定\n**林夕：** 清醒克制。\n**周远：** 平静坚决。\n',
            '## 2. 场景指定\n**客厅｜日｜内：** 日光从窗侧进入。\n',
            '## 3. 道具指定\n**信纸：** 林夕右手持有。\n',
            '## 4. 人物开场站位\n林夕在门旁画面左侧，周远在窗前画面右侧；彼此面对，机位在门口。\n',
            '## 5. 时间线镜头设计\n**整段剧情概述：** 周远说决定，林夕听完抬眼。'+intro+'\n']
    for i, body in enumerate(bodies):
        start,end = i*3,(i+1)*3
        rows.append(f'### 镜头{i+1:02d}｜{start}–{end}秒｜景别：'+('全景' if i==0 else '上半身近景')+'｜林夕与周远｜固定\n')
        if not merged:
            rows.append('**构图：** 从门口拍向窗户，林夕在左，周远在右；背景：窗旁墙面。\n')
        rows.append('**画面内容：** '+body)
        if i==0:
            rows.append(f'[0.2–2秒，镜内] 周远（现场对白）平静地对林夕说：“{dialogue}”')
        rows.append('\n')
    rows.append('## 6. 声音安排\n保留室内环境声，无配乐。\n## 7. 输出要求\n无字幕。\n')
    return ''.join(rows)


SHORT = ['周远朝林夕说话，林夕持信纸的手停住，两人没有走动。',
         '林夕闭口抬眼看周远，摄影机轻推，最后停住。']
DETAIL = [
    '摄影机在门口保持全景，起幅到落幅都保留两人全身和窗框。周远胸口朝林夕，原地说出决定；声音平稳，不用移动靠近来施压。林夕的右手原本持住信纸，听清后持纸动作停下，但纸仍在右手，没有换手或掉落。她的目光随后从纸边抬向周远，身体留在门旁，两个动作在原发声窗口内自然承接，不在句后重复表演。固定机位让这次安静的停顿和两人的距离同时可读，镜末两人仍留原位。',
    '摄影机从周远肩旁拍林夕，取胸口上方到头顶，脸在画面左中，视线朝向画面右侧。周远肩缘只占右边窄窄的一条虚处，不挡眼睛和嘴。背景的门框退到左后方，仍能说明她留在门旁，没有被反打换到窗边。林夕抬起的目光在周远脸上停住，闭合的唇间压着尚未说出的回应，下颌随目光稳定下来；她没有后退或转向。摄影机随目光轻推少许，接近后减速停稳，让稳定注视中的表情变化保持可读。持纸右手仍在胸口裁切之外，不在本镜突然切成手部特写。镜末从她尚未获得回应的目光接入下一镜。']


class ShotDetailTests(unittest.TestCase):
    def test_metrics_remain_observational(self):
        before = document(SHORT)
        after = document(DETAIL)
        self.assertEqual(v.validate_detail_expansion(after,before), [])
        for old,new in zip(v.shot_detail_metrics(before),v.shot_detail_metrics(after)):
            self.assertGreater(new['description_units'],old['description_units'])

    def test_mixed_detail_levels_do_not_trigger_volume_review(self):
        result = v.validate_detail_expansion(document([DETAIL[0],SHORT[1]]),document(SHORT))
        self.assertEqual(result, [])

    def test_long_preamble_synopsis_audio_and_output_do_not_compensate(self):
        baseline = document(SHORT)
        inflated = document(SHORT,intro='这是冗长概述。'*1000)
        inflated = inflated.replace('无字幕。','无字幕。'+'固定画质套话。'*1000)
        self.assertEqual(v.shot_detail_metrics(baseline),v.shot_detail_metrics(inflated))
        self.assertEqual(v.validate_detail_expansion(inflated,baseline),[])

    def test_dialogue_is_not_counted_as_new_description(self):
        baseline = document(SHORT)
        inflated = document(SHORT,dialogue='不应以重复原话增加描述量。'*1000)
        self.assertEqual(v.shot_detail_metrics(baseline),v.shot_detail_metrics(inflated))
        self.assertEqual(v.validate_detail_expansion(inflated,baseline),[])

    def test_clear_shorter_or_unchanged_shots_need_no_expansion(self):
        for current,baseline in ((SHORT,DETAIL),(SHORT,SHORT),(DETAIL,DETAIL)):
            self.assertEqual(v.validate_detail_expansion(document(current),document(baseline)),[])

    def test_incompatible_time_or_shot_count_does_not_fabricate_ratio(self):
        original = document(SHORT)
        for changed in (original.replace('3–6秒','3.1–6秒'),document(SHORT[:1])):
            self.assertEqual(v.validate_detail_expansion(changed,original)[0].code,'DETAIL_BASELINE_INCOMPATIBLE')

    def test_no_baseline_does_not_fabricate_comparison(self):
        self.assertEqual(v.validate_detail_expansion(document(DETAIL)),[])

    def test_more_than_threefold_is_not_a_length_ceiling(self):
        result = v.validate_detail_expansion(document(DETAIL),document(['停住。','抬眼。']))
        self.assertEqual(result,[])

    def test_merged_composition_mode_is_counted(self):
        text = document(DETAIL, merged=True)
        self.assertTrue(all(row['description_units']>0 for row in v.shot_detail_metrics(text)))

    def test_explicit_user_length_override_remains_enforced(self):
        text = document(DETAIL)
        total = v.length_metrics(text)['total']
        for target in (total//2, total*2):
            codes = {f.code for f in v.validate(text,length_target=target)}
            self.assertIn('LENGTH_BUDGET',codes)

    def test_expansion_preserves_original_timeline_and_dialogue(self):
        short,detail = document(SHORT),document(DETAIL)
        before = [(s.number,s.start,s.end) for s in v.parse_shots(short)]
        self.assertEqual(before,[(s.number,s.start,s.end) for s in v.parse_shots(detail)])
        source = [{'speaker':'周远','text':'我明天就走。'}]
        self.assertNotIn('DIALOGUE_SOURCE_MISMATCH',{f.code for f in v.validate(detail,source_dialogue=source)})
        wrong = detail.replace('：“我明天就走。”','：“我现在就走。”')
        self.assertIn('DIALOGUE_SOURCE_MISMATCH',{f.code for f in v.validate(wrong,source_dialogue=source)})

    def test_source_changed_speaker_and_timeline_gap_still_fail(self):
        text = document(DETAIL)
        wrong = text.replace('周远（现场对白）','林夕（现场对白）').replace('3–6秒','3.2–6秒')
        codes = {f.code for f in v.validate(wrong,source_dialogue=[{'speaker':'周远','text':'我明天就走。'}])}
        self.assertIn('DIALOGUE_SOURCE_MISMATCH',codes)
        self.assertIn('TIMELINE_GAP',codes)

    def test_detail_report_is_exposed_in_metrics(self):
        report = v.length_metrics(document(DETAIL))
        self.assertEqual(len(report['per_shot']),2)
        self.assertGreater(report['per_shot'][0]['units_per_second'],0)


if __name__=='__main__': unittest.main()
