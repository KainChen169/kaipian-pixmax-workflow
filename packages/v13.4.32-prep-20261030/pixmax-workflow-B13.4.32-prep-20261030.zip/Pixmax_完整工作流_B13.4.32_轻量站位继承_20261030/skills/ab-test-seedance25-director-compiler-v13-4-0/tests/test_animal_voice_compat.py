"""Parser compatibility only; these tests do not evaluate actual voice identity."""
import json
from pathlib import Path
import unittest

import validate_director_prompt as v
from validate_live_action_prompt import validate_content

ROOT = Path(__file__).resolve().parents[1]
TEXT = (ROOT / 'assets/examples/speaking_animal_voice.prompt.md').read_text(encoding='utf-8')
SOURCE = json.loads((ROOT / 'assets/examples/speaking_animal_voice.dialogue.json').read_text(encoding='utf-8'))


class AnimalVoiceCompatibility(unittest.TestCase):
    def test_voice_directions_do_not_add_speech_or_human_speakers(self):
        rows, issues = v.inline_rows(TEXT)
        self.assertFalse(issues)
        self.assertEqual([(r['speaker'], r['text']) for r in rows],
                         [(r['speaker'], r['text']) for r in SOURCE])
        self.assertFalse([f for f in v.validate(TEXT, source_dialogue=SOURCE)
                          if f.level == 'ERROR'])
        self.assertFalse(validate_content(TEXT))

    def test_changing_silent_voice_description_keeps_source_dialogue(self):
        changed = TEXT.replace('成年男性声线，中低音温厚，表达直接、带保护感',
                               '年轻女性声线，清亮灵动，表达直接、带保护感')
        self.assertFalse(v.validate_inline_dialogue(changed, SOURCE))

    def test_wrong_speaker_and_altered_words_remain_rejected(self):
        wrong_speaker = TEXT.replace('Ash（现场对白）', 'Mara（现场对白）')
        wrong_text = TEXT.replace('Stay behind me.', 'Run away now.')
        self.assertTrue(v.validate_inline_dialogue(wrong_speaker, SOURCE))
        self.assertTrue(v.validate_inline_dialogue(wrong_text, SOURCE))

    def test_internal_voice_kind_is_preserved_not_converted_to_live_dialogue(self):
        text = TEXT.replace('Ash（现场对白）', 'Ash（内心旁白）')
        source = [dict(r) for r in SOURCE]
        source[0]['kind'] = '内心旁白'
        self.assertFalse(v.validate_inline_dialogue(text, source))
        self.assertTrue(v.validate_inline_dialogue(text, SOURCE))


if __name__ == '__main__':
    unittest.main()
