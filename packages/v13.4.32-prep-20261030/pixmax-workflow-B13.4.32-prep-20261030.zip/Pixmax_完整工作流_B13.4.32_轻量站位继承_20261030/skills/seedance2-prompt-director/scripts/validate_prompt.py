#!/usr/bin/env python3
"""检查 Seedance2 15秒完整视频执行提示词的可机械验证规则。"""

from __future__ import annotations

import argparse
import json
import re
import sys
from collections import Counter
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Iterable


PROMPT_TITLE_RE = re.compile(
    r"(?m)^#\s+第[^｜\n]+｜镜头[^｜\n]+｜[^｜\n]+｜15秒完整视频执行提示词\s*$"
)
EPISODE_FROM_TITLE_RE = re.compile(r"^第(?P<episode>[^｜\n]+)｜镜头")
SHOT_RE = re.compile(
    r"(?m)^###\s*镜头(?P<number>[^｜\s]+)｜"
    r"(?P<start>\d+(?:\.\d+)?)\s*[—–-]\s*"
    r"(?P<end>\d+(?:\.\d+)?)秒｜"
    r"(?P<scale>[^｜\n]+)｜(?P<move>[^｜\n]+)｜"
    r"(?P<performance>[^｜\n]+)｜(?P<purpose>[^\n]+)$"
)

REQUIRED_FIELDS = (
    "人物指定",
    "重要道具",
    "场景指定",
    "本段整体动作路径",
    "画幅",
    "时长",
    "对白",
    "VO",
    "字幕",
    "音乐",
    "核心情绪",
)
REQUIRED_SECTIONS = (
    "场景与人物状态 / 位置关系",
    "轴线、景别与镜头执行锁定",
    "时间线镜头设计",
    "声音设计",
    "画风与执行锁定",
)
LOCK_TERMS = {
    "无字幕": ("字幕",),
    "无可读文字": ("可读文字",),
    "无可读UI": ("UI", "界面"),
    "无Logo": ("Logo", "品牌标识"),
    "无水印": ("水印",),
    "无配乐": ("配乐", "背景音乐", "主题音乐", "情绪音乐", "BGM"),
}
NEGATION_MARKERS = ("无", "禁止", "不得", "不使用", "不生成", "不出现", "不显示", "不保留", "不可读")
CONTRAST_MARKERS = ("但是", "但", "不过", "然而", "同时")
MUSIC_TERMS = ("配乐", "背景音乐", "主题音乐", "情绪音乐", "BGM")
READABLE_TERMS = (
    "可读文字",
    "字幕",
    "UI",
    "Logo",
    "水印",
    "时间卡",
    "屏幕文字",
    "手机文字",
    "标牌文字",
    "文件文字",
    "剧情文字",
    "英文文字",
    "中文文字",
)
VISIBLE_TEXT_VERBS = ("显示", "呈现", "出现", "看清", "写有", "写着", "读到", "保留", "允许")
WHITELIST_VALUE_RE = re.compile(r"[`“\"]([^`”\"]+)[`”\"]")
META_FILLER_PATTERNS = (
    "从明确起始状态推进动作",
    "对结果作出因果回应",
    "压住多余动作",
    "确认最终落点",
    "完成动作因果",
    "以眼神、呼吸、下颌、手指、重心和距离逐级呈现",
)
REFERENCE_MARKER_RE = re.compile(r"(?:参考图|!\[[^\]]*\]\(|\[[^\]]+\]\((?:file:|/))", re.IGNORECASE)
LOCAL_ASSET_PATH_RE = re.compile(
    r"(?:file://|/(?:Users|home|private|Volumes|tmp)/|[A-Za-z]:\\|"
    r"(?:[\w.-]+[/\\])+[\w .()-]+\.(?:png|jpe?g|webp|gif|bmp|tiff?))",
    re.IGNORECASE,
)
IMAGE_FILENAME_RE = re.compile(r"\b[^\s/\\]+\.(?:png|jpe?g|webp|gif|bmp|tiff?)\b", re.IGNORECASE)
TIMELINE_DIALOGUE_POINTER_RE = re.compile(
    r"(?:顶层(?:对白|口播|发声)|"
    r"(?:执行|完成)(?:顶层|本段|第[一二两]|唯一|原文|对白中的|口播中的|条)*"
    r"(?:发声|口播|对白|原文)|"
    r"(?:第一|第二|唯一)条(?:发声|口播|对白))"
)


@dataclass
class Utterance:
    field_name: str
    text: str


@dataclass
class Result:
    source: str
    title: str
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    stats: dict[str, int | float | str] = field(default_factory=dict)

    @property
    def ok(self) -> bool:
        return not self.errors


def split_prompts(text: str) -> list[tuple[str, str]]:
    """只按正式单段标题拆分，忽略“16段提示词”等整集总标题。"""
    matches = list(PROMPT_TITLE_RE.finditer(text))
    if not matches:
        return [("未识别到正式标题", text)]

    blocks: list[tuple[str, str]] = []
    for index, match in enumerate(matches):
        end = matches[index + 1].start() if index + 1 < len(matches) else len(text)
        title = match.group(0).lstrip("# ").strip()
        blocks.append((title, text[match.start():end].strip()))
    return blocks


def validate_episode_groups(
    source: str, blocks: list[tuple[str, str]]
) -> list[Result]:
    """在完整单集模式下统计素材量；不把数量或占比当合格门槛。"""
    groups: dict[str, list[tuple[str, str]]] = {}
    for title, text in blocks:
        match = EPISODE_FROM_TITLE_RE.match(title)
        if match:
            groups.setdefault(match.group("episode"), []).append((title, text))

    results: list[Result] = []
    for episode, items in groups.items():
        segment_count = len(items)
        shot_counts = [len(SHOT_RE.findall(text)) for _, text in items]
        counted_shots = [count for count in shot_counts if count > 0]
        average_shots = (
            sum(counted_shots) / len(counted_shots) if counted_shots else 0.0
        )
        result = Result(
            source=source,
            title=f"第{episode}｜整集素材量",
            stats={
                "15秒素材段数": segment_count,
                "平均子镜头数": round(average_shots, 2),
                "计划素材秒数": segment_count * 15,
                "子镜头总数": sum(counted_shots),
                "镜头数分布": ", ".join(
                    f"{count}镜×{frequency}组"
                    for count, frequency in sorted(Counter(counted_shots).items())
                ),
            },
        )
        results.append(result)
    return results


def effective_character_count(text: str) -> int:
    """统计去除空白和常用Markdown标记后的全部有效字符。"""
    return len(re.sub(r"[\s`#*_>|]", "", text))


def extract_field(text: str, label: str) -> str | None:
    match = re.search(
        rf"(?m)^\*\*{re.escape(label)}：\*\*[ \t]*(.*?)(?=\n\*\*[^*\n]+：\*\*|\n##\s|\Z)",
        text,
        flags=re.DOTALL,
    )
    return match.group(1).strip() if match else None


def extract_section(text: str, heading: str) -> str | None:
    match = re.search(
        rf"(?m)^##\s+{re.escape(heading)}\s*\n(.*?)(?=^##\s+|\Z)",
        text,
        flags=re.DOTALL,
    )
    return match.group(1).strip() if match else None


def extract_utterances(text: str) -> list[Utterance]:
    utterances: list[Utterance] = []
    for label in ("对白", "O.S.", "VO"):
        body = extract_field(text, label)
        if body is None:
            continue
        for raw_line in body.splitlines():
            line = re.sub(r"^\s*[-*]\s*", "", raw_line).strip()
            if not line or re.fullmatch(r"无(?:对白|VO|O\.S\.)?[。.]?", line):
                continue
            if re.search(r"按对白栏.*(?:V\.O\.|O\.S\.).*执行", line):
                continue

            sequence_quotes = re.findall(r"〔([^〕]+)〕", line)
            if sequence_quotes:
                utterances.extend(
                    Utterance(label, item.strip())
                    for item in sequence_quotes
                    if item.strip()
                )
                continue

            quoted = re.findall(r"[\"“]([^\"”]+)[\"”]", line)
            if quoted:
                utterances.extend(Utterance(label, item.strip()) for item in quoted if item.strip())
                continue

            payload = re.split(r"[：:]", line, maxsplit=1)[-1].strip()
            if payload and not payload.startswith("无"):
                utterances.append(Utterance(label, payload))
    return utterances


def normalize_dialogue_text(text: str) -> str:
    """只折叠空白；台词用词和标点仍须保持原文。"""
    return re.sub(r"\s+", " ", text).strip()


def validate_timeline_dialogue_binding(
    text: str, utterances: list[Utterance], result: Result
) -> None:
    timeline = extract_section(text, "时间线镜头设计") or ""
    timeline_quotes = Counter(
        normalize_dialogue_text(item)
        for item in re.findall(r"[\"“]([^\"”]+)[\"”]", timeline)
        if item.strip()
    )
    expected_quotes = Counter(
        normalize_dialogue_text(utterance.text)
        for utterance in utterances
        if utterance.text.strip()
    )
    missing = expected_quotes - timeline_quotes
    landed = sum((expected_quotes & timeline_quotes).values())
    result.stats["镜头内逐字发声数"] = landed

    for line, count in missing.items():
        suffix = f"（缺少{count}次）" if count > 1 else ""
        result.errors.append(
            f"顶层发声未在时间线对应子镜头中逐字写出：{line}{suffix}"
        )

    if TIMELINE_DIALOGUE_POINTER_RE.search(timeline):
        result.errors.append(
            "时间线中存在“执行第一条发声/执行顶层口播”等指代；必须在说话镜头的画面内容中直接写出说话者和完整原文台词。"
        )


def estimated_english_seconds(utterances: list[Utterance]) -> tuple[int, float]:
    """约145词/分钟的筛查假设，含轮次间隙；不是实际配音计时。"""
    words = sum(
        len(re.findall(r"[A-Za-z]+(?:[’'-][A-Za-z]+)?", utterance.text))
        for utterance in utterances
    )
    if not words:
        return 0, 0.0
    seconds = words / 2.42 + max(0, len(utterances) - 1) * 0.35
    return words, round(seconds, 1)


def visible_people_count(text: str) -> int:
    people = extract_field(text, "人物指定") or ""
    return sum(
        1
        for raw_line in people.splitlines()
        if re.sub(r"^\s*[-*]\s*", "", raw_line).strip().rstrip("。")
        not in {"", "无实际入画人物", "无人物"}
    )


def explicit_visible_names(value: str) -> set[str]:
    """只读明确名单，不从正文姓名命中推断入画或资产需求。"""
    names = {item.strip().rstrip("。") for item in re.split(r"[、，,;；\n]", value)}
    return names - {"", "无", "无人物", "无实际入画人物"}


def validate_shot_presence(text: str, result: Result, *, require_presence: bool = False) -> None:
    timeline = extract_section(text, "时间线镜头设计") or ""
    shots = list(SHOT_RE.finditer(timeline))
    declared = explicit_visible_names(extract_field(text, "人物指定") or "")
    union: set[str] = set()
    counts: list[int] = []
    missing = 0
    for index, shot in enumerate(shots):
        end = shots[index + 1].start() if index + 1 < len(shots) else len(timeline)
        body = timeline[shot.end():end]
        field = extract_field(body, "入画角色")
        if field is None:
            missing += 1
            continue
        if not field.strip():
            result.errors.append(f"镜头{index + 1}的入画角色为空；无人镜头明确写“无”。")
            continue
        names = explicit_visible_names(field)
        union.update(names)
        counts.append(len(names))
        extra = names - declared
        if extra:
            result.errors.append(f"镜头{index + 1}入画角色不在人物指定中：{'、'.join(sorted(extra))}。")
        if len(names) >= 4:
            result.warnings.append(
                f"镜头{index + 1}显式列出{len(names)}名可见角色；复核同框拥挤与主体，不能以虚焦补齐全场。"
            )
        prose = (extract_field(body, "构图") or "") + "\n" + (extract_field(body, "画面内容") or "")
        for name in sorted(names):
            # This is a review hint only: a later visible entrance may be valid.
            if re.search(re.escape(name) + r"\s*(?:仍|还|本镜|本格|全程|整段)?(?:未|尚未|没有|不)(?:进入画面|入画|出现)", prose):
                result.warnings.append(
                    f"镜头{index + 1}入画名单与{name}的否定出现描述可能冲突；按实际时序核对，禁止据姓名命中自动绑资产。"
                )
    if shots and missing:
        issues = result.errors if require_presence else result.warnings
        issues.append(
            f"{missing}个子镜头缺少显式入画角色名单；旧稿兼容读取，但无法验证单镜人数和人物并集。"
        )
    if shots and not missing and len(counts) == len(shots):
        unused = declared - union
        if unused:
            result.errors.append(f"人物指定包含所有子镜头均未列入的角色：{'、'.join(sorted(unused))}。")
    result.stats["已声明入画名单镜头数"] = len(counts)
    result.stats["已声明单镜最多可见角色"] = max(counts, default=0)
    result.stats["入画语义核验范围"] = "显式名单；正文漏列、声源、否定作用域及静态格仍需人工核对"


def _last_contrast_scope(prefix: str) -> str:
    last = -1
    marker_length = 0
    for marker in CONTRAST_MARKERS:
        position = prefix.rfind(marker)
        if position > last:
            last = position
            marker_length = len(marker)
    return prefix[last + marker_length :] if last >= 0 else prefix


def has_negated_term(text: str, terms: tuple[str, ...]) -> bool:
    """识别“无文字、界面、Logo及水印”一类共享否定语义。"""
    for segment in re.split(r"[；;。\n]", text):
        for term in terms:
            start = 0
            while True:
                index = segment.lower().find(term.lower(), start)
                if index < 0:
                    break
                prefix = _last_contrast_scope(segment[:index])[-28:]
                if any(marker in prefix for marker in NEGATION_MARKERS):
                    return True
                start = index + len(term)
    return False


def extract_whitelist(text: str, label: str) -> tuple[str, ...]:
    """读取“可读文字白名单/音乐白名单”后以反引号或引号列出的精确值。"""
    values: list[str] = []
    for match in re.finditer(
        rf"{re.escape(label)}\s*[:：]\s*(.*?)(?=；|;|。|\n|$)", text
    ):
        values.extend(value.strip() for value in WHITELIST_VALUE_RE.findall(match.group(1)))
    return tuple(dict.fromkeys(value for value in values if value))


def _authorized_clause(clause: str, label: str, whitelist: tuple[str, ...]) -> bool:
    if not whitelist:
        return False
    if label in clause:
        return True
    return any(value in clause for value in whitelist)


def positive_music_instructions(text: str, whitelist: tuple[str, ...] = ()) -> list[str]:
    bad: list[str] = []
    for clause in re.split(r"[，,；;。\n]", text):
        clause = clause.strip()
        if not clause or not any(term.lower() in clause.lower() for term in MUSIC_TERMS):
            continue
        if has_negated_term(clause, MUSIC_TERMS):
            continue
        if _authorized_clause(clause, "音乐白名单", whitelist):
            continue
        bad.append(clause)
    return bad


def positive_readable_text_instructions(
    text: str, whitelist: tuple[str, ...] = ()
) -> list[str]:
    bad: list[str] = []
    for clause in re.split(r"[；;。\n]", text):
        clause = clause.strip()
        if not clause:
            continue
        if not any(term.lower() in clause.lower() for term in READABLE_TERMS):
            continue
        if not any(verb in clause for verb in VISIBLE_TEXT_VERBS):
            continue
        if has_negated_term(clause, READABLE_TERMS):
            continue
        if _authorized_clause(clause, "可读文字白名单", whitelist):
            continue
        bad.append(clause)
    return bad


def parse_shot_number(value: str) -> int | None:
    if value.isdigit():
        return int(value)
    digits = {"零": 0, "一": 1, "二": 2, "三": 3, "四": 4, "五": 5, "六": 6, "七": 7, "八": 8, "九": 9}
    if value in digits:
        return digits[value]
    if value == "十":
        return 10
    if value.startswith("十") and value[1:] in digits:
        return 10 + digits[value[1:]]
    if value.endswith("十") and value[:-1] in digits:
        return digits[value[:-1]] * 10
    return None


def validate_required_structure(text: str, result: Result) -> None:
    for label in REQUIRED_FIELDS:
        if extract_field(text, label) is None:
            result.errors.append(f"缺少顶层字段：{label}。")
    for heading in REQUIRED_SECTIONS:
        if extract_section(text, heading) is None:
            result.errors.append(f"缺少一级执行板块：{heading}。")

    if extract_field(text, "O.S.") is not None:
        result.errors.append("存在额外O.S.顶层字段；请把O.S.直接标在对白说话者姓名后。")

    duration = extract_field(text, "时长") or ""
    if not re.search(r"15秒", duration) or not re.search(r"0\.0\s*[—–-]\s*15\.0秒", duration):
        result.errors.append("时长字段必须明确写出15秒并严格连续覆盖0.0—15.0秒。")


def validate_compact_asset_fields(text: str, result: Result) -> None:
    if (
        REFERENCE_MARKER_RE.search(text)
        or LOCAL_ASSET_PATH_RE.search(text)
        or IMAGE_FILENAME_RE.search(text)
    ):
        result.errors.append(
            "成品中发现参考图标记、图片文件名或本地路径；人物和场景只保留标准名称，道具不得附图片路径。"
        )

    people = extract_field(text, "人物指定")
    if people is not None:
        for raw_line in people.splitlines():
            line = re.sub(r"^\s*[-*]\s*", "", raw_line).strip().rstrip("。")
            if not line or line in {"无实际入画人物", "无人物"}:
                continue
            if re.search(r"[:：,，;；()\[\]（）【】]", line):
                result.errors.append(
                    f"人物指定必须每行只写姓名，不附身份、外形、服装或参考信息：{line}"
                )

    scene = extract_field(text, "场景指定")
    if scene is not None:
        scene_lines = [line.strip() for line in scene.splitlines() if line.strip()]
        if len(scene_lines) != 1:
            result.errors.append("场景指定必须只写一行场景标准名称。")


def validate_block(source: str, title: str, text: str, *, require_presence: bool = False) -> Result:
    result = Result(source=source, title=title)
    shots = list(SHOT_RE.finditer(text))
    shot_count = len(shots)
    wide_count = sum(
        1 for shot in shots if re.search(r"(?:大?全景|远景)", shot.group("scale"))
    )
    close_count = sum(
        1
        for shot in shots
        if re.search(r"(?:中近景|近景|特写|上半身|胸像|半身)", shot.group("scale"))
    )
    fixed_count = sum(1 for shot in shots if "固定" in shot.group("move"))
    handheld_count = sum(1 for shot in shots if "手持" in shot.group("move"))
    moving_count = sum(
        1
        for shot in shots
        if re.search(r"(?:手持|推|拉|摇|移|跟|升|降|焦点)", shot.group("move"))
    )
    char_count = effective_character_count(text)
    utterances = extract_utterances(text)
    people_count = visible_people_count(text)
    timeline = extract_section(text, "时间线镜头设计") or ""
    reaction_count = len(re.findall(r"反打|听者反应|反应镜头|无声反应", timeline))
    readable_whitelist = extract_whitelist(text, "可读文字白名单")
    music_whitelist = extract_whitelist(text, "音乐白名单")
    english_words, speech_seconds = estimated_english_seconds(utterances)

    result.stats = {
        "镜头数": shot_count,
        "全景数": wide_count,
        "近景/特写数": close_count,
        "近景/特写占比": round(close_count / shot_count, 2) if shot_count else 0.0,
        "固定机位数": fixed_count,
        "手持镜头数": handheld_count,
        "运动镜头数": moving_count,
        "正反打/反应标记数": reaction_count,
        "实际入画人物数": people_count,
        "发声段数": len(utterances),
        "英语词数": english_words,
        "英语口播估时秒": speech_seconds,
        "有效字符数": char_count,
        "可读文字白名单项": len(readable_whitelist),
        "音乐白名单项": len(music_whitelist),
    }

    if title == "未识别到正式标题":
        result.errors.append("未找到符合“第XX集｜镜头XX｜名称｜15秒完整视频执行提示词”的一级标题。")

    validate_required_structure(text, result)
    validate_compact_asset_fields(text, result)
    validate_timeline_dialogue_binding(text, utterances, result)
    validate_shot_presence(text, result, require_presence=require_presence)

    if not shots:
        result.errors.append("未识别到符合固定字段格式的镜头标题。")
    else:
        starts = [float(shot.group("start")) for shot in shots]
        ends = [float(shot.group("end")) for shot in shots]
        result.stats["起始秒"] = starts[0]
        result.stats["结束秒"] = ends[-1]
        result.stats["首镜景别"] = shots[0].group("scale").strip()
        result.stats["末镜景别"] = shots[-1].group("scale").strip()

        if abs(starts[0]) > 0.001:
            result.errors.append(f"时间线从{starts[0]:g}秒开始，不是0.0秒。")
        if abs(ends[-1] - 15.0) > 0.001:
            result.errors.append(f"时间线在{ends[-1]:g}秒结束，不是15.0秒。")

        for index, (start, end) in enumerate(zip(starts, ends), start=1):
            if end <= start:
                result.errors.append(f"镜头{index}结束时间不大于开始时间。")
        for index in range(shot_count - 1):
            gap = starts[index + 1] - ends[index]
            if abs(gap) <= 0.001:
                continue
            relation = "空缺" if gap > 0 else "重叠"
            result.errors.append(
                f"镜头{index + 1}与镜头{index + 2}之间存在{abs(gap):g}秒{relation}。"
            )

        parsed_numbers = [parse_shot_number(shot.group("number")) for shot in shots]
        if all(number is not None for number in parsed_numbers):
            actual = [int(number) for number in parsed_numbers if number is not None]
            expected = list(range(1, shot_count + 1))
            if actual != expected:
                result.errors.append(f"镜头编号不连续或重复：实际{actual}，应为{expected}。")
        else:
            result.warnings.append("存在无法解析的镜头编号，未完成编号连续性检查。")

        for index, shot in enumerate(shots):
            section_end = shots[index + 1].start() if index + 1 < shot_count else len(text)
            body = text[shot.end():section_end]
            if not re.search(r"\*\*构图：\*\*|^构图：", body, re.MULTILINE):
                result.errors.append(f"镜头{index + 1}缺少独立的“构图”字段。")
            if not re.search(r"\*\*画面内容：\*\*|^画面内容：", body, re.MULTILINE):
                result.errors.append(f"镜头{index + 1}缺少独立的“画面内容”字段。")

        for attribute, label in (("scale", "景别与机位"), ("move", "摄影机运动")):
            values = [shot.group(attribute).strip() for shot in shots]
            for start in range(max(0, shot_count - 2)):
                if len(set(values[start : start + 3])) == 1:
                    result.warnings.append(
                        f"镜头{start + 1}—{start + 3}连续重复相同{label}：{values[start]}。"
                    )

    if len(utterances) > 2:
        result.errors.append(f"识别到{len(utterances)}段对白/O.S./VO发声，超过每段最多两段的上限。")
    if speech_seconds > 15.0:
        result.warnings.append(
            f"英语口播试算约{speech_seconds:g}秒，已超过整组15秒；请按实际试读拆分或重排，不以“自然快速”掩盖超时。"
        )
    elif speech_seconds > 11.0:
        result.warnings.append(
            f"英语口播估时约{speech_seconds:g}秒，超过通常建议的11秒；请试读并考虑拆段。"
        )

    if wide_count > 2:
        result.errors.append(f"识别到{wide_count}个全景/远景，超过硬上限2个。")
    elif wide_count == 2:
        result.warnings.append("使用了2个全景/远景；请确认第二个确实承担空间结果或大范围动作。")

    if shots and close_count / shot_count < 0.6:
        result.warnings.append(
            "近景/特写占比低于60%；竖屏关系戏通常以近景为主，如本段承担空间建立或大范围动作可保留。"
        )
    if shot_count >= 4 and fixed_count == shot_count:
        result.warnings.append(
            "全段均为固定机位；如并非刻意表现压迫、观察或持续表演，可加入一次有动作或情绪动机的手持/推拉摇移。"
        )
    if shot_count >= 4 and moving_count == shot_count and fixed_count == 0:
        result.warnings.append(
            "全段镜头均在运动；请确认存在节奏依据，并考虑用固定镜头形成对比。"
        )
    if (len(utterances) >= 2 or people_count >= 3) and reaction_count == 0:
        result.warnings.append(
            "多人或多轮发声段未识别到正反打/听者反应；请确认已在台词切换、间隙或句后安排有信息增量的反应镜头。"
        )

    lock_scope = extract_section(text, "画风与执行锁定") or text
    for label, terms in LOCK_TERMS.items():
        if not has_negated_term(lock_scope, terms):
            result.errors.append(f"缺少固定执行锁：{label}。")

    for clause in positive_music_instructions(text, music_whitelist):
        result.errors.append(f"发现与无配乐规则冲突的音乐指令：{clause}")
    for clause in positive_readable_text_instructions(text, readable_whitelist):
        result.errors.append(f"发现与无可读文字规则冲突的可见文字指令：{clause}")

    if re.search(r"(?m)^#{1,6}\s*承接上一段\s*$", text):
        result.errors.append("出现禁止的“承接上一段”独立板块。")
    if re.search(r"(?m)^#{1,6}\s*动作规则\s*$", text):
        result.errors.append("出现禁止的“动作规则”独立板块。")

    filler_counts = Counter(
        phrase for phrase in META_FILLER_PATTERNS for _ in range(text.count(phrase))
    )
    for phrase, count in filler_counts.items():
        result.warnings.append(f"发现{count}处抽象元语言“{phrase}”；请改成可见动作或删除。")

    return result


def iter_markdown_files(paths: Iterable[str]) -> Iterable[Path]:
    for raw in paths:
        path = Path(raw).expanduser()
        if path.is_dir():
            yield from sorted(path.rglob("*.md"))
        elif path.is_file():
            yield path
        else:
            raise FileNotFoundError(f"找不到文件或目录：{path}")


def print_human(results: list[Result]) -> None:
    for result in results:
        status = "通过" if result.ok else "不通过"
        print(f"[{status}] {result.source}｜{result.title}")
        stats = "，".join(f"{key}={value}" for key, value in result.stats.items())
        if stats:
            print(f"  统计：{stats}")
        for error in result.errors:
            print(f"  错误：{error}")
        for warning in result.warnings:
            print(f"  提醒：{warning}")

    passed = sum(result.ok for result in results)
    print(f"\n汇总：{passed}/{len(results)}个提示词通过硬规则检查。")


def _self_test_sample() -> str:
    shots = []
    for index in range(6):
        start = index * 2.5
        end = (index + 1) * 2.5
        content = (
            "角色A稳住视线，清楚说：“I know.”句末闭口，角色B作出具体反应。"
            if index == 0
            else "角色A完成动作，角色B作出具体反应。"
        )
        shots.append(
            f"### 镜头{index + 1}｜{start:.1f}—{end:.1f}秒｜上半身近景，三分之二正面机位｜固定机位｜克制判断｜推进关系\n\n"
            "**入画角色：** 角色A、角色B\n\n"
            "**构图：** 角色A位于画面左侧，身体朝向角色B，摄影机保持在轴线南侧。\n\n"
            f"**画面内容：** {content}\n"
        )
    return (
        "# 第01集｜镜头01｜测试｜15秒完整视频执行提示词\n\n"
        "**人物指定：**\n角色A\n角色B\n\n"
        "**重要道具：**\n无重要道具。\n\n"
        "**场景指定：**\n测试室内场景\n\n"
        "**本段整体动作路径：**\n角色A从门边走到桌旁，角色B保持原位。\n\n"
        "**画幅：** 9:16竖屏精品剧。\n"
        "**时长：** 15秒；时间线严格连续覆盖0.0—15.0秒。\n"
        "**对白：**\n角色A：\"I know.\"\n"
        "**VO：** 无VO。\n"
        "**字幕：** 无字幕。\n"
        "**音乐：** 无配乐、无背景音乐、无主题音乐、无情绪音乐。\n\n"
        "**核心情绪：** 角色A作出决定。\n\n"
        "## 场景与人物状态 / 位置关系\n\n**开场站位：** 角色A在左，角色B在右。\n\n"
        "## 轴线、景别与镜头执行锁定\n\n摄影机保持轴线南侧。\n\n"
        "## 时间线镜头设计\n\n"
        + "\n".join(shots)
        + "\n## 声音设计\n\n0.0—15.0秒：室内底噪与动作同步。\n\n"
        "## 画风与执行锁定\n\n"
        "无字幕，无任何中英文可读文字、无可读UI、无Logo、无品牌标识、无水印、无配乐。"
    )


def self_test() -> int:
    sample = _self_test_sample()
    result = validate_block("内置自测", "测试提示词", sample)
    if not result.ok:
        print_human([result])
        return 1

    assert len(split_prompts("# 第01集｜16段15秒完整视频执行提示词\n" + sample)) == 1
    assert len(extract_utterances("**对白：**\nA：One.\n**O.S.：**\nB：Two.\n**VO：**\nC：Three.")) == 3
    assert len(extract_utterances("**对白：**\n发声序列A：A〔One.〕A〔Two.〕")) == 2
    assert positive_music_instructions("无配乐，但结尾加入情绪音乐")
    assert positive_readable_text_instructions("全段无可读文字。开场清楚显示英文文字时间卡。")
    whitelist_text = "可读文字白名单：`Three years later`；除此之外无任何可读文字。开场显示英文文字Three years later。"
    whitelist = extract_whitelist(whitelist_text, "可读文字白名单")
    assert whitelist == ("Three years later",)
    assert not positive_readable_text_instructions(whitelist_text, whitelist)
    print("内置自测通过。")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(
        description="检查Seedance2提示词的模板、15秒时间线、发声、镜头、全景、篇幅和固定执行锁。"
    )
    parser.add_argument("paths", nargs="*", help="一个或多个Markdown文件/目录")
    parser.add_argument("--json", action="store_true", help="以JSON输出检查结果")
    parser.add_argument("--self-test", action="store_true", help="运行内置自测")
    parser.add_argument("--require-presence", action="store_true", help="新稿交付模式：子镜头缺少入画角色名单视为硬错误；旧稿审查可省略")
    parser.add_argument(
        "--episode-mode",
        action="store_true",
        help="统计整集15秒素材组数、计划秒数与子镜头分布，不按数量或占比判合格",
    )
    args = parser.parse_args()

    if args.self_test:
        return self_test()
    if not args.paths:
        parser.error("请提供至少一个提示词Markdown文件或目录。")

    results: list[Result] = []
    try:
        for path in iter_markdown_files(args.paths):
            text = path.read_text(encoding="utf-8")
            blocks = split_prompts(text)
            for title, block in blocks:
                results.append(validate_block(str(path), title, block, require_presence=args.require_presence))
            if args.episode_mode:
                results.extend(validate_episode_groups(str(path), blocks))
    except (OSError, UnicodeError) as exc:
        print(f"读取失败：{exc}", file=sys.stderr)
        return 2

    if args.json:
        print(
            json.dumps(
                [asdict(result) | {"ok": result.ok} for result in results],
                ensure_ascii=False,
                indent=2,
            )
        )
    else:
        print_human(results)
    return 0 if results and all(result.ok for result in results) else 1


if __name__ == "__main__":
    raise SystemExit(main())
