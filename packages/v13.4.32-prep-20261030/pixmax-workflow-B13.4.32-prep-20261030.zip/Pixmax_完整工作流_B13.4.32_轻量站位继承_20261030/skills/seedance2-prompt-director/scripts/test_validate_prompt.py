#!/usr/bin/env python3
"""validate_prompt.py 的回归测试。"""

from __future__ import annotations

import importlib.util
import sys
import unittest
from pathlib import Path


MODULE_PATH = Path(__file__).with_name("validate_prompt.py")
SPEC = importlib.util.spec_from_file_location("validate_prompt", MODULE_PATH)
assert SPEC and SPEC.loader
VALIDATOR = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = VALIDATOR
SPEC.loader.exec_module(VALIDATOR)


class ValidatePromptTests(unittest.TestCase):
    def setUp(self) -> None:
        self.sample = VALIDATOR._self_test_sample()

    def test_valid_sample_passes(self) -> None:
        self.assertTrue(VALIDATOR.validate_block("test", "test", self.sample).ok)

    def test_six_shots_are_inside_normal_style_range(self) -> None:
        result = VALIDATOR.validate_block("test", "test", self.sample)
        self.assertFalse(any("6—7镜标准" in warning for warning in result.warnings))

    def test_style_warnings_do_not_fail_prompt(self) -> None:
        result = VALIDATOR.validate_block("test", "test", self.sample)
        self.assertTrue(any("固定机位" in warning for warning in result.warnings))
        self.assertTrue(result.ok)

    def test_cinematic_stats_are_reported(self) -> None:
        result = VALIDATOR.validate_block("test", "test", self.sample)
        self.assertEqual(result.stats["镜头数"], 6)
        self.assertEqual(result.stats["近景/特写数"], 6)
        self.assertEqual(result.stats["首镜景别"], "上半身近景，三分之二正面机位")
        self.assertIn("正反打/反应标记数", result.stats)

    def test_episode_summary_title_is_ignored(self) -> None:
        text = "# 第02集 Seedance2｜16段15秒完整视频执行提示词\n\n说明\n\n" + self.sample
        self.assertEqual(len(VALIDATOR.split_prompts(text)), 1)

    def test_all_audible_fields_count_toward_limit(self) -> None:
        text = "**对白：**\nA：One.\n**O.S.：**\nB：Two.\n**VO：**\nC：Three."
        self.assertEqual(len(VALIDATOR.extract_utterances(text)), 3)

    def test_voice_sequences_do_not_hide_multiple_utterances(self) -> None:
        text = "**对白：**\n发声序列A：A〔One.〕A〔Two.〕\n发声序列B：B〔Three.〕"
        self.assertEqual(len(VALIDATOR.extract_utterances(text)), 3)

    def test_episode_group_count_has_no_fixed_floor_or_range_warning(self) -> None:
        for segment_count in (4, 8, 12, 14, 20):
            with self.subTest(segment_count=segment_count):
                blocks = [
                    (
                        f"第01集｜镜头{index:02d}｜测试｜15秒完整视频执行提示词",
                        self.sample,
                    )
                    for index in range(1, segment_count + 1)
                ]
                result = VALIDATOR.validate_episode_groups("test", blocks)[0]
                self.assertTrue(result.ok)
                self.assertFalse(any("不少于10段" in item for item in result.errors))
                self.assertFalse(any("14—16段" in item for item in result.warnings))

    def test_episode_with_four_shots_has_no_quota_warning(self) -> None:
        low_shot_block = "\n".join(
            f"### 镜头{index}｜{(index - 1) * 3.75:.2f}—{index * 3.75:.2f}秒｜近景｜固定｜克制｜推进"
            for index in range(1, 5)
        )
        blocks = [
            (f"第01集｜镜头{index:02d}｜测试｜15秒完整视频执行提示词", low_shot_block)
            for index in range(1, 13)
        ]
        result = VALIDATOR.validate_episode_groups("test", blocks)[0]
        self.assertEqual(result.warnings, [])
        self.assertEqual(result.stats["计划素材秒数"], 180)
        self.assertEqual(result.stats["子镜头总数"], 48)
        self.assertTrue(result.ok)

    def test_concise_prompt_does_not_trigger_padding_warning(self) -> None:
        result = VALIDATOR.validate_block("test", "test", self.sample)
        self.assertTrue(result.ok)
        self.assertFalse(any("有效字符数约" in w for w in result.warnings))

    def test_extra_top_level_visual_asset_fails(self) -> None:
        text = self.sample.replace("**人物指定：**\n角色A\n角色B", "**人物指定：**\n角色A\n角色B\nElara")
        result = VALIDATOR.validate_block("test", "test", text)
        self.assertTrue(any("均未列入" in e and "Elara" in e for e in result.errors))

    def test_offscreen_mention_does_not_add_asset(self) -> None:
        text = self.sample.replace("**画面内容：**", "**画面内容：** Elara仍未进入画面。", 1)
        result = VALIDATOR.validate_block("test", "test", text)
        self.assertTrue(result.ok)
        self.assertEqual(result.stats["已声明单镜最多可见角色"], 2)

    def test_unknown_visible_name_fails(self) -> None:
        text = self.sample.replace("**入画角色：** 角色A、角色B", "**入画角色：** 角色A、Elara", 1)
        result = VALIDATOR.validate_block("test", "test", text)
        self.assertTrue(any("不在人物指定" in e for e in result.errors))

    def test_negative_visibility_conflict_is_reviewed_not_guessed(self) -> None:
        text = self.sample.replace("**画面内容：**", "**画面内容：** 角色B尚未出现。", 1)
        result = VALIDATOR.validate_block("test", "test", text)
        self.assertTrue(any("否定出现" in w for w in result.warnings))
        self.assertTrue(result.ok)

    def test_four_people_in_group_not_same_as_four_per_shot(self) -> None:
        text = self.sample.replace("**人物指定：**\n角色A\n角色B", "**人物指定：**\n角色A\n角色B\n角色C\n角色D")
        text = text.replace("**入画角色：** 角色A、角色B", "**入画角色：** 角色C、角色D", 1)
        result = VALIDATOR.validate_block("test", "test", text)
        self.assertTrue(result.ok)
        self.assertFalse(any("同框拥挤" in w for w in result.warnings))
        self.assertEqual(result.stats["已声明单镜最多可见角色"], 2)

    def test_four_people_in_one_shot_warns(self) -> None:
        text = self.sample.replace("**人物指定：**\n角色A\n角色B", "**人物指定：**\n角色A\n角色B\n角色C\n角色D")
        text = text.replace("**入画角色：** 角色A、角色B", "**入画角色：** 角色A、角色B、角色C、角色D", 1)
        result = VALIDATOR.validate_block("test", "test", text)
        self.assertTrue(result.ok)
        self.assertTrue(any("同框拥挤" in w for w in result.warnings))

    def test_legacy_without_visibility_manifest_warns_but_reads(self) -> None:
        text = self.sample.replace("**入画角色：** 角色A、角色B\n\n", "")
        result = VALIDATOR.validate_block("test", "test", text)
        self.assertTrue(result.ok)
        self.assertTrue(any("无法验证单镜人数" in w for w in result.warnings))

    def test_blank_manifest_is_not_an_empty_shot(self) -> None:
        result = VALIDATOR.Result("test", "test")
        text = self.sample.replace("**入画角色：** 角色A、角色B", "**入画角色：**", 1)
        VALIDATOR.validate_shot_presence(text, result)
        self.assertTrue(any("入画角色为空" in e for e in result.errors))

    def test_new_delivery_requires_visibility_manifest(self) -> None:
        text = self.sample.replace("**入画角色：** 角色A、角色B\n\n", "")
        result = VALIDATOR.validate_block("test", "test", text, require_presence=True)
        self.assertFalse(result.ok)
        self.assertTrue(any("缺少显式入画角色" in e for e in result.errors))

    def test_long_voiceover_flags_whole_group_overflow(self) -> None:
        long_line = " ".join(["No"] * 44) + "."
        text = self.sample.replace("I know.", long_line)
        result = VALIDATOR.validate_block("test", "test", text)
        self.assertTrue(any("超过整组15秒" in w for w in result.warnings))

    def test_missing_required_fields_fail(self) -> None:
        stripped = self.sample.replace("**场景指定：**\n测试室内场景\n\n", "")
        result = VALIDATOR.validate_block("test", "test", stripped)
        self.assertTrue(any("场景指定" in error for error in result.errors))

    def test_reference_image_path_fails(self) -> None:
        broken = self.sample.replace(
            "**人物指定：**\n角色A\n角色B",
            "**人物指定：**\n角色A [参考图：/Users/test/character/a.png]\n角色B",
        )
        result = VALIDATOR.validate_block("test", "test", broken)
        self.assertTrue(any("图片文件名或本地路径" in error for error in result.errors))

    def test_person_description_in_name_field_fails(self) -> None:
        broken = self.sample.replace("**人物指定：**\n角色A", "**人物指定：**\n角色A：女性")
        result = VALIDATOR.validate_block("test", "test", broken)
        self.assertTrue(any("每行只写姓名" in error for error in result.errors))

    def test_dialogue_must_appear_verbatim_in_timeline(self) -> None:
        broken = self.sample.replace("清楚说：“I know.”", "清楚说：“I understand.”")
        result = VALIDATOR.validate_block("test", "test", broken)
        self.assertTrue(any("未在时间线对应子镜头中逐字写出" in error for error in result.errors))

    def test_dialogue_pointer_cannot_replace_literal_line(self) -> None:
        broken = self.sample.replace(
            "角色A稳住视线，清楚说：“I know.”句末闭口，角色B作出具体反应。",
            "角色A稳住视线，执行顶层唯一口播，角色B作出具体反应。",
        )
        result = VALIDATOR.validate_block("test", "test", broken)
        self.assertTrue(any("指代" in error for error in result.errors))
        self.assertTrue(any("未在时间线对应子镜头中逐字写出" in error for error in result.errors))

    def test_duplicate_shot_number_fails(self) -> None:
        broken = self.sample.replace("### 镜头2｜", "### 镜头1｜", 1)
        result = VALIDATOR.validate_block("test", "test", broken)
        self.assertTrue(any("镜头编号" in error for error in result.errors))

    def test_music_contradiction_fails(self) -> None:
        broken = self.sample.replace(
            "无配乐、无背景音乐、无主题音乐、无情绪音乐。",
            "无配乐，但结尾加入情绪音乐。",
            1,
        )
        result = VALIDATOR.validate_block("test", "test", broken)
        self.assertTrue(any("音乐指令" in error for error in result.errors))

    def test_readable_text_contradiction_fails(self) -> None:
        broken = self.sample.replace("测试室内场景", "测试室内场景；开场清楚显示英文文字时间卡。")
        result = VALIDATOR.validate_block("test", "test", broken)
        self.assertTrue(any("可见文字指令" in error for error in result.errors))

    def test_shared_negation_locks_pass(self) -> None:
        lock = "无字幕，无任何中英文可读文字、界面、Logo及水印；禁止配乐。"
        for terms in VALIDATOR.LOCK_TERMS.values():
            self.assertTrue(VALIDATOR.has_negated_term(lock, terms))

    def test_exact_readable_text_whitelist_passes(self) -> None:
        text = (
            "可读文字白名单：`Three years later`；除此之外无任何可读文字。"
            "开场清楚显示英文文字Three years later。"
        )
        whitelist = VALIDATOR.extract_whitelist(text, "可读文字白名单")
        self.assertEqual(whitelist, ("Three years later",))
        self.assertFalse(VALIDATOR.positive_readable_text_instructions(text, whitelist))

    def test_unlisted_readable_text_still_fails(self) -> None:
        text = (
            "可读文字白名单：`Three years later`；除此之外无任何可读文字。"
            "结尾显示英文文字final day。"
        )
        whitelist = VALIDATOR.extract_whitelist(text, "可读文字白名单")
        self.assertTrue(VALIDATOR.positive_readable_text_instructions(text, whitelist))

    def test_music_whitelist_only_allows_listed_item(self) -> None:
        text = (
            "音乐白名单：`片内收音机音乐`；除此之外无配乐。"
            "开场播放片内收音机音乐。结尾加入情绪音乐。"
        )
        whitelist = VALIDATOR.extract_whitelist(text, "音乐白名单")
        conflicts = VALIDATOR.positive_music_instructions(text, whitelist)
        self.assertEqual(conflicts, ["结尾加入情绪音乐"])


if __name__ == "__main__":
    unittest.main()
