"""Parse timed, human-readable dialogue; validate it against an independent source.

No dialogue IDs are required in the generated document. This does not validate
acting, natural speech speed, geometry, or the generated video.
"""
from __future__ import annotations
import math
import re

BEAT = re.compile(r'\[\s*(?:镜内\s*)?(\d+(?:\.\d+)?)\s*[–—-]\s*(\d+(?:\.\d+)?)\s*秒\s*(?:，\s*镜内)?[^\]]*\]')
VOICE = re.compile(r'(?P<speaker>[A-Za-z][A-Za-z0-9 _-]*|[\u4e00-\u9fff]{1,16})（(?P<kind>现场对白|画外对白|内心旁白|旁白|对白|VO)）(?P<acting>[^“”]*?)：“(?P<text>[^“”]+)”')
SPEECH_QUOTE = re.compile(r'(?:说|问|回答|喊|道|接着|继续)[^：“”\n]{0,5}：“')

def count_units(text):
    return len(re.findall(r'[\u3400-\u4dbf\u4e00-\u9fff]|[A-Za-z]+(?:[\x27’][A-Za-z]+)*', text))

def normalized(words):
    # Line wrapping and English word boundaries may change across cuts; words
    # and punctuation may not. Apostrophes remain part of the original text.
    return tuple(re.findall(r"[A-Za-z]+(?:[\x27’][A-Za-z]+)*|\d+(?:\.\d+)?|[^\s]", words))

def category(kind):
    return 'VO' if kind in ('内心旁白', '旁白', 'VO') else 'dialogue'

def parse_inline(body, shot_start, shot_end):
    beats=list(BEAT.finditer(body)); rows=[]; errors=[]
    voices=list(VOICE.finditer(body))
    for bracket in re.finditer(r"\[[^\]]+\]",body):
        if ("秒" in bracket[0] or "镜内" in bracket[0]) and not BEAT.fullmatch(bracket[0]):
            errors.append(("BEAT_FORMAT","存在不可解析的镜内时间，不能跳过"))
    for beat in beats:
        start,end=map(float,beat.groups())
        if not 0 <= start < end <= shot_end-shot_start+0.06:
            errors.append(('BEAT_TIME','镜内区间越界、倒置或零长'))
    for match in voices:
        before=[beat for beat in beats if beat.start()<match.start()]
        if not before:
            errors.append(('INLINE_TIME','台词前缺少可解析的镜内发声区间'))
            continue
        beat=before[-1]; start,end=map(float,beat.groups())
        speaker=match['speaker'].strip()
        rows.append(dict(speaker=speaker,kind=category(match['kind']),text=match['text'],
                         start=shot_start+start,end=shot_start+end,acting=match['acting']))
    for match in SPEECH_QUOTE.finditer(body):
        if not any(v.start() <= match.start() < v.end() for v in voices):
            errors.append(('INLINE_FORMAT','发现未能解析的直接发言；请用人物（声音类别）并将原话放入当前镜内区间'))
    return rows,errors

def compare_source(rows, source):
    errors=[]
    if not isinstance(source,list) or any(not isinstance(r,dict) or not isinstance(r.get('speaker'),str) or not isinstance(r.get('text'),str) or not r['text'] for r in source):
        return [('SOURCE_FORMAT','源原话须为按顺序排列、含speaker/text字符串的列表')]
    cursor=0
    for index,wanted in enumerate(source,1):
        goal=normalized(wanted['text']); accumulated=(); chosen=[]
        while cursor<len(rows) and len(accumulated)<len(goal):
            row=rows[cursor];cursor+=1;chosen.append(row)
            if row['speaker']!=wanted['speaker']:
                errors.append(('DIALOGUE_SOURCE_MISMATCH',f'第{index}句说话者不符来源'))
            if 'kind' in wanted and category(wanted['kind'])!=row['kind']:
                errors.append(('DIALOGUE_SOURCE_MISMATCH',f'第{index}句声音类别不符来源'))
            if len(chosen)>1 and row['kind']!=chosen[0]['kind']:
                errors.append(('DIALOGUE_SOURCE_MISMATCH',f'第{index}句跨镜改变对白／旁白性质'))
            accumulated+=normalized(row['text'])
            if goal[:len(accumulated)] != accumulated:
                break
        if accumulated!=goal:
            errors.append(('DIALOGUE_SOURCE_MISMATCH',f'第{index}句有缺词、改词、重复、标点或顺序错误'))
        if chosen:
            for a,b in zip(chosen,chosen[1:]):
                if b['start']<a['end']-0.06:
                    errors.append(('DIALOGUE_OVERLAP',f'第{index}句跨镜发声重叠'))
            for key,actual in [('start',chosen[0]['start']),('end',chosen[-1]['end'])]:
                if key in wanted:
                    value=wanted[key]
                    if not isinstance(value,(int,float)) or not math.isfinite(value) or abs(value-actual)>0.06:
                        errors.append(('DIALOGUE_TIME',f'第{index}句与来源锁定的{key}不符'))
        elif goal:
            errors.append(('MISSING_DIALOGUE',f'缺少第{index}句原话'))
    if cursor<len(rows):
        errors.append(('EXTRA_DIALOGUE','时间线存在来源之外或重复的发言'))
    return errors
