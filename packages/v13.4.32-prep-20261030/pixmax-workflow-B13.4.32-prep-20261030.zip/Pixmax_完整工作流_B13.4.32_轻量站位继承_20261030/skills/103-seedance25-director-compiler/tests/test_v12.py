import json
import unittest
from pathlib import Path
from test_validator import validator as v

ROOT = Path(__file__).resolve().parents[1]
PROMPT = (ROOT / 'assets/examples/e01_hand_to_face.prompt.md').read_text(encoding='utf-8')
SOURCE = json.loads((ROOT / 'assets/examples/e01_dialogue.json').read_text(encoding='utf-8'))


def codes(text, source=SOURCE):
    return {f.code for f in v.validate(text, source_dialogue=source)}


class AssetFormatTests(unittest.TestCase):
    def test_minimal_header_selects_inline_source_validation(self):
        self.assertNotIn('版本', PROMPT)
        self.assertTrue(v.asset_template(PROMPT))
        self.assertEqual('composition', v.output_mode(PROMPT))
        self.assertFalse([f for f in v.validate(PROMPT, source_dialogue=SOURCE) if f.level in ('ERROR', 'WARNING')])
        self.assertIn('DIALOGUE_SOURCE_MISMATCH', codes(PROMPT.replace('：“就走。”', '：“走。”')))

    def test_sections_route_to_actual_asset_descriptions(self):
        self.assertEqual(['林夕', '周远'], v.character_names(PROMPT))
        self.assertIn('**信纸：**', v.role_section(PROMPT, 'props'))
        self.assertNotIn('**林夕：**', v.role_section(PROMPT, 'props'))
        self.assertIn('**小客厅', v.role_section(PROMPT, 'space'))
        self.assertEqual(3, len(v.parse_shots(PROMPT)))

    def test_natural_continuity_requires_no_separate_state_table(self):
        self.assertIn('STATE_IN_DESIGNATIONS', codes(PROMPT))
        self.assertNotIn('NO_STATE_LEDGER', codes(PROMPT))

    def test_missing_scene_and_empty_asset_description_block(self):
        self.assertIn('STRUCTURE', codes(PROMPT.replace('## 2. 场景指定', '## 2. 其他')))
        self.assertIn('ASSET_DESIGNATION', codes(PROMPT.replace(v.role_section(PROMPT, 'space'), '\n**小客厅：**\n')))

    def test_no_prop_statement_does_not_invent_a_prop(self):
        text = PROMPT.replace(v.role_section(PROMPT, 'props'), '\n本段无剧情道具。\n')
        self.assertNotIn('ASSET_DESIGNATION', codes(text))
        self.assertIn('UNDECLARED_PROP', {f.code for f in v.validate_props(text.replace('信纸', '信件'), v.parse_shots(text))})

    def test_role_labels_block_in_titles_and_timeline(self):
        for before, after in [('**林夕：**', '**女主林夕：**'), ('周远面部近景', '男二周远面部近景'), ('林夕右拇指', '女主右拇指')]:
            with self.subTest(replacement=after):
                self.assertIn('ROLE_ALIAS', codes(PROMPT.replace(before, after)))

    def test_machine_references_block(self):
        for token in ['%%@[REF_EP01_CHAR_Seren][image][0](e5219821-9fce-4649-9206-321ff79218c6)%%', '[image][0]', 'e5219821-9fce-4649-9206-321ff79218c6']:
            with self.subTest(token=token):
                self.assertIn('ASSET_REFERENCE', codes(PROMPT.replace('**林夕：**', '**林夕：** ' + token)))

    def test_empty_inheritance_blocks(self):
        for phrase in ['沿用既有人物形象', '沿用同一枚道具', '同一枚道具']:
            self.assertIn('EMPTY_INHERITANCE', codes(PROMPT.replace('**信纸：**', '**信纸：** ' + phrase)))

    def test_internal_header_metadata_blocks(self):
        self.assertIn('HEADER_METADATA', codes(PROMPT.replace('总时长：', '版本｜v12｜总时长：')))

    def test_quotes_protect_source_words_from_format_filters(self):
        replacement = '女主说D01是REF_EP01的同一枚道具。'
        text = PROMPT.replace('：“那你看着我。”', '：“' + replacement + '”')
        source = [dict(row) for row in SOURCE]
        source[-1]['text'] = replacement
        findings = v.validate(text, source_dialogue=source)
        self.assertFalse([f for f in findings if f.level in ('ERROR', 'WARNING')])
        self.assertEqual(replacement, v.inline_rows(text)[0][-1]['text'])

    def test_speaker_must_be_declared_by_name(self):
        self.assertIn('UNDECLARED_SPEAKER', codes(PROMPT.replace('林夕（画外对白）', '程宁（画外对白）')))

    def test_local_intervals_check_bounds_without_full_ledger(self):
        text = PROMPT.replace('**信纸：**', '**信纸：** [5–7秒] ')
        self.assertNotIn('STATE_START', codes(text))
        self.assertNotIn('STATE_END', codes(text))
        for interval, expected in [('[5–4]', 'STATE_RANGE'), ('[-1–7]', 'STATE_RANGE'), ('[5–16]', 'STATE_END'), ('[五–7]', 'STATE_FORMAT')]:
            self.assertIn(expected, codes(text.replace('[5–7秒]', interval)))

    def test_new_format_does_not_skip_timing_checks(self):
        self.assertIn('TIMELINE_GAP', codes(PROMPT.replace('镜头02｜6–10秒', '镜头02｜7–10秒')))
        self.assertIn('BEAT_TIME', codes(PROMPT.replace('[0–1.2秒，镜内]', '[0–4.2秒，镜内]')))


if __name__ == '__main__':
    unittest.main()
