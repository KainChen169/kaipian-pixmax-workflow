from __future__ import annotations

import importlib.util
import re
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "validate_director_prompt.py"
SPEC = importlib.util.spec_from_file_location("director_validator", SCRIPT)
assert SPEC and SPEC.loader
validator = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = validator
SPEC.loader.exec_module(validator)


VALID_PROMPT = """模式｜总时长：10秒｜9:16
## 1. 人物指定
Lena位于低位，Sea Witch位于高位。
## 2. 道具指定
戒指：戴在Lena左手无名指，0.00–10.00秒持续可见。
白玉台：固定于场景后方中央。
## 3. 场景指定
夜，深蓝海底洞穴，白玉台位于后方中央。
## 4. 开场整体站位
Lena位于画面左侧前景，Sea Witch位于画面右侧后景高位，主关系轴稳定。
## 5. 开场当前空间状态
Lena双膝承重，左手无名指佩戴戒指；Sea Witch悬浮于白玉台上方。
## 6. 人物与道具状态时间轴
Lena｜[0.00–10.00] 低位跪姿持续，左手无名指持续佩戴戒指。
Sea Witch｜[0.00–10.00] 白玉台上方高位悬浮持续。
戒指｜[0.00–10.00] 持续佩戴在Lena左手无名指。
白玉台｜[0.00–10.00] 固定于后方中央。
## 7. 时间线镜头设计
### 镜头01｜0.00–5.00秒｜双人中景｜低位缓推
**构图：** Lena在画面左侧前景，Sea Witch在画面右侧后景，关系轴稳定。
**画面内容：** Sea Witch说：“代价很重。”Lena听到“代价”时目光轻颤，呼吸停在胸口，双手在膝上收紧，镜末重新抬眼。
### 镜头02｜5.00–10.00秒｜Lena近景｜侧面固定
**构图：** Lena保持画面左侧，Sea Witch白袍形成右侧低比例虚焦层次。
**画面内容：** Lena说：“我愿意。”左手无名指的戒指持续可见，手指逐渐松开，最终目光稳定落向Sea Witch。
## 8. Camera设计
主关系轴稳定，关系中景进入侧面近景。
## 9. 表演设计
Lena从短暂动摇进入坚定；听见代价后由呼吸、目光和手部完成反应。
## 10. 音频设计
对白、呼吸与水流声共同构成声场。
## 11. 正向约束
人物身份、位置、戒指佩戴、双手结构与口型持续连贯。
"""


def codes(text: str) -> set[str]:
    return {item.code for item in validator.validate(text)}


class ValidatorTests(unittest.TestCase):
    def test_valid_prompt_passes(self):
        self.assertEqual([], validator.validate(VALID_PROMPT))

    def test_requires_prop_and_state_sections(self):
        broken = VALID_PROMPT.replace("## 2. 道具指定", "## 2. 临时说明")
        self.assertIn("STRUCTURE", codes(broken))

    def test_detects_state_gap_and_missing_persistence(self):
        broken = VALID_PROMPT.replace(
            "Lena｜[0.00–10.00] 低位跪姿持续，左手无名指持续佩戴戒指。",
            "Lena｜[0.00–3.00] 低位跪姿；[4.00–6.00] 跪姿 → 起身 → 站姿。",
        )
        result = codes(broken)
        self.assertIn("STATE_GAP", result)
        self.assertIn("STATE_END", result)

    def test_detects_undeclared_prop(self):
        broken = VALID_PROMPT.replace("戒指：戴在Lena左手无名指，0.00–10.00秒持续可见。", "手部状态稳定。")
        self.assertIn("UNDECLARED_PROP", codes(broken))

    def test_detects_hand_conflict(self):
        broken = VALID_PROMPT.replace(
            "戒指｜[0.00–10.00] 持续佩戴在Lena左手无名指。",
            "戒指｜[0.00–10.00] Lena右手同时抓住衣料并托住戒指。",
        )
        self.assertIn("HAND_OCCUPANCY", codes(broken))

    def test_detects_passive_state_break(self):
        broken = VALID_PROMPT.replace(
            "Lena｜[0.00–10.00] 低位跪姿持续，左手无名指持续佩戴戒指。",
            "Lena｜[0.00–10.00] 昏迷状态持续，左手无名指持续佩戴戒指。",
        ).replace("手指逐渐松开", "主动抬头并回握，手指逐渐松开")
        self.assertIn("PASSIVE_STATE_BREAK", codes(broken))

    def test_detects_non_self_contained_reference_and_project_language(self):
        broken = VALID_PROMPT.replace("夜，深蓝海底洞穴", "布局与上一场一致，夜，深蓝海底洞穴").replace("目光轻颤", "眉头紧锁")
        result = codes(broken)
        self.assertIn("NON_SELF_CONTAINED", result)
        self.assertIn("PROJECT_LANGUAGE", result)

    def test_detects_palm_tail_visibility_conflict(self):
        broken = VALID_PROMPT.replace(
            "Lena近景｜侧面固定",
            "掌心顶视特写｜俯拍固定",
        ).replace("左手无名指的戒指持续可见", "掌心戒指与远处鱼尾同时清晰可见")
        self.assertIn("VISIBILITY_CONFLICT", codes(broken))

    def test_detects_listener_reaction_failure(self):
        broken = VALID_PROMPT.replace(
            "Lena听到“代价”时目光轻颤，呼吸停在胸口，双手在膝上收紧，镜末重新抬眼。",
            "Lena安静听着。",
        )
        self.assertIn("LISTENER_REACTION", codes(broken))

    def test_detects_shot_timing_gap(self):
        broken = VALID_PROMPT.replace("### 镜头02｜5.00–10.00秒", "### 镜头02｜6.00–10.00秒")
        self.assertIn("TIMELINE_GAP", codes(broken))

    def test_no_composition_mode_moves_geometry_into_visual_content(self):
        prompt = VALID_PROMPT.replace(
            "模式｜总时长：10秒｜9:16",
            "模式｜总时长：10秒｜9:16｜输出模式｜无独立构图栏模式",
        )
        prompt = re.sub(
            r"\*\*构图：\*\*.*?\n\*\*画面内容：\*\*",
            "**画面内容：** Lena身体朝向画面右侧，面部朝向画面右侧，视线看向画面右侧的Sea Witch；",
            prompt,
        )
        self.assertEqual([], validator.validate(prompt))

    def test_no_composition_mode_rejects_composition_field(self):
        broken = VALID_PROMPT.replace(
            "模式｜总时长：10秒｜9:16",
            "模式｜总时长：10秒｜9:16｜输出模式｜无独立构图栏模式",
        )
        self.assertIn("UNEXPECTED_COMPOSITION", codes(broken))

    def test_explicit_mode_requires_body_face_and_gaze_directions(self):
        broken = VALID_PROMPT.replace(
            "模式｜总时长：10秒｜9:16",
            "模式｜总时长：10秒｜9:16｜输出模式｜构图模式",
        )
        result = codes(broken)
        self.assertIn("BODY_ORIENTATION_MISSING", result)
        self.assertIn("FACE_DIRECTION_MISSING", result)
        self.assertIn("GAZE_TARGET_MISSING", result)

    def test_detects_unmotivated_cross_shot_orientation_change(self):
        prompt = VALID_PROMPT.replace(
            "模式｜总时长：10秒｜9:16",
            "模式｜总时长：10秒｜9:16｜输出模式｜无独立构图栏模式",
        )
        marker = "**画面内容：** Lena身体朝向画面右侧，面部朝向画面右侧，视线看向画面右侧的Sea Witch；"
        prompt = re.sub(
            r"\*\*构图：\*\*.*?\n\*\*画面内容：\*\*",
            marker,
            prompt,
        )
        first = prompt.find(marker)
        second = prompt.find(marker, first + len(marker))
        changed = marker.replace("画面右侧", "画面左侧")
        prompt = prompt[:second] + changed + prompt[second + len(marker):]
        prompt = prompt.replace("镜末重新抬眼", "镜末保持浅短呼吸")
        self.assertIn("UNMOTIVATED_ORIENTATION_CHANGE", codes(prompt))


if __name__ == "__main__":
    unittest.main()
