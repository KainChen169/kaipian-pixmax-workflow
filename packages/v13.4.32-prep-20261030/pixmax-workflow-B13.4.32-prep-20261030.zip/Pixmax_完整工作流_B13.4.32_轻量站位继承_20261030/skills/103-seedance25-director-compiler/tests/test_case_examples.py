from __future__ import annotations

import json
import re
import unittest
from pathlib import Path

from test_validator import validator

ROOT = Path(__file__).resolve().parents[1]
EXAMPLES = ROOT / "assets" / "examples"
CATALOG = json.loads((EXAMPLES / "catalog.json").read_text(encoding="utf-8"))["examples"]


class CaseExampleTests(unittest.TestCase):
    def test_complete_examples_pass_structure_timing_and_exact_dialogue(self):
        for entry in CATALOG:
            with self.subTest(example=entry["id"]):
                prompt = (EXAMPLES / entry["prompt"]).read_text(encoding="utf-8")
                source = json.loads((EXAMPLES / entry["source_dialogue"]).read_text(encoding="utf-8"))
                blockers = [f.render() for f in validator.validate(prompt, entry["duration_seconds"], source) if f.level in ("ERROR", "WARNING")]
                self.assertEqual([], blockers)

    def test_examples_cover_both_picture_field_modes(self):
        modes = {validator.output_mode((EXAMPLES / entry["prompt"]).read_text(encoding="utf-8")) for entry in CATALOG}
        self.assertEqual({"composition", "no_composition"}, modes)

    def test_cross_cut_fragments_preserve_source_without_aliases(self):
        for entry in CATALOG:
            prompt = (EXAMPLES / entry["prompt"]).read_text(encoding="utf-8")
            source = json.loads((EXAMPLES / entry["source_dialogue"]).read_text(encoding="utf-8"))
            rows, errors = validator.inline_rows(prompt)
            self.assertEqual([], errors)
            self.assertGreater(len(rows), len(source))
            self.assertEqual([], validator.compare_source(rows, source))
            self.assertNotRegex(prompt, r"\b(?:SC\d+-)?D\d+\b")

    def test_changing_example_fragment_is_detected(self):
        for entry in CATALOG:
            prompt = (EXAMPLES / entry["prompt"]).read_text(encoding="utf-8")
            source = json.loads((EXAMPLES / entry["source_dialogue"]).read_text(encoding="utf-8"))
            rows, _ = validator.inline_rows(prompt)
            changed = prompt.replace('：“' + rows[0]["text"] + '”', '：“错误替换。”', 1)
            codes = {f.code for f in validator.validate(changed, source_dialogue=source)}
            self.assertIn("DIALOGUE_SOURCE_MISMATCH", codes)

    def test_all_reference_links_resolve(self):
        for path in [ROOT / "SKILL.md", *list((ROOT / "references").rglob("*.md"))]:
            for link in re.findall(r"\[[^\]]+\]\(([^)]+)\)", path.read_text(encoding="utf-8")):
                if "://" in link or link.startswith("#"):
                    continue
                self.assertTrue((path.parent / link.split("#")[0]).is_file(), f"{path.name}: {link}")

    def test_catalog_references_real_unique_cases(self):
        cases = []
        for path in (ROOT / "references" / "cases").glob("*.md"):
            cases.extend(re.findall(r"^## ([MSPR]\d{2})｜", path.read_text(encoding="utf-8"), re.M))
        self.assertEqual(len(cases), len(set(cases)))
        for entry in CATALOG:
            self.assertTrue(set(entry["case_ids"]).issubset(cases))


if __name__ == "__main__":
    unittest.main()
