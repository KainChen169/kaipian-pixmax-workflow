import json
import re
import unittest
from pathlib import Path
from test_validator import validator as v

ROOT=Path(__file__).resolve().parents[1]
PROMPT=(ROOT/'assets/examples/e01_hand_to_face.prompt.md').read_text(encoding='utf-8')
SOURCE=json.loads((ROOT/'assets/examples/e01_dialogue.json').read_text(encoding='utf-8'))

def codes(text,source=SOURCE,**kwargs):
    return {x.code for x in v.validate(text,source_dialogue=source,**kwargs)}

class V11Tests(unittest.TestCase):
    def test_inline_examples_are_valid(self):
        self.assertFalse([x for x in v.validate(PROMPT,source_dialogue=SOURCE) if x.level in ('ERROR','WARNING')])

    def test_rejects_alias_and_separate_declaration(self):
        self.assertIn('DIALOGUE_ALIAS',codes(PROMPT+'\n对白D01持续。'))
        self.assertIn('SEPARATE_DIALOGUE',codes(PROMPT+'\n**英文台词与发声：** 另列发声。'))

    def test_wrong_speaker_is_rejected(self):
        self.assertIn('DIALOGUE_SOURCE_MISMATCH',codes(PROMPT.replace('周远（画外对白）','林夕（画外对白）')))

    def test_missing_crosscut_words_are_rejected(self):
        self.assertIn('DIALOGUE_SOURCE_MISMATCH',codes(PROMPT.replace('：“就走。”','：“走。”')))

    def test_changed_punctuation_is_rejected(self):
        self.assertIn('DIALOGUE_SOURCE_MISMATCH',codes(PROMPT.replace('：“就走。”','：“就走！”')))

    def test_wrong_voice_category_is_rejected(self):
        self.assertIn('DIALOGUE_SOURCE_MISMATCH',codes(PROMPT.replace('周远（画外对白）','周远（内心旁白）')))

    def test_time_outside_shot_is_rejected(self):
        self.assertIn('BEAT_TIME',codes(PROMPT.replace('[0–1.2秒，镜内]','[0–4.2秒，镜内]')))

    def test_malformed_time_cannot_be_skipped(self):
        self.assertIn('BEAT_FORMAT',codes(PROMPT.replace('[0–1.2秒，镜内]','[零–1.2秒，镜内]')))

    def test_missing_overview_is_rejected(self):
        self.assertIn('OVERVIEW_MISSING',codes(PROMPT.replace('**整段剧情概述：**','**梗概：**')))

    def test_overview_does_not_count_as_shot_body(self):
        before=v.length_metrics(PROMPT)
        after=v.length_metrics(PROMPT.replace('**整段剧情概述：**','**整段剧情概述：** '+'说明'*200))
        self.assertEqual(before['timeline'],after['timeline'])
        self.assertLess(after['ratio'],before['ratio'])
        self.assertGreater(after['overview'],before['overview'])

    def test_overview_cap(self):
        self.assertIn('OVERVIEW_TOO_LONG',codes(PROMPT.replace('**整段剧情概述：**','**整段剧情概述：** '+'说明'*300)))

    def test_30_second_length_density_and_shot_limit(self):
        shots=v.parse_shots(PROMPT)
        findings=v.validate_v11(PROMPT,shots*5,30)
        found={f.code for f in findings}
        self.assertTrue({'LENGTH_BUDGET','TIMELINE_DENSITY','SHOT_LIMIT'}<=found)

    def test_english_fragments_preserve_word_boundaries(self):
        source=[dict(speaker='Seren',text="He promised he'd marry me.")]
        rows=[dict(speaker='Seren',kind='dialogue',start=0,end=1,text="He promised he'd"),
              dict(speaker='Seren',kind='dialogue',start=1,end=2,text='marry me.')]
        self.assertEqual([],v.compare_source(rows,source))
        rows[1]['text']='mar ry me.'
        self.assertTrue(v.compare_source(rows,source))

    def test_identical_source_lines_are_not_deduplicated(self):
        source=[dict(speaker='A',text='Wait.'),dict(speaker='B',text='Wait.')]
        rows=[dict(speaker='A',kind='dialogue',start=0,end=1,text='Wait.'),
              dict(speaker='B',kind='dialogue',start=1,end=2,text='Wait.')]
        self.assertEqual([],v.compare_source(rows,source))
        self.assertTrue(v.compare_source(rows[:1],source))

    def test_counting_ignores_numeric_timeline_and_punctuation(self):
        self.assertEqual(4,v.count_units('镜头 01 [0–4秒] Seren.'))

if __name__=='__main__':
    unittest.main()
