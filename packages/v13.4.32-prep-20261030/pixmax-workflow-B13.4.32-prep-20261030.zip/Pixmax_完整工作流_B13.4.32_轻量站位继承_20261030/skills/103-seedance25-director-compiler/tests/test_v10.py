from __future__ import annotations

import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from test_validator import validator

ROOT = Path(__file__).resolve().parents[1]
PROMPT = (ROOT / "tests" / "fixtures" / "moving_dialogue.md").read_text(encoding="utf-8")
SOURCE = [{"id": "D01", "speaker": "B", "text": "我明天就走。"},
          {"id": "D02", "speaker": "A", "text": "那你看着我。"}]


def issues(text, source=None):
    return validator.validate(text, source_dialogue=source)


def codes(text, source=None):
    return {item.code for item in issues(text, source)}


def blocking(text, source=None):
    return [item for item in issues(text, source) if item.level in ("ERROR", "WARNING")]


class V10Tests(unittest.TestCase):
    def test_complete_compact_motion_dialogue(self):
        self.assertEqual([], blocking(PROMPT, SOURCE))
        shots = validator.parse_shots(PROMPT)
        self.assertEqual([(0, 4), (4, 8), (8, 12)], [(s.start, s.end) for s in shots])

    def test_integrated_picture_mode_preserves_timeline(self):
        import re
        text = PROMPT.replace("输出模式｜构图模式", "输出模式｜无独立构图栏模式")
        text = re.sub(r"\*\*构图：\*\*(.*?)\n\*\*画面内容：\*\*", r"**画面内容：** \1 ", text, flags=re.S)
        self.assertEqual([], blocking(text, SOURCE))
        self.assertEqual(3, len(validator.parse_shots(text)))

    def test_legacy_template_with_modern_content(self):
        parts = {i: validator.section(PROMPT, i) for i in range(1, 7)}
        text = PROMPT.split("\n## ", 1)[0].replace("精简六段", "兼容十一段") + "\n"
        bodies = [parts[2], parts[2], parts[1], parts[3], parts[3], parts[3],
                  parts[4], "运动围绕信息递进。\n", "克制交流。\n", parts[5], parts[6]]
        for i, (name, body) in enumerate(zip(validator.REQUIRED_HEADINGS, bodies), 1):
            text += f"## {i}. {name}\n{body}\n"
        self.assertEqual([], blocking(text, SOURCE))
        self.assertEqual(3, len(validator.parse_shots(text)))

    def test_intra_shot_beats_are_not_cuts(self):
        self.assertEqual(3, len(validator.parse_shots(PROMPT)))

    def test_actual_shot_gap_blocks(self):
        self.assertIn("TIMELINE_GAP", codes(PROMPT.replace("镜头02｜4–8", "镜头02｜5–8")))

    def test_state_end_overshoot_blocks(self):
        text = PROMPT.replace("信件｜[0–12]", "信件｜[0–13]")
        self.assertIn("STATE_END", codes(text))

    def test_zero_and_reversed_state_intervals_block(self):
        for window in ("[0–0]", "[3–1]"):
            self.assertIn("STATE_RANGE", codes(PROMPT.replace("信件｜[0–12]", "信件｜" + window)))

    def test_out_of_order_state_intervals_block(self):
        text = PROMPT.replace("信件｜[0–12]", "信件｜[6–12] 右手；[0–6]")
        self.assertIn("STATE_ORDER", codes(text))

    def test_final_frame_completion_needs_no_extra_interval(self):
        text = PROMPT.replace("信件｜[0–12] A右手持有，位置随同一右手的小幅动作变化，完整状态持续。",
                              "信件｜[0–10] A右手持有；[10–12] A右手将信件贴近胸前，镜末完成，出口仍由右手持有。")
        self.assertEqual([], validator.validate_state_timeline(text, 12))

    def test_shared_contact_is_not_duplicate_ownership_error(self):
        text = PROMPT.replace("信件｜[0–12] A右手持有，位置随同一右手的小幅动作变化，完整状态持续。",
                              "信件｜[0–4] A右手持有；[4–5] 同时由A和B握住，共持并承接重量，A随后松手；[5–12] B持有。")
        self.assertNotIn("MULTIPLE_PROP_OWNERS", codes(text))

    def test_two_actors_opposite_facing_does_not_conflict(self):
        text = PROMPT.replace("A画面左侧，B画面右侧。",
                              "A身体朝向画面右侧；B身体朝向画面左侧；A画面左侧，B画面右侧。")
        self.assertNotIn("ORIENTATION_CONFLICT", codes(text))

    def test_gaze_only_reaction_is_allowed(self):
        shot = validator.Shot(1, 0, 4, "双人中景", "固定",
                              "**画面内容：** B说：“好。”A听见后保持注视，等待下一句话。", 1)
        self.assertEqual([], validator.validate_reactions([shot]))

    def test_same_camera_grammar_with_different_beats_is_allowed(self):
        shots = [validator.Shot(i, i-1, i, "近景", "缓推", f"变化{i}", i) for i in (1, 2, 3)]
        self.assertEqual([], validator.validate_camera_rhythm(shots))

    def test_exact_source_words_and_speaker_checked(self):
        for text in (PROMPT.replace("我明天就走。", "我今晚就走。"),
                     PROMPT.replace("说话者：B｜听者：A", "说话者：A｜听者：A")):
            self.assertIn("DIALOGUE_SOURCE_MISMATCH", codes(text, SOURCE))

    def test_duplicate_dialogue_is_error(self):
        row = "对白D01｜[0.8–4.8]｜说话者：B｜听者：A｜原文：“我明天就走。”"
        self.assertIn("DUPLICATE_DIALOGUE", codes(PROMPT.replace(row, row + "\n" + row), SOURCE))

    def test_cross_cut_dialogue_is_one_continuous_line(self):
        self.assertEqual([], validator.validate_dialogue(PROMPT, 12, SOURCE))

    def test_unresolved_dialogue_is_error(self):
        self.assertIn("UNRESOLVED_DIALOGUE", codes(PROMPT.replace("对白D02由", "对白D99由")))

    def test_dialogue_outside_package_is_error(self):
        self.assertIn("DIALOGUE_TIME", codes(PROMPT.replace("[8.5–10.5]", "[8.5–13]")))

    def test_invalid_source_schema_is_error(self):
        self.assertIn("SOURCE_FORMAT", codes(PROMPT, {"bad": "schema"}))

    def test_no_subtitles_or_music_is_not_a_language_fault(self):
        text = PROMPT.replace("无配乐，无字幕", "不要配乐，禁止字幕")
        self.assertNotIn("NEGATIVE_LANGUAGE", codes(text))

    def test_invalid_expected_duration_rejected(self):
        for target in (-1, 0, float("inf"), float("nan")):
            self.assertIn("INVALID_DURATION", {x.code for x in validator.validate(PROMPT, target)})

    def test_missing_camera_mode_is_warning(self):
        text = PROMPT.replace("｜近主观克制手持\n", "\n")
        self.assertIn("CAMERA_MODE", codes(text))


    def test_malformed_shot_header_cannot_hide_inside_previous_shot(self):
        self.assertIn("SHOT_HEADER_FORMAT", codes(PROMPT.replace("镜头02｜4–8秒", "镜头02｜四至八秒")))

    def test_negative_state_interval_cannot_be_skipped(self):
        self.assertIn("STATE_START", codes(PROMPT.replace("信件｜[0–12]", "信件｜[-1–12]")))

    def test_missing_total_duration_is_flagged_in_v10(self):
        self.assertIn("DURATION_MISSING", codes(PROMPT.replace("总时长：12秒", "总时长：待定")))

    def test_malformed_state_interval_is_flagged(self):
        self.assertIn("STATE_FORMAT", codes(PROMPT.replace("信件｜[0–12]", "信件｜[零–12]")))

    def test_cli_strict_checks_source_and_returns_failure_for_mismatch(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            prompt, source = root / "prompt.md", root / "dialogue.json"
            prompt.write_text(PROMPT, encoding="utf-8")
            source.write_text(json.dumps(SOURCE, ensure_ascii=False), encoding="utf-8")
            command = [sys.executable, "-X", "utf8", str(ROOT / "scripts" / "validate_director_prompt.py"),
                       str(prompt), "--strict", "--source-dialogue", str(source)]
            result = subprocess.run(command, capture_output=True, text=True, encoding="utf-8")
            self.assertEqual(0, result.returncode, result.stdout + result.stderr)
            prompt.write_text(PROMPT.replace("那你看着我。", "别看着我。"), encoding="utf-8")
            result = subprocess.run(command, capture_output=True, text=True, encoding="utf-8")
            self.assertEqual(1, result.returncode)
            self.assertIn("DIALOGUE_SOURCE_MISMATCH", result.stdout)


if __name__ == "__main__":
    unittest.main()
