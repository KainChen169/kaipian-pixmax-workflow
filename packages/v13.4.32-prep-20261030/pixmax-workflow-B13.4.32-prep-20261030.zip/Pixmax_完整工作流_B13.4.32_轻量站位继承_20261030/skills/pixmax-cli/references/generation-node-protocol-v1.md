# Agent 画布生成节点与普通任务对接协议 v1

## 1. 文档状态

| 项目       | 内容                                   |
| ---------- | -------------------------------------- |
| 协议版本   | `agent-canvas-v1`                      |
| 适用客户端 | Agent、CLI、脚本及其他非 Web UI 客户端 |
| API 前缀   | `/user/api`                            |
| 节点范围   | 文本、图片、音频、视频生成节点         |
| 任务范围   | 普通生成任务 `/generate/batch`         |

本文是 Agent 客户端接入当前画布接口的规范性文档。本文中的“必须”“不得”“应当”是协议约束，不是界面操作建议。

接口鉴权方式由接入环境另行提供。请求中的用户身份由服务端鉴权上下文确定，客户端不得伪造 `userId`。

## 2. 支持范围

### 2.1 支持的节点

| 业务类型 | `CanvasNodeType` | 默认尺寸    | 结果字段              |
| -------- | ---------------- | ----------- | --------------------- |
| 文本生成 | `GENERATE_TEXT`  | `240 x 240` | `TaskCO.resultText`   |
| 图片生成 | `GENERATE_IMAGE` | `200 x 200` | `TaskCO.resultAssets` |
| 音频生成 | `GENERATE_AUDIO` | `280 x 120` | `TaskCO.resultAssets` |
| 视频生成 | `GENERATE_VIDEO` | `300 x 200` | `TaskCO.resultAssets` |

### 2.2 不支持的能力

本协议不支持：

- 快捷任务、模板任务和快捷工具任务；
- 分镜、分镜脚本、3D、导演台和剪辑台；
- Frame/group 创建及组内相对坐标；
- 批量生成、组任务和下游递归执行；
- 局部重绘、多角度、打光、超分、擦除等特殊任务；
- 依赖特殊 Web UI 才能完成配置的字段，例如录音、声音克隆、资产选择弹窗和可视化编辑器字段；
- 修改任务状态、进度、生成结果、合规状态或服务端资产信息。

如果目标模型包含本协议无法表达的必填字段，客户端必须选择其他模型或终止操作，不得猜测字段值。

## 3. 核心数据模型

### 3.1 画布作用域

一个项目可以包含多个画布文件。所有读写必须以当前画布文件的 `fileUuid` 为作用域，`projectUuid` 不能替代 `fileUuid`。

读取画布后必须保存响应中的 `revision`。后续节点写入必须把它作为 `baseRevision` 提交。

### 3.2 节点标识

- 新节点 `uuid` 由客户端生成；
- 推荐使用 UUID v7；
- 在一次操作及其重试过程中必须复用同一个 UUID；
- 不得复用画布中已有节点的 UUID 创建另一节点；
- 所有 `prevNodeUuids` 必须引用同一 `fileUuid` 下真实存在的节点。

### 3.3 节点类型

读取现有节点时，连接规则使用接口返回的 `CanvasNodeType`：

| 普通节点     | 生成节点         |
| ------------ | ---------------- |
| `BASE_TEXT`  | `GENERATE_TEXT`  |
| `BASE_IMAGE` | `GENERATE_IMAGE` |
| `BASE_AUDIO` | `GENERATE_AUDIO` |
| `BASE_VIDEO` | `GENERATE_VIDEO` |

Agent v1 只能创建右列四种生成节点，但可以把表中普通节点或生成节点作为上游输入。

### 3.4 服务端权威字段

以下数据由服务端任务或资产关系维护，客户端不得写入 `metaData.data`：

```text
status
errMsg
progress
userConcurrencyWaiting
url
assetsId
thumbnailUrl
poster
assets
width（媒体自然宽度）
height（媒体自然高度）
verifyStatus
verifyErrMsg
text
params
duration
```

生成参数写在 CanvasNode 顶层 `params`；文本生成结果/内容写在顶层 `nodeText`；媒体结果由服务端 `defaultAsset`、`nodeAssets` 和 `generationTask` 返回。

## 4. 接口总览

所有接口均为 `POST`。

| 阶段 | 路径                           | 用途                      |
| ---- | ------------------------------ | ------------------------- |
| 读取 | `/user/api/canvas/get`         | 获取画布、节点和 revision |
| 配置 | `/user/api/canvas/modelConfig` | 获取模型、参数和输入约束  |
| 保存 | `/user/api/canvas/node/batch`  | 创建或更新节点及关系      |
| 提交 | `/user/api/generate/batch`     | 提交普通生成任务          |
| 查询 | `/user/api/generate/progress`  | 查询任务状态和结果        |
| 取消 | `/user/api/generate/cancel`    | 取消排队任务，可选        |

通用响应外层：

```json
{
  "success": true,
  "errCode": "",
  "errMessage": "",
  "requestId": "request-id",
  "data": {}
}
```

客户端必须先判断 `success`，不得只依据 HTTP 状态码判断业务成功。

## 5. 固定调用流程

客户端必须按以下顺序执行：

```text
1. canvas/get：读取当前画布和 revision
2. canvas/modelConfig：读取动态模型配置
3. 选择节点类型和当前用户可用的 modelCode
4. 根据选定模型校验有序上游输入
5. 根据模型 schema 组装并规范化 params
6. 计算节点位置和 metaData
7. canvas/node/batch：保存节点、参数和 prevNodeUuids
8. 确认保存成功并记录新 revision
9. generate/batch：提交目标 nodeUuid
10. 确认返回 data 中存在目标 nodeUuid
11. generate/progress：轮询直到终态
```

节点保存成功前不得调用 `/generate/batch`。

节点只保存不执行时，在第 8 步结束即可。

## 6. 读取画布

请求：

```http
POST /user/api/canvas/get
```

```json
{
  "fileUuid": "<FILE_UUID>"
}
```

关键响应：

```json
{
  "success": true,
  "data": {
    "uuid": "<CANVAS_UUID>",
    "fileUuid": "<FILE_UUID>",
    "revision": "<REVISION>",
    "nodes": [
      {
        "uuid": "<NODE_UUID>",
        "type": "BASE_IMAGE",
        "nodeText": "",
        "params": {},
        "metaData": "{...}",
        "prevNodeUuids": [],
        "defaultAsset": null,
        "nodeAssets": [],
        "generationTask": null
      }
    ]
  }
}
```

客户端至少需要建立以下索引：

```text
nodeByUuid: nodeUuid -> CanvasNodeCO
nodeTypeByUuid: nodeUuid -> CanvasNodeType
positionByUuid: nodeUuid -> { x, y, width, height }
```

`position`、节点外框 `width/height` 位于 `metaData` JSON 字符串中。解析失败时不得覆盖原节点；新节点布局可退化为默认尺寸计算。

## 7. 读取和解释模型配置

请求：

```http
POST /user/api/canvas/modelConfig
```

请求体可以为空对象：

```json
{}
```

响应中的每个 `canvasNodeType` 对应多个模型：

```json
{
  "canvasNodeType": "GENERATE_IMAGE",
  "nodeConfig": [
    {
      "modelName": "展示名称",
      "modelCode": "MODEL_CODE",
      "restricted": false,
      "modelConfig": {
        "allowNodeType": [
          {
            "codes": ["BASE_IMAGE", "GENERATE_IMAGE"],
            "length": "[0,4]",
            "allTextLength": "[0,0]"
          }
        ],
        "params": [
          {
            "name": "prompt",
            "type": "text",
            "length": "[0,2000]",
            "advanced": false
          },
          {
            "name": "count",
            "type": "select",
            "default": "1",
            "options": [{ "name": "1", "value": "1" }],
            "advanced": false,
            "length": "[0,0]"
          }
        ]
      }
    }
  ]
}
```

示例只用于说明结构，实际模型、字段和值必须使用当次接口响应。

### 7.1 选择模型

客户端必须：

1. 选择与目标生成节点类型相同的 `canvasNodeType`；
2. 只选择 `restricted !== true` 的模型；
3. 使用 `modelCode` 写入 `params.model`；
4. 不得把 `modelName` 写入新节点；
5. 确认当前有序上游输入满足该模型的连接约束；
6. 无合法模型时终止操作。

服务端仍可能因为订阅、权限、区域、积分或模型临时状态拒绝任务。客户端必须保留并返回服务端 `errCode/errMessage`。

### 7.2 初始化参数

参数组装顺序：

```text
1. params.model = modelCode
2. 遍历所选模型的 modelConfig.params
3. 每个字段先取 default
4. 没有 default 时取空字符串 ""
5. 应用调用方显式传入的值
6. 执行字段依赖、选项和范围校验
7. 删除不属于当前模型 schema 的字段
```

所有动态字段建议以字符串提交，包括 `count`、时长、开关和数值范围。

### 7.3 字段规则

| 字段类型       | v1 处理规则                                                    |
| -------------- | -------------------------------------------------------------- |
| `text`         | 字符串；长度必须在 `length` 范围内                             |
| `select`       | 值必须来自当前启用的 `options[].value`                         |
| `radio`        | 同 `select`                                                    |
| `switch`       | 使用字符串 `"true"` 或 `"false"`                               |
| `range`        | 解析为数字，限制到 `min/max`，再按 `step` 吸附，最后转回字符串 |
| `input`        | 只有接入方明确实现该字段时才允许使用                           |
| `radio-switch` | 只有接入方明确实现该字段时才允许使用                           |

范围字符串采用 `[min,max]` 格式，边界均包含。例如 `[0,4]` 表示 `0 <= value <= 4`。

`range` 规范化算法：

```text
parsed = Number(value)
fallback = Number(default)，若无合法 default 则取 min
clamped = min(max, max(min, parsed ?? fallback))
snapped = round(clamped / step) * step
result = String(clamp(snapped, min, max))
```

### 7.4 选项依赖

`options[].dependOn` 可能包含：

- `type: "field"`：其他字段值必须在 `inValues` 中；
- `type: "inputNodeTypes"`：指定输入节点类型的合计数量必须在 `length` 范围内。

一个 option 的所有 `dependOn` 必须同时满足，才能使用该 option。

如果显式值不可用，客户端按以下顺序回退：

```text
1. 当前仍启用且等于字段 default 的 option
2. 第一个启用的 option
3. 字段 default
4. 空字符串
```

### 7.5 切换模型

修改已有节点的模型时必须重建参数：

1. 读取新模型 schema；
2. 用新模型默认值初始化全部字段；
3. 原 `prompt` trim 后非空时允许保留；
4. 其他旧模型字段不得自动保留；
5. 重新执行连接和字段依赖校验。

## 8. 上游输入与连线规则

### 8.1 数据表达

服务端没有需要客户端维护的独立 Edge ID。目标节点通过有序数组 `prevNodeUuids` 保存全部直接上游：

```json
{
  "uuid": "<TARGET_NODE_UUID>",
  "prevNodeUuids": ["<FIRST_SOURCE_NODE_UUID>", "<SECOND_SOURCE_NODE_UUID>"]
}
```

数组顺序即输入顺序。交换数组元素属于业务修改，不是纯展示修改。

### 8.2 必须满足的不变量

- source 和 target 必须存在；
- source 与 target 不得相同；
- `prevNodeUuids` 中不得出现重复 UUID；
- source 与 target 必须属于同一画布文件；
- source 类型必须出现在所选模型至少一个 `allowNodeType[].codes` 中；
- 每个 `allowNodeType` 分组的输入合计数量必须满足其 `length`；
- 不得创建有向环；
- Agent v1 只修改目标生成节点的直接上游，不递归修改其他节点。

“不得创建有向环”是 Agent v1 的保守规则。即使部分 Web 交互未显式阻止所有环，Agent 也不得依赖该行为。

### 8.3 连接数量校验

对所选模型的每个约束项执行：

```text
total = sum(
  上游节点类型在 constraint.codes 中的节点数量
)

要求 constraint.min <= total <= constraint.max
```

例如：

```json
{
  "codes": ["BASE_IMAGE", "GENERATE_IMAGE"],
  "length": "[1,4]"
}
```

表示普通图片节点和图片生成节点合计必须为 1 至 4 个。

### 8.4 修改和清空关系

更新目标节点时：

- 省略 `prevNodeUuids`：保持关系不变；
- 传 `prevNodeUuids: []`：清空全部直接上游；
- 传非空数组：按给定顺序重建全部直接上游。

不得使用已废弃的 `mapAdd/mapRemove` 表达 Agent v1 的连线修改。

## 9. 输入资源属性校验

所选模型的 `allowNodeType[].properties` 可能限制输入内容。客户端能够获得元数据时应预校验，服务端错误仍是最终结果。

| 媒体 | 可能的限制                                |
| ---- | ----------------------------------------- |
| 文本 | 节点数量、最大字符/token 配置 `maxTokens` |
| 图片 | 单个/总体积、格式、长宽比、分辨率、总像素 |
| 视频 | 图片类限制、最小/最大/总时长、帧率、编码  |
| 音频 | 单个/总体积、格式、最小/最大/总时长       |

如果必要元数据缺失，客户端不得伪造。可以继续提交并让服务端校验，但必须把服务端校验失败返回给调用者。

## 10. 位置与布局

### 10.1 坐标语义

- `position` 是画布世界坐标中的节点左上角；
- 不是浏览器屏幕坐标；
- Agent v1 创建的节点均为根节点，不传 `parentId`；
- `x/y` 必须为有限数；
- `abs(x)` 和 `abs(y)` 均不得超过 `1,000,000`。

### 10.2 默认布局算法

调用方没有指定绝对位置时，客户端应使用以下确定性算法：

有上游输入：

```text
newX = max(source.position.x + source.width) + 200
newY = average(source.position.y + source.height / 2) - newNode.height / 2
```

无上游输入：

```text
newX = max(existing.position.x + existing.width) + 200
newY = 0
```

空画布：

```text
newX = 0
newY = 0
```

如果新节点矩形与现有节点重叠，则保持 `newX` 不变，并反复执行：

```text
newY = newY + newNode.height + 80
```

直到不再重叠或坐标超出有效范围。超出范围时终止操作。

### 10.3 metaData

Agent v1 新建节点的逻辑结构：

```json
{
  "data": {
    "label": "节点标题"
  },
  "position": {
    "x": 600,
    "y": 200
  },
  "width": 200,
  "height": 200
}
```

在线上传输时，`metaData` 必须是上述对象的 JSON 字符串：

```json
{
  "metaData": "{\"data\":{\"label\":\"节点标题\"},\"position\":{\"x\":600,\"y\":200},\"width\":200,\"height\":200}"
}
```

本协议范围内不得写入 `measured`、`hidden`、`parentId` 或 `groupTitle`。

## 11. 创建和更新节点

### 11.1 批量保存接口

```http
POST /user/api/canvas/node/batch
```

```json
{
  "fileUuid": "<FILE_UUID>",
  "baseRevision": "<REVISION_FROM_CANVAS_GET>",
  "create": [],
  "update": [],
  "delete": []
}
```

没有对应操作时可以省略 `create/update/delete`。

### 11.2 创建字段

| 字段               | 必填     | 规则                             |
| ------------------ | -------- | -------------------------------- |
| `uuid`             | 是       | 客户端生成并在重试中复用         |
| `type`             | 是       | 本协议支持的四种生成类型之一     |
| `metaData`         | 是       | 第 10 节定义的 JSON 字符串       |
| `params`           | 是       | 当前模型完整、规范化后的参数     |
| `prevNodeUuids`    | 有输入时 | 有序直接上游列表；无输入时可省略 |
| `nodeText`         | 文本生成 | 新节点传空字符串 `""`            |
| `defaultAssetUuid` | 媒体生成 | 新节点无结果时传空字符串 `""`    |

### 11.3 更新字段

`update` 项必须传 `uuid`，其他字段按修改内容传递：

```json
{
  "uuid": "<NODE_UUID>",
  "params": {
    "model": "MODEL_CODE",
    "prompt": "新的提示词"
  },
  "prevNodeUuids": ["<SOURCE_NODE_UUID>"]
}
```

省略字段表示保持不变。修改 `metaData` 前必须读取并保留其中不属于本协议管理范围的未知字段，避免覆盖其他客户端数据。

### 11.4 成功响应

```json
{
  "success": true,
  "data": {
    "created": ["<NODE_UUID>"],
    "updated": [],
    "deleted": [],
    "restored": [],
    "revision": "<NEW_REVISION>"
  }
}
```

客户端必须确认目标 UUID 出现在 `created` 或 `updated` 中，并保存新 `revision`。

## 12. revision、幂等与重试

### 12.1 revision 冲突

当响应：

```json
{
  "success": false,
  "errCode": "Canvas.Revision.Conflict"
}
```

客户端必须：

1. 重新调用 `/canvas/get`；
2. 获取最新节点和 revision；
3. 检查目标节点及所有上游仍存在；
4. 基于最新状态重新计算关系、位置和 update；
5. 使用新 revision 重试；
6. 默认最多自动重试一次，仍冲突则交给调用者处理。

客户端不得移除 `baseRevision` 强行覆盖。

### 12.2 请求结果不明确

网络超时或连接中断导致保存结果不明确时：

1. 不生成新的 node UUID；
2. 调用 `/canvas/get` 查找原 node UUID；
3. 节点已存在时，将后续修改作为 update；
4. 节点不存在时，复用原 UUID 重试 create。

接口当前允许把重复 UUID 的 create 转换为 update，因此盲目重试可能覆盖已有节点。重试前必须重新读取。

### 12.3 部分流程失败

| 状态                       | 重试动作                                                |
| -------------------------- | ------------------------------------------------------- |
| 节点保存失败               | 不提交任务，修复或重试保存                              |
| 节点保存成功，任务提交失败 | 不重复创建节点，只重试 `/generate/batch`                |
| 任务提交结果不明确         | 先查询 `/generate/progress` 或重新读取 `generationTask` |
| 轮询临时失败               | 保持任务注册状态，退避后继续轮询                        |

## 13. 提交普通生成任务

请求：

```http
POST /user/api/generate/batch
```

Agent v1 每次只提交一个节点：

```json
{
  "nodeUuids": ["<NODE_UUID>"]
}
```

成功响应是任务数组：

```json
{
  "success": true,
  "data": [
    {
      "taskUuid": "<TASK_UUID>",
      "nodeUuid": "<NODE_UUID>",
      "status": "QUEUE",
      "createTime": "2026-08-20T12:00:00Z",
      "updateTime": "2026-08-20T12:00:00Z"
    }
  ]
}
```

除检查 `success === true` 外，还必须确认 `data` 中存在 `nodeUuid === <NODE_UUID>` 的任务。不存在时按提交失败处理。

## 14. 查询任务状态和结果

请求：

```http
POST /user/api/generate/progress
```

```json
{
  "nodeUuids": ["<NODE_UUID>"]
}
```

建议每 3 秒轮询一次。临时错误应采用退避策略，避免高频重试。

### 14.1 状态机

| 状态                  | 类型     | 客户端行为              |
| --------------------- | -------- | ----------------------- |
| `QUEUE`               | 进行中   | 继续轮询                |
| `WAITING_CONCURRENCY` | 进行中   | 继续轮询                |
| `RUNNING`             | 进行中   | 更新 progress，继续轮询 |
| `COMPLETE`            | 成功终态 | 读取结果并停止轮询      |
| `FAILED`              | 失败终态 | 返回错误并停止轮询      |
| `ABORTED`             | 失败终态 | 返回错误并停止轮询      |

### 14.2 结果读取

文本：

```json
{
  "status": "COMPLETE",
  "resultText": "生成的文本"
}
```

图片、音频和视频：

```json
{
  "status": "COMPLETE",
  "resultAssets": [
    {
      "assetsUuid": "<ASSET_UUID>",
      "webUrl": "<RESULT_URL>",
      "thumbnailWebUrl": "<THUMBNAIL_URL>"
    }
  ]
}
```

失败时应返回原始 `providerErrorMsg` 和接口 `requestId`，便于定位问题。

任务完成后不需要由 Agent 把结果重新写入 `metaData`、`nodeText` 或 `defaultAssetUuid`。服务端返回的任务和资产关系是权威结果。

## 15. 端到端示例

以下示例中的 `<...>` 必须替换为当次真实值。模型参数只是结构示例，必须以 `/canvas/modelConfig` 为准。

### 15.1 文本生成，无上游

保存节点：

```json
{
  "fileUuid": "<FILE_UUID>",
  "baseRevision": "<REVISION>",
  "create": [
    {
      "uuid": "<NEW_TEXT_NODE_UUID>",
      "type": "GENERATE_TEXT",
      "nodeText": "",
      "metaData": "{\"data\":{\"label\":\"文案生成\"},\"position\":{\"x\":0,\"y\":0},\"width\":240,\"height\":240}",
      "params": {
        "model": "<TEXT_MODEL_CODE>",
        "prompt": "为新品写一段简洁的产品介绍"
      }
    }
  ]
}
```

提交：

```json
{
  "nodeUuids": ["<NEW_TEXT_NODE_UUID>"]
}
```

### 15.2 图片生成，引用一张已有图片

前置条件：`<SOURCE_IMAGE_NODE_UUID>` 存在，类型为所选模型允许的 `BASE_IMAGE` 或 `GENERATE_IMAGE`。

```json
{
  "fileUuid": "<FILE_UUID>",
  "baseRevision": "<REVISION>",
  "create": [
    {
      "uuid": "<NEW_IMAGE_NODE_UUID>",
      "type": "GENERATE_IMAGE",
      "defaultAssetUuid": "",
      "metaData": "{\"data\":{\"label\":\"参考图生图\"},\"position\":{\"x\":600,\"y\":100},\"width\":200,\"height\":200}",
      "params": {
        "model": "<IMAGE_MODEL_CODE>",
        "prompt": "保持主体特征，生成简洁的棚拍产品图",
        "count": "1"
      },
      "prevNodeUuids": ["<SOURCE_IMAGE_NODE_UUID>"]
    }
  ]
}
```

### 15.3 音频生成

仅选择其所有必填字段都能由 Agent v1 表达的音频模型。例如模型要求 `timbreId` 时，接入方必须已经获得合法的 `timbreId`，否则不得提交。

```json
{
  "fileUuid": "<FILE_UUID>",
  "baseRevision": "<REVISION>",
  "create": [
    {
      "uuid": "<NEW_AUDIO_NODE_UUID>",
      "type": "GENERATE_AUDIO",
      "defaultAssetUuid": "",
      "metaData": "{\"data\":{\"label\":\"旁白生成\"},\"position\":{\"x\":600,\"y\":350},\"width\":280,\"height\":120}",
      "params": {
        "model": "<AUDIO_MODEL_CODE>",
        "prompt": "欢迎使用我们的新产品",
        "timbreId": "<VALID_TIMBRE_ID>"
      }
    }
  ]
}
```

### 15.4 视频生成，两个有序输入

```json
{
  "fileUuid": "<FILE_UUID>",
  "baseRevision": "<REVISION>",
  "create": [
    {
      "uuid": "<NEW_VIDEO_NODE_UUID>",
      "type": "GENERATE_VIDEO",
      "defaultAssetUuid": "",
      "metaData": "{\"data\":{\"label\":\"产品视频\"},\"position\":{\"x\":900,\"y\":200},\"width\":300,\"height\":200}",
      "params": {
        "model": "<VIDEO_MODEL_CODE>",
        "prompt": "生成平稳的产品展示镜头",
        "duration": "5"
      },
      "prevNodeUuids": ["<FIRST_SOURCE_NODE_UUID>", "<SECOND_SOURCE_NODE_UUID>"]
    }
  ]
}
```

`FIRST` 和 `SECOND` 的顺序不得在保存或重试时被排序器打乱。

## 16. 可选的 prompt 上游引用协议

普通连接只需要 `prevNodeUuids`。只有模型或业务明确要求 prompt 内指向某个上游时，才使用当前 mention token：

```text
%%@[tokenTitle][text|audio|image|video][index](nodeUuid)%%
```

例如：

```text
参考 %%@[产品正面图][image][0](019-source-uuid)%% 生成棚拍主图
```

其中 `index` 是同媒体类型输入中的零基序号。mention 中的 `nodeUuid` 必须同时存在于目标节点 `prevNodeUuids`。

Agent v1 不支持其他富文本 token、相机参数 token、运镜 token、全景 token 或自定义 hash token。

## 17. 错误处理表

| `errCode`/情况                | 是否可重试 | 动作                                         |
| ----------------------------- | ---------- | -------------------------------------------- |
| `Canvas.Revision.Conflict`    | 是         | 重新读取画布并最多自动重试一次               |
| `DUPLICATE_SUBMISSION`        | 视情况     | 重新读取目标节点和任务状态，不得盲目重复提交 |
| `Param.Error`                 | 否         | 修正请求字段或动态参数                       |
| `Invalid.Model.Name`          | 否         | 重新拉取模型配置并选择合法 modelCode         |
| `Prompt.Empty`                | 否         | 提供 prompt 或选择允许空 prompt 的模型       |
| `Prompt.Too.Long`             | 否         | 按 schema 截断或让调用者修改                 |
| `Credit.Insufficient.Balance` | 否         | 返回调用者处理                               |
| 权限相关错误                  | 否         | 返回调用者处理，不切换身份                   |
| HTTP 5xx/网络错误             | 是         | 指数退避；写请求重试前先读取服务器状态       |
| `success=true` 但缺少目标任务 | 视为失败   | 查询任务状态，仍不存在则返回异常             |

客户端返回错误时至少保留：

```text
阶段：read/config/save/submit/poll
fileUuid
nodeUuid
taskUuid（若有）
requestId
errCode
errMessage
是否可重试
```

## 18. Agent 客户端建议工具面

Agent 运行时不需要读取本文全文。客户端可以把本文规则固化为以下工具：

```text
get_canvas(fileUuid)
get_generation_models(nodeType)
create_generation_node(fileUuid, revision, type, modelCode, params, inputNodeUuids, position?)
update_generation_node(fileUuid, revision, nodeUuid, params?, inputNodeUuids?, position?)
submit_generation(nodeUuid)
get_generation_status(nodeUuid)
```

工具实现负责：

- 读取并解释动态模型配置；
- 生成 UUID；
- 参数默认值、范围和依赖校验；
- 上游类型、数量、顺序和环校验；
- metaData 序列化；
- revision 冲突重试；
- 任务状态归一化。

LLM 只负责选择业务意图，不应直接拼接未校验的 `/canvas/node/batch` 请求。

## 19. 接入验收清单

接入完成前必须通过以下用例：

- 创建无上游文本生成节点并获得 `resultText`；
- 创建无上游图片生成节点并获得 `resultAssets`；
- 创建带单一图片上游的图片生成节点；
- 创建带两个有序上游的视频生成节点，刷新画布后顺序不变；
- 创建音频生成节点，特殊必填字段缺失时在保存/提交前失败；
- 非法 modelCode 被拒绝；
- 超出连接数量限制时被拒绝；
- source 或 target 不存在时被拒绝；
- 自连、重复连接和环被拒绝；
- revision 冲突后能重新读取并安全重试；
- 保存成功但任务提交失败时不会重复创建节点；
- `QUEUE/RUNNING/WAITING_CONCURRENCY` 持续轮询；
- `COMPLETE/FAILED/ABORTED` 停止轮询并返回正确结果；
- Agent 不会把任务状态和结果字段写入 metaData。
