# pixmax

`pixmax` 是 Pixmax 平台的官方命令行工具。它直接调用 Pixmax Web 端正在使用的 `/user/api` 后端接口，用于管理项目、画布、节点、资产、模型、任务、模板，以及图片、视频、分镜、脚本等生成工作流。面向用户的一页式入口见仓库根目录 `README.md`。

文档结构：

- 先给可直接复制的安装、登录、上下文绑定命令
- 再给能力矩阵，明确当前命令覆盖哪些平台能力
- 再给安全约定：所有远端变更和生成任务优先试运行
- 最后给图片、视频、资产、合规、脚本、分镜和工作流的领域化示例

## 给智能体的安装提示词

可以把下面这段话直接发给支持终端操作的智能体：

```text
请帮我安装并初始化 Pixmax CLI。进入 Pixmax CLI 包目录（包含 setup.py 的目录）后，执行 bash scripts/install.sh。安装后运行 pixmax --json doctor 做本地自检，再运行 pixmax --help 确认命令可用。需要登录时运行 pixmax auth login web，我会在浏览器里完成授权；也可以只使用当前 shell 的 PIXMAX_BEARER_TOKEN 环境变量。不要把我的 Pixmax token 写入源码、文档、脚本或提交记录。登录后请运行 pixmax --json doctor --online 验证线上鉴权。
```

## 安装

推荐使用一键安装脚本，它会检查 Python 环境、安装稳定启动器和自包含 Runtime，并自动运行 `doctor` 自检：

```bash
# macOS / Linux
bash scripts/install.sh
```

```powershell
# Windows（PowerShell）
powershell -ExecutionPolicy Bypass -File scripts/install.ps1
```

远程安装入口会初始化对应环境并固化对应站点的更新源；两个站点使用相同的 Runtime 内容：

```bash
curl -fsSL https://app.pixmax.cn/cli/install.sh | bash       # 中国大陆
curl -fsSL https://console.pixmax.ai/cli/install.sh | bash  # 海外
```

本地安装可传 `--environment global`；PowerShell 对应 `-Environment global`。已有配置不会在升级时被覆盖。

## 环境与语言配置

```bash
pixmax --json config show
pixmax config set --environment cn       # 或 global
pixmax config set --locale zh-CN         # 或 en
```

也可单次使用 `--environment` / `--locale`，或设置 `PIXMAX_ENV` / `PIXMAX_LOCALE`。语言不会改变服务环境，机器可读 JSON 字段也不随语言变化。本地 session 按服务环境隔离账号、项目、文件和工作流，避免跨站混用凭证。

本地源码开发安装：

```bash
PIXMAX_CLI_SOURCE_DIR="$PWD" bash scripts/install.sh
```

本地源码安装使用 `development` 通道并关闭云端更新。生产安装每次启动都会校验签名静态源；任何更新失败都会阻止原始业务命令。

更新状态与恢复命令：

```bash
pixmax --version
pixmax --json update status
pixmax update retry
pixmax update repair
```

热更新构建、签名、目录格式、退出码和发布顺序记录在源码仓库维护文档中；该维护文档不进入发布包。

生成可分发的 Skill 包：

```bash
pixmax --json skill package --out <输出目录>
```

默认输出：

- `dist/pixmax-cli-skill/`
- `dist/pixmax-cli-skill.zip`

Skill 包内包含可安装 CLI 源码、`setup.py`、`SKILL.md`、中文总览、中文 README、工程说明和安装脚本，解压后可直接执行 `bash scripts/install.sh`。

## 登录

推荐使用网页登录。CLI 会打开浏览器授权页，你在网页上确认授权后，CLI 自动获取凭证并保存到本地：

```bash
pixmax auth login web
pixmax --json auth login status
```

网页登录默认把 token 保存在本地 session 文件（`~/.pixmax-cli/session.json`）；传 `--no-store-token` 则只验证不保存。

已有 bearer token 时，也可以使用环境变量或 token 登录。不要把 token 写进脚本、源码或文档：

```bash
export PIXMAX_BEARER_TOKEN="..."          # Windows PowerShell: $env:PIXMAX_BEARER_TOKEN = "..."
pixmax --json auth login token --token "$PIXMAX_BEARER_TOKEN" --profile main
pixmax --json auth login token --token "$PIXMAX_BEARER_TOKEN" --profile main --store-token
```

`auth login token` 默认只保存账号摘要，不保存 token；只有显式 `--store-token` 才会把 token 写入本地 session 文件。需要多账号切换时，可以继续使用本地 auth profile：

```bash
pixmax --json auth profile list
pixmax --json auth profile use main
```

如果没有有效登录凭证，线上命令会返回认证失败，`doctor --online` 会把它归类为鉴权问题而不是平台能力缺失。

## 快速开始

```bash
pixmax --json doctor
pixmax --json skill prompt
pixmax --json skill files
pixmax --json auth login status
pixmax auth whoami
pixmax --json auth profile list
pixmax project use <project_uuid> --file <file_uuid>
pixmax --json doctor --online
pixmax --json project files
pixmax --json canvas summary --no-prompts
pixmax canvas export -o canvas-summary.json
pixmax --json capabilities matrix
pixmax --json capabilities probe --dry-run
pixmax --json model search --type GENERATE_IMAGE pix
pixmax --json node list --generated
```

默认建议加 `--json` 给智能体或自动化脚本使用；人手调试时可以省略。

## 常用命令

```bash
pixmax --json doctor
pixmax --json doctor --online
pixmax --json skill prompt
pixmax --json skill show
pixmax --json skill package --out /tmp/pixmax-skill
pixmax auth login web
pixmax --json auth login token --token "$PIXMAX_BEARER_TOKEN" --profile main
pixmax --json auth login status
pixmax --json auth profile save main --token "$PIXMAX_BEARER_TOKEN"
pixmax --json auth profile use main
pixmax project info
pixmax project save --name "New Project" --dry-run
pixmax project file create --name "Frame 2" --dry-run
pixmax canvas nodes --generated --json
pixmax canvas model-config --json
pixmax canvas node create --data '{"type":"BASE_IMAGE"}' --dry-run
pixmax model search --type GENERATE_IMAGE gpt --json
pixmax model explain PIXDANCE_2 --json
pixmax model get GPT_IMAGE_2 --json
pixmax node get "Hero" --json
pixmax node update "Hero" --prompt "new prompt" --left "Reference" --run
pixmax node create "New Hero" -t GENERATE_IMAGE --model GPT_IMAGE_2 --prompt "make image" --run
pixmax image generate "New Hero" --prompt "make image" --run
pixmax image edit "Realistic Hero" --image-node "Reference" --prompt "make it realistic" --run
pixmax assets upload ./image.png --file-uuid <file_uuid> --as-node "Reference" --dry-run
pixmax assets compliance-check <asset_uuid>
pixmax video image-to-video "Shot 1" --image-node "Reference" --prompt "make it move"
pixmax video text-to-video "Shot 2" --prompt "a cinematic sunrise"
pixmax workflow image-to-video "Shot Chain" --image-prompt "a realistic monk portrait" --video-prompt "the monk chants then stands" --run
pixmax workflow script-to-video "Script" --max-rows 2 --run
pixmax workflow save monk-shot --type image-to-video -s image_prompt="a monk portrait" -s video_prompt="make it move"
pixmax workflow run monk-shot --dry-run
pixmax tasks wait <node_uuid>
pixmax tasks submit-batch --data '{"fileUuid":"...","nodeUuids":["..."]}' --wait
pixmax templates categories --json
pixmax raw POST /project/get --data '{"uuid":"..."}'
```

## 能力总览

完整、权威的能力矩阵（命令分组、子命令、对应端点）由 CLI 自身维护，`doctor` 会校验它与实际命令树一致：

```bash
pixmax --json capabilities matrix
```

分领域的命令示例见上方"常用命令"和下文图片、视频、资产、脚本、分镜、工作流章节；单条命令的参数用 `pixmax <command> --help` 查看。

## 智能体使用模式

### 1. 先做安装自检

```bash
pixmax --json doctor
pixmax --json doctor --online
```

`doctor` 默认只检查本地安装、能力矩阵、session 和 token 是否配置，不调用 Pixmax 线上接口；加 `--online` 后会调用 `/user/info` 验证 token 是否真实可用。输出中的 `nextActions` 可以直接作为智能体下一步操作清单。

`skill prompt` 输出可直接发给智能体的安装提示词；`skill show` 展示本地 `SKILL.md`；`skill files` 列出 Skill 包组成；`skill package` 会生成可分发 Skill 目录和 zip。

如果是在打包后的 Skill 目录中使用，优先阅读 `OVERVIEW.md`、`INSTALL.md` 和 `SKILL.md`。这三个文件分别对应用户总览、安装步骤和智能体执行规则。

### 2. 再绑定上下文

```bash
pixmax project use <project_uuid> --file <file_uuid>
pixmax session status --json
```

绑定后，大多数命令可以省略 `--project` 和 `--file`，更适合连续自动化。

### 3. 用 `nodeKey` 串联节点

`node get`、`node create`、`image generate`、`storyboard create` 等命令会输出可复用的 `nodeKey`。后续命令可以用 label、uuid 或 `nodeKey` 记录连接上游节点。

```bash
pixmax node get "Reference" --json
pixmax node create "New Hero" -t GENERATE_IMAGE --model GPT_IMAGE_2 --prompt "use reference" --left "Reference" --dry-run
```

### 4. 生成任务默认可等待终态

面向生成的高层命令支持 `--run`、`--wait/--no-wait`、`--interval`、`--timeout`：

```bash
pixmax image generate "Hero" --prompt "a realistic monk portrait" --run --interval 5 --timeout 1800
pixmax tasks wait <node_uuid>
```

返回结果会包含 Pixmax 原始提交结果、等待状态和 `resultAssets`。

### 5. 提交前验证模型参数

`node create|update --run`、`image`、`video`、`storyboard`、`workflow` 等提交路径会读取 `canvas model-config` 做本地校验。当前校验覆盖：

- 模型 code 与节点类型是否匹配
- select/radio 枚举值
- 文本长度
- `allowNodeType` 输入节点数量和类型
- 媒体宽高、时长、文件大小等 schema 约束
- `requiredIf`、`dependsOn` 等常见条件参数
- Seedance `referModel` 的图生视频/文生视频输入规则

查看模型能力：

```bash
pixmax model explain PIXDANCE_2 --json
```

只有在测试新后端参数或平台刚上线但 schema 未同步时，才建议使用 `--no-validate`。

### 6. Prompt 中引用节点

Pixmax 画布把 `@` 资产引用保存为平台 mention token：

```text
%%@[tokenTitle][text|audio|image|video][index](nodeUuid)%%
```

其中 `nodeUuid` 是承载资产的画布节点 UUID，不是资产 UUID。CLI 会确认节点属于当前画布且具有可用内容，把它加入 `prevNodeUuids`，并按最终上游顺序重新计算标题、媒体类型和同类零基 `index`。

迁移期仍可把旧格式作为输入简写：

```text
{{Node "exact label or uuid"}}
```

CLI 会在保存前把它转换成平台 mention token，不会原样写入 prompt。更新节点时使用 `--left-set` 按给定顺序完整替换上游，使用 `--left-clear` 清空；断开仍被 prompt 引用的节点会失败，必须同时修改 prompt。

普通生成节点不接受畸形 mention、跨画布节点，以及 `%%#[...]`、`<#...#>` 等 v1 未支持的富 token。

## 资产上传与合规检测

资产上传遵循 Pixmax 当前接口链路：

1. `/assets/check` 秒传/预检查
2. `/assets/oss/authorize` 获取 OSS 授权
3. 调用 OSS PUT/POST/STS 上传
4. `/assets/oss/check` 轮询确认
5. 可选 `--as-node` 在画布创建 `BASE_IMAGE`、`BASE_VIDEO` 或 `BASE_AUDIO`

```bash
pixmax assets upload ./reference.png --file-uuid <file_uuid> --as-node "Reference" --dry-run
```

Seedance 2.0 图生视频如果使用人物参考图，应先做资产合规检测：

```bash
pixmax assets compliance-check <asset_uuid>
```

该命令调用 `/assetLibrary/compliance/check`，并轮询到 `ACTIVE`、`PASS`、`FAILED` 等终态。

## 图片、视频、分镜、脚本

图片：

- `image generate`：创建 `GENERATE_IMAGE` 节点，提交并等待结果
- `image edit`：解析参考图片节点，连接上游，再创建图像生成节点

视频：

- `video image-to-video`：解析参考图片节点，默认做合规检测，创建 `GENERATE_VIDEO` 节点并提交
- `video text-to-video`：创建文生视频节点，并拒绝 prompt 中的媒体节点引用，避免误走图生视频

分镜：

- `storyboard config`：读取 Pixmax 分镜配置
- `storyboard create`：创建 `GENERATE_STORYBOARD` 节点，可 `--run` 等待结果

脚本：

- `script create`：创建 `GENERATE_TEXT` 脚本承载节点
- `script set-rows`：把结构化行数据存入节点 metadata
- `script rows`：读取脚本行
- `script storyboard`：按脚本行派生分镜节点

## 工作流

`workflow image-to-video` 会先生成参考图，等待图片 `resultAssets`，再做合规检测，并创建下游 Seedance 视频节点。

```bash
pixmax workflow image-to-video "Monk Shot" \
  --image-prompt "a realistic old monk portrait" \
  --video-prompt "an old monk chants then stands up" \
  --run
```

`workflow script-to-video` 会把脚本行变成分镜图，再把分镜图变成 Seedance 视频镜头：

```bash
pixmax workflow script-to-video "Script" --max-rows 2 --run
```

`workflow save|run` 支持本地保存可复用定义，默认试运行：

```bash
pixmax workflow save monk-shot --type image-to-video \
  -s image_prompt="a monk portrait" \
  -s video_prompt="make it move"
pixmax workflow run monk-shot --dry-run
```

支持的本地保存工作流类型：

- `image-to-video`
- `script-to-video`
- `generate-batch`
- `quick-task`
- `template-task`

这使得线上探测发现的模板和快捷任务可以先沉淀成可复用载荷工作流，再升级成专用命令。

## 能力发现

```bash
pixmax capabilities matrix --json
pixmax capabilities probe --dry-run --json
```

`doctor` 更适合安装后自检；`capabilities probe` 更适合在 token 可用后盘点 Pixmax 线上平台能力。

`capabilities probe` 是只读探测；不创建项目、不上传资产、不提交生成任务。它会读取用户信息、积分、项目、资产、任务、快捷任务、模板、分镜配置、模型配置，以及可选项目/画布信息。

如果 Pixmax 返回 `401` 或 `No login`，CLI 会把它标记为认证失败，不会把失败误判成平台能力缺失。刷新 token 后再做正式 probe。

## 线上冒烟测试

默认测试不调用 Pixmax 线上接口。需要线上冒烟测试时显式设置：

```bash
export PIXMAX_BEARER_TOKEN="..."
export PIXMAX_LIVE_PROJECT_UUID="..."
export PIXMAX_LIVE_FILE_UUID="..."
PIXMAX_LIVE_SMOKE=1 python3 -m pytest -q pixmax/tests/test_live_smoke.py
```

`PIXMAX_LIVE_GENERATE=1` 会提交真实生成任务，可能产生费用；只有明确需要时再打开。Seedance 视频 smoke 还需要 `PIXMAX_LIVE_IMAGE_NODE`。

## 安全约定

- 所有修改远端状态或可能产生费用的命令，优先使用 `--dry-run` 试运行
- 不在仓库中保存 bearer token
- `raw` 只用于尚未包装的 Pixmax `/user/api` 端点
- `group` 是 CLI 本地抽象，不伪造 Pixmax 远端 group 语义
- 对于平台刚上线的新模型，先用 `model explain` 和 `capabilities probe` 观察，再决定是否加专用命令
