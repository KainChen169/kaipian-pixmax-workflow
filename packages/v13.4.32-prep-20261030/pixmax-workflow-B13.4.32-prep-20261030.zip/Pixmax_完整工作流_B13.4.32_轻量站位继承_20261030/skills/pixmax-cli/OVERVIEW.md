# Pixmax CLI

Pixmax CLI 是 Pixmax 平台的官方命令行工具。它把 Pixmax Web 端同源使用的 `/user/api` 能力整理成稳定命令，可以直接在终端使用，也可以接入 Codex、Claude Code、Kimi Code、MiniMax Agent、Trae、通义灵码等支持终端操作的智能体，让智能体调用 Pixmax 的项目、画布、资产、模型、任务、图片生成、视频生成、脚本、分镜和复合工作流能力。

## 安装

### 一键安装（推荐）

在包目录（包含 `setup.py` 的目录）内执行：

```bash
# macOS / Linux
bash scripts/install.sh
```

```powershell
# Windows（PowerShell）
powershell -ExecutionPolicy Bypass -File scripts/install.ps1
```

脚本会检查 Python 环境（需要 3.10+）、安装稳定启动器和自包含 Runtime，并自动运行安装自检。生产安装后每次执行 `pixmax` 都会先检查静态更新源；更新失败时不会继续执行原始业务命令。托管后也支持远程一键安装：

```bash
# 中国大陆
curl -fsSL https://app.pixmax.cn/cli/install.sh | bash

# 海外
curl -fsSL https://console.pixmax.ai/cli/install.sh | bash
```

```powershell
# 中国大陆
irm https://app.pixmax.cn/cli/install.ps1 | iex

# 海外
irm https://console.pixmax.ai/cli/install.ps1 | iex
```

两个入口安装相同的 Runtime，但首包会固化各自站点的更新 manifest URL，并初始化不同的默认服务环境；升级不会覆盖用户已有选择。本地安装包可显式指定：`bash scripts/install.sh --environment global` 或 `scripts\install.ps1 -Environment global`。

### 环境与语言

服务环境和界面语言互相独立。安装来源只决定首次默认服务环境，CLI 语言按 `--locale`、`PIXMAX_LOCALE`、持久配置、系统语言的顺序选择。

```bash
pixmax --json config show
pixmax config set --environment global
pixmax config set --locale zh-CN
pixmax --environment cn --locale en --json doctor
```

大陆环境使用 `https://app.pixmax.cn/user/api`，海外环境使用 `https://console.pixmax.ai/user/api`。账号凭证、项目、文件和工作流状态按环境隔离；`--json` 的字段和枚举不随语言改变。

### 本地开发安装

```bash
PIXMAX_CLI_SOURCE_DIR="$PWD" bash scripts/install.sh
```

本地源码安装进入 `development` 通道，默认关闭云端自动更新；如果当前 Python 没有 `click`/`requests`，安装器会通过 pip 将依赖下载到临时目录并封装进 Runtime，不会写入用户环境。正式用户应使用上述托管安装入口，不要用 `pip install .` 绕过稳定启动器。

### 版本更新与恢复

```bash
pixmax --version
pixmax --json update status
pixmax update retry
pixmax update repair
```

`status` 和 `--version` 只读取本地状态；`retry` 强制重新检查，`repair` 重新下载安装签名源中的当前最新 Runtime。完整构建、签名和发布协议保存在源码仓库维护文档中，不进入发布包。

### 让智能体帮你安装

把下面这段话直接发给支持终端操作的智能体（Codex、Claude Code 等）：

```text
请帮我安装并初始化 Pixmax CLI。进入 Pixmax CLI 包目录（包含 setup.py 的目录）后，执行 bash scripts/install.sh。安装后运行 pixmax --json doctor 做本地自检，再运行 pixmax --help 确认命令可用。需要登录时运行 pixmax auth login web，我会在浏览器里完成授权。不要把我的 Pixmax token 写入源码、文档、脚本或提交记录。登录后请运行 pixmax --json doctor --online 验证线上鉴权。
```

也可以在 CLI 内随时获取这段提示词：`pixmax --json skill prompt`。

构建可分发 Skill 包（含 CLI 源码、文档和安装脚本）：

```bash
python3 -m pixmax.utils.skill_packager
# 输出共享 CLI zip 以及 dist/installers/cn、dist/installers/global
```

## 登录

### 网页登录（推荐）

```bash
pixmax auth login web
```

CLI 会打开浏览器授权页（`/bridge/passport/cli/?code=xxx`），你在网页上用 Pixmax 账号确认授权后，CLI 自动完成登录并把凭证保存到本地（`~/.pixmax-cli/session.json`）。之后所有命令免配置直接使用。

```bash
pixmax --json auth login status
pixmax --json doctor --online
```

如果不希望本地保存 token，可以加 `--no-store-token`，登录验证后自行导出环境变量。

### Token 登录

已有 bearer token 时，可以直接使用环境变量或 token 登录：

```bash
export PIXMAX_BEARER_TOKEN="..."          # macOS / Linux
# $env:PIXMAX_BEARER_TOKEN = "..."        # Windows（PowerShell）
pixmax --json doctor --online
pixmax --json auth login token --token "$PIXMAX_BEARER_TOKEN" --profile main
```

多账号切换使用 `auth profile save|list|use|delete`。

## 三分钟上手

```bash
pixmax --json doctor
pixmax auth login web
pixmax --json doctor --online
pixmax --json capabilities matrix
pixmax project use <project_uuid> --file <file_uuid>
pixmax --json canvas summary --no-prompts
pixmax --json model explain PIXDANCE_2
```

常用生成路径：

```bash
pixmax image generate "New Image" --prompt "一张写实风格人物肖像" --run
pixmax image edit "Realistic Reference" --image-node "Reference" --prompt "参考上传图片，将画面风格转换为写实风格" --run
pixmax video image-to-video "Shot 1" --image-node "Reference" --prompt "一个老和尚在念经，然后突然站起来"
pixmax workflow image-to-video "Monk Shot" --image-prompt "写实风格老和尚肖像" --video-prompt "一个老和尚在念经，然后突然站起来" --run
```

涉及远端修改、上传或可能产生费用的命令，建议先加 `--dry-run`。

## 能力总览

命令覆盖项目、画布、节点、模型、图片、视频、资产、合规、任务、脚本、分镜、工作流和本地节点组，另有 `raw` 与 `repl` 作为兜底。完整、权威的能力清单由 CLI 自身维护（`doctor` 会校验它与实际命令树一致）：

```bash
pixmax --json capabilities matrix
```

分领域的命令示例见 [Pixmax CLI 详细 README](README.md)。

## 文档入口

- [Pixmax CLI 详细 README](README.md)：完整命令手册与分领域示例
- [Pixmax CLI 封装说明](PIXMAX.md)：面向开发者的工程与接口设计说明
- CLI 热更新方案（上游工程文档，发行包未附）：启动器、签名、静态发布和恢复协议
- 生产部署说明（上游工程文档，发行包未附）：GitLab CI、首次服务器迁移、SSH 与签名密钥配置
- [Pixmax CLI Skill](SKILL.md)：智能体执行规则

## 安全约定

- 不把真实 token 写入源码、文档、脚本或提交记录
- 鉴权优先使用 `auth login web`；也支持 `PIXMAX_BEARER_TOKEN` 或命令级 `--token`
- 远端写入、上传、删除、提交生成前优先使用 `--dry-run`
- 真实线上生成测试必须显式开启 `PIXMAX_LIVE_GENERATE=1`
- `raw` 只用于临时访问尚未封装的 Pixmax `/user/api` 端点
