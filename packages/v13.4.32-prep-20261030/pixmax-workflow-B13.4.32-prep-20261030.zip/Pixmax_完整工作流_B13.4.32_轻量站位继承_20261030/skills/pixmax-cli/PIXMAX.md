# Pixmax CLI 封装说明

这是 Pixmax 的命令行封装。它不重新实现 Pixmax 的画布或生成逻辑，而是封装 Pixmax Web 端同源使用的 `/user/api` REST 接口，让用户和智能体能用稳定命令操作项目、画布、资产、模型、任务和生成工作流。

## 接入目标

- 中国大陆：`https://app.pixmax.cn`，API base 为 `https://app.pixmax.cn/user/api`
- 海外：`https://console.pixmax.ai`，API base 为 `https://console.pixmax.ai/user/api`
- 鉴权方式：`Authorization: Bearer <token>`

CLI 使用同一份部署产物。服务环境解析优先级为命令级 `--environment` / `--base-url`、`PIXMAX_ENV` / `PIXMAX_API_BASE_URL`、`~/.pixmax-cli/config.json`、兼容默认值 `cn`。locale 独立按 `--locale`、`PIXMAX_LOCALE`、持久配置、操作系统语言选择，并通过 `Accept-Language` 传给 API；机器可读 JSON schema 不做本地化。

## 命令分组

命令分组、每组覆盖的子命令和对应 `/user/api` 端点由 CLI 内置能力矩阵维护，`doctor` 会校验矩阵与实际命令树一致，因此以命令输出为准：

```bash
pixmax --json capabilities matrix
```

各命令组的使用说明和示例见 [pixmax/README.md](README.md)。本文件只描述工程设计：登录流程、安装分发、平台支持、模型校验、上传链路和工作流编排。

## 登录设计

`auth login web` 实现 Pixmax 设备码授权流程：

1. CLI 调用 `POST /auth/code`（body `{clientCode: "Pixmax CLI"}`）获取 5 分钟临时 code
2. CLI 打开浏览器授权页 `{应用 origin}/bridge/passport/cli/?code=xxx`
3. 用户在浏览器中登录 Pixmax 账号并确认授权（授权页调用 `/auth/code/info` 与 `/auth/code/confirm`）
4. CLI 轮询 `POST /auth/getToken` 获取 bearer token
5. CLI 调用 `/user/info` 验证 token，把账号摘要与 token 保存为本地 auth profile

登录后 token 默认保存在 `~/.pixmax-cli/session.json`；传 `--no-store-token` 时只验证不保存。`auth login token` 与 `auth profile save` 默认只保存账号摘要，显式传 `--store-token` 才保存 token。session 内的 token、账号 profile、项目、文件、节点组和工作流按 `cn` / `global` 分区，profile 还记录登录时的 API base，防止凭证跨站自动复用。旧版 session 固定迁移到 `cn`。

## 安装与分发

- `scripts/install.sh`：macOS / Linux 一键安装脚本。支持 `--environment cn|global`，也可由托管入口注入 `PIXMAX_INSTALL_ENV`；它按环境选择安装包域名，并安装稳定 Shell shim。
- `scripts/install.ps1`：Windows（PowerShell）对等安装器，支持 `-Environment cn|global`，安装 `pixmax.cmd` 并把可能抢先解析的旧 `pixmax.exe` 移入可恢复的 legacy 目录。
- `pixmax/update/install.py`：两个平台安装脚本共用的标准库安装实现，负责初始 Runtime、安全解压、配置初始化和离线 doctor。
- `pixmax/update/launcher.py`：每次启动的 fail-closed 更新门禁，负责 ETag、Ed25519、SHA-256、跨平台锁、staging 和原子激活。
- `scripts/build-pixmax-skill.sh`：Skill 包构建入口。打包逻辑在 `pixmax/utils/skill_packager.py` 中以纯 Python 实现（跨平台），Windows 上可直接运行 `python -m pixmax.utils.skill_packager`。生成共享的 `dist/pixmax-cli-skill.zip`，以及可分别发布到两个域名的 `dist/installers/cn/`、`dist/installers/global/`。
- `scripts/build-pixmax-release.sh`：使用仓库外 Ed25519 私钥生成完整静态发布树，包括签名 manifest、自包含 Runtime、首安装包和站点安装入口。
- 安装脚本不读取、保存或传输 bearer token。

管道执行本身拿不到原始下载 URL，因此 `app.pixmax.cn/cli/install.*` 与 `console.pixmax.ai/cli/install.*` 分别发布对应站点构建。Runtime 内容相同，首包中的 manifest URL 不同。具体目录、状态机、恢复命令、退出码和发布顺序保存在源码仓库维护文档中，不进入发布包。

## 平台支持

CLI 支持 macOS、Linux 和 Windows：

- 核心代码平台无关（pathlib、webbrowser、click）；生产安装不依赖 pip。
- macOS/Linux 使用稳定 Shell shim，Windows 使用 `pixmax.cmd`，二者都固定安装根目录与 Python 解释器。
- 本地 session 文件锁在类 Unix 使用 `fcntl`，Windows 使用 `msvcrt`，均不可用时优雅降级。
- CLI 入口强制 stdout/stderr 为 UTF-8，避免旧版 Windows 控制台（GBK）中文乱码。

## 安全约定

CLI 的推荐登录方式是 `auth login web`。不走网页登录时，使用 `PIXMAX_BEARER_TOKEN`、命令级 `--token` 或 `auth login token`。项目、文件、画布、上传、任务和生成类命令在可行处提供 `--dry-run` 试运行。默认测试使用模拟后端，不提交真实 Pixmax 任务。

安装后优先运行 `pixmax --json doctor`。该命令默认不联网，只检查 CLI、能力矩阵、session 和 token 配置；需要验证 token 时再运行 `pixmax --json doctor --online`，它只调用 `/user/info`。

线上冒烟测试由 `PIXMAX_LIVE_SMOKE=1` 显式开启，需要：

- `PIXMAX_BEARER_TOKEN`
- `PIXMAX_LIVE_PROJECT_UUID`
- `PIXMAX_LIVE_FILE_UUID`

提交真实生成任务还需要额外开启 `PIXMAX_LIVE_GENERATE=1`。Seedance 视频 smoke 还需要 `PIXMAX_LIVE_IMAGE_NODE`。

## 模型校验

提交生成前，CLI 会根据 `canvas model-config` 做本地校验：

- 模型 code 与节点类型匹配
- select/radio 参数枚举
- 文本长度
- 输入节点类型和数量
- schema 暴露的媒体宽高、时长、文件大小
- `requiredIf`、`dependsOn` 等条件参数规则
- Seedance `referModel` 对图生视频/文生视频的输入限制

`model explain <code>` 会输出智能体友好的模型说明，包括参数、条件规则、输入规则和媒体约束。

## 资产上传与合规

资产上传走 Pixmax 的真实链路：

1. `/assets/check`
2. `/assets/oss/authorize`
3. OSS PUT/POST/STS 上传
4. `/assets/oss/check`
5. 可选 `/canvas/node/batch` 创建 base node

Seedance 2.0 使用人物/人像参考素材时，先通过 `/assetLibrary/compliance/check` 做合规检测。`video image-to-video` 和复合 workflow 默认会在需要时执行该步骤。

## 工作流设计

`workflow image-to-video`：先创建并提交图片生成节点，等待 `resultAssets`，执行合规检测，然后创建连接该图片的 Seedance 视频节点并提交。

`workflow script-to-video`：读取脚本节点 rows，为每一行创建分镜图，等待分镜结果，做合规检测，再创建对应 Seedance 视频节点。

`workflow save|run`：把可复用工作流定义存在本地 session。支持：

- `image-to-video`
- `script-to-video`
- `generate-batch`
- `quick-task`
- `template-task`

## 能力发现

`capabilities probe` 是只读命令，用于把真实平台能力变成可审计矩阵。它会探测用户、积分、项目、资产、任务、快捷任务、模板、分镜配置、模型配置，以及可选项目文件树和画布。

如果探测返回 `401` 或 `No login`，CLI 会把它归类为认证失败，不把它当成平台能力缺失。应重新登录或刷新 token 后再继续能力盘点。
