# Pixmax CLI 安装说明

## 快速安装

进入这个包目录后执行：

- macOS / Linux：

```bash
bash scripts/install.sh
```

- Windows（PowerShell）：

```powershell
powershell -ExecutionPolicy Bypass -File scripts/install.ps1
```

安装脚本会检查 Python 环境（需要 3.10+）、安装稳定启动器和自包含 Runtime，并自动运行安装自检。源码 development 安装若缺少 `click`/`requests`，会把依赖下载到临时目录后封装进 Runtime，不污染用户环境。生产安装后每次执行 `pixmax` 都会先校验静态更新源；更新失败时业务命令不会执行。

本地包默认初始化中国大陆环境；海外环境安装时使用：

```bash
bash scripts/install.sh --environment global
```

PowerShell 使用 `scripts\install.ps1 -Environment global`。安装不会覆盖已有环境选择。可用 `pixmax config show` 查看环境和 locale，用 `pixmax config set --environment cn|global` 或 `pixmax config set --locale zh-CN|en` 修改。

## 登录

安装完成后登录 Pixmax（会打开浏览器完成授权）：

```bash
pixmax auth login web
```

验证登录状态：

```bash
pixmax --json doctor --online
```

也可以不走网页登录，直接使用当前 shell 的 `PIXMAX_BEARER_TOKEN` 环境变量
（PowerShell 语法：`$env:PIXMAX_BEARER_TOKEN = "<token>"`）。
不要把 Pixmax token 写入源码、文档、脚本或提交记录。

## 包内文档

- `OVERVIEW.md`：面向用户和智能体的中文总览。
- `README.md`：详细命令说明。
- `PIXMAX.md`：工程封装说明。
- `SKILL.md`：智能体 Skill 使用说明。
