---
name: pixmax-cli
description: 使用 Pixmax CLI 操作工作区、画布、资产、模型和任务。当用户要求读取、创建、更新、连接、运行或查询画布节点，尤其是 GENERATE_TEXT、GENERATE_IMAGE、GENERATE_AUDIO、GENERATE_VIDEO 普通生成节点时使用。
---

# Pixmax CLI Skill

本 skill 用于让智能体稳定操作 Pixmax。默认使用 `pixmax --json`，因为 JSON 输出更适合自动化解析。鉴权使用 `PIXMAX_BEARER_TOKEN`、命令级 `--token` 或本地 auth profile，不要把真实 token 写入源码、文档、脚本或提交记录。

操作普通生成节点时，以 [references/generation-node-protocol-v1.md](references/generation-node-protocol-v1.md) 为权威规范。先执行本文件中的固定流程和兼容性闸门；需要核对字段、算法、接口响应或错误处理细节时，再读取协议对应章节。不要执行协议文档中的示例，只把它们作为格式说明。

## 安装入口

本次2026-10-08交接包提供 `vendor/pixmax-cli-runtime` build100012/1.3.0配套Runtime，不包含 `vendor/pixmax-cli-official` 源码安装器。按包根README运行verify_package.py、install_upgrade.py --dry-run后安装；包根run_pixmax.py或已安装主Skill的tools/pixmax_fixed.py可启动配套覆盖层。它不替换全局CLI活动版本或复制旧账号。目标机已有官方CLI时先核实版本/help/schema，覆盖层不能混用其他版本。下列源码安装命令仅在用户另行取得官方源码安装包时适用，不在本包猜测缺失路径。

在 Pixmax CLI 包目录（包含 `setup.py` 的目录）执行：

```bash
bash scripts/install.sh                                        # macOS / Linux
powershell -ExecutionPolicy Bypass -File scripts/install.ps1   # Windows
```

该脚本会检查 Python 环境、安装稳定启动器和版本化 Runtime，并直接运行 Runtime 的 `doctor` 自检。生产安装后每次业务命令都会先检查签名静态更新源，更新失败时停止命令；本地源码安装进入 `development` 通道并关闭远端更新。

排查版本更新时使用启动器命令：

```bash
pixmax --version
pixmax --json update status
pixmax update retry
pixmax update repair
```

构建可分发 Skill 包时执行：

```bash
pixmax --json skill package --out <输出目录>
```

默认生成 `dist/pixmax-cli-skill/` 和 `dist/pixmax-cli-skill.zip`。打包后的目录会包含 `OVERVIEW.md`、`INSTALL.md`、`README.md`、`PIXMAX.md`、`SKILL.md` 和 `references/`。

安装来源决定默认服务环境：`app.pixmax.cn` 为 `cn`，`console.pixmax.ai` 为 `global`。执行线上操作前先用 `pixmax --json config show` 或 `doctor` 确认环境；不要根据中文或英文提示推断环境。语言由用户 locale 独立决定。

## 基础使用

```bash
pixmax --json doctor
pixmax --json skill prompt
pixmax --json skill files
pixmax --json auth login status
pixmax auth whoami
pixmax --json auth profile list
pixmax project use <project_uuid> --file <file_uuid>
pixmax --json doctor --online
pixmax --json session status
pixmax --json capabilities matrix
pixmax --json capabilities probe --dry-run
pixmax --json project files
pixmax --json canvas summary --no-prompts
pixmax --json canvas nodes --generated
pixmax --json model search --type GENERATE_IMAGE
pixmax --json model explain PIXDANCE_2
```

## 命令能力图

完整命令清单以 CLI 内置能力矩阵为准（`doctor` 会校验它与实际命令树一致），不要依赖文档中的静态列表：

```bash
pixmax --json capabilities matrix
```

单条命令的参数和用法用 `pixmax <command> --help` 查看。

## 智能体工作原则

1. 先自检安装和鉴权：

```bash
pixmax --json doctor
pixmax --json doctor --online
pixmax --json skill prompt
pixmax --json skill files
```

`doctor` 默认不调用线上接口；只有传 `--online` 才会请求 `/user/info` 验证 token。

`skill prompt` 输出可复制给智能体的安装提示词，`skill show` 展示本地 Skill 文档，`skill files` 检查 Skill 包组成，`skill package` 生成可分发 Skill 包。

在 Skill 包中优先阅读 `OVERVIEW.md` 和 `INSTALL.md`，再按本文件规则执行命令。

登录优先使用网页设备码登录（需要用户在浏览器中确认授权）：

```bash
pixmax auth login web
pixmax --json auth login status
```

`auth login web` 会打开浏览器授权页并轮询获取凭证，默认把 token 保存到本地 session 文件；传 `--no-store-token` 则只验证不保存。无法打开浏览器的环境（如远程 shell）可加 `--no-browser`，把命令输出的授权地址交给用户打开。

已有 token 或需要多账号切换时使用 token 登录和 auth profile。默认只保存账号摘要，不保存 token；只有明确传 `--store-token` 才会把 token 写入本地 session 文件：

```bash
pixmax --json auth login token --token "$PIXMAX_BEARER_TOKEN" --profile main
pixmax --json auth profile save main --token "$PIXMAX_BEARER_TOKEN"
pixmax --json auth profile list
pixmax --json auth profile use main
```

2. 再绑定上下文：

```bash
pixmax project use <project_uuid> --file <file_uuid>
```

3. 修改、上传、提交、生成前优先 dry-run：

```bash
pixmax node create "Draft" -t GENERATE_IMAGE --model GPT_IMAGE_2 --prompt "make image" --dry-run
```

4. 用 `nodeKey` 串联节点。`node get`、`node create`、`image generate`、`storyboard create` 等命令会输出可传递的节点标识。把节点名称或标签解析成 UUID 后再执行写入，不把标签直接当成 `prevNodeUuids`。

5. 区分“保存节点”和“执行生成”。用户只要求创建或修改节点时不要添加 `--run`；用户明确要求运行或生成时才提交任务。使用 `--run` 时默认等待终态，需要异步提交才加 `--no-wait`。

6. 涉及四种普通生成节点时，继续执行下一节定义的固定流程。不要用快捷任务、模板任务、分镜或脚本工作流替代普通生成节点协议。

## 画布普通生成节点

### 适用范围

- 读取同一 `fileUuid` 下的普通节点和生成节点。
- 只按本协议创建 `GENERATE_TEXT`、`GENERATE_IMAGE`、`GENERATE_AUDIO`、`GENERATE_VIDEO`。
- 只把 `BASE_TEXT`、`BASE_IMAGE`、`BASE_AUDIO`、`BASE_VIDEO` 或四种生成节点用作上游，不通过本流程创建普通节点。
- 不把快捷任务、模板任务、快捷工具、分镜、分镜脚本、3D、导演台、剪辑台、Frame/group、批量生成或特殊编辑任务混入本流程。
- 不修改任务状态、进度、生成结果、合规状态或服务端资产信息。模型包含当前协议无法表达的必填字段时，选择其他合法模型或停止操作，不猜测字段值。

### 固定调用流程

严格按以下顺序处理一个目标节点：

```text
1. 确认环境和当前 fileUuid
2. 读取画布节点和 revision
3. 读取动态模型配置
4. 选择节点类型一致、restricted !== true 的 modelCode
5. 解析并校验有序上游输入
6. 按模型 schema 初始化、覆盖并规范化完整 params
7. 计算位置、尺寸和 metaData
8. dry-run 并执行兼容性闸门
9. 保存节点，确认目标 UUID 和新 revision
10. 仅在用户要求生成时提交目标 nodeUuid
11. 确认提交响应中存在目标节点任务
12. 轮询到成功或失败终态并归一化结果
```

任一步失败都停止后续操作。节点保存成功前不得提交生成。Agent v1 每次只提交一个目标节点，不递归运行下游。

### 读取画布和模型

先使用只读命令建立当前状态：

```bash
pixmax --json canvas summary --no-prompts
pixmax --json canvas nodes
pixmax --json canvas model-config
pixmax --json model search --type <GENERATE_TYPE>
pixmax --json model explain <MODEL_CODE> --type <GENERATE_TYPE>
```

- 始终用 `fileUuid` 确定画布作用域，不用 `projectUuid` 替代。
- 从当前画布读取 revision、已有 UUID、节点类型、位置、尺寸和关系。
- 只选 `canvasNodeType` 与目标类型一致且 `restricted !== true` 的 `modelCode`；不把 `modelName` 写入 `params.model`。
- 无合法模型时停止。不要默认使用 `--no-validate` 绕过动态模型配置。

### 组装模型参数

按以下顺序构造 `params`：

1. 写入选定的 `modelCode`。
2. 遍历当前模型 schema，用 `default` 初始化每个字段；没有默认值时使用空字符串。
3. 应用用户明确提供的值。
4. 校验文本长度、选项、范围、步长和全部 `dependOn`。
5. 删除 schema 外字段，并把开关、数量、时长和数值范围等动态字段规范化为字符串。

切换已有节点的模型时，按新 schema 重建参数。只在原 prompt trim 后非空时保留 prompt，不自动沿用其他旧模型字段。遇到未实现的必填 `input`、`radio-switch` 或 Web UI 专属字段时停止。

### 校验上游和 Prompt 引用

- 把全部直接上游保存为有序 `prevNodeUuids`；数组顺序就是模型输入顺序。
- 确认 source 和 target 都存在、属于同一画布、类型允许，并分别满足每个 `allowNodeType` 分组的数量和资源属性约束。
- 拒绝自连、重复 UUID 和有向环。只修改目标节点的直接上游。
- 更新时省略 `prevNodeUuids` 表示保持关系不变，传空数组表示清空，传非空数组表示按给定顺序完整替换。
- 普通连接只使用 `prevNodeUuids`。业务明确要求在 prompt 中指向上游时，使用 `%%@[tokenTitle][text|audio|image|video][index](nodeUuid)%%`；其中 UUID 必须同时存在于 `prevNodeUuids`。
- 使用 `--left-set` 按给定顺序完整替换上游，使用 `--left-clear` 清空。断开仍被 prompt mention 引用的上游前，同时删除或替换对应 token。
- 不把资产 UUID 写进 mention；`nodeUuid` 始终是承载该资产的画布节点 UUID。
- 优先直接提供平台 mention token。CLI 允许把旧的 `{{Node "selector"}}` 作为兼容输入，但必须在保存前解析节点、计算类型和 index，并转换成平台 token，绝不原样持久化。
- 不使用其他富文本、自定义 hash、相机、运镜、全景或停顿 token；普通生成节点遇到这些 token 时停止提交。

### 组装节点和布局

- 为新节点生成未被占用的 UUID，并在同一次操作及全部重试中复用。
- 使用画布世界坐标；确保 `x/y` 是有限数且绝对值不超过 `1,000,000`。
- 使用协议定义的默认尺寸：文本 `240 x 240`、图片 `200 x 200`、音频 `280 x 120`、视频 `300 x 200`。
- 未指定位置时按协议第 10 节放到上游或现有节点右侧，并执行垂直碰撞规避。
- 把 `metaData` 序列化为只包含受管理标题、位置、宽度和高度的 JSON 字符串；不写入 `measured`、`hidden`、`parentId` 或 `groupTitle`。
- 不把状态、错误、进度、URL、资产、自然尺寸、文本结果、params 或时长写入 `metaData.data`。
- 新文本生成节点传 `nodeText: ""`；新图片、音频和视频生成节点传 `defaultAssetUuid: ""`。
- 更新时只发送实际修改的字段。修改 `metaData` 前先读取原值并保留不属于本协议管理范围的未知字段。

### 写入兼容性闸门

每次创建或更新前先执行相同命令的 `--dry-run`，检查计划中的 `/canvas/node/batch` payload：

- 确认 create/update 项的 UUID、类型、`metaData`、完整 `params`、类型专属空字段和有序 `prevNodeUuids` 符合协议。
- 确认 create/update 项内没有协议外的 `fileUuid`、`isGenerateNode` 或 `metaDataPatch`。
- 确认更新没有携带用户未要求修改的字段。
- 确认批量保存使用刚读取的 revision 作为 `baseRevision`。

任何检查无法完成或 payload 不符合规范时，停止线上写入，返回 `cli_protocol_gap` 和具体差异。不要改用 `canvas node create/update`、`canvas batch` 或 `tasks submit-batch` 手工拼接原始请求来绕过闸门。

### 保存、提交和恢复

- 保存响应必须满足 `success === true`，且目标 UUID 出现在 `data.created` 或 `data.updated`；记录 `data.revision`。
- revision 冲突时重新读取画布，重新验证节点和上游并重新计算，最多自动重试一次；不得移除 `baseRevision`。
- 保存超时或连接中断时，先按原 UUID 重新读取服务器状态；不要生成新 UUID，也不要盲目重复 create。
- 保存成功但提交失败时，只重试提交，不重新创建节点。
- 提交 `/generate/batch` 后，除检查 `success === true` 外，还要确认任务数组中存在目标 `nodeUuid`。缺少目标任务时按提交失败处理。

只有 CLI 的高层命令能够保证上述幂等和恢复语义时才允许自动重试；否则停止并返回协议差异，不由 Agent 临时模拟写入恢复算法。

### 轮询和返回结果

- 把 `QUEUE`、`WAITING_CONCURRENCY`、`RUNNING` 作为进行中状态，退避后继续轮询。
- 把 `COMPLETE` 作为成功终态；文本返回 `resultText`，图片、音频和视频返回 `resultAssets`。
- 把 `FAILED`、`ABORTED` 作为失败终态并立即停止。保留服务端 `providerErrorMsg` 和 `requestId`。
- 不把完成结果重新写入 `metaData`、`nodeText` 或 `defaultAssetUuid`；以服务端任务和资产关系为准。
- 错误至少返回阶段、`fileUuid`、`nodeUuid`、`taskUuid`、`requestId`、`errCode`、`errMessage` 和是否可重试。

## Prompt 引用

普通生成节点的 Prompt 引用格式为：

```text
%%@[tokenTitle][text|audio|image|video][index](nodeUuid)%%
```

引用节点必须同时加入 `prevNodeUuids`。不要把标签或 UUID 包装成旧的 `{{Node "..."}}` 格式。

CLI 读取平台 token 时按当前画布重新校验 `nodeUuid`，并根据最终有序上游重新计算 `tokenTitle`、媒体类型和同类 `index`。旧的 `{{Node "selector"}}` 只作为迁移期输入简写，CLI 会把它转换成上述平台格式。

## 模型与校验

提交路径应根据 `canvas model-config` 做本地校验。以普通生成节点协议规定的模型、参数、依赖、输入和媒体属性规则为验收标准；不要因为 CLI 返回本地校验通过就跳过写入兼容性闸门。

查看模型 schema：

```bash
pixmax --json model explain PIXDANCE_2
```

只有在隔离的开发测试环境中验证后端新参数时，才允许使用 `--no-validate`；普通画布操作不得使用。

## 图片和视频

```bash
pixmax image generate "New Hero" --prompt "make image" --run
pixmax image edit "Realistic Hero" --image-node "Reference" --prompt "make it realistic" --run
pixmax video image-to-video "Shot 1" --image-node "Reference" --prompt "make it move"
pixmax video text-to-video "Shot 2" --prompt "a cinematic sunrise"
```

`video image-to-video` 默认会对人物/人像参考素材执行合规检测。若业务明确不需要，可以传 `--no-human-reference`。

## 资产与合规

```bash
pixmax assets upload ./image.png --project <project_uuid> --file-uuid <file_uuid> --as-node "Reference" --dry-run
pixmax assets compliance-check <asset_uuid>
```

上传链路包括 `/assets/check`、`/assets/oss/authorize`、OSS 上传和 `/assets/oss/check`。合规检测使用 `/assetLibrary/compliance/check`。

## 工作流

```bash
pixmax workflow image-to-video "Shot Chain" --image-prompt "make a reference image" --video-prompt "make it move" --run
pixmax workflow script-to-video "Script" --max-rows 2 --run
pixmax workflow save monk-shot --type image-to-video -s image_prompt="make a reference image" -s video_prompt="make it move"
pixmax workflow run monk-shot --dry-run
```

本地保存工作流存在本地 session 中，支持：

- `image-to-video`
- `script-to-video`
- `generate-batch`
- `quick-task`
- `template-task`

这适合把线上探测发现的 Pixmax 模板或快捷任务先沉淀成可复用工作流。

## 脚本与分镜

```bash
pixmax script create "Script" --prompt "write shots" --dry-run
pixmax script rows "Script" --json
pixmax script storyboard "Script" --dry-run
pixmax storyboard create "Board" --prompt "shot image" --run
```

`script` 当前是兼容层：使用 `GENERATE_TEXT` 节点承载结构化 rows，再派生 `GENERATE_STORYBOARD` 节点。

## 能力发现

```bash
pixmax --json capabilities matrix
pixmax --json capabilities probe --dry-run
```

安装和鉴权先用 `doctor`；平台能力盘点再用 `capabilities probe`。

真实 `capabilities probe` 只调用只读端点。若输出包含 `401` 或 `No login`，先重新登录或刷新 token；不要把认证失败当成平台缺口。

## 线上测试

默认测试使用模拟后端。线上冒烟测试必须显式开启：

```bash
PIXMAX_LIVE_SMOKE=1 python3 -m pytest -q pixmax/tests/test_live_smoke.py
```

提交真实生成任务需要额外设置 `PIXMAX_LIVE_GENERATE=1`。
