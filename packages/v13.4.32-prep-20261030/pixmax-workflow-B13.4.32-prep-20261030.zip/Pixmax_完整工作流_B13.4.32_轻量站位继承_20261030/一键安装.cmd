@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0安装升级.ps1" %*
if errorlevel 1 exit /b 1
pause
